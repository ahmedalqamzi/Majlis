import SwiftUI

// Local, scalable artwork and tokens shared by the native game-night surfaces.
enum MajlisTheme {
    static let ink = Color(red: 36/255, green: 40/255, blue: 63/255)
    static let paper = Color(red: 247/255, green: 243/255, blue: 232/255)
    static let blue = Color(red: 64/255, green: 85/255, blue: 216/255)
    static let yellow = Color(red: 255/255, green: 211/255, blue: 99/255)
    static let coral = Color(red: 240/255, green: 120/255, blue: 96/255)
    static let mint = Color(red: 184/255, green: 221/255, blue: 208/255)
}

struct MajlisGame: Identifiable {
    let id: String
    let title: String
    let subtitle: String
    let symbol: String
    let color: Color

    static let all: [MajlisGame] = [
        .init(id: "who_am_i", title: "Who Am I?", subtitle: "Big questions. Wild guesses.", symbol: "questionmark", color: MajlisTheme.yellow),
        .init(id: "feud", title: "Majlis Feud", subtitle: "Beat them to the buzzer.", symbol: "bell.fill", color: MajlisTheme.coral),
        .init(id: "impostor", title: "Impostor", subtitle: "Someone is bluffing.", symbol: "eye.fill", color: MajlisTheme.mint),
        .init(id: "taboo", title: "Taboo", subtitle: "Say it without saying it.", symbol: "bubble.left.and.bubble.right.fill", color: Color(red: 196/255, green: 183/255, blue: 235/255)),
        .init(id: "bluff", title: "Bluff", subtitle: "Make your lie the favourite.", symbol: "quote.bubble.fill", color: Color(red: 159/255, green: 197/255, blue: 237/255)),
        .init(id: "escape_room", title: "Escape Room", subtitle: "One team. One way out.", symbol: "key.fill", color: Color(red: 233/255, green: 190/255, blue: 150/255))
    ]
    static func named(_ id: String) -> MajlisGame? { all.first { $0.id == id } }
}

struct MajlisWordmark: View {
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 8) {
            Text("majlis.").font(.system(.title, design: .rounded).weight(.black)).tracking(-1)
            Text("مجلس").font(.title3.weight(.bold)).accessibilityHidden(true)
        }
        .foregroundStyle(MajlisTheme.ink)
        .accessibilityLabel("Majlis")
    }
}

struct MajlisGameArt: View {
    let game: MajlisGame
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15).fill(MajlisTheme.ink.opacity(0.12))
                .frame(width: 64, height: 72).rotationEffect(.degrees(-16)).offset(x: -14, y: 5)
            RoundedRectangle(cornerRadius: 15).fill(MajlisTheme.paper)
                .overlay(RoundedRectangle(cornerRadius: 15).stroke(MajlisTheme.ink, lineWidth: 2.5))
                .frame(width: 64, height: 72).rotationEffect(.degrees(10)).offset(x: 12)
            Image(systemName: game.symbol).font(.system(size: 32, weight: .black))
                .foregroundStyle(MajlisTheme.ink).rotationEffect(.degrees(10)).offset(x: 12)
            Image(systemName: "sparkle").font(.system(size: 19, weight: .bold))
                .offset(x: -41, y: -25)
            Circle().fill(MajlisTheme.ink).frame(width: 7, height: 7).offset(x: 43, y: 31)
        }
        .foregroundStyle(MajlisTheme.ink)
        .frame(height: 96).frame(maxWidth: .infinity)
        .accessibilityHidden(true)
    }
}

struct MajlisGameTile: View {
    let game: MajlisGame
    var selected = false
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            MajlisGameArt(game: game)
            HStack(alignment: .top, spacing: 4) {
                Text(game.title).font(.system(.title3, design: .rounded).weight(.heavy))
                    .fixedSize(horizontal: false, vertical: true)
                Spacer(minLength: 0)
                if selected { Image(systemName: "checkmark.circle.fill").font(.title3) }
            }
            Text(game.subtitle).font(.footnote.weight(.medium))
                .fixedSize(horizontal: false, vertical: true)
        }
        .foregroundStyle(MajlisTheme.ink)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
        .padding(14).background(game.color, in: RoundedRectangle(cornerRadius: 22))
        .overlay(RoundedRectangle(cornerRadius: 22).stroke(MajlisTheme.ink, lineWidth: selected ? 3 : 1.5))
        .accessibilityElement(children: .combine)
    }
}

struct MajlisButtonStyle: ButtonStyle {
    @Environment(\.isEnabled) private var enabled
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.system(.headline, design: .rounded).weight(.bold))
            .frame(maxWidth: .infinity).padding(.horizontal, 18).padding(.vertical, 17)
            .foregroundStyle(configuration.role == .destructive ? Color(red: 0.65, green: 0.16, blue: 0.12) : MajlisTheme.ink)
            .background(configuration.role == .destructive ? MajlisTheme.paper : MajlisTheme.yellow,
                        in: RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(MajlisTheme.ink.opacity(configuration.role == .destructive ? 0.22 : 1), lineWidth: 1.5))
            .opacity(enabled ? (configuration.isPressed ? 0.76 : 1) : 0.45)
            .scaleEffect(configuration.isPressed ? 0.98 : 1)
    }
}
