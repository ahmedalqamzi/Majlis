// Majlis Party: the ten required modes. `playable` is true only once a complete, server-backed
// loop exists in this build. Everything else is shown as "Not playable yet" and cannot be chosen.
export const MODES = [
  { id: 'who_am_i', title: 'Who Am I?', ar: 'من أنا؟', blurb: 'Everyone sees your character except you. Ask yes/no questions.', playable: true },
  { id: 'feud', title: 'Majlis Feud', ar: 'تحدي المجلس', blurb: 'Buzz in and find the house answers on the board.', playable: true },
  { id: 'impostor', title: 'Impostor', ar: 'الدخيل', blurb: 'Everyone gets the same word except the impostor. Discuss, vote, catch them.', playable: true },
  { id: 'draw_guess', title: 'Draw & Guess', ar: 'ارسم وخمّن', playable: false },
  { id: 'drawing_chain', title: 'Drawing Chain', ar: 'سلسلة الرسم', playable: false },
  { id: 'bluff', title: 'Bluff', ar: 'الخداع', blurb: 'Write a fake answer, vote for the real one, and try to fool everyone else.', playable: true },
  { id: 'werewolf', title: 'Werewolf', ar: 'المستذئب', playable: false },
  { id: 'taboo', title: 'Taboo', ar: 'الممنوع', blurb: 'Give clues for your word without saying the forbidden terms.', playable: true },
  { id: 'wavelength', title: 'Wavelength-style', ar: 'نفس الموجة', playable: false },
  { id: 'escape_room', title: 'Escape Room', ar: 'غرفة الهروب', blurb: 'Share your clue, solve three puzzles together before time runs out.', playable: false },
];

export function modeInfo(id) {
  return MODES.find(m => m.id === id) || { id, title: id || 'No game chosen', playable: false };
}

// Public, static "how to play" steps for the phone's own disclosure (see rulesPanel() in
// views.js). Derived from the engines' actual reduce()/project() behavior in
// party/core/majlis-core.js (WhoAmI, Feud, Impostor, Taboo) and the existing player-facing copy
// in play.js's guess-help text -- never invented score values, automatic-judging claims, or
// private data.
export const RULES = {
  who_am_i: {
    title: 'How to play Who Am I',
    steps: [
      'Everyone else can see your character — only you can’t.',
      'Ask the group yes/no questions out loud to work out who you are.',
      'Type your guess and send it — only the host sees the text; it is not graded automatically.',
      'Tap “I’m ready” to show the host (and the group) you want to answer; it sends no guess.',
      'The host reveals your character when you solve it or when the round ends.',
    ],
  },
  feud: {
    title: 'How to play Majlis Feud',
    steps: [
      'Answers are the host’s own list for this question — not real survey results.',
      'When the buzzer opens, tap BUZZ as fast as you can.',
      'Whoever buzzes first answers out loud; the host decides if it’s a match.',
      'Three wrong answers (strikes) can let the host offer a steal to the other side.',
      'The host reveals board answers, points and strikes as the round plays out.',
    ],
  },
  impostor: {
    title: 'How to play Impostor',
    steps: [
      'Everyone except the impostor gets the same secret word on their phone; the impostor does not.',
      'Discuss out loud and try to work out who is missing the word — or, if you’re the impostor, blend in.',
      'When the host opens voting, tap a player’s name on your phone to vote for who you think the impostor is.',
      'If the group votes out the actual impostor, they get one phone guess at the word before the round ends.',
      'The host reveals the impostor, the word, and how the round ended.',
    ],
  },
  taboo: {
    title: 'How to play Taboo',
    steps: [
      'Teams take turns: one player is the clue giver, the rest of their team guesses out loud.',
      'The clue giver sees a secret word and its forbidden terms on their phone, and gives spoken clues without saying any of them.',
      'Guessing teammates can also type a guess on their phone; a correct word moves play on to the next card.',
      'The host listens in and adjudicates each card — awarding it, calling a forbidden-word violation, or skipping it.',
      'Each turn runs on a shared timer; the host starts the next team’s turn once it ends.',
    ],
  },
  bluff: {
    title: 'How to play Bluff',
    steps: [
      'Everyone sees the same question and writes their own convincing fake answer on their phone.',
      'No other player can see what you wrote while answers are coming in — the host’s own screen may show submissions differently.',
      'When voting opens, tap the answer you think is the real one; you can’t vote for your own fake.',
      'Pick the real answer and you score; vote for someone else’s fake instead and its author scores from your vote.',
      'The reveal then shows the real answer plus who wrote and voted for every option — nothing stays hidden after that point.',
    ],
  },
};
