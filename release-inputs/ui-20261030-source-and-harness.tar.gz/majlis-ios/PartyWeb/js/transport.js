// Majlis Party: HTTP + fetch-SSE client for the protocol v1 room server (party/CONTRACT.md).
// The server is authoritative. This file never decides game outcomes; it only sends actions and
// relays role-projected snapshots. Capability tokens travel only in the Authorization header.

export class ApiError extends Error {
  constructor(code, status = 0, detail = '') {
    super(code);
    this.code = code;       // stable machine code from the server, or a client-side code below
    this.status = status;
    this.detail = detail;
  }
}

// Client-side codes: network_error, bad_response, aborted, request_timeout.
const DEFAULT_REQUEST_TIMEOUT_MS = 10000;

function validTimeout(ms) {
  return typeof ms === 'number' && Number.isFinite(ms) && ms > 0;
}

// Resolves once `ms` elapses or `signal` aborts, whichever comes first; rejects with
// ApiError('aborted') in the latter case so a cancelled act() retry backoff stops at once instead
// of sleeping out the full delay.
function cancellableDelay(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal && signal.aborted) { reject(new ApiError('aborted')); return; }
    const onAbort = () => { clearTimeout(timer); if (signal) signal.removeEventListener('abort', onAbort); reject(new ApiError('aborted')); };
    const timer = setTimeout(() => { if (signal) signal.removeEventListener('abort', onAbort); resolve(); }, ms);
    if (signal) signal.addEventListener('abort', onAbort);
  });
}

function newActionId() {
  if (globalThis.crypto && crypto.randomUUID) return crypto.randomUUID();
  const b = new Uint8Array(16);
  crypto.getRandomValues(b);
  return Array.from(b, x => x.toString(16).padStart(2, '0')).join('');
}

export { newActionId };

async function readJson(res) {
  const text = await res.text();
  if (!text) return {};
  try { return JSON.parse(text); } catch { throw new ApiError('bad_response', res.status); }
}

function errorCodeFrom(body, status) {
  if (body && typeof body.error === 'string') return body.error;
  if (body && body.error && typeof body.error.code === 'string') return body.error.code;
  if (status === 401) return 'unauthorized';
  if (status === 403) return 'forbidden';
  if (status === 404) return 'not_found';
  if (status === 429) return 'rate_limited';
  return 'http_' + status;
}

// Parses a text/event-stream byte stream. Calls onEvent({id, event, data}) per dispatched event.
export class SseParser {
  constructor(onEvent) {
    this.onEvent = onEvent;
    this.buf = '';
    this.reset();
  }
  reset() { this.id = null; this.event = ''; this.data = []; }
  push(chunk) {
    this.buf += chunk;
    let idx;
    while ((idx = this.buf.search(/\r\n|\r|\n/)) >= 0) {
      const line = this.buf.slice(0, idx);
      const nl = this.buf[idx] === '\r' && this.buf[idx + 1] === '\n' ? 2 : 1;
      // A lone trailing \r may be the first half of \r\n; wait for more input.
      if (this.buf[idx] === '\r' && idx + 1 === this.buf.length) break;
      this.buf = this.buf.slice(idx + nl);
      this.line(line);
    }
  }
  line(line) {
    if (line === '') {
      if (this.data.length) this.onEvent({ id: this.id, event: this.event || 'message', data: this.data.join('\n') });
      this.event = ''; this.data = [];
      return;
    }
    if (line[0] === ':') return; // heartbeat comment
    const c = line.indexOf(':');
    const field = c < 0 ? line : line.slice(0, c);
    let value = c < 0 ? '' : line.slice(c + 1);
    if (value[0] === ' ') value = value.slice(1);
    if (field === 'data') this.data.push(value);
    else if (field === 'event') this.event = value;
    else if (field === 'id' && !value.includes('\0')) this.id = value;
  }
}

export class HttpTransport {
  constructor({ base = '', fetchImpl, requestTimeoutMs = DEFAULT_REQUEST_TIMEOUT_MS } = {}) {
    if (!validTimeout(requestTimeoutMs)) throw new ApiError('invalid_options');
    this.base = base;
    this.kind = 'network';
    this.fetch = fetchImpl || ((...a) => fetch(...a));
    this.requestTimeoutMs = requestTimeoutMs;
  }

  // Raw single attempt: no deadline of its own, aborts with `signal` only. Kept separate from
  // request() so the deadline race below can hold a reference to this exact work promise and
  // swallow (never propagate) whatever it eventually settles with once the race is already over.
  // `bodyText`, when given, is the exact wire body to send (see act() below, which freezes it
  // once per call so a caller mutating its payload object between automatic retries can never
  // change what a later attempt actually sends over the same actionId).
  async _attempt(method, path, token, body, signal, bodyText, deadlineCtx) {
    const headers = { Accept: 'application/json' };
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (token) headers.Authorization = 'Bearer ' + token;
    let res;
    try {
      res = await this.fetch(this.base + path, {
        method, headers, signal, credentials: 'same-origin', cache: 'no-store',
        body: body === undefined ? undefined : (bodyText !== undefined ? bodyText : JSON.stringify(body)),
      });
    } catch (e) {
      if (e && e.name === 'AbortError') throw new ApiError('aborted');
      throw new ApiError('network_error');
    }
    // A non-OK response is already a known server rejection the instant headers/status arrive,
    // independent of whether its body can still be read. Record that provisional ApiError now,
    // before ever touching the body, in `deadlineCtx` (shared with request() below) so a deadline
    // race that later times out this same attempt can still return the known rejection instead of
    // degrading to a generic request_timeout if the body then stalls forever.
    if (!res.ok && deadlineCtx) deadlineCtx.rejection = new ApiError(errorCodeFrom(null, res.status), res.status);
    // A broken response body (e.g. the connection drops mid-stream) rejects res.text() with
    // whatever error the fetch implementation throws, not necessarily an ApiError. A response that
    // already carried a known HTTP rejection keeps that status/code regardless of the body error;
    // only an otherwise-successful or unclassified response degrades to the generic retryable
    // 'network_error' code request()/act() already classify and retry. A deliberate protocol error
    // (malformed JSON) is already thrown by readJson() as ApiError('bad_response') and passes
    // through unchanged.
    let json;
    try {
      json = await readJson(res);
    } catch (e) {
      if (!res.ok) throw deadlineCtx ? deadlineCtx.rejection : new ApiError(errorCodeFrom(null, res.status), res.status);
      if (e instanceof ApiError) throw e;
      throw new ApiError('network_error');
    }
    if (!res.ok) throw new ApiError(errorCodeFrom(json, res.status), res.status);
    return json;
  }

  // Ordinary (non-subscribe) request: bounded by a finite deadline covering both response
  // headers and full JSON body consumption. The deadline always settles this promise, even if
  // `this.fetch` (or its Response.text()) ignores the abort signal it was given — a scripted or
  // misbehaving fetchImpl in a test must never be able to hang the caller forever. A caller
  // `signal` is distinguished from the deadline: aborting it rejects with ApiError('aborted'),
  // never 'request_timeout', and stops immediately rather than waiting out the deadline.
  async request(method, path, { token, body, bodyText, signal, timeoutMs } = {}) {
    const effective = timeoutMs === undefined ? this.requestTimeoutMs : timeoutMs;
    if (!validTimeout(effective)) throw new ApiError('invalid_options');
    if (signal && signal.aborted) throw new ApiError('aborted');

    const inner = new AbortController();
    let timedOut = false, callerAborted = false, rejectGuard;
    const guard = new Promise((_, reject) => { rejectGuard = reject; });
    // Shared with _attempt(): filled in with the known-rejection ApiError the instant a non-OK
    // response's headers/status arrive, so a timeout below can still preserve that status even
    // if the body never finishes (see _attempt() for why).
    const deadlineCtx = { rejection: null };
    const settleGuard = (isTimeout) => {
      if (timedOut || callerAborted) return;
      if (isTimeout) timedOut = true; else callerAborted = true;
      inner.abort();
      rejectGuard(new ApiError(isTimeout ? 'request_timeout' : 'aborted'));
    };
    const onCallerAbort = () => settleGuard(false);
    if (signal) signal.addEventListener('abort', onCallerAbort);
    const timer = setTimeout(() => settleGuard(true), effective);
    const cleanup = () => {
      clearTimeout(timer);
      if (signal) signal.removeEventListener('abort', onCallerAbort);
    };

    const work = this._attempt(method, path, token, body, inner.signal, bodyText, deadlineCtx);
    try {
      const result = await Promise.race([work, guard]);
      cleanup();
      return result;
    } catch (e) {
      cleanup();
      if (timedOut) throw (deadlineCtx.rejection || new ApiError('request_timeout'));
      if (callerAborted) throw new ApiError('aborted');
      throw e;
    } finally {
      // If `guard` won the race, `work` is still running (or about to settle) with nothing left
      // to observe its result: swallow a late rejection so it never surfaces as an unhandled one.
      work.catch(() => {});
    }
  }

  health() { return this.request('GET', '/api/health'); }
  createRoom(operatorName) {
    return this.request('POST', '/api/rooms', { body: operatorName ? { operatorName } : {} });
  }
  join(code, name) {
    return this.request('POST', `/api/rooms/${encodeURIComponent(code)}/join`, { body: { name } });
  }
  state(code, token) {
    return this.request('GET', `/api/rooms/${encodeURIComponent(code)}/state`, { token });
  }

  // Sends one action. Network failures and deadline timeouts are retried with the SAME
  // actionId, so the server's idempotency makes the retry safe and the result exactly-once; a
  // server rejection is returned, never retried. Explicit caller cancellation (`signal`) stops
  // immediately: no further attempt, no backoff wait, and it is thrown, not returned, since it
  // is not a server decision. `attempts` and `timeoutMs` are rejected up front if malformed,
  // rather than silently permitting an endless retry loop.
  async act(code, token, type, payload = {}, roundId, { attempts = 3, timeoutMs, signal } = {}) {
    if (!(Number.isInteger(attempts) && attempts >= 1 && attempts <= 10)) throw new ApiError('invalid_options');
    if (signal && signal.aborted) throw new ApiError('aborted');
    const body = { actionId: newActionId(), type, payload };
    if (roundId !== undefined && roundId !== null) body.roundId = roundId;
    // Freeze the exact wire body now, synchronously, before any attempt/backoff ever yields: the
    // caller is free to keep mutating its own `payload` object afterward (e.g. a draft the
    // player keeps typing into) without a later automatic retry ever sending anything other
    // than this exact serialized body under the same actionId.
    const bodyText = JSON.stringify(body);
    let last;
    for (let i = 0; i < attempts; i++) {
      try {
        const r = await this.request('POST', `/api/rooms/${encodeURIComponent(code)}/actions`, { token, body, bodyText, signal, timeoutMs });
        // Normalise {error:{code,message}} to the bare stable code the pages switch on.
        if (r && r.accepted === false) return { accepted: false, error: errorCodeFrom(r, 409), revision: r.revision };
        return r;
      } catch (e) {
        if (e.code === 'aborted') throw e;
        last = e;
        // A completed HTTP response is a server decision, never a transport failure, even if its
        // body happens to carry a client-shaped code like 'network_error' -- `status` is only
        // ever set by _attempt() once a response (4xx/5xx) was actually received, so its presence
        // alone is what must gate retry eligibility, not the error-code name. A pure client-side
        // transport failure never carries a status.
        if (e.status || (e.code !== 'network_error' && e.code !== 'request_timeout')) {
          return { accepted: false, error: e.code, status: e.status };
        }
        if (i < attempts - 1) await cancellableDelay(300 * (i + 1), signal);
      }
    }
    throw last;
  }

  // Opens the role-projected event stream with fetch so the token stays in a header.
  // Reconnects with capped backoff. Returns {close()}.
  subscribe(code, token, { onSnapshot, onStatus }) {
    let closed = false, lastId = null, ctrl = null, delay = 500, timer = null, watchdog = null;
    const status = (s, extra) => onStatus && onStatus(s, extra);
    // The server writes a heartbeat comment every 15 s. A stream that stays silent for longer than
    // SILENCE_MS is treated as dropped (a phone that lost Wi-Fi can leave a socket open but dead).
    const SILENCE_MS = 40000;
    const feed = () => { clearTimeout(watchdog); watchdog = setTimeout(() => { if (ctrl) ctrl.abort(); }, SILENCE_MS); };
    // Codes after which reconnecting can never succeed: the page is told once and the stream stops.
    const fatal = new Set(['unauthorized', 'token_expired', 'forbidden', 'not_found', 'room_not_found', 'room_closed', 'room_expired', 'invalid_token']);
    let streamError = null;
    const run = async () => {
      if (closed) return;
      ctrl = new AbortController();
      status(lastId === null ? 'connecting' : 'reconnecting');
      const headers = { Accept: 'text/event-stream', Authorization: 'Bearer ' + token };
      if (lastId !== null) headers['Last-Event-ID'] = lastId;
      try {
        const res = await this.fetch(`${this.base}/api/rooms/${encodeURIComponent(code)}/events`, {
          headers, signal: ctrl.signal, cache: 'no-store', credentials: 'same-origin',
        });
        if (!res.ok) {
          const json = await readJson(res).catch(() => ({}));
          const codeStr = errorCodeFrom(json, res.status);
          if (fatal.has(codeStr) || res.status === 401 || res.status === 403 || res.status === 404) {
            closed = true;
            status('fatal', new ApiError(codeStr, res.status));
            return;
          }
          throw new ApiError(codeStr, res.status);
        }
        if (!res.body || !res.body.getReader) throw new ApiError('streaming_unsupported');
        const reader = res.body.getReader();
        const dec = new TextDecoder();
        feed();
        const parser = new SseParser(ev => {
          if (ev.id !== null) lastId = ev.id;
          // The server ends a stream with `event: error` {"ok":false,"error":{"code"}} on room or
          // token expiry; it then closes the connection.
          if (ev.event === 'error') {
            let body = null;
            try { body = JSON.parse(ev.data); } catch { /* unreadable */ }
            streamError = errorCodeFrom(body, 0);
            return;
          }
          if (ev.event !== 'state') return;
          let snap;
          try { snap = JSON.parse(ev.data); } catch { return; }
          delay = 500;
          status('live');
          onSnapshot(snap);
        });
        for (;;) {
          const { value, done } = await reader.read();
          if (done) break;
          feed();
          parser.push(dec.decode(value, { stream: true }));
        }
        throw new ApiError(streamError || 'stream_ended');
      } catch (e) {
        clearTimeout(watchdog);
        if (closed) return;
        if (e && fatal.has(e.code)) {
          closed = true;
          status('fatal', e);
          return;
        }
        status('reconnecting', e);
        timer = setTimeout(() => { timer = null; run(); }, delay + Math.floor(Math.random() * 250));
        delay = Math.min(delay * 2, 8000);
      }
    };
    // Reconnect now: skips a pending backoff wait, or drops a stalled stream (e.g. after the tab wakes).
    const kick = () => {
      if (closed) return;
      if (timer) { clearTimeout(timer); timer = null; delay = 500; run(); }
      else if (ctrl) ctrl.abort();
    };
    // The browser's own network signal: drop the stream at once when it goes offline (so the page
    // says "Reconnecting" instead of looking live), and retry immediately when it comes back.
    const onOffline = () => { if (!closed && ctrl) ctrl.abort(); };
    const onOnline = () => kick();
    if (typeof addEventListener === 'function') { addEventListener('offline', onOffline); addEventListener('online', onOnline); }
    run();
    return {
      close() {
        closed = true; clearTimeout(timer); clearTimeout(watchdog); if (ctrl) ctrl.abort();
        if (typeof removeEventListener === 'function') { removeEventListener('offline', onOffline); removeEventListener('online', onOnline); }
      },
      kick,
    };
  }
}
