// Majlis Party: per-role, per-room resume credentials.
// Tokens are stored only in this device's localStorage, keyed by role and room code, and are
// never written to URLs, QR codes, the DOM or logs. A device can hold one credential per role
// per room; the operator token is never readable by the player or display pages' code paths.
//
// Persistence is best-effort. A denied/throwing storage getter, a quota error on write, a read
// that throws or a removal that silently fails must never stop a seat from working on this open
// document: every credential lives in an in-memory cache first (set on save, before persistence
// is attempted), and that cache is always consulted before any storage read. A credential whose
// storage write failed is marked `persisted: false` so callers can show a temporary-session
// notice; it still works for the rest of this document's life exactly like a persisted one.
// Clearing a credential tombstones its memory entry so a storage removal that silently failed
// can never resurrect it within this document.

const PREFIX = 'majlisParty.v1';
const MAX_AGE_MS = 12 * 60 * 60 * 1000;
// Small allowance for legitimate clock skew between when a record was written and read back.
// A savedAt further in the future than this is treated as malformed, not as "not yet expired".
const CLOCK_SKEW_MS = 5 * 60 * 1000;
const ROLES = new Set(['operator', 'player', 'display']);

// In-memory fallback: every key this document has touched this page-load, keyed by the exact
// same string as the storage key. A tombstone (CLEARED) means "do not resurrect from storage".
const CLEARED = Symbol('cleared');
const memory = new Map();
const memoryLastRoom = new Map(); // `${sim}.${role}` -> code | CLEARED

// Room identity is normalised once, here, so save/load/clear and the last-room pointer all key
// off the exact same string no matter what case/punctuation a caller passed in: a denied-storage
// save under one casing must still be found by a load under another, and a clear under one
// casing must tombstone the record a save wrote under another.
function key(role, code, sim) {
  if (!ROLES.has(role)) throw new Error('bad_role');
  return `${PREFIX}.${sim ? 'sim.' : ''}${role}.${normalizeCode(code)}`;
}

function lastKeyFor(role, sim) {
  return `${PREFIX}.${sim ? 'sim.' : ''}last.${role}`;
}

function lastRoomMemKey(role, sim) {
  return `${sim ? 'sim.' : ''}${role}`;
}

function store() {
  try { return window.localStorage; } catch { return null; }
}

// Shape/expiry validation shared by memory and storage reads. A malformed record (wrong types,
// a non-finite savedAt, or a savedAt further in the future than clock skew allows) is rejected
// outright rather than accidentally treated as fresh.
function isValidShape(rec) {
  return !!rec && typeof rec === 'object' && typeof rec.token === 'string' && rec.token.length > 0
    && typeof rec.savedAt === 'number' && Number.isFinite(rec.savedAt)
    && rec.savedAt <= Date.now() + CLOCK_SKEW_MS;
}

function isExpired(rec) {
  return Date.now() - rec.savedAt > MAX_AGE_MS;
}

export function saveCredential(role, code, cred, sim = false) {
  const k = key(role, code, sim);
  const rec = { token: cred.token, savedAt: Date.now(), persisted: false };
  if (role === 'player') { rec.playerId = cred.playerId; rec.name = cred.name; }
  // The live seat is usable from this instant, regardless of what storage does below.
  memory.set(k, rec);
  memoryLastRoom.set(lastRoomMemKey(role, sim), code);
  const s = store();
  if (!s) return false;
  try {
    const { persisted, ...toWrite } = rec;
    s.setItem(k, JSON.stringify(toWrite));
  } catch {
    return false;
  }
  rec.persisted = true;
  // Best-effort convenience pointer for "last room"; its failure does not affect the seat itself.
  try { s.setItem(lastKeyFor(role, sim), code); } catch { /* ignored: seat credential above still holds */ }
  return true;
}

export function loadCredential(role, code, sim = false) {
  if (!code) return null;
  const k = key(role, code, sim);
  if (memory.has(k)) {
    const rec = memory.get(k);
    if (rec === CLEARED) return null;
    if (!isValidShape(rec)) { memory.set(k, CLEARED); return null; }
    if (isExpired(rec)) { clearCredential(role, code, sim); return null; }
    return rec;
  }
  const s = store();
  if (!s) return null;
  let raw;
  try { raw = s.getItem(k); } catch { return null; }
  if (raw == null) return null;
  let parsed;
  try { parsed = JSON.parse(raw); } catch { return null; }
  if (!isValidShape(parsed)) return null;
  if (isExpired(parsed)) { clearCredential(role, code, sim); return null; }
  const rec = { ...parsed, persisted: true };
  memory.set(k, rec);
  return rec;
}

export function clearCredential(role, code, sim = false) {
  const k = key(role, code, sim);
  // Tombstone first: even if every storage call below throws, this document never resurrects
  // this seat from stale storage again.
  memory.set(k, CLEARED);
  const lastMemK = lastRoomMemKey(role, sim);
  if (memoryLastRoom.get(lastMemK) === code) memoryLastRoom.set(lastMemK, CLEARED);
  const s = store();
  if (!s) return;
  try { s.removeItem(k); } catch { /* tombstoned above; storage may still hold a stale copy */ }
  try {
    const lastKey = lastKeyFor(role, sim);
    if (s.getItem(lastKey) === code) s.removeItem(lastKey);
  } catch { /* ignored: memory tombstone already prevents resurrection this document */ }
}

export function lastRoom(role, sim = false) {
  const memK = lastRoomMemKey(role, sim);
  if (memoryLastRoom.has(memK)) {
    const code = memoryLastRoom.get(memK);
    return code !== CLEARED && loadCredential(role, code, sim) ? code : null;
  }
  const s = store();
  if (!s) return null;
  let code;
  try { code = s.getItem(lastKeyFor(role, sim)); } catch { return null; }
  return code && loadCredential(role, code, sim) ? code : null;
}

// Room codes: six characters, normalised to upper case, ambiguous characters left to the server.
export function normalizeCode(raw) {
  return String(raw || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);
}

export function isCodeShape(code) {
  return /^[A-Z0-9]{6}$/.test(code);
}
