// Majlis Party: view pieces shared by operator, player and TV. Pure render from a role-projected
// snapshot; no view ever derives hidden information or decides a winner locally.
import { h, sortedScores, playerName, joinUrl } from './ui.js';
import { encodeText, toSvg } from './qr.js';
import { modeInfo, RULES } from './modes.js';

export function qrBlock(code, { size = 'md' } = {}) {
  const url = joinUrl(code);
  const holder = h('div', { class: 'qr qr-' + size, 'data-join-url': url });
  // Our own encoder output; the SVG contains only path data, no external or user markup.
  holder.innerHTML = toSvg(encodeText(url, 'M'), { title: 'QR code to join room ' + code });
  return holder;
}

export function codeBlock(code, { label = 'Room code' } = {}) {
  return h('div', { class: 'code-block' },
    h('div', { class: 'eyebrow', text: label }),
    h('div', { class: 'room-code', 'aria-label': 'Room code ' + code.split('').join(' '), text: code }));
}

export function playerChips(snap, { showScores = false, highlight } = {}) {
  const players = snap.players || [];
  if (!players.length) return h('p', { class: 'muted', text: 'No players yet. Share the code or QR.' });
  return h('ul', { class: 'chips', 'aria-label': 'Players' },
    players.map(p => h('li', { class: 'chip' + (p.connected ? '' : ' offline') + (highlight === p.id ? ' hl' : '') },
      h('span', { class: 'dot', 'aria-hidden': 'true' }),
      h('span', { class: 'chip-name', dir: 'auto', text: p.name }),
      showScores ? h('span', { class: 'chip-score', text: String(p.score) }) : null,
      p.connected ? null : h('span', { class: 'sr-only', text: '(disconnected)' }))));
}

// Competitive per-player modes whose final-score card may name a winner; cooperative Escape
// Room and team-based Taboo (teamScoreboard) are deliberately excluded.
const COMPETITIVE_MODES = new Set(['who_am_i', 'feud', 'impostor', 'bluff']);

// Standard competition ranking (1,1,3 / 1,2,2,4): equal scores share the lower rank, and the
// next distinct score resumes at its 1-based position rather than incrementing past the tie.
// `scores` must already be sorted descending (sortedScores()).
export function competitionRanks(scores) {
  const ranks = [];
  for (let i = 0; i < scores.length; i++) ranks.push(i > 0 && scores[i] === scores[i - 1] ? ranks[i - 1] : i + 1);
  return ranks;
}

function pointsWord(n) { return Math.abs(n) === 1 ? 'point' : 'points'; }

// Only on an ended, supported competitive room with real scores for every row — never guesses a
// winner from an empty roster or score data the projection never sent.
function winnerLine(snap, rows) {
  if (snap.phase !== 'ended' || !COMPETITIVE_MODES.has(snap.mode) || !rows.length) return null;
  if (!rows.every(p => Number.isFinite(p.score))) return null;
  const top = rows[0].score;
  const winners = rows.filter(p => p.score === top);
  const names = winners.map((p, i) => [i > 0 ? ', ' : '', h('span', { dir: 'auto', text: p.name })]);
  return h('p', { class: 'score-winner', role: 'status' }, names,
    (winners.length > 1 ? ' tie for first with ' : ' wins with ') + top + ' ' + pointsWord(top) + '!');
}

export function scoreboard(snap, { title = 'Scores', selfId } = {}) {
  const rows = sortedScores(snap);
  const ranks = competitionRanks(rows.map(p => p.score));
  const rankTally = new Map();
  for (const r of ranks) rankTally.set(r, (rankTally.get(r) || 0) + 1);
  return h('section', { class: 'card scores', 'aria-label': title },
    h('h2', { class: 'card-title', text: title }),
    winnerLine(snap, rows),
    // A plain <ul>, not <ol>: ranks can tie, so the list's own ordinal position (what a screen
    // reader announces as "item N of M") no longer matches the shared rank shown in the row.
    h('ul', { class: 'score-list' },
      rows.map((p, i) => {
        const rank = ranks[i];
        const tied = rankTally.get(rank) > 1;
        const self = p.id === selfId;
        const label = 'Rank ' + rank + (tied ? ' tied' : '') + ', ' + p.name + (self ? ', you' : '')
          + ', ' + p.score + ' ' + pointsWord(p.score) + (p.connected ? '' : ', disconnected');
        return h('li', { class: 'score-row' + (self ? ' me' : '') + (p.connected ? '' : ' offline'), 'aria-label': label },
          h('span', { class: 'rank', 'aria-hidden': 'true', text: String(rank) }),
          h('span', { class: 'sname', dir: 'auto', 'aria-hidden': 'true', text: p.name + (self ? ' (you)' : '') }),
          h('span', { class: 'spts', 'aria-hidden': 'true', text: String(p.score) }));
      })));
}

// Read-only "how to play" disclosure for Who Am I, Feud, Impostor and Taboo, shared by lobby()
// and each game's own screen in play.js: native <details>/<summary> (keyboard/touch operable with no
// extra script), default closed, no gameplay data. `open` is caller-owned state so it survives
// a full re-render (play.js's mount() replaces this node on every snapshot); the summary's
// stable id lets ui.js's preserveFocus() keep focus on it across that replacement. `onToggle`
// only records the browser's own toggle — it must never trigger a page render itself, so an
// open/close can never touch any other mode state (guess draft, pending request, buzzer).
export function rulesPanel(mode, { open = false, onToggle } = {}) {
  const rules = RULES[mode];
  if (!rules) return null;
  return h('details', { class: 'card rules-panel', open, ontoggle: e => { if (onToggle) onToggle(e.target.open); } },
    h('summary', { id: 'rules-toggle', text: 'How to play' }),
    h('div', { class: 'rules-body' },
      h('h2', { class: 'card-title', text: rules.title }),
      h('ol', { class: 'rules-steps' }, rules.steps.map(step => h('li', { dir: 'auto', text: step })))));
}

export function modeHeading(snap) {
  const m = modeInfo(snap.mode);
  return h('div', { class: 'mode-heading', 'data-mode': snap.mode },
    h('h1', { class: 'mode-title', text: m.title }),
    m.ar ? h('span', { class: 'mode-ar', lang: 'ar', dir: 'rtl', text: m.ar }) : null,
    roundLabel(snap) ? h('span', { class: 'pill', text: roundLabel(snap) }) : null);
}

// Human round label from the projection (the opaque roundId is never shown).
export function roundLabel(snap) {
  const g = snap.game || {};
  if (snap.mode === 'feud' && g.board) return 'Question ' + g.board + ' of ' + g.boardCount;
  if (snap.mode === 'who_am_i' && g.round) return 'Round ' + g.round;
  if (snap.mode === 'impostor' && g.round) return 'Round ' + g.round;
  if (snap.mode === 'bluff' && g.round) return 'Round ' + g.round + ' of ' + g.rounds;
  if (snap.mode === 'escape_room' && g.puzzleCount) return 'Puzzle ' + (g.puzzleIndex + 1) + ' of ' + g.puzzleCount;
  return '';
}

// Plain wording for impostor round outcomes (party/server/modes/impostor.py); shared by the
// operator, player and TV views so the three pages never disagree on what happened.
export const IMPOSTOR_OUTCOMES = {
  impostor_survived: 'Nobody caught the impostor.',
  impostor_guessed_word: 'The impostor guessed the word!',
  crew_wrong_guess: 'The impostor guessed wrong.',
  crew_forfeit: 'The host ended the guess.',
  aborted: 'The round ended early.',
};

// Safe PLAYER-PANEL-LOCAL name resolver for the Impostor nominee/reveal references
// (majlis:impostor-player-round-status-v1): same discipline as feudPanelName above — playerName()
// already falls back to 'A player' for an unknown id, but passes a found row's own `name` field
// through whatever it is, so a missing/blank/non-string roster name must not surface as
// "undefined was caught!" or an object-coerced reveal line. Stays local to the Impostor player
// panel; tv.js keeps its own separate copy (impostorSafeName) for the shared display.
export function impostorPanelName(snap, id) {
  const n = playerName(snap, id);
  return (typeof n === 'string' && n.trim() !== '') ? n : 'A player';
}

// Dedupe-and-validate game.order into the roster id set used for vote ELIGIBILITY checks below
// (correction-r1). Returns null (not an empty set) when `order` itself is missing, holds a
// non-string or blank entry, or holds a duplicate — an invalid roster can never establish
// eligibility, so callers must treat null as "eligibility unavailable", never as an empty roster
// that would silently let every vote through unchecked.
function impostorPlayerOrderSet(g) {
  if (!Array.isArray(g.order)) return null;
  if (!g.order.every(id => typeof id === 'string' && id.trim() !== '')) return null;
  const set = new Set(g.order);
  return set.size === g.order.length ? set : null;
}

// Authoritative player-facing vote-progress summary (majlis:impostor-player-round-status-v1,
// correction-r1). A finite non-negative integer votesNeeded is authoritative ON ITS OWN, including
// zero; `order` is only a FALLBACK denominator for when authority is genuinely ABSENT (votesNeeded
// strictly undefined or null — never sent). A PRESENT but malformed authority (negative, fractional,
// non-finite, a string, or any other non-integer) is never treated as absent and never falls back
// to order: it is reported unavailable outright, regardless of whether order would otherwise be
// valid. Denominator choice and vote ELIGIBILITY are kept strictly separate: eligibility always
// requires its own valid deduped `order` roster (unique, nonblank strings) — a missing, duplicate,
// blank-containing or otherwise invalid order can never authorize counting any voter/target pair,
// even when votesNeeded itself is valid, so that case is also reported unavailable rather than
// silently trusting unverifiable votes. The one thing never done once both are established is
// clamping: a numerator that would exceed the chosen denominator is contradictory authority,
// reported as unavailable rather than capped.
function impostorVoteProgressText(g) {
  const needed = g.votesNeeded;
  const absentAuthority = needed === undefined || needed === null;
  if (!absentAuthority && !(Number.isInteger(needed) && needed >= 0)) return 'Vote progress unavailable.';
  const orderSet = impostorPlayerOrderSet(g);
  if (!orderSet) return 'Vote progress unavailable.'; // eligibility cannot be established
  const total = absentAuthority ? orderSet.size : needed;
  const votes = g.votes;
  if (votes === null || typeof votes !== 'object' || Array.isArray(votes)) return 'Vote progress unavailable.';
  const cast = new Set();
  for (const voter of Object.keys(votes)) {
    if (!orderSet.has(voter)) continue; // unknown voter, excluded
    const target = votes[voter];
    if (typeof target !== 'string' || target === voter) continue; // invalid/self target, excluded
    if (!orderSet.has(target)) continue; // unknown target, excluded
    cast.add(voter);
  }
  if (cast.size > total) return 'Vote progress unavailable.'; // contradictory, never clamped
  return cast.size + ' of ' + total + ' player' + (total === 1 ? '' : 's') + ' have voted.';
}

// Personal round-points sentence for the Impostor PLAYER ended/reveal panel only
// (majlis:impostor-player-round-status-v1, correction-r1): any actual finite number (integer or
// fractional) in g.roundPoints[me] counts as a real score — absent/non-finite/non-numeric data is
// "unavailable", never a fabricated +0 (the pre-existing `|| 0` bug this corrects), and a negative
// value keeps its own sign (never double-prefixed with the existing hard-coded '+') with correct
// singular/plural wording via pointsWord(). Never called for a spectator (no `you.role`) — see
// impostorPlayerStatusPanel below.
function impostorPersonalPointsText(g, me) {
  const pts = (g.roundPoints || {})[me];
  if (!Number.isFinite(pts)) return 'Points unavailable this round.';
  return 'You scored ' + (pts >= 0 ? '+' : '') + pts + ' ' + pointsWord(pts) + ' this round.';
}

// Accessible, labelled Impostor PLAYER round-status panel (majlis:impostor-player-round-status-v1):
// pause always wins, even mid-vote/guess-word (same discipline as feudPlayerStatusPanel above), and
// an unknown/missing roundPhase gets neutral waiting text instead of silently falling through to a
// claimed result (the pre-existing generic-else bug this corrects) — it never infers or reveals
// role/word/outcome data the projection itself has not yet sent. `spectating` selects the neutral,
// non-prompting wording for guess_word/paused text and skips the personal-points item entirely (a
// spectator never earned points). Vote/guess_word's own interactive controls (candidate buttons,
// guess form) stay in play.js's impostor() — this panel is status/guidance only, never an action.
export function impostorPlayerStatusPanel(snap, { spectating = false } = {}) {
  const g = snap.game || {};
  const phase = g.roundPhase;
  if (snap.phase === 'paused') {
    return h('section', { class: 'card pl-imp-status', 'aria-label': 'Round status' },
      h('p', { class: 'status-line', role: 'status', text: 'Paused by the host.' }));
  }
  const items = [];
  switch (phase) {
    case 'discussion':
      items.push(h('p', { class: 'status-line', role: 'status', text: 'Discuss! Who doesn’t have the word?' }));
      break;
    case 'vote':
      items.push(h('div', { class: 'pl-imp-status-item' },
        h('span', { class: 'eyebrow', text: 'Vote progress' }),
        h('span', { class: 'status-line', role: 'status', text: impostorVoteProgressText(g) })));
      break;
    case 'guess_word':
      items.push(h('p', { class: 'status-line', role: 'status', dir: 'auto', text: spectating
        ? 'Waiting for the caught player’s guess.'
        : impostorPanelName(snap, g.nominee) + ' was caught! Waiting for their guess.' }));
      break;
    case 'reveal':
    case 'ended':
      items.push(h('p', { class: 'status-line', role: 'status', text: IMPOSTOR_OUTCOMES[g.outcome] || 'Round over.' }));
      if (!spectating) {
        const me = snap.self ? snap.self.id : null;
        items.push(h('div', { class: 'pl-imp-status-item' },
          h('span', { class: 'eyebrow', text: 'Your result' }),
          h('span', { class: 'status-line', role: 'status', text: impostorPersonalPointsText(g, me) })));
      }
      break;
    default:
      items.push(h('p', { class: 'status-line', role: 'status', text: 'Waiting for the host…' }));
  }
  return h('section', { class: 'card pl-imp-status', 'aria-label': 'Round status' }, items);
}

export function strikesRow(n, { big = false, fresh = false, max = 3 } = {}) {
  return h('div', { class: 'strikes' + (big ? ' big' : ''), role: 'img', 'aria-label': 'Strike ' + n + ' of ' + max },
    Array.from({ length: max }, (_, i) => i).map(i => h('span', { class: 'strike' + (i < n ? ' on' : '') + (fresh && i === n - 1 ? ' fresh' : ''), 'aria-hidden': 'true', text: '✕' })));
}

// Tracks what this page has already shown so only NEW reveals and strikes animate and are
// announced. The first snapshot of a round (initial load or reconnect) never animates.
export class FeudChanges {
  constructor() { this.round = null; this.revealed = new Set(); this.strikes = 0; }
  diff(snap) {
    const g = snap.game || {};
    const ids = (g.slots || []).filter(s => s.revealed).map(s => String(s.index));
    if (this.round !== snap.roundId) {
      this.round = snap.roundId; this.revealed = new Set(ids); this.strikes = g.strikes || 0;
      return { fresh: new Set(), freshStrike: false, newSlots: [] };
    }
    const fresh = new Set(ids.filter(i => !this.revealed.has(i)));
    const freshStrike = (g.strikes || 0) > this.strikes;
    this.revealed = new Set(ids); this.strikes = g.strikes || 0;
    return { fresh, freshStrike, newSlots: (g.slots || []).filter(s => fresh.has(String(s.index))) };
  }
}

// Feud board for player and TV: only revealed slots carry text, matching the projection.
// Slot `index` is zero-based on the wire; people see 1, 2, 3…
export function feudBoard(game, { tv = false, changes } = {}) {
  const fresh = changes ? changes.fresh : new Set();
  const slots = game.slots || [];
  return h('section', { class: 'feud-board' + (tv ? ' tv' : '') + (slots.length <= 4 ? ' one-col' : ''), 'aria-label': 'Answer board' },
    h('div', { class: 'house-label', text: game.label || 'House answers' }),
    h('p', { class: 'feud-q', dir: 'auto', text: game.question }),
    h('ol', { class: 'slots', style: tv ? '--rows:' + Math.max(1, Math.ceil(slots.length / 2)) : null },
      slots.map(s => s.revealed
        ? h('li', { class: 'slot revealed' + (fresh.has(String(s.index)) ? ' fresh' : '') },
          h('span', { class: 'slot-text', dir: 'auto', text: s.text }), h('span', { class: 'slot-pts', text: String(s.points) }))
        : h('li', { class: 'slot', 'aria-label': 'Answer ' + (s.index + 1) + ', hidden' },
          h('span', { class: 'slot-num', 'aria-hidden': 'true', text: String(s.index + 1) }), h('span', { class: 'slot-q', 'aria-hidden': 'true', text: '?' })))),
    h('div', { class: 'feud-meta' },
      strikesRow(game.strikes || 0, { big: tv, fresh: changes && changes.freshStrike, max: game.maxStrikes || 3 }),
      h('div', { class: 'bank' }, h('span', { class: 'eyebrow', text: 'Round points' }), h('span', { class: 'bank-num', text: String(game.roundPoints || 0) }))));
}

export function announceFeudChanges(changes, game, announce) {
  for (const s of changes.newSlots) announce('Answer ' + (s.index + 1) + ' revealed: ' + s.text + ', ' + s.points + ' points.');
  if (changes.freshStrike) announce('Strike ' + (game.strikes || 0) + ' of ' + (game.maxStrikes || 3) + '.');
}

export function feudStatusLine(snap) {
  const g = snap.game || {};
  const name = id => playerName(snap, id);
  const winner = g.buzzer && g.buzzer.winner;
  switch (g.roundPhase) {
    case 'closed': return 'Get ready – the host will open the buzzer.';
    case 'buzzer_open': return 'Buzzer is OPEN!';
    case 'answering':
      if ((g.strikes || 0) >= (g.maxStrikes || 3)) return 'Three strikes! The host may offer a steal.';
      return g.control ? name(g.control) + (winner === g.control ? ' buzzed first.' : ' is answering.') : 'Answering…';
    case 'steal': return g.control ? name(g.control) + ' is trying to steal' + (g.stealFrom ? ' from ' + name(g.stealFrom) : '') + '.' : 'Steal attempt.';
    case 'awarded': return g.awardedTo ? name(g.awardedTo) + ' won ' + (g.awardedPoints || 0) + ' points this round.' : 'Round over.';
    case 'ended': return 'Game over.';
    default: return '';
  }
}

// Safe PLAYER-PANEL-LOCAL name resolver for control/steal/award references (correction-r1 for
// majlis:feud-player-round-status-v1): playerName() already falls back to 'A player' for an id
// with no roster match, but passes through a found player's own `name` field whatever it is — a
// missing/blank/non-string roster name must not surface as "undefined is answering"/"null is
// trying to steal"/"[object Object] won ... points". Stays local to this Feud player panel; the
// global playerName() in ui.js and every other mode/view calling it directly are unchanged.
function feudPanelName(snap, id) {
  const n = playerName(snap, id);
  return (typeof n === 'string' && n.trim() !== '') ? n : 'A player';
}

// Authoritative round-award sentence for the Feud PLAYER panel only: a real zero-point award is
// kept distinct from missing/malformed points (never silently prints 0, never hides a valid award
// behind "Round over."), only an actually-finite nonnegative integer counts, and a missing/invalid
// recipient falls back to feudPanelName()'s neutral text rather than inventing a participant
// identity or discarding the points sentence entirely.
function feudAwardText(snap, g) {
  const name = id => feudPanelName(snap, id);
  const pts = Number.isInteger(g.awardedPoints) && g.awardedPoints >= 0 ? g.awardedPoints : null;
  return pts === null
    ? name(g.awardedTo) + ' won this round — points unavailable.'
    : name(g.awardedTo) + ' won ' + pts + ' ' + pointsWord(pts) + ' this round.';
}

// Honest strikes-used/limit summary for the Feud PLAYER panel only: never hard-codes a "Three
// strikes" assumption (feudBoard's own strike dots and feudStatusLine above are untouched), and
// never fabricates 0-of-N for a missing/invalid pair. Only a finite nonnegative used count that
// does not exceed a positive valid maximum is ever shown as a real count; a valid zero is kept.
function feudStrikeSummary(g) {
  const used = Number.isInteger(g.strikes) && g.strikes >= 0 ? g.strikes : null;
  const max = Number.isInteger(g.maxStrikes) && g.maxStrikes > 0 ? g.maxStrikes : null;
  if (used === null || max === null || used > max) return 'Strikes unavailable';
  if (used >= max) return 'Strike limit reached (' + used + ' of ' + max + ')';
  return used + ' of ' + max + ' strikes';
}

// Single-line Feud PLAYER round narrative (majlis:feud-player-round-status-v1): paused/ended
// always wins over a stale open/answering/steal/awarded projection, a buzz invitation requires a
// live playing room plus an authoritative buzzer_open phase plus buzzer.open===true with no
// winner yet (never a bare roundPhase check), and a spectator gets watching guidance rather than
// an invitation to tap. Shared by feudPlayerStatusPanel() below and by play.js's own deduplicated
// polite announcement of real transitions, so the spoken and rendered text can never drift apart.
// Distinct from feudStatusLine above, which stays exactly as host.js's operator view uses it.
export function feudPlayerStatusText(snap, { spectating = false } = {}) {
  const g = snap.game || {};
  const name = id => feudPanelName(snap, id);
  if (snap.phase === 'paused') return 'Paused by the host.';
  if (snap.phase === 'ended' || g.roundPhase === 'ended') return 'Game over.';
  const winner = g.buzzer && g.buzzer.winner;
  switch (g.roundPhase) {
    case 'closed': return 'Get ready — the host will open the buzzer.';
    case 'buzzer_open':
      if (spectating) return 'Watching — waiting for a player to buzz in.';
      return (snap.phase === 'playing' && !!g.buzzer && g.buzzer.open === true && !winner)
        ? 'Buzzer is open — buzz in!' : 'Waiting for the host.';
    case 'answering':
      return g.control ? name(g.control) + (winner === g.control ? ' buzzed first.' : ' is answering.') : 'Waiting for the host.';
    case 'steal':
      return g.control ? name(g.control) + ' is trying to steal' + (g.stealFrom ? ' from ' + name(g.stealFrom) : '') + '.' : 'Steal attempt — waiting for the host.';
    case 'awarded': return feudAwardText(snap, g);
    default: return 'Waiting for the host…';
  }
}

// Labelled Feud PLAYER status panel: readable items instead of one run-on sentence, covering
// closed/get-ready, live open buzzer, answering/current controller, steal, round award, paused
// and ended — plus a scoped strikes-used/limit summary. Never shown pre-award as a predicted
// winner (the 'awarded' branch is the only place feudAwardText can run). feudBoard's own strike
// dots, host.js's operator feudStatusLine and tv.js's shared-display guidance are all untouched;
// this is presentation only, with no change to buzz request dispatch/retry/ownership.
export function feudPlayerStatusPanel(snap, { spectating = false } = {}) {
  const g = snap.game || {};
  const phase = g.roundPhase;
  const headline = feudPlayerStatusText(snap, { spectating });
  if (snap.phase === 'paused' || snap.phase === 'ended' || phase === 'ended') {
    return h('section', { class: 'card pl-feud-status', 'aria-label': 'Round status' },
      h('p', { class: 'status-line', text: headline }));
  }
  const items = [];
  if (phase === 'awarded') {
    items.push(h('div', { class: 'pl-feud-status-item' },
      h('span', { class: 'eyebrow', text: 'Round award' }),
      h('span', { class: 'status-line', text: headline })));
  } else {
    items.push(h('p', { class: 'status-line', text: headline }));
    if (phase === 'closed' || phase === 'buzzer_open' || phase === 'answering' || phase === 'steal') {
      items.push(h('div', { class: 'pl-feud-status-item' },
        h('span', { class: 'eyebrow', text: 'Strikes' }),
        h('span', { class: 'status-line', text: feudStrikeSummary(g) })));
    }
  }
  return h('section', { class: 'card pl-feud-status', 'aria-label': 'Round status' }, items);
}

// Finite-safe-count guard shared by both Bluff progress lines below (majlis:bluff-player-round-
// status-v1): only an actual nonnegative integer numerator paired with a positive integer
// denominator, numerator never exceeding it, counts as real progress — never a numeric
// coercion/clamp, never a fallback to game.options.length or an inferred private roster size. An
// explicit numeric 0 passes (0 <= total), so a genuine zero-votes/zero-submitted state is never
// folded into the same "unavailable" branch as missing/malformed data.
// correction-r1: Number.isSafeInteger, not Number.isInteger — 9007199254740992 (2^53) passes
// Number.isInteger but can no longer be trusted to compare/round-trip exactly, so a count or
// total at or beyond that magnitude must be rejected as unavailable rather than displayed.
function bluffCountPair(count, total) {
  return typeof count === 'number' && Number.isSafeInteger(count) && count >= 0
    && typeof total === 'number' && Number.isSafeInteger(total) && total > 0
    && count <= total;
}

// Qualified-viewer check (majlis:bluff-player-round-status-v1 correction-r1), mirroring play.js's
// own bluffSelfIsPlayer: a foreign/placeholder self.id — one naming no actual seat in
// snap.players — must never qualify for a personal phase claim below, even when game.you happens
// to carry plausible-looking data for it.
function bluffSelfIsPlayer(snap) {
  const id = snap && snap.self && snap.self.id;
  return typeof id === 'string' && !!id && Array.isArray(snap.players) && snap.players.some(p => p && p.id === id);
}

// Submission-phase progress text only — "accounted for" (not "answered") because the native
// projection's submittedCount already folds in any seat the host force-advanced past without an
// answer (majlis-core.js's Bluff project(): accounted = fakes + excluded), so this wording and
// its explanatory line below never imply every counted seat actually wrote a fake.
function bluffSubmissionProgressText(g) {
  return bluffCountPair(g.submittedCount, g.totalPlayers)
    ? 'Players accounted for: ' + g.submittedCount + ' of ' + g.totalPlayers + '.'
    : 'Progress unavailable.';
}

function bluffVotingProgressText(g) {
  return bluffCountPair(g.votedCount, g.totalPlayers)
    ? 'Votes received: ' + g.votedCount + ' of ' + g.totalPlayers + '.'
    : 'Progress unavailable.';
}

// Panel-local "Round N of M" text, distinct from roundLabel() above (modeHeading's pill for every
// mode, unguarded string concatenation): never shown at all unless round/rounds are both a
// coherent finite positive pair with round <= rounds.
function bluffRoundText(g) {
  return Number.isInteger(g.round) && g.round > 0 && Number.isInteger(g.rounds) && g.rounds > 0 && g.round <= g.rounds
    ? 'Round ' + g.round + ' of ' + g.rounds + '.' : '';
}

// Single-line Bluff PLAYER/spectator phase headline (majlis:bluff-player-round-status-v1): paused
// always wins over a stale submission/voting/reveal projection, a room-ended projection is kept
// neutral, and every phase gives a spectator watching-only wording distinct from the player's own
// next-step instruction — never an invitation to submit/vote, which only bluff()'s own admitted-
// player branch in play.js ever renders. An unrecognized/missing g.phase falls through to the
// same neutral "waiting for the host" text bluff() previously hard-coded for its own unknown-phase
// branch, so the two can never drift apart.
export function bluffPlayerStatusText(snap, { spectating = false } = {}) {
  const g = snap.game || {};
  const you = g.you;
  if (snap.phase === 'paused') return 'Paused by the host.';
  if (snap.phase === 'ended') return 'Game over.';
  // correction-r1/r2: a personal submission/voting claim — invitation OR affirmative "sent" — may
  // only be made for an explicitly `playing` room, an actual roster seat (never a foreign/missing
  // self.id), and a typed `you` object (never a missing one silently defaulted to {}). Within that,
  // only an explicit typed `true`/`false` flag may assert completion or invite the action; an
  // undefined/missing flag (e.g. an empty `you: {}`) stays the same neutral wording the
  // unrecognized-phase branch below already uses, so a stale/contradictory/incomplete projection
  // can never read as either state.
  const canClaim = !spectating && snap.phase === 'playing' && bluffSelfIsPlayer(snap)
    && you && typeof you === 'object' && !Array.isArray(you);
  switch (g.phase) {
    case 'submission':
      if (spectating) return 'Watching — players are writing their fake answers.';
      if (!canClaim) return 'Waiting for the host…';
      if (you.submitted === true) return 'Fake answer sent — waiting for everyone else.';
      if (you.submitted === false) return 'Write your fake answer.';
      return 'Waiting for the host…';
    case 'voting':
      if (spectating) return 'Watching — players are voting.';
      if (!canClaim) return 'Waiting for the host…';
      if (you.voted === true) return 'Vote sent — waiting for everyone else.';
      if (you.voted === false) return 'Vote for the real answer.';
      return 'Waiting for the host…';
    case 'reveal':
      return spectating ? 'Watching the reveal.' : 'See how this round turned out below.';
    case 'finished':
      return spectating ? 'Watching — the game has finished.' : 'The game has finished — waiting for the host.';
    default:
      return 'Waiting for the host…';
  }
}

// Labelled Bluff PLAYER/spectator phase panel: a readable next-step card plus the guarded
// submission/voting progress line, shared by both the admitted-player and spectator branches of
// play.js's bluff() so the two can never show different progress wording for the same projection.
// Paused/ended/unknown phase never renders a round label or progress line (nothing to count
// while the room itself isn't in a live phase), matching feudPlayerStatusPanel's own precedence
// above. This is presentation only — it reads g.phase/g.you/g.submittedCount/g.totalPlayers/
// g.votedCount/g.round/g.rounds and nothing else, never game.options or any private roster field.
export function bluffPlayerStatusPanel(snap, { spectating = false } = {}) {
  const g = snap.game || {};
  const headline = bluffPlayerStatusText(snap, { spectating });
  const live = snap.phase !== 'paused' && snap.phase !== 'ended';
  const items = [h('p', { class: 'status-line', text: headline })];
  if (live) {
    const roundText = bluffRoundText(g);
    if (roundText) items.push(h('p', { class: 'muted small', text: roundText }));
    if (g.phase === 'submission') {
      items.push(h('div', { class: 'pl-bluff-status-item' },
        h('span', { class: 'status-line', text: bluffSubmissionProgressText(g) }),
        h('span', { class: 'muted small', text: 'Includes any seat the host moved on without an answer.' })));
    } else if (g.phase === 'voting') {
      items.push(h('div', { class: 'pl-bluff-status-item' },
        h('span', { class: 'status-line', text: bluffVotingProgressText(g) })));
    }
  }
  return h('section', { class: 'card pl-feud-status pl-bluff-status', 'aria-label': 'Round status' }, items);
}

// Team-based scoreboard for Taboo: unlike `scoreboard()` (per-player score),
// Taboo's project() only exposes teamScores/teams — no per-player score is
// synced to room-level players for this mode (syncScores() in
// party/core/majlis-core.js reads game.scores, which Taboo's state never
// sets), so reusing the individual scoreboard would always show zero.
export function teamScoreboard(snap, { title = 'Teams', selfId } = {}) {
  const g = snap.game || {};
  const teams = g.teams || { A: [], B: [] };
  const scores = g.teamScores || { A: 0, B: 0 };
  const row = (id) => {
    const score = Number.isFinite(scores[id]) ? scores[id] : 0;
    const members = teams[id] || [];
    return h('li', { class: 'team-col' },
      h('h3', { class: 'card-title team-head', 'aria-label': 'Team ' + id + ', ' + score + ' ' + pointsWord(score) },
        h('span', { 'aria-hidden': 'true', text: 'Team ' + id }),
        h('span', { class: 'team-pts', 'aria-hidden': 'true', text: String(score) })),
      members.length
        ? h('ul', { class: 'who-cards', 'aria-label': 'Team ' + id + ' players' }, members.map(pid => {
          // selfId must be an actual roster member for the marker to appear — a spectator's own
          // id (never in `teams`) can never match, so it can never acquire a "you" marker here.
          const self = pid === selfId;
          const isGiver = pid === g.clueGiverId;
          const label = playerName(snap, pid) + (self ? ', you' : '') + (isGiver ? ', clue giver' : '');
          return h('li', { class: 'who-card' + (self ? ' me' : ''), 'aria-label': label },
            h('span', { class: 'who-name', dir: 'auto', 'aria-hidden': 'true', text: playerName(snap, pid) + (self ? ' (you)' : '') }),
            isGiver ? h('span', { class: 'badge-warn', 'aria-hidden': 'true', text: 'Clue giver' }) : null);
        }))
        : h('p', { class: 'muted small', text: 'No players on this team.' }));
  };
  return h('section', { class: 'card stack', 'aria-label': title },
    h('h2', { class: 'card-title', text: title }),
    h('ul', { class: 'team-cols' }, row('A'), row('B')));
}

// Final winner/draw text for an ended Taboo room, derived strictly from the authoritative
// projected game.result — never from live teamScores (which can read differently from the
// final award, e.g. a last-turn violation) and never shown while the room/game isn't actually
// over or the projection sent an absent/malformed result.
export function tabooResultText(snap) {
  const g = snap.game || {};
  if (snap.phase !== 'ended' || !g.ended) return null;
  const r = g.result;
  if (!r || typeof r !== 'object') return null;
  if (r.draw === true) return 'It’s a draw!';
  if (r.draw === false && (r.winner === 'A' || r.winner === 'B')) return 'Team ' + r.winner + ' wins!';
  return null;
}

// mm:ss countdown from the server-derived remainingMs; never a client timer.
export function formatClock(ms) {
  const total = Math.max(0, Math.round((ms || 0) / 1000));
  const m = Math.floor(total / 60), s = total % 60;
  return m + ':' + String(s).padStart(2, '0');
}

export const TABOO_RESULT_TEXT = {
  correct: 'Correct!',
  violation: 'Violation — point to the other team.',
  skip: 'Skipped.',
  pass: 'Turn passed.',
  expired: 'Time ran out.',
};

// Classifies the authoritative g.remainingMs into a safe, honest display: never a client-side
// countdown, never a percentage (there is no total duration to measure against), and never NaN
// or an invented value for missing/non-finite/negative input. `paused` suppresses urgency and
// relabels the same supplied value as paused rather than counting down — the caller must not
// pass a locally-ticked value here, only the last value the server actually sent.
export function tabooTimeState(ms, paused) {
  const finite = Number.isFinite(ms) && ms >= 0;
  if (!finite) return { text: 'Time unavailable', urgency: 'unavailable' };
  if (paused) return { text: formatClock(ms) + ' (time paused)', urgency: 'paused' };
  if (ms <= 0) return { text: '0:00 — waiting for host update', urgency: 'zero' };
  if (ms <= 10000) return { text: formatClock(ms) + ' left — hurry!', urgency: 'low' };
  return { text: formatClock(ms) + ' left', urgency: 'normal' };
}

// Compact turn-status panel: time, active team and cards-remaining as separate labelled items
// (not one run-on sentence), plus explicit paused/turn-complete/exhausted messages. None of this
// carries role="status"/aria-live — a full render() replaces this subtree on every snapshot, so a
// live region here would either never fire (a brand-new node, not an update to an existing one)
// or spam on every tick if it ever did; the caller announces real transitions once via its own
// deduplicated call to announce() instead. Returns null when there is nothing turn-specific to
// show (lobby/other phases already covered elsewhere).
export function tabooStatusPanel(snap) {
  const g = snap.game || {};
  const phase = g.roundPhase;
  const paused = snap.phase === 'paused';
  if (phase === 'turn_complete') return h('p', { class: 'status-line', text: 'Turn complete — waiting for the host.' });
  if (phase === 'exhausted') return h('p', { class: 'status-line', text: 'Out of cards — waiting for the host.' });
  if (phase !== 'clue_turn') return null;
  const time = tabooTimeState(g.remainingMs, paused);
  if (paused) {
    return h('section', { class: 'card taboo-status', 'aria-label': 'Turn status' },
      h('p', { class: 'status-line', text: 'Paused by the host.' }),
      h('p', { class: 'small muted', text: time.text }));
  }
  const cards = Number.isFinite(g.cardsRemaining) ? String(g.cardsRemaining) : '—';
  return h('section', { class: 'card taboo-status' + (time.urgency === 'low' || time.urgency === 'zero' ? ' urgent' : ''), 'aria-label': 'Turn status' },
    h('div', { class: 'taboo-status-item' }, h('span', { class: 'eyebrow', text: 'Time' }), h('span', { class: 'status-line', text: time.text })),
    h('div', { class: 'taboo-status-item' }, h('span', { class: 'eyebrow', text: 'Team' }), h('span', { class: 'status-line', text: 'Team ' + (g.activeTeam || '—') })),
    h('div', { class: 'taboo-status-item' }, h('span', { class: 'eyebrow', text: 'Cards left' }), h('span', { class: 'status-line', text: cards })));
}

// Players and the TV get a passive notice. The operator passes `actions`: the panel then becomes a
// modal dialog holding the only reachable controls (the page behind it is made inert by the caller).
export function pausedOverlay({ title = 'Paused', text = 'Paused by operator.', actions = null } = {}) {
  if (!actions) {
    return h('div', { class: 'overlay', role: 'alert' },
      h('div', { class: 'overlay-card' }, h('div', { class: 'overlay-title', text: title }), h('p', { text })));
  }
  // Not aria-modal: the connection banner's Retry (outside this panel) must stay operable.
  return h('div', { class: 'overlay op-pause', id: 'paused-panel' },
    h('div', { class: 'overlay-card', role: 'dialog', tabindex: '-1', 'aria-labelledby': 'paused-title', 'aria-describedby': 'paused-text' },
      h('h2', { class: 'overlay-title', id: 'paused-title', text: title }),
      h('p', { id: 'paused-text', text }),
      h('div', { class: 'op-pause-actions' }, actions)));
}
