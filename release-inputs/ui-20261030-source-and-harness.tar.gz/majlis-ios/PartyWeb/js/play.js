// Majlis Party player (phone) interface. Identity comes only from the player token the server
// issued on join. The page never decides who buzzed first and never holds the player's own
// Who Am I character before the reveal: the server leaves it out of this role's projection.
import { h, mount, makeTransport, simRibbon, connBanner, toast, describeError, pageUrl, withBusy, playerName, params, vibrate, isSim, preserveFocus, confirmDialog, setRetryHandler, announce, TERMINAL_ROOM, TERMINAL_SEAT } from './ui.js';
import { saveCredential, loadCredential, clearCredential, lastRoom, normalizeCode, isCodeShape } from './session.js';
import { modeInfo } from './modes.js';
import { playerChips, scoreboard, modeHeading, feudBoard, feudPlayerStatusText, feudPlayerStatusPanel, bluffPlayerStatusPanel, pausedOverlay, FeudChanges, announceFeudChanges, IMPOSTOR_OUTCOMES, impostorPlayerStatusPanel, impostorPanelName, teamScoreboard, tabooResultText, formatClock, TABOO_RESULT_TEXT, rulesPanel, tabooTimeState, tabooStatusPanel } from './views.js';

const app = document.getElementById('app');
const simEl = document.getElementById('sim');
if (simEl) mount(simEl, simRibbon());

let transport, code = null, cred = null, stream = null, snap = null, temporarySeat = false;
// Bumped at the very start of enter()/leave()/closedByHost(), before `code`/`cred` are reassigned
// to the next session's identity. The active subscribe()'s onSnapshot/onStatus close over the
// epoch they were created under; if a reentrant callback from a stream.close() fires after this
// counter has moved on (whether because that same call already bumped it, or a still-newer one
// has), the callback is for a session that is no longer live and must be a no-op rather than act
// on `code`/`cred`, which by then may already belong to a different room.
let sessionEpoch = 0;
const local = { buzzPending: false, buzzPendingReqId: null, buzzReqSeq: 0, buzzFailure: null, feudAuthKey: null, feudGen: 0,
  guessDraft: '', guessError: '', lastWin: null, lastGuess: undefined, guessRound: null, impRound: null, impostorGuessDraft: '',
  impCardKey: null, impCardRevealed: false, impCardGen: 0, impCardEligible: true, impCardVisible: true,
  tabooRound: null, tabooEpoch: null, tabooGuessDraft: '', tabooSending: false, tabooReqId: 0,
  tabooCardKey: null, tabooCardRevealed: false, tabooCardGen: 0, tabooCardEligible: true, tabooCardVisible: true,
  tabooStatusKey: null,
  bluffRound: null, bluffDraft: '', bluffError: '', bluffVoteError: '',
  bluffPending: false, bluffPendingReqId: null, bluffReqSeq: 0, bluffGen: 0,
  erRound: null, erDraft: '', erError: '', erAuthKey: null, erPending: false, erPendingReqId: null, erGen: 0, erReqSeq: 0, erRefreshSeq: 0, erRefreshApplied: 0,
  waAuthKey: null, waGen: 0, waGuessPending: false, waGuessPendingReqId: null, waGuessReqSeq: 0,
  waReadyPending: false, waReadyPendingReqId: null, waReadyReqSeq: 0, waReadyDesired: null,
  rulesOpen: false, rulesAuthKey: null, rulesGen: 0 };

// Drops the how-to-play disclosure's open state. Called from enter()/leave()/closedByHost() (a
// new room/session must never start with a previous room's panel left open) and from render()'s
// own authKey diff below on an actual room/mode replacement — never on a plain phase change
// (lobby -> playing -> paused for the SAME mode), so the panel stays open across routine
// snapshot rerenders as required.
function resetRulesLocal() { local.rulesOpen = false; local.rulesAuthKey = null; }

// Renders the how-to-play disclosure for the given mode, gating its onToggle against the
// render generation captured at this call. Every render() fully replaces the DOM subtree
// (mount()/replaceChildren()), so a native 'toggle' event already queued on a prior render's
// <details> node can still be delivered after that node is detached -- same-mode rerender,
// mode/room replacement, or leave/rejoin all retire the old node without necessarily changing
// rulesAuthKey (same-mode rerenders intentionally keep that key stable so the open state
// survives). Comparing against local.rulesGen, bumped once per render() below, rejects any
// toggle whose node is no longer the one actually on screen, while a toggle from the current
// node (gen unchanged since this call) still applies normally.
function renderRulesPanel(mode) {
  const gen = local.rulesGen;
  return rulesPanel(mode, { open: local.rulesOpen, onToggle: v => { if (local.rulesGen === gen) local.rulesOpen = v; } });
}

// Drops any in-flight taboo guess request and its draft/sending state. Used whenever this phone
// leaves the taboo view entirely (room/seat/mode/lobby/terminal transitions) so a response that
// finally arrives after the fact can never resurrect stale UI state the player never saw again.
function resetTabooLocal() {
  local.tabooEpoch = null; local.tabooGuessDraft = ''; local.tabooSending = false;
  local.tabooReqId = (local.tabooReqId || 0) + 1;
  local.tabooStatusKey = null;
  resetTabooCardReveal();
}

// What the dedicated off-screen live region should say for a real turn-status transition (room/
// session/round/phase/urgency change) — never for an unchanged repeated snapshot, and never the
// raw ticking clock itself (see the dedup key check at this function's call site in taboo()).
function tabooAnnounceText(phase, paused, time, g) {
  if (paused) return 'Paused. ' + time.text + '.';
  if (phase === 'turn_complete') return 'Turn complete.';
  if (phase === 'exhausted') return 'Out of cards.';
  if (phase !== 'clue_turn') return null;
  if (time.urgency === 'zero') return 'Time’s up — waiting for host update.';
  if (time.urgency === 'low') return time.text + ' for Team ' + g.activeTeam + '.';
  return 'Team ' + g.activeTeam + '’s turn, ' + (Number.isFinite(g.cardsRemaining) ? g.cardsRemaining : '—') + ' cards left.';
}

// Centralized feud-buzzer lifecycle reset, mirroring resetTabooLocal()/erReset(): drops any
// pending buzz ownership and bumps a monotonic generation counter. The counter (not just the
// authKey fields it is paired with in feud()) is what a captured authority is checked against at
// completion time, because pause/resume or a direct re-entry can return every authority FIELD
// (room/round/seat/credential) to the exact values a request captured before the transition
// (ABA) -- a value-equality-only check would then treat that retired request as current again.
// Called from enter()/leave()/closedByHost()/the fatal-status handler (so a retained buzzer from
// before the transition can never dispatch or have a stale reply act on newer state), and from
// feud()'s own authKey diff for room/round/mode/seat/credential changes while still in feud mode.
function resetFeudLocal() {
  local.feudAuthKey = null;
  local.buzzPending = false; local.buzzPendingReqId = null; local.buzzFailure = null;
  local.feudGen = (local.feudGen || 0) + 1;
  // A genuine authority transition (new room/seat/credential/round) must count as a fresh mount
  // for the status-panel announcement too, exactly like buzzPending/buzzFailure above: otherwise
  // this player's first render under the NEW authority would compare its headline against stale
  // text left over from whatever the OLD authority last showed and could announce on arrival,
  // contradicting feud()'s own "never on first mount/reconnect" comment at the call site.
  local.feudStatusSeen = false; local.feudStatusText = null;
}

// Forces this player's own Impostor role/word card back under cover and bumps impCardGen, the
// counter the Reveal/Hide control captures at its own render (see impCardPanel below), mirroring
// resetTabooCardReveal() immediately below. A detached control's onclick closes over the gen it
// was built under; once this call has moved the counter on, that closure's own guard refuses to
// flip impCardRevealed back on, so a stale click arriving after the transition that triggered
// this reset can never re-unmask the role. Called from resetImpLocal() (room/seat/mode/lobby/
// leave/closedByHost/fatal-seat transitions) and from the connection-status/visibility handlers
// below (disconnect/stale/reconnecting/hidden), and driven by impostor()'s own impCardKey diff for
// every other transition (round change, authority loss, pause) without this call needing to know
// about any of them individually.
function resetImpCardReveal() {
  local.impCardKey = null; local.impCardRevealed = false;
  local.impCardGen = (local.impCardGen || 0) + 1;
}

// Centralized Impostor lifecycle reset, mirroring resetTabooLocal(): drops any in-progress guess
// draft and forces the role card back under cover. Used whenever this phone leaves Impostor mode
// entirely (room/seat/mode/lobby/leave/closedByHost/fatal-seat transitions) so neither survives
// into a session/identity that is no longer the one they were captured under.
function resetImpLocal() {
  local.impRound = null; local.impostorGuessDraft = '';
  resetImpCardReveal();
}

// Tracks connection eligibility (`kind` omitted/'conn') and tab visibility (`kind` 'visibility')
// for the Impostor role card independently of whether it happens to be covered right now, mirroring
// coverTabooCardIfNotLive() immediately below. Always retires any outstanding reveal callback on a
// live/non-live transition in either — even while already covered — so a detached control built
// while covered cannot still validate against an untouched gen/key after the transition.
function coverImpCardIfNotLive(st, kind) {
  const live = st === 'live';
  const key = kind === 'visibility' ? 'impCardVisible' : 'impCardEligible';
  if (local[key] === live) return;
  local[key] = live;
  if (!live) resetImpCardReveal();
  if (snap) render();
}
// Local-shoulder-surfing cover for the Impostor role card, mirroring the Taboo card's own
// visibilitychange handling below: backgrounding this tab covers the role/word and requires a
// fresh explicit reveal once the tab is visible again.
document.addEventListener('visibilitychange', () => {
  coverImpCardIfNotLive(document.hidden ? 'hidden' : 'live', 'visibility');
});

// Forces the clue giver's card back under cover and bumps tabooCardGen, the counter the
// Reveal/Hide control captures at its own render (see tabooCardPanel below). A detached
// control's onclick closes over the gen it was built under; once this call has moved the
// counter on, that closure's own guard refuses to flip tabooCardRevealed back on, so a stale
// click arriving after the transition that triggered this reset can never re-unmask the card.
// Called from resetTabooLocal() (room/seat/mode/lobby/leave/closedByHost/fatal-seat transitions,
// including a leave+rejoin of the very same identifiers) and from the connection-status handler
// below (disconnect/stale/reconnecting), and driven by taboo()'s own giverKey diff for every
// other transition (card/round change, authority loss, pause) without this call needing to know
// about any of them individually.
function resetTabooCardReveal() {
  local.tabooCardKey = null; local.tabooCardRevealed = false;
  local.tabooCardGen = (local.tabooCardGen || 0) + 1;
}

// Tracks connection eligibility (`kind` omitted/'conn') and tab visibility (`kind` 'visibility')
// independently of whether the card happens to be covered right now, and always retires any
// outstanding reveal callback on a live/non-live transition in either — even while already
// covered. A detached Reveal control closes over the gen/key it was built under (see
// tabooCardPanel below); if a non-live transition only reset state while the card was showing
// (the old behavior), a stale control built while covered would keep validating against an
// untouched gen/key and could still re-reveal after the transition. Guarded by a per-kind
// eligibility diff so repeated identical status/visibility events are no-ops rather than
// redundant resets/renders, and the two kinds never clobber each other's stored eligibility.
function coverTabooCardIfNotLive(st, kind) {
  const live = st === 'live';
  const key = kind === 'visibility' ? 'tabooCardVisible' : 'tabooCardEligible';
  if (local[key] === live) return;
  local[key] = live;
  if (!live) resetTabooCardReveal();
  if (snap) render();
}
// Local-shoulder-surfing cover, not a transport/screenshot-security claim: the moment this tab
// is backgrounded (app-switch, screen lock, another window raised over it), the clue giver's card
// is covered and requires a fresh explicit reveal once the tab is visible again. Routed through
// the same eligibility gate as connection status above (just the 'visibility' kind), so becoming
// visible again is tracked the same no-op-on-repeat way and a passive snapshot handled while
// backgrounded can never leave stale visibility state behind.
document.addEventListener('visibilitychange', () => {
  coverTabooCardIfNotLive(document.hidden ? 'hidden' : 'live', 'visibility');
});
const feudChanges = new FeudChanges();

// Invalidation key for Who Am I's private guess/ready request-ownership state: any change to
// room/round/phase/seat/credential/mode/round-phase/own-revealed/own-solved is a genuine authority
// change (round.next, leave/closed/fatal/direct-enter, pause/resume, this player's own reveal or
// solve all move one of these), so an outstanding guess/ready request's capture must stop owning
// anything once it is replayed. See erAuthKey for the same pattern applied to escape room.
function waAuthKey(s, you) {
  const g = s ? (s.game || {}) : {};
  return s ? [s.code, s.mode, s.phase, s.roundId, s.self && s.self.id, cred && cred.token,
    g.roundPhase, you ? !!you.revealed : null, you ? !!you.solved : null].join('|') : null;
}

// Centralized Who Am I lifecycle reset: clears the private guess draft/error and the guess/ready
// pending-request ownership, and bumps a monotonic generation counter (see erReset's comment on
// why a counter, not just the auth key, guards the ABA case — pause followed by resume can return
// every authority field to the exact values a request captured before the pause).
function waReset() {
  local.waAuthKey = null; local.guessDraft = ''; local.guessError = ''; local.lastGuess = undefined; local.guessRound = null;
  local.waGuessPending = false; local.waGuessPendingReqId = null;
  local.waReadyPending = false; local.waReadyPendingReqId = null; local.waReadyDesired = null;
  local.waGen = (local.waGen || 0) + 1;
}

// `quiet`: refusal codes the screen already explains itself, so no toast is shown for them.
// `isLive`: optional predicate re-checked at completion time, for callers (like the escape-room
// form) that must suppress BOTH the toast and their own reply handling once the authority that
// issued this request is no longer current — without this, a stale/old-round reply would raise a
// toast through this shared helper before the caller's own guard ever runs. Omitted by every
// other caller, which keeps their existing always-toast behavior unchanged.
// `authority`: optional {code, credToken, roundId} captured by the caller BEFORE this call starts
// (the escape-room form captures it once at build time — see `authority` in escapeRoom()). When
// given, dispatch uses these explicit, already-captured values instead of the live `code`/
// `cred.token`/`snap.roundId` globals, so a request that is in flight while those globals move on
// (leave/reconnect/round change) still carries the identity it was actually admitted under. Every
// sibling caller (whoami/feud/impostor) omits this and keeps reading the live globals unchanged.
async function act(type, payload, btn, quiet, isLive, authority) {
  return withBusy(btn, async () => {
    try {
      const actCode = authority ? authority.code : code;
      const actToken = authority ? authority.credToken : (cred && cred.token);
      const actRoundId = authority ? authority.roundId : (snap ? snap.roundId : undefined);
      const r = await transport.act(actCode, actToken, type, payload, actRoundId);
      if (!r.accepted && !(quiet && quiet.includes(r.error)) && !(isLive && !isLive())) toast(describeError(r.error), 'error');
      return r;
    } catch (e) {
      if (!(isLive && !isLive())) toast(describeError(e.code), 'error');
      return { accepted: false, error: e.code };
    }
  });
}

// ---- join / resume --------------------------------------------------------------------

const JOIN_NAME_MAX = 24;

// Mirrors the pieces of the host's cleanName (textutil.py, via majlis-core.js) that a length
// guide and submitted payload need in the browser: NFC composition (so a combining sequence
// counts as the same number of characters the host sees), Unicode code-point counting (so a
// supplementary-plane character, which is two UTF-16 units, counts as one — unlike plain
// .length/HTML maxlength, which both operate on UTF-16 units and would otherwise truncate or
// reject host-valid names), and whitespace collapsing using the public, stable Unicode
// White_Space property — the same codepoint set Python's str.split()/str.isspace() use, which is
// what the host's clean_text actually collapses on. That set includes the ASCII controls
// \t\n\v\f\r\x1c-\x1f (FS/GS/RS/US count as whitespace to the host) and \x85 (NEL), plus the
// Unicode space/line/paragraph separators. It deliberately EXCLUDES U+FEFF (ZERO WIDTH NO-BREAK
// SPACE): the host does not treat FEFF as whitespace and preserves it as an ordinary
// identity-bearing character, unlike JS's native \s class, which (for legacy BOM-stripping
// reasons) does include FEFF — using native \s/trim here would silently change a host-valid
// name's identity. The host's control/forbidden-character table lives only in the generated
// unicode13 tables and is NOT reproduced here; the host's invalid_name/name_taken response stays
// authoritative for rejection, this only has to match the host's whitespace collapsing so a
// host-valid name is never blocked or mis-submitted before it ever reaches the host.
const JOIN_WS_SOURCE = '\\t-\\r\\x1c-\\x1f \\x85\\u00a0\\u1680\\u2000-\\u200a\\u2028\\u2029\\u202f\\u205f\\u3000';
const JOIN_WS_RUN_RE = new RegExp('[' + JOIN_WS_SOURCE + ']+', 'g');
const JOIN_WS_EDGE_RE = new RegExp('^[' + JOIN_WS_SOURCE + ']+|[' + JOIN_WS_SOURCE + ']+$', 'g');
function joinNameCodePointLength(s) { return Array.from(s).length; }
function collapseJoinName(raw) {
  return raw.normalize('NFC').replace(JOIN_WS_RUN_RE, ' ').replace(JOIN_WS_EDGE_RE, '');
}

// Room-code paste/invite-link parsing ----------------------------------------------------
// The code field accepts more on paste than its bare 6-character shape: whitespace-padded
// bare codes, the explicit human grouping "ABC 123"/"ABC-123", or a full same-origin play.html
// invite link whose sole `code` query value is itself exactly a 6-character ASCII code. Used by
// both the paste handler (below) and the submit guard, so a value a script/autofill set directly
// on the field (bypassing the paste event entirely) is held to the exact same contract as a real
// paste — it is parsed with the URL API (never HTML/regex scraping of markup) and is never
// broadened by stripping arbitrary punctuation into a different, coincidentally-valid code.
// Never returns or retains the raw pasted text itself, only a canonical code or a field message.
const BARE_CODE_RE = /^([A-Za-z0-9]{3})[ -]?([A-Za-z0-9]{3})$/;
const LOOKS_LIKE_URL_RE = /^[a-zA-Z][a-zA-Z0-9+.-]*:|^\/\//;

function resolveRoomCode(raw) {
  const text = String(raw == null ? '' : raw).trim();
  const bare = text.match(BARE_CODE_RE);
  if (bare) {
    const code = (bare[1] + bare[2]).toUpperCase();
    if (isCodeShape(code)) return { ok: true, code };
  }
  if (!LOOKS_LIKE_URL_RE.test(text)) return { ok: false, message: 'Room codes have 6 letters or numbers.' };
  let u;
  try { u = new URL(text); } catch { return { ok: false, message: 'That invite link looks incomplete.' }; }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') return { ok: false, message: 'That link type isn’t supported here.' };
  if (u.username || u.password) return { ok: false, message: 'That link isn’t supported here.' };
  if (u.origin !== location.origin) return { ok: false, message: 'That link is for a different host — open it directly instead.' };
  if (u.pathname !== new URL(pageUrl('play.html')).pathname) return { ok: false, message: 'That link doesn’t point to this join page.' };
  const codes = u.searchParams.getAll('code');
  if (codes.length === 1 && /^[A-Za-z0-9]{6}$/.test(codes[0])) return { ok: true, code: codes[0].toUpperCase() };
  return { ok: false, message: 'That link has an unexpected room code.' };
}

function renderJoin({ error, code: presetCode, name } = {}) {
  // Bump sessionEpoch first (see enter()): this is itself a new join-view/navigation authority,
  // so any request still pending from a previous renderJoin()'s form (retained detached submit,
  // or a late reply after this exact code was re-entered another way) closes over an epoch that
  // is already stale by the time it resolves, and its success/error/finally becomes a no-op
  // instead of acting on a view this call has already replaced.
  const joinEpoch = ++sessionEpoch;
  const fromUrl = normalizeCode(new URLSearchParams(location.search).get('code')); // live URL: leave() clears it
  const codeIn = h('input', { id: 'join-code', name: 'code', inputmode: 'text', autocapitalize: 'characters', autocomplete: 'off', spellcheck: 'false',
    required: true, value: presetCode || fromUrl || '', 'aria-describedby': 'code-help code-error', class: 'code-input' });
  // No native maxlength/pattern here either: both would truncate/reject a real paste (invite
  // link, "ABC 123") before the paste handler below ever sees it. resolveRoomCode() above and the
  // submit guard further down are the only validation now.
  // No native maxlength at all: HTML maxlength counts UTF-16 units and enforces natively on real
  // typing/paste, not just the final .value — a host-valid name padded with long whitespace runs
  // (e.g. 30 separator characters that collapse to one space) can exceed any fixed native cap
  // while still being well under JOIN_NAME_MAX after collapseJoinName, and a native cap would
  // silently drop trailing host-valid characters (including the closing character of the name)
  // before collapseJoinName/the submit guard below ever see them. The submit guard and the live
  // counter below are the only length enforcement; they operate on the collapsed, code-point
  // count.
  const nameIn = h('input', { id: 'join-name', name: 'name', required: true, autocomplete: 'nickname', dir: 'auto', value: name || '',
    'aria-describedby': 'name-help name-error' });
  const btn = h('button', { class: 'btn btn-pri btn-lg', type: 'submit', text: 'Join game' });
  const errEl = h('p', { class: 'form-error', role: 'alert', id: 'join-error', text: error || '' });
  const codeErrEl = h('p', { class: 'form-error', role: 'alert', id: 'code-error', text: '' });
  const nameErrEl = h('p', { class: 'form-error', role: 'alert', id: 'name-error', text: '' });
  const nameHelpEl = h('p', { class: 'muted small', id: 'name-help', text: '' });

  function setCodeError(msg) {
    codeErrEl.textContent = msg || '';
    if (msg) codeIn.setAttribute('aria-invalid', 'true'); else codeIn.removeAttribute('aria-invalid');
  }
  function setNameError(msg) {
    nameErrEl.textContent = msg || '';
    if (msg) nameIn.setAttribute('aria-invalid', 'true'); else nameIn.removeAttribute('aria-invalid');
  }
  // Plain text, no aria-live/role=status: a per-keystroke count must never be announced.
  function updateNameHelp() {
    nameHelpEl.textContent = joinNameCodePointLength(collapseJoinName(nameIn.value)) + '/' + JOIN_NAME_MAX + ' characters.';
  }

  // IME composition safety: while an input method is composing, Enter must never submit the
  // form (some browsers, notably Safari, fire the implicit-submit keydown mid-composition
  // instead of suppressing it), and the live count/error must wait for the committed text rather
  // than flicker on each candidate. compositionend's own value is what carries the final text;
  // nothing here replaces or clears it.
  let composing = false;
  nameIn.addEventListener('compositionstart', () => { composing = true; });
  nameIn.addEventListener('compositionend', () => { composing = false; updateNameHelp(); });
  nameIn.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (composing || e.isComposing || e.keyCode === 229)) e.preventDefault();
  });
  nameIn.addEventListener('input', () => {
    if (composing) return;
    updateNameHelp();
    if (nameErrEl.textContent) setNameError('');
  });
  codeIn.addEventListener('input', () => { if (codeErrEl.textContent) setCodeError(''); });
  // Takes over the paste entirely (preventDefault, so native insertion — and any native
  // maxlength — never runs) and resolves it through the exact same contract the submit guard
  // below applies: a bare code, "ABC 123"/"ABC-123", or a same-origin play.html invite link. On
  // success the canonical code replaces the field and any stale error clears; on rejection the
  // field's existing value/code is left completely untouched — the rejected text is never
  // inserted and never kept past this handler. This never navigates, fetches, or submits.
  codeIn.addEventListener('paste', (e) => {
    e.preventDefault();
    const dt = e.clipboardData;
    const text = dt ? dt.getData('text') : '';
    const r = resolveRoomCode(text);
    if (r.ok) { codeIn.value = r.code; setCodeError(''); }
    else setCodeError(r.message);
  });
  updateNameHelp(); // initial count for a prefilled/resumed name

  // Guards this exact rendered form's own join transaction: true only while ITS request is in
  // flight. Checked first and set synchronously in onsubmit, before any await (and before
  // resolveRoomCode/loadCredential/name validation run again), so two submit events for the same
  // transaction -- a double-click, a double Enter, a retained reference to this form dispatched
  // again -- can never issue a second join POST.
  let submitting = false;
  // Announces once when a request starts/ends (role=status), not per keystroke like nameHelpEl.
  const pendingEl = h('p', { class: 'muted small', role: 'status', id: 'join-pending', text: '' });

  const form = h('form', { class: 'card stack join-form', novalidate: true, onsubmit: async (e) => {
    e.preventDefault();
    if (composing) return; // a deliberate submit never fires mid-composition
    // Retired (a newer renderJoin/enter/leave/closedByHost already took over this epoch) or this
    // exact transaction is already in flight: any further submit for this form is a no-op.
    if (joinEpoch !== sessionEpoch || submitting) return;
    // Same resolveRoomCode() the paste handler uses, not the old bare normalizeCode/isCodeShape
    // pair: a value a script or autofill set directly on the field (never firing the 'paste'
    // event above) is held to the identical contract, so it cannot bypass invite-link rejection
    // by landing here instead.
    const parsed = resolveRoomCode(codeIn.value);
    if (!parsed.ok) { setCodeError(parsed.message); codeIn.focus(); return; }
    const c = parsed.code;
    // This phone already has a seat in that room: go back to it rather than joining twice.
    if (loadCredential('player', c, isSim)) { enter(c); return; }
    const n = collapseJoinName(nameIn.value);
    if (!n || joinNameCodePointLength(n) > JOIN_NAME_MAX) { setNameError(describeError('invalid_name')); nameIn.focus(); return; }
    // Claim ownership of this transaction synchronously, before any await: `c`/`n` above are
    // already captured, so further edits to the fields while this request is pending can never
    // change what was actually sent. Lock the fields read-only (not disabled, so focus/assistive
    // tech keep tracking them) and announce the pending state once, not per keystroke.
    submitting = true;
    codeIn.readOnly = true; nameIn.readOnly = true;
    pendingEl.textContent = 'Joining…';
    await withBusy(btn, async () => {
      try {
        const r = await transport.join(c, n);
        // This exact view may have been retired (a newer renderJoin/enter/leave/closedByHost ran)
        // while the request was in flight. A retired success must never navigate away from
        // whatever is live now, and must never overwrite a credential a newer transaction already
        // wrote for this same code -- but a genuinely valid seat this call captured is still not
        // simply discarded when there is nothing newer to conflict with: it is saved so the seat
        // still works on reload, it just never takes over the page that is live right now.
        const stale = joinEpoch !== sessionEpoch;
        const conflict = stale && loadCredential('player', c, isSim);
        if (!conflict) {
          // The seat is issued; it must never be lost from this open document, whether or not the
          // write below persists. saveCredential keeps the live credential in page memory first.
          const persisted = saveCredential('player', c, { token: r.playerToken, playerId: r.playerId, name: n }, isSim);
          if (!stale) {
            if (!persisted) toast('You’re in! This device couldn’t save your seat, so closing or reloading this page may lose it.', 'info', 5000);
            enter(c);
          }
        }
      } catch (err) {
        if (joinEpoch !== sessionEpoch) return; // retired: never mutate/focus a replacement view
        // invalid_name/name_taken are reported on the name field, with the typed draft kept
        // in place for correction; every other join failure keeps the prior whole-form notice.
        if (err.code === 'invalid_name' || err.code === 'name_taken') setNameError(describeError(err.code));
        else errEl.textContent = describeError(err.code);
      } finally {
        // A retired view's own fields/status are never touched here (they were already replaced
        // or are no longer this page's live form); only the still-current view unlocks itself.
        if (joinEpoch === sessionEpoch) {
          submitting = false;
          codeIn.readOnly = false; nameIn.readOnly = false;
          pendingEl.textContent = '';
        }
      }
    });
  } },
    h('h1', { class: 'card-title', text: 'Join the party' }),
    h('label', { for: 'join-code', text: 'Room code' }), codeIn,
    h('p', { class: 'muted small', id: 'code-help', text: 'Find it on the host’s screen, or paste your invite link.' }), codeErrEl,
    h('label', { for: 'join-name', text: 'Your name' }), nameIn,
    nameHelpEl, nameErrEl,
    errEl, pendingEl, btn);
  const resume = lastRoom('player', isSim);
  mount(app,
    h('header', { class: 'topbar' }, h('a', { class: 'brand', href: pageUrl('index.html'), text: 'majlis.' })),
    h('main', { class: 'page narrow stack' },
      h('div', { class: 'join-welcome' }, h('div', { class: 'join-art', 'aria-hidden': 'true' }, h('span')),
        h('p', { class: 'join-title', text: 'Your seat is waiting.' }),
        h('p', { text: 'A room code. Your name. You’re in.' })),
      resume && resume !== (presetCode || fromUrl) ? h('button', { class: 'btn btn-sec', type: 'button', onclick: () => enter(resume), text: 'Back to room ' + resume }) : null,
      form));
  ((presetCode || fromUrl) ? nameIn : codeIn).focus();
}

function enter(c) {
  // A direct enter() — even into the same room/credential/seat/round/card this device already
  // held, and even before any new snapshot arrives — is itself an authority-lifecycle transition:
  // any retained form or in-flight request from before this call closes over a `snap`/identity
  // this call is about to replace. Bump tabooReqId and drop the stale snapshot right here, before
  // loadCredential or the new subscribe, so draftKey/liveKey rederivation elsewhere can never
  // mistake the old form/request for one this (re)entry itself produced.
  // Bump sessionEpoch before `code`/`cred` are reassigned below: the previous session's
  // onSnapshot/onStatus close over the epoch they were subscribed under, so a reentrant callback
  // from closing its stream (a few lines down) is for an epoch that is already stale and becomes
  // a no-op instead of acting on this call's new `code`/`cred`.
  const myEpoch = ++sessionEpoch;
  resetTabooLocal();
  resetFeudLocal();
  resetImpLocal();
  resetBluffLocal();
  if (local.waAuthKey) waReset();
  resetRulesLocal();
  snap = null;
  code = c;
  cred = loadCredential('player', code, isSim);
  if (!cred) { renderJoin({ code }); return; }
  // Shown for the rest of this document's life whenever this seat's credential could not be
  // written to storage: it never recovers on its own mid-document, so the notice stays up.
  temporarySeat = cred.persisted === false;
  history.replaceState(null, '', pageUrl('play.html', { code }));
  mount(app, h('main', { class: 'page center' }, h('p', { class: 'muted', role: 'status', text: 'Connecting…' })));
  // Detach the previous session's stream into a local and null the shared ref before closing it:
  // a synchronous transport can call back into onStatus/onSnapshot from inside close() itself, and
  // that reentrant callback must already see `stream` cleared, not the stream it is itself closing.
  const oldStream = stream; stream = null;
  if (oldStream) oldStream.close();
  setRetryHandler(() => stream && stream.kick());
  stream = transport.subscribe(code, cred.token, {
    onSnapshot: (s) => {
      if (myEpoch !== sessionEpoch) return;
      if (s.phase === 'closed') { closedByHost(); return; }
      snap = s; local.snapAt = Date.now(); render();
      // lobby()/ended() never route through escapeRoom(), so its own authKey-diffing reset would
      // never run again for this game; clear eagerly rather than leave a stale pending/draft
      // behind for however long the room stays in either phase.
      if ((s.phase === 'lobby' || s.phase === 'ended') && local.erAuthKey) erReset();
      if ((s.phase === 'lobby' || s.phase === 'ended') && local.waAuthKey) waReset();
      // Ended is terminal: keep the final scores and stop reconnecting.
      if (s.phase === 'ended' && stream) { stream.close(); stream = null; connBanner('live'); }
    },
    onStatus: (st, err) => {
      if (myEpoch !== sessionEpoch) return;
      const c = err && err.code;
      if (st === 'fatal' && c === 'room_closed') { closedByHost(); return; }
      connBanner(st, c);
      coverTabooCardIfNotLive(st);
      coverImpCardIfNotLive(st);
      if (st === 'fatal' && !(snap && snap.phase === 'ended')) {
        const name = cred && cred.name;
        // Only a code that can never work again drops this phone's seat.
        if (TERMINAL_ROOM.has(c) || TERMINAL_SEAT.has(c)) clearCredential('player', code, isSim);
        stream = null; snap = null; temporarySeat = false;
        // A fatal status (e.g. this seat was removed) never routes back through render()'s own
        // "left taboo mode" reset (snap is already null here, so entersTaboo's check in render()
        // never runs), so any pending request/draft bound to the old authority would otherwise
        // survive untouched: resetTabooLocal() bumps tabooReqId (orphaning the in-flight request's
        // captured id so its eventual response is a no-op) and clears the stale draft directly.
        // resetFeudLocal() does the same for a pending buzz.
        resetTabooLocal();
        resetFeudLocal();
        resetImpLocal();
        resetBluffLocal();
        if (local.erAuthKey) erReset();
        if (local.waAuthKey) waReset();
        resetRulesLocal();
        connBanner('live');
        renderJoin({ error: describeError(c), code: TERMINAL_ROOM.has(c) ? '' : code, name });
      }
    },
  });
}

// Leaving the view keeps this phone's seat (its token stays on this device), so "Back to room"
// resumes it. The server keeps the seat and the name; there is no way to free them here.
function leave() {
  // Bump sessionEpoch first (see enter()): invalidates the live subscription's callbacks before
  // this function touches any of the state they might otherwise still act on reentrantly.
  ++sessionEpoch;
  // Detach and invalidate before closing (see enter()): a reentrant close callback must land
  // after `stream` is already cleared, not before it.
  const oldStream = stream; stream = null;
  snap = null; cred = null; temporarySeat = false;
  resetTabooLocal();
  resetFeudLocal();
  resetImpLocal();
  resetBluffLocal();
  if (local.erAuthKey) erReset();
  if (local.waAuthKey) waReset();
  resetRulesLocal();
  if (oldStream) oldStream.close();
  connBanner('live');
  history.replaceState(null, '', pageUrl('play.html'));
  renderJoin();
}

// The host closed the room: nothing can be done in it any more, so its token is dropped.
function closedByHost() {
  const c = code;
  // Bump sessionEpoch first (see enter()), after capturing `c` but before anything else: any
  // reentrant callback nested inside this call's own stream.close() below is for a now-stale
  // epoch and becomes a no-op, while `c` still correctly names the room actually being closed.
  ++sessionEpoch;
  // Detach and invalidate before closing (see enter()): a reentrant close callback must land
  // after `stream` is already cleared, not before it.
  const oldStream = stream; stream = null;
  snap = null; cred = null; temporarySeat = false;
  resetTabooLocal();
  resetFeudLocal();
  resetImpLocal();
  resetBluffLocal();
  if (local.erAuthKey) erReset();
  if (local.waAuthKey) waReset();
  resetRulesLocal();
  if (oldStream) oldStream.close();
  clearCredential('player', c, isSim);
  connBanner('live');
  history.replaceState(null, '', pageUrl('play.html'));
  mount(app,
    h('header', { class: 'topbar' }, h('a', { class: 'brand', href: pageUrl('index.html'), text: 'majlis.' })),
    h('main', { class: 'page narrow stack' },
      h('section', { class: 'card stack center-text', role: 'alert' },
        h('h1', { class: 'card-title', text: 'Room closed' }),
        h('p', { text: 'The host closed room ' + c + '. Thanks for playing!' }),
        h('button', { class: 'btn btn-pri', type: 'button', onclick: () => renderJoin(), text: 'Join another room' }))));
}

function myScore() {
  const me = snap.self && (snap.players || []).find(p => p.id === snap.self.id);
  return me ? me.score : 0;
}

// ---- render ----------------------------------------------------------------------------

function header() {
  return h('header', { class: 'topbar' },
    h('span', { class: 'brand', text: 'majlis.' }),
    h('span', { class: 'code-chip', 'aria-label': 'Room code ' + snap.code, text: snap.code }),
    h('span', { class: 'me-chip', dir: 'auto', text: snap.self ? snap.self.name + ' · ' + myScore() : '' }));
}

// Accessible, concise, and stays up for as long as this seat has no durable copy: closing or
// reloading the page would lose it, so the player should know before they consider leaving.
function temporarySeatNotice() {
  if (!temporarySeat) return null;
  return h('p', { class: 'muted small', role: 'status', text: 'Temporary seat: you can keep playing, but closing or reloading this page may lose it on this device.' });
}

function render() {
  if (!snap) return;
  // Any branch other than taboo() itself skips that function's own draft/epoch/authority
  // bookkeeping — a terminal screen, the lobby for the next game, or a different mode entirely.
  // Without this, a taboo guess request left in flight when the player's view moves on (room
  // ends, next game starts, mode changes) stays bound to module-level `local` state that no
  // later taboo() call is guaranteed to revisit and reset before its response arrives.
  const entersTaboo = snap.mode === 'taboo' && snap.phase !== 'lobby' && snap.phase !== 'ended';
  if (!entersTaboo && local.tabooEpoch !== null) resetTabooLocal();
  // Centralized authority-transition invalidation before mode dispatch: escapeRoom()'s own
  // authKey diff (erReset() on any authKey change) only runs while THIS render routes to
  // escapeRoom() below. A mode switch away from escape_room to a sibling mode (room.set_mode
  // while a player still holds stale escape-room draft/error/pending state) skips that branch
  // entirely, so the private state would otherwise survive — visibly or not — until some future
  // re-entry into escape_room ever calls escapeRoom() again to notice the authKey moved. Clearing
  // it here, before body is chosen for ANY mode (including lobby/ended, already covered by
  // onSnapshot's own eager reset, so this is a no-op there), covers that one remaining gap without
  // duplicating the lobby/ended/leave/closedByHost/fatal-status resets already in place elsewhere.
  if (local.erAuthKey && snap.mode !== 'escape_room') erReset();
  // Same gap as above, for feud: a mode switch away from feud while a buzz is pending must drop
  // that ownership immediately rather than waiting for some future re-entry into feud() to notice
  // its own authKey moved (which, after a mode change, may never happen again this session).
  // `mode` alone misses a lobby/ended excursion that leaves `snap.mode` at 'feud' the whole time
  // (the host can return to the same game without ever switching modes): without also checking
  // phase here, a same-identity playing -> lobby/ended -> playing round trip never resets, so
  // feud()'s own authKey diff later sees every field (room/round/seat/credential) back to the
  // exact values a retired pending/failed buzz already captured and treats it as still current.
  if (local.feudAuthKey && (snap.mode !== 'feud' || snap.phase === 'lobby' || snap.phase === 'ended')) resetFeudLocal();
  // Same centralized invalidation for Who Am I's own guess/ready request-ownership state: a mode
  // switch away from who_am_i (room.set_mode while a pending request or draft is still held) skips
  // whoAmI() entirely below, so its own authKey diff would never run again for this game.
  if (local.waAuthKey && snap.mode !== 'who_am_i') waReset();
  // Same centralized invalidation for the Impostor role card, mirroring feudAuthKey above: a mode
  // switch away from impostor (room.set_mode while a reveal is still held) skips impostor()
  // entirely below, so its own impCardKey diff would never run again for this game to notice the
  // card is stale. `mode` alone also misses a lobby/ended excursion that leaves snap.mode at
  // 'impostor' the whole time (a replay or "play again" loop) — render() routes lobby/ended phases
  // to lobby()/ended() instead of impostor(), so impostor()'s own diff never runs during that
  // excursion either; checking phase here closes that gap too.
  if (local.impCardKey && (snap.mode !== 'impostor' || snap.phase === 'lobby' || snap.phase === 'ended')) resetImpCardReveal();
  // Same centralized invalidation for Bluff's pending-submission ownership: a mode switch away
  // from bluff (room.set_mode while a submit request is in flight) skips bluff() entirely below,
  // so its own roundId diff would never run again for this game to notice the submission is
  // stale. `mode` alone also misses a lobby/ended excursion that leaves snap.mode at 'bluff' the
  // whole time (a replay or "play again" loop) — render() routes lobby/ended phases to
  // lobby()/ended() instead of bluff(), so bluff()'s own diff never runs during that excursion
  // either; checking phase here closes that gap too, same as feud/impostor above.
  if (local.bluffRound !== null && (snap.mode !== 'bluff' || snap.phase === 'lobby' || snap.phase === 'ended')) resetBluffLocal();
  // Same centralized invalidation for the how-to-play disclosure: a room re-entry already cleared
  // it in enter(), so this covers the one remaining case — the host replacing the selected/active
  // mode (room.set_mode) while this phone stays in the same session. Phase alone (lobby <->
  // playing <-> paused for the SAME mode) must never reset it, so the key omits phase/round.
  const rulesKey = code + '|' + snap.mode;
  if (local.rulesAuthKey !== null && local.rulesAuthKey !== rulesKey) local.rulesOpen = false;
  local.rulesAuthKey = rulesKey;
  local.rulesGen++;
  let body;
  if (snap.phase === 'lobby') body = lobby();
  else if (snap.phase === 'ended') body = ended();
  else if (snap.mode === 'who_am_i') body = whoAmI();
  else if (snap.mode === 'feud') body = feud();
  else if (snap.mode === 'impostor') body = impostor();
  else if (snap.mode === 'taboo') body = taboo();
  else if (snap.mode === 'bluff') body = bluff();
  else if (snap.mode === 'escape_room') body = escapeRoom();
  else body = h('p', { text: 'This game is not playable yet.' });
  const paused = snap.phase === 'paused';
  const top = header(), main = h('main', { class: 'page narrow pl-page', inert: paused }, temporarySeatNotice(), body);
  if (paused) top.inert = true; // nothing behind the pause notice is operable
  preserveFocus(app, () => mount(app, top, main, paused ? pausedOverlay() : null));
  trackBuzzSpace();
}

// --buzz-space follows the sticky buzzer's real height so scrolling and focus keep answers and
// scores clear of it (fallback in CSS when ResizeObserver is missing).
let buzzObserver = null, buzzWatched = null;
function trackBuzzSpace() {
  const wrap = app.querySelector('.buzz-wrap');
  if (wrap === buzzWatched || typeof ResizeObserver === 'undefined') return;
  if (!buzzObserver) buzzObserver = new ResizeObserver(() => {
    if (buzzWatched && buzzWatched.isConnected) document.documentElement.style.setProperty('--buzz-space', Math.ceil(buzzWatched.getBoundingClientRect().height) + 'px');
  });
  if (buzzWatched) buzzObserver.unobserve(buzzWatched);
  buzzWatched = wrap;
  if (wrap) buzzObserver.observe(wrap);
}

function lobby() {
  const m = snap.mode ? modeInfo(snap.mode) : null;
  return h('div', { class: 'stack' },
    h('section', { class: 'card center-text' },
      h('div', { class: 'big-emoji', 'aria-hidden': 'true', text: '✓' }),
      h('h1', { class: 'card-title', dir: 'auto', text: 'You’re in, ' + (snap.self ? snap.self.name : '') + '!' }),
      h('p', { class: 'muted', role: 'status', text: m ? 'Next game: ' + m.title + '. Waiting for the host to start…' : 'Waiting for the host to choose a game…' })),
    renderRulesPanel(snap.mode),
    h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'In the room' }), playerChips(snap, { highlight: snap.self && snap.self.id })),
    h('button', { class: 'btn btn-ghost', type: 'button', onclick: async () => { if (await confirmDialog('Leave this screen? Your seat stays in the room, and “Back to room” on this phone brings you back.', { confirmLabel: 'Leave', danger: true })) leave(); }, text: 'Leave room' }));
}

// Server contract (party/server/modes/who_am_i.py project()): game.order/ready/revealed/solved/
// pendingGuesses are the only authoritative player-id lists. A helper that only trusts an id
// present in `order` *and* actually seated in `snap.players` (deduped, non-string entries
// dropped) protects every count/badge below from a malformed snapshot or a duplicate/foreign id
// without inventing new transport shape -- `order` alone was not enough: a planted id absent from
// the roster but merely repeated inside `order` previously still counted as a real member. Kept
// local here, not in views.js, since this change (majlis:whoami-player-round-status-v1) is
// scoped to play.js -- mirrors tv.js's own local copy of the same helpers for the same reason.
function whoAmIOrderSet(g, players) {
  const knownIds = new Set((Array.isArray(players) ? players : []).map(p => p && p.id));
  return new Set(Array.isArray(g.order) ? g.order.filter(id => typeof id === 'string' && knownIds.has(id)) : []);
}
function whoAmIEligibleSet(list, orderSet) {
  const out = new Set();
  if (Array.isArray(list)) for (const id of list) if (typeof id === 'string' && orderSet.has(id)) out.add(id);
  return out;
}
// True only when this player's own identity and server-sent `you` projection are both present,
// and game.order is itself a valid array in which that identity is a qualified (known-roster)
// member. A missing/malformed order can never be treated as "no membership to check" -- without
// an authoritative roster this caller's own membership is unknown, not assumed. Gates the whole
// phase/self status panel below: with no reliable `self`/`you`/order authority the panel must
// never affirmatively invite a live action, claim a round phase, or say "hidden from you", since
// none of that can actually be attributed to this caller.
function whoAmIHasPlayerAuthority(snap, g, orderSet) {
  if (!snap.self || !snap.self.id || typeof snap.self.id !== 'string') return false;
  if (!g.you || typeof g.you !== 'object') return false;
  // "Incomplete" you: the server's who_am_i project() always sends these three booleans together
  // (party/server/modes/who_am_i.py project()); any one missing means this is not the real
  // per-player projection the rest of this panel assumes it can read from.
  if (typeof g.you.revealed !== 'boolean' || typeof g.you.ready !== 'boolean' || typeof g.you.solved !== 'boolean') return false;
  if (!Array.isArray(g.order) || !orderSet.has(snap.self.id)) return false;
  return true;
}

// Truthful round-number label: only a positive integer round is ever shown; a missing/malformed
// value gives neutral unavailable text rather than fabricating a round or silently omitting it.
function whoAmIRoundLabel(g) {
  return Number.isInteger(g.round) && g.round > 0 ? 'Round ' + g.round : 'Round unavailable';
}

// This player's own progress, independent of room/round phase: the most definitive true fact
// about their own projection wins. Precedence (most to least definitive): solved > revealed-but-
// unsolved > guess awaiting the host > ready > hidden-and-asking. Reads only `you`/`myGuess`,
// already the authoritative per-player projection -- never infers a hidden character, an award or
// a remaining-rounds count from a missing field. `hasAuthority` (see whoAmIHasPlayerAuthority)
// must be checked first: with no reliable self/you projection, "Hidden from you." is itself an
// unearned claim about this caller's own state, not a safe default.
function whoAmISelfStateText(you, myGuess, hasAuthority) {
  if (!hasAuthority) return 'Waiting for your status.';
  if (you.solved) return 'You solved it!';
  if (you.revealed) return 'Your character was revealed.';
  if (myGuess !== null) return 'Your guess is with the host.';
  if (you.ready) return 'You’re ready.';
  return 'Hidden from you.';
}

// Room/round phase guidance. Paused always wins over every other phase text, even mid-round (same
// precedent as tv.js's whoAmIPhaseText and views.js's tabooStatusPanel): this is the one line that
// could otherwise wrongly invite a live action while the host has the room on hold. Past that,
// whoAmI() is only ever mounted once snap.phase has already resolved to 'playing' or 'paused' (see
// render()'s lobby()/ended() dispatch above); a `snap.phase` reading anything else here is itself
// an unknown/invalid room authority, not a legitimate third state, and -- like a missing/incomplete
// self/you projection -- must not be trusted enough to claim a live round phase. After a full
// reveal or game end this says the host advances the game -- never implies a player control exists
// here.
function whoAmIPhaseGuidance(snap, hasAuthority) {
  if (snap.phase === 'paused') return 'Paused by the host.';
  if (!hasAuthority || snap.phase !== 'playing') return 'Waiting for the host.';
  switch ((snap.game || {}).roundPhase) {
    case 'asking': return 'Ask yes/no questions aloud to work it out.';
    case 'revealed': return 'This round is over. The host will start the next round.';
    case 'ended': return 'The game has ended.';
    default: return 'Waiting for the host.';
  }
}

// Labelled, honest public progress: solved and pending-guess counts, out of the unique known-
// roster size from game.order (see whoAmIOrderSet -- a foreign id present in `order` but absent
// from snap.players counts toward neither the numerator nor the denominator). Returns null (omit
// the whole panel) when game.order itself is missing/malformed -- an absent authoritative roster
// is not a valid zero. A non-empty order needs snap.players itself to be a real, non-empty roster
// list to look members up against; a missing/empty players list alongside a non-empty order is an
// inconsistent/unavailable roster authority, not a genuine zero, so every count reads
// "unavailable" rather than a fabricated "0 of 0". An explicitly empty order, by contrast, is
// itself the real denominator (0) regardless of players. Once the roster authority is
// established, a missing/malformed individual list still reads "unavailable" rather than a
// fabricated zero; an explicit empty array for a list present alongside a valid roster is a real,
// valid zero. Solved/pending stay distinct counts (never merged with each other or with
// revealed-but-unsolved, which the roster below shows per player instead).
function whoAmIProgressItems(g, players) {
  if (!Array.isArray(g.order)) return null;
  if (g.order.length > 0 && !(Array.isArray(players) && players.length > 0)) {
    return [
      { label: 'Solved', value: 'unavailable' },
      { label: 'Guesses awaiting the host', value: 'unavailable' },
    ];
  }
  const orderSet = whoAmIOrderSet(g, players);
  const total = orderSet.size;
  const count = list => Array.isArray(list) ? String(whoAmIEligibleSet(list, orderSet).size) + ' of ' + total : 'unavailable';
  return [
    { label: 'Solved', value: count(g.solved) },
    { label: 'Guesses awaiting the host', value: count(g.pendingGuesses) },
  ];
}

// Local "Unknown player" fallback for a missing/blank roster name -- never the raw internal id.
// A whitespace-only name (e.g. a stray " ") is treated the same as blank, not rendered verbatim
// as an empty-looking card heading. Distinct from ui.js's playerName() (which returns "A player"
// only for a wholly unknown id and does not treat a blank-but-present name as missing); kept local
// to this narrowly scoped change.
function whoAmIDisplayName(snap, pid) {
  const p = (snap.players || []).find(x => x.id === pid);
  const hasName = p && p.name != null && String(p.name).trim() !== '';
  return hasName ? String(p.name) : 'Unknown player';
}

function whoAmI() {
  const g = snap.game || {};
  const me = snap.self ? snap.self.id : null;
  const you = g.you || {};
  const orderSet = whoAmIOrderSet(g, snap.players);
  const hasAuthority = whoAmIHasPlayerAuthority(snap, g, orderSet);
  const solved = whoAmIEligibleSet(g.solved, orderSet);
  const pending = whoAmIEligibleSet(g.pendingGuesses, orderSet);
  const revealedSet = whoAmIEligibleSet(g.revealed, orderSet);
  const ready = whoAmIEligibleSet(g.ready, orderSet);
  const asking = g.roundPhase === 'asking';
  const assignments = g.assignments || {};
  // Own card: rendered from the projection only. `you.assignment` exists only after this player
  // is revealed; before that the server sends nothing about it.
  const mine = you.assignment || null;
  // Centralized authority-transition invalidation (see waAuthKey/waReset): any genuine authority
  // change retires an outstanding guess/ready request and its draft, even one whose captured
  // fields will later read identically again (pause+resume, a round that loops back to a value).
  const waKey = waAuthKey(snap, you);
  if (local.waAuthKey !== waKey) { waReset(); local.waAuthKey = waKey; }
  // A pending guess that disappears without a reveal was cleared by the host as wrong.
  if (local.guessRound !== snap.roundId) { local.guessRound = snap.roundId; local.lastGuess = undefined; local.guessError = ''; }
  const myGuess = you.guess === undefined ? null : you.guess;
  if (local.lastGuess !== undefined && local.lastGuess !== null && myGuess === null && !you.revealed && !you.solved) {
    announce('Not quite. The host cleared your guess. Try again.', { assertive: true });
    local.guessError = 'Not quite – the host cleared your guess. Try again.';
  }
  if (myGuess !== null) local.guessError = '';
  local.lastGuess = myGuess;
  const myCard = h('section', { class: 'card my-card' + (mine ? ' revealed' : ''), 'aria-label': 'Your character' },
    h('div', { class: 'eyebrow', text: 'Your character' }),
    mine
      ? [h('div', { class: 'char-big', dir: 'auto', text: mine.label }), mine.ar ? h('div', { class: 'char-ar', lang: 'ar', dir: 'rtl', text: mine.ar }) : null,
        you.solved ? h('p', { class: 'status-line', text: 'You got it!' }) : null]
      : [h('div', { class: 'mystery', 'aria-hidden': 'true', text: '?' }), h('p', { class: 'muted', text: 'Hidden from you. Ask yes/no questions to work it out.' })]);
  // Deduped defensively: the server never sends a duplicate id in `order`, but a list built
  // straight from it would double-render a planted repeat rather than merely miscounting it.
  const others = Array.from(new Set(g.order || Object.keys(assignments))).filter(pid => pid !== me && assignments[pid]);
  // Precedence mirrors whoAmISelfStateText above: solved > revealed-but-unsolved > guessing >
  // ready. Revealed-but-unsolved (that player now knows their own character but the host has not
  // awarded it) previously had no badge at all; a pending guess and a revealed player can never
  // coincide (the server refuses whoami.guess once a player is revealed), so this ordering is for
  // readability, not to break a tie that can actually occur.
  const list = h('ul', { class: 'who-cards' }, others.map(pid => h('li', { class: 'who-card' + (solved.has(pid) ? ' solved' : '') },
    h('span', { class: 'who-name', dir: 'auto', text: whoAmIDisplayName(snap, pid) }),
    h('span', { class: 'char-label', dir: 'auto', text: assignments[pid].label }),
    assignments[pid].ar ? h('span', { class: 'char-ar', lang: 'ar', dir: 'rtl', text: assignments[pid].ar }) : null,
    solved.has(pid) ? h('span', { class: 'badge-good', text: 'Solved' })
      : revealedSet.has(pid) ? h('span', { class: 'badge-info', text: 'Revealed' })
      : pending.has(pid) ? h('span', { class: 'badge-warn', text: 'Guessing' })
      : ready.has(pid) ? h('span', { class: 'badge-later', text: 'Ready' }) : null)));
  let guessUi = null;
  if (asking && !you.revealed && !you.solved) {
    // Full guess/ready authority, captured once at build time (not re-read live at submit/click
    // time) — see escapeRoom()'s `authority`/`isLiveAuthority` for the same pattern and why it
    // matters: a control kept alive past its own round/room/phase/seat/credential/reveal/solve (a
    // detached DOM node, a focus-preservation reattach, a reconnect that re-authenticates the
    // seat) must refuse to dispatch, and a completion that arrives after any of this changed must
    // not touch local/UI state. `gen` guards the ABA case plain field-equality misses (e.g. a
    // pause+resume returning every other field to the exact value this control captured): waReset()
    // always moves it forward on any genuine authority change, so a control from before that
    // change can never match again.
    const authority = { code: snap.code, mode: snap.mode, roomPhase: snap.phase, roundId: snap.roundId,
      seatId: snap.self && snap.self.id, credToken: cred && cred.token, gameRoundPhase: g.roundPhase,
      youRevealed: !!you.revealed, youSolved: !!you.solved, gen: local.waGen };
    const isLiveAuthority = () => {
      const liveYou = (snap && snap.game && snap.game.you) || {};
      return !!snap && snap.code === authority.code && snap.mode === authority.mode
        && snap.phase === authority.roomPhase && snap.roundId === authority.roundId
        && (snap.self && snap.self.id) === authority.seatId && (cred && cred.token) === authority.credToken
        && (snap.game && snap.game.roundPhase) === authority.gameRoundPhase
        && !!liveYou.revealed === authority.youRevealed && !!liveYou.solved === authority.youSolved
        && local.waGen === authority.gen;
    };
    // Admission-only checks (run once, synchronously, before any request starts): every render()
    // replaces this mode's whole DOM subtree (mount() -> replaceChildren, no node reuse), so a
    // detached control is always from a PRIOR render, never the one currently on screen.
    // isLiveAuthority()'s value-equality alone cannot catch that.
    const canAdmitGuess = () => form.isConnected && !form.closest('[inert]') && isLiveAuthority();
    const canAdmitReady = () => readyBtn.isConnected && !readyBtn.closest('[inert]') && isLiveAuthority();

    // The guess is free text (1-80 characters) that only the host and this player ever see.
    // Sending a new one replaces the pending one.
    const sendingGuess = local.waGuessPending;
    // This closure's own captured gen, compared against local.waGen at *event* time (not build
    // time, when they always match): a control from a build that waReset() has since retired
    // (round/phase/seat/credential/reveal/solve change) keeps firing its old 'input' listener as
    // long as it stays referenced (e.g. a reproducer that holds onto the detached node), and must
    // not go on writing into the draft that a newer authority's render now owns.
    const inputGen = local.waGen;
    const inp = h('input', { id: 'guess', maxlength: 80, required: true, dir: 'auto', autocomplete: 'off', placeholder: 'I think I am…', value: local.guessDraft,
      disabled: sendingGuess, 'aria-describedby': 'guess-help guess-error',
      oninput: e => { if (local.waGen !== inputGen) return; local.guessDraft = e.target.value; } });
    const btn = h('button', { class: 'btn btn-pri', type: 'submit', disabled: sendingGuess,
      text: sendingGuess ? 'Sending…' : myGuess !== null ? 'Change guess' : 'Send guess' });
    const errEl = h('p', { class: 'form-error', id: 'guess-error', role: 'alert', text: local.guessError });
    const form = h('form', { class: 'guess-form', novalidate: true, onsubmit: async e => {
      e.preventDefault();
      if (local.waGuessPending || !canAdmitGuess()) return; // stale/detached/inert/non-asking form: refuse to send
      const text = inp.value.replace(/\s+/g, ' ').trim();
      if (!text) { local.guessError = 'Type who you think you are first.'; errEl.textContent = local.guessError; inp.focus(); return; }
      // Scope this reply to its own request: a waAuthKey-triggered waReset() already forces
      // waGuessPending back to false (so a brand-new request can start under a new authority)
      // without waiting for this request's reply, so a bare `local.waGuessPending = false` on
      // completion could clobber a newer, still-unresolved request's pending flag. Only the reply
      // whose reqId still owns `waGuessPendingReqId` may touch pending/draft/error/toast at all.
      const reqId = (local.waGuessReqSeq = (local.waGuessReqSeq || 0) + 1);
      local.waGuessPending = true; local.waGuessPendingReqId = reqId; render();
      const isCurrentRequest = () => isLiveAuthority() && local.waGuessPendingReqId === reqId;
      // Pass this control's own captured authority through explicitly: act()'s default live-global
      // read (code/cred.token/snap.roundId) would re-read whatever the page has moved on to by the
      // time this POST actually dispatches, not what this request was admitted under.
      const r = await act('whoami.guess', { text }, btn, null, isCurrentRequest, authority);
      const stillOwner = local.waGuessPendingReqId === reqId;
      if (stillOwner) { local.waGuessPending = false; local.waGuessPendingReqId = null; }
      // A snapshot that moved this player on while this was in flight (round/phase/seat/credential
      // change, reveal, solve, leave, close, fatal, pause/resume) already re-rendered this page
      // under a new authority (or a newer request already claimed pending); applying a stale
      // success/clear here would fight that render, and `snap` may already be null (leave/
      // closedByHost), so this is checked before any dereference.
      if (!stillOwner || !isLiveAuthority()) { render(); return; }
      // Clear only the draft version this completion actually covers: an edit typed after send
      // (still under the same authority, so admitted by the oninput guard above) has already moved
      // local.guessDraft past `text`, and an accepted reply for the older text must not erase it.
      if (r && r.accepted) { if (local.guessDraft === text) local.guessDraft = ''; local.guessError = ''; }
      render();
    } }, h('label', { for: 'guess', class: 'small', text: 'Your guess' }), inp, btn);

    // Ready intent is serialized (at most one outstanding ready mutation) and, while pending,
    // displayed as its own actual requested (target) state rather than the possibly-stale
    // rendered `you.ready` — toggling off that stale value, instead of the in-flight target,
    // is what let a rapid double-tap send the same direction twice instead of the intended
    // toggle-then-undo.
    const sendingReady = local.waReadyPending;
    const readyTarget = sendingReady ? local.waReadyDesired : !!you.ready;
    const readyBtn = h('button', { class: 'btn btn-ghost', type: 'button', disabled: sendingReady,
      'aria-pressed': readyTarget ? 'true' : 'false', 'aria-busy': sendingReady ? 'true' : 'false',
      onclick: () => {
        if (local.waReadyPending || !canAdmitReady()) return; // stale/detached/inert/non-asking control: refuse to send
        const desired = !readyTarget;
        const reqId = (local.waReadyReqSeq = (local.waReadyReqSeq || 0) + 1);
        local.waReadyPending = true; local.waReadyPendingReqId = reqId; local.waReadyDesired = desired; render();
        const isCurrentRequest = () => isLiveAuthority() && local.waReadyPendingReqId === reqId;
        act('whoami.ready', { ready: desired }, readyBtn, null, isCurrentRequest, authority).then(() => {
          const stillOwner = local.waReadyPendingReqId === reqId;
          if (stillOwner) { local.waReadyPending = false; local.waReadyPendingReqId = null; local.waReadyDesired = null; }
          render();
        });
      },
      text: sendingReady ? 'Sending…' : readyTarget ? 'Ready ✓ (tap to undo)' : 'I’m ready' });
    guessUi = h('section', { class: 'card stack guess-card' },
      myGuess !== null ? h('p', { class: 'status-line', role: 'status', dir: 'auto', text: 'Your guess “' + myGuess + '” is with the host. Say it out loud!' }) : null,
      form, errEl,
      h('p', { class: 'muted small', id: 'guess-help', text: 'Only the host sees your guess. “I’m ready” just tells the host you are ready; it sends no guess.' }),
      readyBtn);
  }
  const progressItems = whoAmIProgressItems(g, snap.players);
  return h('div', { class: 'stack' },
    modeHeading(snap),
    renderRulesPanel('who_am_i'),
    h('section', { class: 'card stack whoami-status', 'aria-label': 'Round status' },
      h('div', { class: 'whoami-status-row' }, h('span', { class: 'eyebrow', text: 'Round' }), h('span', { class: 'status-line', text: whoAmIRoundLabel(g) })),
      h('p', { class: 'status-line', role: 'status', text: whoAmIPhaseGuidance(snap, hasAuthority) }),
      h('p', { class: 'muted small', text: whoAmISelfStateText(you, myGuess, hasAuthority) })),
    myCard,
    guessUi,
    progressItems ? h('section', { class: 'card whoami-progress', 'aria-label': 'Public round progress' },
      h('h2', { class: 'card-title', text: 'Round progress' }),
      progressItems.map(it => h('div', { class: 'whoami-progress-item' },
        h('span', { class: 'eyebrow', text: it.label }), h('span', { class: 'status-line', text: it.value })))) : null,
    h('section', { class: 'card' },
      h('h2', { class: 'card-title', text: asking ? 'Everyone else' : 'Everyone’s characters' }),
      others.length ? list : h('p', { class: 'muted', text: 'Waiting for characters…' })),
    scoreboard(snap, { selfId: me }));
}

// Dispatches a buzz admitted under `authority` (captured once, at this exact render, by feud()
// below), using `canAdmit`/`isLiveAuthority` closures built from the same live globals every
// other `act()` caller reads, and `btn` so withBusy() disables/restores the real button this tap
// came from. Binds the request to its own reqId: only the reply whose reqId still owns
// `buzzPendingReqId` may clear pending state, show retry guidance, or (indirectly, through
// `isCurrentRequest`/`authority` passed to act()) toast/suppress-toast and reach the transport
// under this request's own captured room/credential/round rather than whatever the live globals
// have moved on to by the time the POST actually resolves. A retired reply never rerenders a
// retired screen: see the early return below, mirroring escapeRoom()'s isCurrentRequest gate.
async function sendBuzz(authority, isLiveAuthority, canAdmit, btn) {
  if (local.buzzPending || !canAdmit()) return;
  const reqId = (local.buzzReqSeq = (local.buzzReqSeq || 0) + 1);
  local.buzzPending = true; local.buzzPendingReqId = reqId; local.buzzFailure = null; vibrate(20); render();
  const isCurrentRequest = () => isLiveAuthority() && local.buzzPendingReqId === reqId;
  // Losing a race (buzzer_taken/buzzer_closed) is not an error: the buzzer itself turns into
  // "<winner> buzzed first" (and it is announced), so a toast would only linger and could
  // contradict the next round's result. Any other rejection/timeout is a genuinely uncertain
  // outcome and gets its own accessible retry guidance below instead of a transient toast.
  const r = await act('feud.buzz', {}, btn, ['buzzer_taken', 'buzzer_closed'], isCurrentRequest, authority);
  // A newer request, or an authority transition, already owns whatever is on screen now (its own
  // sendBuzz call, or resetFeudLocal(), already rendered that screen). A retired reply must never
  // rerender it: render() always replaces this mode's whole DOM subtree (see ui.js's mount()), so
  // even a no-op rerender here would disconnect the newer pending/failed screen's live nodes —
  // exactly the "stale completion replaces newer DOM" defect this gate exists to prevent.
  if (!isCurrentRequest()) return;
  local.buzzPending = false; local.buzzPendingReqId = null;
  if (r && !r.accepted && r.error !== 'buzzer_taken' && r.error !== 'buzzer_closed') {
    local.buzzFailure = { reqId, text: describeError(r.error) };
  }
  render();
}

function feud() {
  const g = snap.game || {};
  const me = snap.self ? snap.self.id : null;
  const spectating = snap.role === 'spectator' || (snap.self && snap.self.spectator === true);
  // Bind buzz ownership to this room, this device's credential/seat and this round — not round
  // alone — so a room/credential/seat replacement (including a replacement session for the same
  // room, or a pause/resume ABA, which moves snap.phase away and back) invalidates a pending/
  // failed buzz even when other fields happen to coincide with the previous identity. The counter
  // in resetFeudLocal() (not just this key) is what completion time actually checks, since a
  // round trip back to an identical key string can't be told apart from "never left" otherwise.
  const authKey = [code, snap.mode, snap.phase, snap.roundId, me, cred && cred.token].join('|');
  if (local.feudAuthKey !== authKey) { resetFeudLocal(); local.feudAuthKey = authKey; }
  const winner = g.buzzer && g.buzzer.winner;
  let state, label, sub;
  if (local.buzzPending && !winner) { state = 'sending'; label = 'Sending…'; sub = 'Waiting for the server to decide who was first.'; }
  else if (winner === me) { state = 'won'; label = 'You buzzed first!'; sub = 'Say your answer out loud.'; }
  else if (winner) { state = 'lost'; label = playerName(snap, winner); sub = 'buzzed first.'; }
  else if (!spectating && g.roundPhase === 'buzzer_open' && g.buzzer && g.buzzer.open) { state = 'open'; label = 'BUZZ!'; sub = 'Tap as fast as you can.'; }
  else { state = 'locked'; label = 'Buzzer locked'; sub = g.roundPhase === 'awarded' ? 'Round over.' : spectating ? 'You’re watching this game.' : 'Wait for the host to open it.'; }
  // During a steal the face follows control, not the original buzz winner.
  if (g.roundPhase === 'steal' && g.control) {
    if (g.control === me) { state = 'won'; label = 'Steal!'; sub = 'Your chance to steal! Say your answer.'; }
    else { state = 'lost'; label = playerName(snap, g.control); sub = 'is trying to steal.'; }
  }
  // Captured once, at this exact render, under this render's own authKey/gen — never re-read live
  // at dispatch/completion time (see escapeRoom()'s `authority`/`isLiveAuthority` for the same
  // pattern and its rationale). `buzz` is referenced inside its own event handlers below via
  // closure, after the const is fully assigned by the time those handlers actually run.
  const authority = { code: snap.code, mode: snap.mode, roomPhase: snap.phase, roundId: snap.roundId, seatId: me, credToken: cred && cred.token, gen: local.feudGen };
  const isLiveAuthority = () => !!snap && snap.code === authority.code && snap.mode === authority.mode
    && snap.phase === authority.roomPhase && snap.roundId === authority.roundId
    && (snap.self && snap.self.id) === authority.seatId && (cred && cred.token) === authority.credToken
    && local.feudGen === authority.gen;
  // Live eligibility re-derived from the current globals rather than trusting this render's own
  // (possibly stale) `g`/`state`/`spectating`. `role` is checked here (not just `self.spectator`)
  // because a spectator rendering with no `self.spectator` marker still renders locked, but a
  // retained pointer/click callback built off this closure must refuse to dispatch too, or the
  // dispatch predicate disagrees with what the screen itself shows as eligible.
  const liveEligible = () => !!snap && snap.phase === 'playing' && snap.mode === 'feud'
    && !!snap.self && snap.role !== 'spectator' && !snap.self.spectator && !!snap.game && snap.game.roundPhase === 'buzzer_open'
    && !!(snap.game.buzzer && snap.game.buzzer.open) && isLiveAuthority();
  // Admission check for an actual dispatch, run synchronously before a request starts (never at
  // completion time — see isLiveAuthority/isCurrentRequest in sendBuzz for that). A retained
  // button from a prior render is always detached (render() replaces this mode's whole DOM
  // subtree — see ui.js's mount()), so `buzz.isConnected` catches that on top of `liveEligible()`.
  // Only usable once `buzz` itself is mounted; the retry button below uses `liveEligible()` alone,
  // since it is evaluated here, before mount(), while `buzz` (even the one from THIS render) is
  // still unconnected — checking isConnected there would make it permanently disabled.
  const canAdmit = () => buzz.isConnected && liveEligible();
  const buzz = h('button', { id: 'buzzer', class: 'buzzer state-' + state, type: 'button', disabled: state !== 'open', 'aria-describedby': 'buzz-sub', 'aria-busy': state === 'sending' ? 'true' : null,
    // Buzz on press, not on release: a snapshot that arrives while the finger is down re-renders
    // this button, and a release on a replaced node never becomes a click, so a click-only buzzer
    // can silently drop a tap that was in time. Keyboard and assistive-technology activation still
    // arrive as a click; a click right after a press is the same tap and is ignored.
    onpointerdown: e => { if (e.isPrimary && e.button === 0 && buzz.isConnected) { local.buzzPressAt = performance.now(); sendBuzz(authority, isLiveAuthority, canAdmit, buzz); } },
    onclick: () => { if (performance.now() - (local.buzzPressAt || -1e9) > 1500) sendBuzz(authority, isLiveAuthority, canAdmit, buzz); },
  }, h('span', { class: 'buzz-label', dir: 'auto', text: label }));
  // Announce and vibrate once per server-decided winner (never for a local guess).
  const winKey = winner ? snap.roundId + ':' + winner : null;
  let winnerJustAnnounced = false;
  if (winKey && local.lastWin !== winKey) {
    const first = local.lastWin === null && !local.buzzSeen;
    local.lastWin = winKey;
    if (!first) {
      winnerJustAnnounced = true;
      if (winner === me) { vibrate([40, 50, 40]); announce('You buzzed first! Say your answer.', { assertive: true }); }
      else { vibrate(20); announce(playerName(snap, winner) + ' buzzed first.', { assertive: true }); }
    }
  }
  local.buzzSeen = true;
  const changes = feudChanges.diff(snap);
  announceFeudChanges(changes, g, announce);
  // Polite, deduplicated status-panel announcement: fires only on a real transition seen while
  // this screen was already up (never on first mount/reconnect, matching buzzSeen's own guard
  // above), and is skipped for this render when the winner-decided path above just made its own
  // assertive announcement for the same transition — never two live-region messages for one event.
  const statusText = feudPlayerStatusText(snap, { spectating });
  if (local.feudStatusSeen && local.feudStatusText !== statusText && !winnerJustAnnounced) announce(statusText);
  local.feudStatusText = statusText;
  local.feudStatusSeen = true;
  // Accessible, current-request-only retry guidance: shown only while the failed attempt it
  // belongs to is still the one this screen reflects (no server-decided winner has since
  // explained the outcome, and no newer press/authority transition has cleared it — both already
  // drop buzzFailure above/in resetFeudLocal()). Ordinary lost/closed races never reach here (see
  // sendBuzz's quiet-error check), so this never contradicts the authoritative winner/locked text.
  // Retry is only offered while the live snapshot would actually admit a fresh press right now.
  const failure = (local.buzzFailure && !winner)
    ? h('div', { class: 'form-error buzz-failure', role: 'alert' },
      h('p', { text: local.buzzFailure.text }),
      h('button', { class: 'btn btn-sec btn-sm', type: 'button', disabled: !liveEligible(),
        onclick: () => { sendBuzz(authority, isLiveAuthority, canAdmit, buzz); },
        text: 'Try again' }))
    : null;
  return h('div', { class: 'stack pl-feud' },
    h('div', { class: 'stack feud-content' },
      modeHeading(snap),
      renderRulesPanel('feud'),
      feudBoard(g, { changes }),
      feudPlayerStatusPanel(snap, { spectating }),
      scoreboard(snap, { selfId: me })),
    h('div', { class: 'buzz-wrap' }, buzz, h('p', { id: 'buzz-sub', class: 'buzz-sub', dir: 'auto', text: sub }), failure));
}

// ---- Impostor ------------------------------------------------------------------------------

function impostor() {
  const g = snap.game || {};
  const me = snap.self ? snap.self.id : null;
  const you = g.you || {};
  const phase = g.roundPhase;
  const votes = g.votes || {};
  if (local.impRound !== snap.roundId) { local.impRound = snap.roundId; local.impostorGuessDraft = ''; }
  const myVote = votes[me];

  // This device's own role-card authority identity: room, credential/seat and round — not
  // roundPhase, so moving between discussion/vote/guess_word within the same round (this
  // player's role never changes mid-round) is an ordinary same-authority snapshot that must
  // preserve an already-active reveal, per the brief. `you.role` absent means a spectator or any
  // viewer the engine never sent a `you` projection to (see party/core/majlis-core.js project(),
  // which omits `you` entirely for every non-"player" viewer) — never fabricate a role for them.
  // Eligibility (room actually playing + document visible + connection live) gates the key the
  // same way Taboo's giverKey does: a passive snapshot delivered while hidden, disconnected or
  // paused must not keep (or reconstruct) a usable key, so impCardPanel below can neither offer
  // nor retain a reveal without this device actually holding a live, visible, connected round.
  const impCardKey = (!!you.role && snap.phase === 'playing' &&
    local.impCardEligible !== false && local.impCardVisible !== false && !document.hidden)
    ? (code + ':' + (cred ? cred.token : '') + ':' + me + ':' + snap.roundId) : null;
  if (impCardKey !== local.impCardKey) { resetImpCardReveal(); local.impCardKey = impCardKey; }

  // Same discipline as bluff()'s own spectating check above: `you.role` is already absent for any
  // non-"player" viewer (project() never sends `you` to them), so this mirrors the roleCard branch
  // just below rather than re-deriving a second, possibly-disagreeing signal.
  const spectating = !you.role;

  const roleCard = you.role
    ? impCardPanel(you, impCardKey)
    : h('section', { class: 'card stack my-card', 'aria-label': 'Your role' },
        h('div', { class: 'eyebrow', text: 'Your role' }),
        h('p', { class: 'muted small', role: 'status', text: 'You’re watching this game. You don’t have a role to reveal.' }));

  // Accessible, labelled phase guidance and authoritative vote progress (majlis:impostor-player-
  // round-status-v1): covers discussion/vote/guess_word/reveal/ended/paused/unknown entirely on
  // its own, so `body` below is only ever the player-only INTERACTIVE controls (vote buttons, own-
  // vote confirmation, guess form) this panel deliberately leaves out — never a second, possibly
  // disagreeing copy of the same guidance text.
  const statusPanel = impostorPlayerStatusPanel(snap, { spectating });

  let body = null;
  if (phase === 'vote' && !spectating) {
    // A spectator never reaches here (gets the panel's neutral vote-progress text instead): the
    // pre-existing bug this corrects let any spectator see — and click — the full candidate list,
    // since `me` (their own connection id) is simply absent from `g.order`/`votes`, same as a
    // player who has not yet voted.
    const candidates = (g.order || []).filter(pid => pid !== me);
    body = h('section', { class: 'card stack' },
      h('h2', { class: 'card-title', text: 'Who is the impostor?' }),
      myVote !== undefined
        ? h('p', { class: 'status-line', role: 'status', dir: 'auto', text: 'You voted for ' + playerName(snap, myVote) + '. Waiting for the others…' })
        : h('ul', { class: 'who-cards' }, candidates.map(pid => h('li', { class: 'who-card' },
          h('button', { class: 'btn btn-sec', type: 'button', dir: 'auto',
            onclick: e => act('impostor.vote', { playerId: pid }, e.currentTarget, ['already_voted', 'self_vote', 'stale_round']),
            text: playerName(snap, pid) })))));
  } else if (phase === 'guess_word' && you.role === 'impostor') {
    const inp = h('input', { id: 'impostor-guess', maxlength: 80, required: true, dir: 'auto', autocomplete: 'off', placeholder: 'What’s the word?', value: local.impostorGuessDraft,
      oninput: e => { local.impostorGuessDraft = e.target.value; } });
    const btn = h('button', { class: 'btn btn-pri', type: 'submit', text: 'Submit guess' });
    const form = h('form', { class: 'guess-form', novalidate: true, onsubmit: async e => {
      e.preventDefault();
      const text = inp.value.replace(/\s+/g, ' ').trim();
      if (!text) return;
      const r = await act('impostor.guess_word', { text }, btn);
      if (r && r.accepted) local.impostorGuessDraft = '';
    } }, h('label', { for: 'impostor-guess', class: 'small', text: 'You were caught! Guess the word' }), inp, btn);
    body = h('section', { class: 'card stack' }, form);
  } else if (phase === 'reveal' || phase === 'ended') {
    const reveal = g.reveal || {};
    const items = [
      reveal.impostor ? h('p', { dir: 'auto', text: impostorPanelName(snap, reveal.impostor) + ' was the impostor.' }) : null,
      reveal.word ? h('p', { dir: 'auto', text: 'The word was “' + reveal.word + '”.' }) : null,
    ].filter(Boolean);
    body = items.length ? h('section', { class: 'card stack' }, items) : null;
  }
  return h('div', { class: 'stack' }, modeHeading(snap), renderRulesPanel('impostor'), roleCard, statusPanel, body, scoreboard(snap, { selfId: me }));
}

// This player's own Impostor role/word: covered by default so a shoulder-surfer never sees
// "Impostor" or the crew's secret word without this player's own, explicit tap — this is local
// shoulder-surfing assistance only, not a transport or screenshot-security claim. Covered, the
// DOM holds no trace of the role/word at all (no text, no aria-label/aria-describedby/title/
// data-* attribute, nothing in a live region) rather than a CSS-hidden copy, so inspecting the
// connected DOM while covered can never recover it. Mirrors tabooCardPanel() below. `key` is this
// render's impCardKey (null whenever this device has no role to show); `gen` is captured at this
// exact render so the toggle's own closure can tell whether a lifecycle transition retired it
// before it fires (see resetImpCardReveal above) — a stale/detached click arriving after that
// point is a no-op rather than a re-reveal, even if (improbably) it still carries the same key.
function impCardPanel(you, key) {
  const revealed = !!key && local.impCardKey === key && local.impCardRevealed;
  const gen = local.impCardGen;
  // Same id on both the covered and revealed toggle: preserveFocus() (already wrapping every
  // mount(app, ...) in render()) restores focus by id after a reveal/hide re-render, so an
  // explicit toggle lands on its replacement control automatically, and a passive snapshot that
  // leaves the id and revealed state alone never moves focus at all — no extra focus plumbing
  // needed here beyond giving the control a stable id.
  const toggle = h('button', { id: 'impostor-card-toggle', class: 'btn ' + (revealed ? 'btn-sec' : 'btn-pri'), type: 'button', 'aria-pressed': revealed ? 'true' : 'false',
    onclick: () => {
      if (!key || local.impCardKey !== key || local.impCardGen !== gen) return; // retired by a transition since this control was rendered
      const wasRevealed = local.impCardRevealed;
      local.impCardRevealed = !wasRevealed;
      // Explicit Hide (revealed -> covered) must retire this reveal's own gen, not just the
      // lifecycle-transition resets above: otherwise a callback captured while this card was
      // revealed (this toggle's closure, or an earlier one from the same impCardKey) stays
      // authorized under the unchanged gen and can flip impCardRevealed back on by itself,
      // re-exposing the role/word with no fresh explicit reveal. Hiding keeps impCardKey intact
      // so a genuinely fresh Reveal tap right after still works.
      if (wasRevealed) local.impCardGen = (local.impCardGen || 0) + 1;
      render();
    },
    text: revealed ? 'Hide role' : 'Reveal role' });
  if (!revealed) {
    return h('section', { class: 'card stack my-card', 'aria-label': 'Your role' },
      h('div', { class: 'eyebrow', text: 'Your role' }),
      h('p', { class: 'muted small', role: 'status', text: 'Role hidden — tap Reveal role to see whether you’re crew or the impostor.' }),
      toggle);
  }
  return h('section', { class: 'card stack my-card revealed', 'aria-label': 'Your role' },
    h('div', { class: 'eyebrow', text: 'Your role' }),
    you.role === 'impostor'
      ? [h('div', { class: 'char-big', text: 'Impostor' }), h('p', { class: 'muted', text: 'You don’t have the word. Listen closely and try to blend in.' })]
      : [h('div', { class: 'char-big', dir: 'auto', text: you.word || '' }), h('p', { class: 'muted', text: 'You’re crew. Everyone except the impostor has this word.' })],
    toggle);
}

// ---- Taboo ----------------------------------------------------------------------------------

function taboo() {
  const g = snap.game || {};
  const me = snap.self ? snap.self.id : null;
  const you = g.you || {};
  const role = you.role; // 'clue_giver' | 'guesser' | 'spectator' (never 'operator' on this page)
  const phase = g.roundPhase;
  // Bind the draft/request identity to this room, this device's credential and seat, and this
  // round/card — not round/card alone. A room code or credential/seat change (including a
  // replacement session issued for the same room) must invalidate a pending draft/request even
  // when the round and card id happen to coincide with the previous room/seat's.
  const draftKey = code + ':' + (cred ? cred.token : '') + ':' + me + ':' + snap.roundId + ':' + g.cardEpoch;
  // Full guessing authority: this device's own team must also be the active team. The engine's
  // projection labels every non-giver roster player 'guesser' regardless of team, so role+phase
  // alone describe the opposing team's guessers too; the server already rejects their actual
  // guess.taboo action, but the affordance itself must not be offered to them in the first place.
  const isGuesser = role === 'guesser' && phase === 'clue_turn' && you.team === g.activeTeam;
  // Clear the draft and invalidate any in-flight request whenever the round/card changes, or
  // this device loses guessing authority (phase moved on, the active team changed, or this
  // device's role changed) — never on an ordinary same-round-and-authority snapshot, so a normal
  // in-flight redraw cannot wipe what the player is typing. Invalidating by request id (not just
  // flipping the sending flag) means a response for an abandoned request can no longer unlock
  // sending or clear a newer draft once it finally arrives — see the submit handler below.
  if (local.tabooEpoch !== draftKey || !isGuesser) {
    if (local.tabooEpoch !== draftKey || !isGuesser) local.tabooGuessDraft = '';
    local.tabooSending = false;
    local.tabooReqId = (local.tabooReqId || 0) + 1;
    local.tabooEpoch = draftKey;
  }
  // A real entry/authority lifecycle transition (leave+re-enter of the same saved seat/room/
  // round/card, or an authority loss followed by a regain) can reproduce the exact same
  // `draftKey` string the form was originally built under, so content equality alone cannot
  // tell a retained pre-transition form apart from a fresh one for the same identity. Every
  // transition that reaches the branch above (content change, authority loss/regain, or a
  // forced reset such as leave()/closedByHost()/a fatal seat callback setting the epoch to
  // null) always bumps `tabooReqId`, even when it leaves `draftKey`'s string unchanged — so
  // the form below captures that counter's value at its own render and treats any later
  // mismatch as proof a transition happened since this exact form was built, regardless of
  // whether the content key still happens to match.
  const renderGen = local.tabooReqId;
  // The clue giver's own card-authority identity: same shape as draftKey (room, credential/seat,
  // round and card), null while this device is not actually the live clue giver with a card to
  // show — which includes the room being paused, so a pause forces the same giverKey mismatch as
  // every other authority-loss transition below. A mismatch against the retained
  // local.tabooCardKey (set only while giverKey is non-null) means a lifecycle transition
  // happened since the card was last shown: card/round change, authority loss, pause, or a
  // leave+rejoin of the very same identifiers (resetTabooLocal already nulled the key on that
  // path, so draftKey reproducing it exactly still reads as a mismatch against null). Reset the
  // card back under cover and require a fresh explicit reveal in every one of those cases.
  // Eligibility (document visible + connection live) gates giverKey the same way card/round/
  // authority already do: a passive snapshot delivered while hidden or disconnected must not
  // reconstruct a usable key, or tabooCardPanel would admit a reveal (or keep one admissible)
  // without the giver ever regaining an actually live, visible clue turn. Checks the live
  // document.hidden read IN ADDITION TO the cached tabooCardVisible flag, not instead of it: the
  // flag alone has an optimistic startup default (true) that a page already hidden before its
  // very first visibilitychange transition would never correct, so admission here also consults
  // document.hidden directly rather than trusting that cached flag's initial value. The flag
  // itself is retained because it is also what every synthetic/no-listener transition (e.g. a
  // caller driving coverTabooCardIfNotLive('hidden'|'live', 'visibility') directly) gates through.
  // Authority also requires the room to be actually playing with a live clue turn (not merely
  // "not paused") — a retained card from a prior clue_turn must not stay admissible once the
  // turn completes, the round otherwise moves on, or the room reaches any non-playing phase
  // (e.g. closed) without going through paused.
  const giverKey = (role === 'clue_giver' && !!you.card && snap.phase === 'playing' && phase === 'clue_turn' &&
    local.tabooCardEligible !== false && local.tabooCardVisible !== false && !document.hidden) ? draftKey : null;
  if (giverKey !== local.tabooCardKey) { resetTabooCardReveal(); local.tabooCardKey = giverKey; }

  const teams = teamScoreboard(snap, { selfId: me });
  // Announce a real transition (room/session/round/phase/urgency change) at most once — never the
  // raw ticking clock, and never a repeated identical snapshot. The key intentionally omits
  // cardEpoch (a new card within the same turn/phase/urgency is not itself an announceable
  // transition) but includes everything resetTabooLocal() also nulls on session teardown/
  // replacement, so a leave+rejoin that reproduces the same room/round/phase/urgency still
  // re-announces once rather than silently inheriting a retired announcement's ownership.
  const paused = snap.phase === 'paused';
  const time = tabooTimeState(g.remainingMs, paused);
  const statusKey = code + ':' + (cred ? cred.token : '') + ':' + snap.roundId + ':' + phase + ':' + (paused ? 'paused' : time.urgency);
  if (statusKey !== local.tabooStatusKey) {
    local.tabooStatusKey = statusKey;
    const text = tabooAnnounceText(phase, paused, time, g);
    if (text) announce(text);
  }
  const clock = tabooStatusPanel(snap);

  let body;
  if (role === 'clue_giver' && you.card) {
    body = tabooCardPanel(you.card, giverKey);
  } else if (isGuesser) {
    const inp = h('input', { id: 'taboo-guess', maxlength: 120, required: true, dir: 'auto', autocomplete: 'off', placeholder: 'Shout your guess…',
      value: local.tabooGuessDraft, disabled: local.tabooSending, oninput: e => { local.tabooGuessDraft = e.target.value; } });
    const btn = h('button', { class: 'btn btn-pri', type: 'submit', disabled: local.tabooSending, text: 'Guess' });
    const form = h('form', { class: 'guess-form', novalidate: true, onsubmit: async e => {
      e.preventDefault();
      if (local.tabooSending) return; // one in-flight submission at a time for this authority context
      // Reject first if any lifecycle transition (re-entry, authority loss/regain, or a fatal
      // seat/room reset) has bumped tabooReqId since this exact form was rendered — before the
      // content-key checks below, which a transition back to the same identity can pass by
      // coincidence (see renderGen's comment above).
      if (local.tabooReqId !== renderGen) return;
      // This handler closes over the room/round/card/authority this exact form was built under
      // (`draftKey`, and implicitly this device's role/team at that render). A stale form/handler
      // can still fire after that — not just from an abandoned response (handled below by reqId),
      // but from the submit itself: the node this closure belongs to may not have been replaced in
      // the live DOM for this exact render pass, or an event can be queued before/without one. So
      // re-derive the current live authority from the global `snap` (never the captured `g`) right
      // here, before touching any pending/sending state or the transport, and refuse silently if it
      // no longer matches what was captured: wrong mode, wrong room/round/card, lost active-team
      // guessing authority, or the room is currently paused.
      const liveG = (snap && snap.game) || {};
      const liveYou = liveG.you || {};
      const liveMe = snap && snap.self ? snap.self.id : null;
      // Re-derive the same room/credential/seat/round/card identity the draft was captured under
      // (never just round/card) so a replaced room, credential/session or seat cannot submit
      // through this stale form even when round and card id coincide with the prior identity.
      const liveKey = snap ? code + ':' + (cred ? cred.token : '') + ':' + liveMe + ':' + snap.roundId + ':' + liveG.cardEpoch : null;
      // Require the room to be explicitly playing (not merely "not paused/ended/lobby"), so a
      // synthetic or transitional snapshot — such as a closed room reached without going through
      // closedByHost — can never dispatch a guess either.
      const liveIsGuesser = !!snap && snap.mode === 'taboo' && snap.phase === 'playing' &&
        liveYou.role === 'guesser' && liveG.roundPhase === 'clue_turn' && liveYou.team === liveG.activeTeam;
      if (liveKey !== draftKey || !liveIsGuesser) return;
      const text = inp.value.replace(/\s+/g, ' ').trim();
      if (!text) { inp.focus(); return; }
      // Bind this request's effects to its own id and the authority context it was sent under.
      // If the round/card/authority moves on before this resolves, local.tabooReqId is bumped
      // (above) and this stale response becomes a no-op instead of unlocking sending or wiping
      // whatever the player has since typed for the next card.
      const reqId = ++local.tabooReqId, reqKey = draftKey;
      local.tabooSending = true; render();
      const r = await act('taboo.guess', { cardEpoch: g.cardEpoch, text }, btn);
      if (local.tabooReqId !== reqId) return; // superseded — a newer request or exit owns this state now
      // reqId surviving the await only proves no *render-driven* transition (round/card/authority
      // change, leave(), fatal reset) bumped it meanwhile — not that the live room/credential/seat/
      // mode/round/card/authority this response is about to mutate state for still matches what was
      // captured when sent. A direct enter()/re-entry can leave reqId's owner intact up to this exact
      // point while the live context has already moved past `reqKey` (e.g. without a render in
      // between). Re-derive live identity/authority from the current globals — never the captured
      // `g`/`snap` closed over above — the same way the pre-send check above does, and refuse the
      // mutation if it no longer matches: never let a stale response clear/unlock what a newer
      // request or context already owns.
      const postG = (snap && snap.game) || {};
      const postYou = postG.you || {};
      const postMe = snap && snap.self ? snap.self.id : null;
      const postKey = snap ? code + ':' + (cred ? cred.token : '') + ':' + postMe + ':' + snap.roundId + ':' + postG.cardEpoch : null;
      const postIsGuesser = !!snap && snap.mode === 'taboo' && snap.phase === 'playing' &&
        postYou.role === 'guesser' && postG.roundPhase === 'clue_turn' && postYou.team === postG.activeTeam;
      if (postKey !== reqKey || !postIsGuesser) return;
      local.tabooSending = false;
      if (r && r.accepted && local.tabooEpoch === reqKey) local.tabooGuessDraft = '';
      render();
    } }, h('label', { for: 'taboo-guess', class: 'small', text: 'Your guess (said out loud too)' }), inp, btn);
    body = h('section', { class: 'card stack' },
      h('p', { class: 'muted', role: 'status', text: 'Listen to your clue giver and type what you think the word is.' }), form);
  } else if (role === 'guesser' && phase === 'clue_turn') {
    // Same projected role as the active guesser, but this device's team isn't up: read-only.
    body = h('p', { class: 'muted', role: 'status', text: 'Wait for your team’s turn…' });
  } else if (phase === 'turn_complete') {
    const lr = g.lastResolved;
    body = h('section', { class: 'card stack' },
      h('p', { class: 'status-line', role: 'status', text: lr ? TABOO_RESULT_TEXT[lr.outcome] || 'Round over.' : 'Turn over.' }),
      h('p', { class: 'muted', text: 'Waiting for the host to start the next turn…' }));
  } else if (phase === 'exhausted') {
    body = h('p', { class: 'muted', role: 'status', text: 'Out of cards. Waiting for final results…' });
  } else if (role === 'spectator') {
    body = h('p', { class: 'muted', role: 'status', text: 'You’re watching this game. You’ll join the next one.' });
  } else {
    body = h('p', { class: 'muted', role: 'status', text: 'Waiting for your team’s turn…' });
  }
  return h('div', { class: 'stack' }, modeHeading(snap), renderRulesPanel('taboo'), clock, body, teams);
}

// The clue giver's own card: covered by default so a shoulder-surfer never sees the word or the
// forbidden list without the giver's own, explicit tap — this is local shoulder-surfing
// assistance only, not a transport or screenshot-security claim. Covered, the DOM holds no trace
// of the secret at all (no text, no aria-label/aria-describedby/title/data-* attribute, nothing
// in a live region) rather than a CSS-hidden copy, so inspecting the connected DOM while covered
// can never recover it. `key` is this render's giverKey (null whenever this device is not the
// live clue giver with a card to show); `gen` is captured at this exact render so the toggle's
// own closure can tell whether a lifecycle transition retired it before it fires (see
// resetTabooCardReveal above) — a stale/detached click arriving after that point is a no-op
// rather than a re-reveal, even if (improbably) it still carries the same key.
function tabooCardPanel(card, key) {
  const revealed = !!key && local.tabooCardKey === key && local.tabooCardRevealed;
  const gen = local.tabooCardGen;
  // Same id on both the covered and revealed toggle: preserveFocus() (already wrapping every
  // mount(app, ...) in render()) restores focus by id after a reveal/hide re-render, so an
  // explicit toggle lands on its replacement control automatically, and a passive snapshot that
  // leaves the id and revealed state alone never moves focus at all — no extra focus plumbing
  // needed here beyond giving the control a stable id.
  const toggle = h('button', { id: 'taboo-card-toggle', class: 'btn ' + (revealed ? 'btn-sec' : 'btn-pri'), type: 'button', 'aria-pressed': revealed ? 'true' : 'false',
    onclick: () => {
      if (!key || local.tabooCardKey !== key || local.tabooCardGen !== gen) return; // retired by a transition since this control was rendered
      local.tabooCardRevealed = !local.tabooCardRevealed;
      render();
    },
    text: revealed ? 'Hide card' : 'Reveal card' });
  if (!revealed) {
    return h('section', { class: 'card stack my-card', 'aria-label': 'Your card' },
      h('div', { class: 'eyebrow', text: 'Give clues for' }),
      h('p', { class: 'muted small', role: 'status', text: 'Card hidden — tap Reveal card to see your word and the words you must not say.' }),
      toggle);
  }
  return h('section', { class: 'card stack my-card revealed', 'aria-label': 'Your card' },
    h('div', { class: 'eyebrow', text: 'Give clues for' }),
    h('div', { class: 'char-big', dir: 'auto', text: card.word }),
    h('p', { class: 'muted small', text: 'Do not say:' }),
    h('ul', { class: 'who-cards' }, card.forbidden.map(w => h('li', { class: 'who-card' }, h('span', { class: 'char-label', dir: 'auto', text: w })))),
    toggle);
}

function tabooEnded() {
  const text = tabooResultText(snap);
  return h('section', { class: 'card stack center-text' },
    h('h2', { class: 'card-title', text: text || 'Final scores' }),
    teamScoreboard(snap, { title: 'Final scores', selfId: snap.self && snap.self.id }));
}

// ---- Bluff ------------------------------------------------------------------------------

// Drops any in-flight Bluff submission's ownership and the draft/error state, and bumps a
// monotonic generation counter (mirroring resetTabooLocal()/erReset()'s own `gen`/epoch fields).
// Called from enter()/leave()/closedByHost()/the fatal-status handler (so a pending submission
// from before the transition can never land in a replacement form's state) and from render()'s
// own mode/phase diff below for a mode switch away from bluff while this session stays live.
function resetBluffLocal() {
  local.bluffRound = null; local.bluffDraft = ''; local.bluffError = ''; local.bluffVoteError = '';
  local.bluffPending = false; local.bluffPendingReqId = null;
  local.bluffGen = (local.bluffGen || 0) + 1;
}

// Client-side mirror of the host's answer-length GUIDE only (clean_text/MAX_ANSWER_LEN in
// textutil.py/majlis-core.js): NFC-normalizes and collapses runs of the same Unicode
// White_Space-property codepoints the host's str.split() collapses on, using the exact same
// JOIN_WS_SOURCE/JOIN_WS_RUN_RE/JOIN_WS_EDGE_RE already verified against the host's whitespace
// set for the join-name field above — the host collapses bluff answers through the identical
// clean_text() whitespace rule. It deliberately does NOT reproduce the host's character-rejection
// table (the generated unicode13 tables) or its separate UTF-8 byte cap: the host's
// invalid_payload response stays authoritative for those. At the 160-code-point cap below, a
// collapsed answer is at most 640 UTF-8 bytes (4 bytes × 160, the most any single code point ever
// encodes to) — well under the host's independent 1024-byte cap — so an answer that respects this
// code-point guide can never trip that byte cap; this file never needs its own byte-length check.
const BLUFF_ANSWER_MAX = 160;
function collapseBluffAnswer(raw) {
  return raw.normalize('NFC').replace(JOIN_WS_RUN_RE, ' ').replace(JOIN_WS_EDGE_RE, '');
}

// Bluff-result-row name fallback (majlis:bluff-player-round-status-v1): a dedicated roster lookup
// rather than a wrapper around playerName() (which is ui.js's own not-found fallback, "A player",
// a non-blank string this function can't distinguish from a real name after the fact) — both a
// missing roster id AND a found-but-blank/non-string `name` field must surface as the same
// "Unknown player" text here, never "undefined's fake"/"Voted by: null, Tom" in the reveal/
// finished option rows below, and never ui.js's differently-worded fallback either.
function bluffResultName(snap, id) {
  const p = (snap.players || []).find(x => x.id === id);
  const n = p ? p.name : null;
  return (typeof n === 'string' && n.trim() !== '') ? n : 'Unknown player';
}

// Qualified-viewer check shared by the two personal reveal helpers below (majlis:bluff-player-
// round-status-v1 correction-r1): a foreign/placeholder self.id — one that names no actual seat
// in snap.players — must never qualify for a personal points or vote-outcome claim, even when
// game.you happens to carry plausible-looking data for it.
function bluffSelfIsPlayer(snap) {
  const id = snap && snap.self && snap.self.id;
  return typeof id === 'string' && !!id && Array.isArray(snap.players) && snap.players.some(p => p && p.id === id);
}

// Own-property, finite-numeric-only personal round-points text (majlis:bluff-player-round-
// status-v1): the previous `(last.scoreDelta || {})[me] || 0` folded a genuinely missing entry
// into the exact same "+0" text as a real zero award, and always prefixed '+' even for a
// (currently impossible, but never assumed) negative delta. Only a key actually present on
// scoreDelta, holding a finite number, is ever shown — anything else (missing key, NaN,
// +/-Infinity, a string) renders neutral "points unavailable" text instead of inventing a value.
// `isPlayer` (correction-r1) additionally requires `me` to actually be a current roster seat —
// without it a foreign self.id that happens to collide with a real scoreDelta key could claim
// someone else's points. `you` (correction-r2) must be the RAW game.you — a missing, array, or
// string you is not a typed personal-authority object, so even an identified roster seat must not
// have its points claimed from a scoreDelta key that was never actually gated on `you` existing.
function bluffPointsText(isPlayer, you, scoreDelta, me) {
  if (!isPlayer || !you || typeof you !== 'object' || Array.isArray(you)
    || !scoreDelta || typeof scoreDelta !== 'object' || typeof me !== 'string' || !me
    || !Object.prototype.hasOwnProperty.call(scoreDelta, me)) return 'Points unavailable this round.';
  const pts = scoreDelta[me];
  if (typeof pts !== 'number' || !Number.isFinite(pts)) return 'Points unavailable this round.';
  return 'You scored ' + (pts >= 0 ? '+' + pts : pts) + ' this round.';
}

// Qualified correct/incorrect/did-not-vote headline for the reveal/finished Bluff result (majlis:
// bluff-player-round-status-v1, correction-r1): requires `isPlayer` (an actual roster seat, never
// a foreign/placeholder self.id); `you` must be the RAW game.you (never a caller-side `|| {}`
// default), so a genuinely missing you is distinguished from one that resolves to an empty
// object; `last.trueOptionId` must resolve against an actual entry in `last.options`, never just
// "some non-empty string"; and abstention requires `you.voted` to be the explicit boolean
// `false` — any other non-`true` shape (missing, a string, etc.) stays neutral rather than being
// read as an abstention. A `false` vote (correction-r2) also requires a coherent absent/null
// `optionId`: `voted: false` alongside an `optionId` that itself resolves against `last.options`
// is a contradictory projection (never produced by a real round), and must stay neutral rather
// than assert an abstention that the same object's `optionId` contradicts. A `true` vote
// additionally needs a string `optionId` that resolves against `last.options` before a
// correct/incorrect verdict is ever shown.
function bluffVoteOutcomeText(isPlayer, you, last) {
  const options = Array.isArray(last.options) ? last.options : [];
  const trueOptionId = typeof last.trueOptionId === 'string' ? last.trueOptionId : null;
  const trueResolved = trueOptionId !== null && options.some(o => o.optionId === trueOptionId);
  if (!isPlayer || !you || typeof you !== 'object' || Array.isArray(you) || !options.length || !trueResolved) {
    return 'Round results unavailable.';
  }
  if (you.voted === false) {
    const optionResolved = typeof you.optionId === 'string' && you.optionId && options.some(o => o.optionId === you.optionId);
    if (optionResolved) return 'Round results unavailable.';
    return 'You didn’t vote this round.';
  }
  if (you.voted !== true) return 'Round results unavailable.';
  if (typeof you.optionId !== 'string' || !you.optionId) return 'Round results unavailable.';
  if (!options.some(o => o.optionId === you.optionId)) return 'Round results unavailable.';
  return you.optionId === trueOptionId ? 'You found the real answer!' : 'That one was a fake.';
}

function bluff() {
  const g = snap.game || {};
  const me = snap.self ? snap.self.id : null;
  // A spectator (role === 'spectator', self.spectator) gets projectRoom's
  // display projection for the game — {role: 'display', playerId: null} —
  // so `game.you` is always absent and `me` is never one of the players.
  // The old code only guarded on that absence implicitly (`g.you || {}`
  // leaves every `you.*` check falsy), which happened to hide the player's
  // own prior answer/vote, but never stopped rendering the submission input
  // or an *enabled* vote button for a spectator — this explicit check does.
  const spectating = snap.role === 'spectator' || (snap.self && snap.self.spectator === true);
  const you = g.you || {};
  // Raw game.you (correction-r1), kept separate from the `you` default above: bluffVoteOutcomeText
  // must be able to tell a genuinely missing you apart from one that resolves to {}.
  const isPlayer = bluffSelfIsPlayer(snap);
  const phase = g.phase;
  // A new round for this same mode/session is itself a submission-ownership transition that
  // render()'s centralized mode/phase diff above cannot see (snap.mode stays 'bluff' the whole
  // time): drop any pending-submission ownership and bump bluffGen here too, exactly like
  // resetBluffLocal() does for every other transition, so a response still in flight for the
  // PRIOR round can never clear/overwrite this new round's draft once it finally arrives.
  if (local.bluffRound !== snap.roundId) {
    local.bluffRound = snap.roundId; local.bluffDraft = ''; local.bluffError = ''; local.bluffVoteError = '';
    local.bluffPending = false; local.bluffPendingReqId = null;
    local.bluffGen = (local.bluffGen || 0) + 1;
  }

  const question = h('section', { class: 'card bluff-question-card' },
    h('div', { class: 'eyebrow', text: 'Question' }),
    h('p', { class: 'bluff-q-en', text: g.question && g.question.en }),
    g.question && g.question.ar ? h('p', { class: 'bluff-q-ar', lang: 'ar', dir: 'rtl', text: g.question.ar }) : null);

  // Shared player/spectator phase panel (majlis:bluff-player-round-status-v1): headline plus the
  // guarded submission/voting progress line, so the two branches below can never show different
  // progress wording for the same projection. Spectator-only wording lives entirely inside
  // bluffPlayerStatusPanel itself via `spectating`; this call site never branches on phase again
  // for that purpose.
  const statusPanel = bluffPlayerStatusPanel(snap, { spectating });

  let body;
  if (spectating) {
    if (phase === 'submission') {
      body = null; // statusPanel's own guarded progress line replaces the prior raw concatenation
    } else if (phase === 'voting') {
      const options = g.options || [];
      body = h('section', { class: 'card stack' },
        h('h2', { class: 'card-title', text: 'Which one is the real answer?' }),
        h('ul', { class: 'bluff-options' }, options.map(o =>
          h('li', { class: 'bluff-option' }, h('span', { class: 'bluff-option-btn', dir: 'auto', text: o.text })))),
        h('p', { class: 'muted small', text: 'You’re spectating — voting is for players only.' }));
    } else if (phase === 'reveal' || phase === 'finished') {
      const last = g.lastResult || {};
      const trueOpt = (last.options || []).find(o => o.optionId === last.trueOptionId);
      body = h('section', { class: 'card stack' },
        trueOpt ? h('p', { class: 'status-line', role: 'status', dir: 'auto', text: 'The real answer was: “' + trueOpt.text + '”.' }) : null);
    } else {
      body = null; // statusPanel's own default "Waiting for the host…" already covers this
    }
    return h('div', { class: 'stack' }, modeHeading(snap), renderRulesPanel('bluff'), question, statusPanel, body, scoreboard(snap));
  }
  if (phase === 'submission') {
    if (you.submitted) {
      body = h('section', { class: 'card stack center-text' },
        you.text !== null
          ? h('p', { class: 'status-line', role: 'status', dir: 'auto', text: 'Your fake answer: “' + you.text + '”. Waiting for everyone else…' })
          : h('p', { class: 'status-line', role: 'status', text: 'The host moved on without your answer this round.' }));
    } else {
      // Full form authority, captured once at build time (not re-read live at submit/completion
      // time) — same contract as escapeRoom()'s own `authority`/`isLiveAuthority` below, scaled to
      // Bluff's simpler single-submission-per-round shape (no team/role dimension to track).
      // `gen` guards the ABA case plain field-equality misses: any resetBluffLocal() transition
      // (leave/rejoin, a fatal seat reset, a mode switch away and back) always moves bluffGen
      // forward, even when it leaves every other field at the exact value this form captured, so
      // a form from before that transition can never match again.
      const authority = { code: snap.code, roundId: snap.roundId, seatId: me, credToken: cred && cred.token, gen: local.bluffGen };
      const isLiveAuthority = () => !!snap && snap.code === authority.code && snap.mode === 'bluff'
        && snap.roundId === authority.roundId && (snap.self && snap.self.id) === authority.seatId
        && (cred && cred.token) === authority.credToken && local.bluffGen === authority.gen;

      const sendDisabled = local.bluffPending;
      const inp = h('input', { id: 'bluff-answer', required: true, dir: 'auto', autocomplete: 'off', placeholder: 'Write a convincing fake answer…', value: local.bluffDraft,
        disabled: sendDisabled, 'aria-describedby': 'bluff-help bluff-count bluff-error' });
      const btn = h('button', { class: 'btn btn-pri', type: 'submit', disabled: sendDisabled, text: sendDisabled ? 'Sending…' : 'Submit fake answer' });
      const errEl = h('p', { class: 'form-error', id: 'bluff-error', role: 'alert', text: local.bluffError });
      // Plain text, no aria-live/role=status: a per-keystroke count must never be announced (same
      // rationale as nameHelpEl above).
      const countEl = h('p', { class: 'muted small', id: 'bluff-count', text: '' });

      function setBluffError(msg) {
        local.bluffError = msg || '';
        errEl.textContent = local.bluffError;
        if (msg) inp.setAttribute('aria-invalid', 'true'); else inp.removeAttribute('aria-invalid');
      }
      function updateBluffCount() {
        countEl.textContent = Array.from(collapseBluffAnswer(inp.value)).length + '/' + BLUFF_ANSWER_MAX + ' characters.';
      }

      // IME composition safety, identical contract to nameIn above: while an input method is
      // composing, Enter must never submit the form (some browsers, notably Safari, fire the
      // implicit-submit keydown mid-composition instead of suppressing it), and the live count
      // must wait for compositionend's own committed value rather than flicker on each candidate.
      let composing = false;
      inp.addEventListener('compositionstart', () => { composing = true; });
      inp.addEventListener('compositionend', () => { composing = false; local.bluffDraft = inp.value; updateBluffCount(); });
      inp.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' && (composing || e.isComposing || e.keyCode === 229)) e.preventDefault();
      });
      inp.addEventListener('input', () => {
        local.bluffDraft = inp.value;
        if (composing) return; // candidate text only — wait for compositionend's committed value
        updateBluffCount();
        if (errEl.textContent) setBluffError('');
      });
      updateBluffCount(); // initial count for a draft preserved across a passive rerender

      // Admission-only checks (run once, synchronously, before any request starts): render()
      // replaces this mode's whole DOM subtree on every call (mount() -> replaceChildren, no node
      // reuse), so a detached form is always a form from a PRIOR render, never the one currently
      // on screen — isLiveAuthority()'s value-equality alone cannot catch that, nor a form built
      // (and left connected) while the room is paused, which `inert` on <main> covers here.
      const canAdmit = () => form.isConnected && !form.closest('[inert]') && isLiveAuthority();
      const form = h('form', { class: 'guess-form', novalidate: true, onsubmit: async e => {
        e.preventDefault();
        if (composing) return; // a deliberate submit never fires mid-composition
        if (local.bluffPending || !canAdmit()) return; // stale/detached/inert/retired form: refuse to send
        const text = collapseBluffAnswer(inp.value);
        if (!text) { setBluffError('Write a fake answer first.'); inp.focus(); return; }
        if (Array.from(text).length > BLUFF_ANSWER_MAX) {
          setBluffError('Your fake answer is too long — please shorten it to ' + BLUFF_ANSWER_MAX + ' characters or fewer.');
          inp.focus();
          return;
        }
        // Scope this reply to its own request: a resetBluffLocal()-triggered transition already
        // forces bluffPending back to false (so a brand-new request can start under a new
        // authority) without waiting for this request's reply, so a bare `local.bluffPending =
        // false` on completion could clobber a newer, still-unresolved request's pending flag.
        // Only the reply whose reqId still owns bluffPendingReqId may touch pending/draft/error.
        const reqId = (local.bluffReqSeq = (local.bluffReqSeq || 0) + 1);
        local.bluffPending = true; local.bluffPendingReqId = reqId; render();
        const isCurrentRequest = () => isLiveAuthority() && local.bluffPendingReqId === reqId;
        // Pass this form's own captured authority through explicitly: act()'s default live-global
        // read (code/cred.token/snap.roundId) would re-read whatever the page has moved on to by
        // the time this POST actually dispatches, not what this request was admitted under.
        const r = await act('bluff.submit_answer', { text }, btn, [], isCurrentRequest, authority);
        const stillOwner = local.bluffPendingReqId === reqId;
        if (stillOwner) { local.bluffPending = false; local.bluffPendingReqId = null; }
        // A snapshot that moved the room on while this was in flight (round/mode/seat/credential
        // change, leave, close, fatal, reset, pause/resume) already re-rendered under a new
        // authority (or a newer request already claimed pending); applying a stale success/
        // error/focus here would fight that render — and act on a now-detached input — instead.
        if (!stillOwner || !isLiveAuthority()) { render(); return; }
        if (r && r.accepted) { local.bluffDraft = ''; setBluffError(''); }
        // invalid_answer covers two distinct server-side causes (matches the true answer/an
        // alias, OR collides with another player's already-submitted fake) that must never be
        // told apart here: describeError's text for it is deliberately neutral (see ui.js) so
        // this can never reveal which case happened or imply the rejected text was actually
        // correct. The draft is left in place (never cleared on rejection) for a deliberate retry;
        // nothing here resubmits on its own.
        const rejected = !!(r && !r.accepted);
        if (rejected) setBluffError(describeError(r.error));
        render();
        // render() just replaced this entire subtree (mount() -> replaceChildren, no node reuse),
        // so focusing the OLD `inp` here would be a no-op the instant it's detached — the retry
        // focus has to land on the freshly rendered input, found by id, not the stale closure ref.
        if (rejected) { const freshInp = document.getElementById('bluff-answer'); if (freshInp) freshInp.focus(); }
      } }, h('label', { for: 'bluff-answer', class: 'small', text: 'Your fake answer (private until voting)' }), inp, countEl, btn);
      body = h('section', { class: 'card stack' },
        form, errEl,
        h('p', { class: 'muted small', id: 'bluff-help', text: 'Write something believable but wrong. No other player can see this before voting, and the reveal will show who wrote and voted for each answer.' }));
    }
  } else if (phase === 'voting') {
    const options = g.options || [];
    if (you.voted) {
      body = h('section', { class: 'card stack center-text' },
        h('p', { class: 'status-line', role: 'status', text: 'Vote sent. Waiting for everyone else…' }));
    } else {
      // self_vote/already_voted/unknown_option were previously passed as
      // `quiet` codes (no toast) with nothing shown in their place — a
      // genuine rejection (e.g. a stale option id from a race with another
      // player, or a double-tap) then left no visible feedback at all. Now
      // they render a real inline error instead of just suppressing the toast.
      const errEl = h('p', { class: 'form-error', role: 'alert', text: local.bluffVoteError });
      const list = h('ul', { class: 'bluff-options' }, options.map(o => {
        const mine = o.optionId === you.ownOptionId;
        return h('li', { class: 'bluff-option' + (mine ? ' mine' : '') },
          h('button', { class: 'btn btn-sec bluff-option-btn', type: 'button', dir: 'auto', disabled: mine,
            'aria-label': (mine ? 'Your own fake answer, can’t vote for it: ' : 'Vote for: ') + o.text,
            onclick: async e => {
              const r = await act('bluff.vote', { optionId: o.optionId }, e.currentTarget, ['self_vote', 'already_voted', 'unknown_option']);
              if (r && r.accepted) { local.bluffVoteError = ''; errEl.textContent = ''; }
              else if (r) { local.bluffVoteError = describeError(r.error); errEl.textContent = local.bluffVoteError; }
            },
            text: o.text }),
          mine ? h('span', { class: 'badge-later small', text: 'Yours' }) : null);
      }));
      body = h('section', { class: 'card stack' },
        h('h2', { class: 'card-title', text: 'Which one is the real answer?' }),
        list, errEl,
        h('p', { class: 'muted small', text: 'Pick the one you think is true. Fool others with your own fake answer to score points too.' }));
    }
  } else if (phase === 'reveal' || phase === 'finished') {
    const last = g.lastResult || {};
    // REVEAL/FINISHED-only: majlis-core.js's project() includes authorId on
    // every option (every role, not just operator) only from this phase
    // onward. lastResult.voters (pid -> optionId, same reveal-only tier as
    // authorId/trueOptionId/scoreDelta) names who cast each vote; it is
    // never present before this round's own reveal.
    const trueOpt = (last.options || []).find(o => o.optionId === last.trueOptionId);
    const votersByOption = {};
    Object.keys(last.voters || {}).forEach(pid => {
      const oid = last.voters[pid];
      (votersByOption[oid] = votersByOption[oid] || []).push(bluffResultName(snap, pid));
    });
    const optionRows = (last.options || []).map(o => {
      const isTrue = o.optionId === last.trueOptionId;
      const votes = (last.voteTally || {})[o.optionId] || 0;
      const voterNames = (votersByOption[o.optionId] || []).join(', ');
      return h('li', { class: 'bluff-option' + (isTrue ? ' mine' : '') },
        h('span', { class: 'bluff-option-btn', dir: 'auto', text: o.text }),
        h('span', { class: 'badge-later small', text: (isTrue ? 'True answer' : (o.authorId ? bluffResultName(snap, o.authorId) + '’s fake' : 'Fake')) + ' · ' + votes + ' vote' + (votes === 1 ? '' : 's') }),
        voterNames ? h('span', { class: 'muted small', dir: 'auto', text: 'Voted by: ' + voterNames }) : null);
    });
    body = h('section', { class: 'card stack' },
      h('p', { class: 'status-line', role: 'status', dir: 'auto', text: bluffVoteOutcomeText(isPlayer, g.you, last) }),
      trueOpt ? h('p', { class: 'status-line', dir: 'auto', text: 'The real answer: “' + trueOpt.text + '”.' }) : null,
      h('ul', { class: 'bluff-options' }, optionRows),
      h('p', { class: 'small muted', text: bluffPointsText(isPlayer, g.you, last.scoreDelta, me) }));
  } else {
    body = null; // statusPanel's own default "Waiting for the host…" already covers this
  }

  return h('div', { class: 'stack' }, modeHeading(snap), renderRulesPanel('bluff'), question, statusPanel, body, scoreboard(snap, { selfId: me }));
}

function ended() {
  return h('div', { class: 'stack' },
    h('h1', { class: 'mode-title', text: 'Game over' }),
    snap.mode === 'who_am_i' && snap.game ? whoAmIRevealList() : null,
    snap.mode === 'impostor' && snap.game ? impostorRevealCard() : null,
    snap.mode === 'escape_room' && snap.game ? escapeRoomRevealCard() : null,
    // Taboo has no per-player score (syncScores never populates it for this mode — see
    // teamScoreboard's note in views.js), so the generic per-player scoreboard is skipped here.
    snap.mode === 'taboo' && snap.game ? tabooEnded() : scoreboard(snap, { title: 'Final scores', selfId: snap.self && snap.self.id }),
    h('button', { class: 'btn btn-pri', type: 'button', onclick: leave, text: 'Done' }));
}

function escapeRoomRevealCard() {
  const g = snap.game;
  const reveal = g.reveal || {};
  const outcomeText = g.outcome === 'success' ? 'The team escaped! All three puzzles solved.'
    : g.outcome === 'timeout' ? 'Time ran out before the team escaped.'
    : 'The host ended the game early.';
  return h('section', { class: 'card stack' },
    h('h2', { class: 'card-title', text: 'Escape room recap' }),
    h('p', { text: outcomeText }),
    (reveal.puzzles || []).map((p, i) => h('div', { class: 'stack' },
      h('h3', { class: 'small', dir: 'auto', text: 'Puzzle ' + (i + 1) + ': ' + p.promptEn }),
      h('p', { class: 'status-line', dir: 'auto', text: 'Answer: ' + p.answer }))));
}

// ---- Escape Room ---------------------------------------------------------------------------

let erCooldownTick = null;

function erTeamScore() {
  const list = snap.players || [];
  if (!list.length) return 0;
  const mine = snap.self && list.find(p => p.id === snap.self.id);
  return mine ? mine.score : list[0].score;
}

// Invalidation key for the escape-room form's private draft/error/pending state: any change to
// room/round/phase/seat/credential/role/game-phase is a genuine authority change (leave/closed/
// fatal/reset/pause/resume/lobby all move one of these), so the draft is cleared. An "ordinary"
// rerender that keeps all six the same (a heartbeat snapshot, a cooldown tick) retains it.
function erAuthKey(s, you) {
  return s ? [s.code, s.mode, s.phase, s.roundId, s.self && s.self.id, cred && cred.token, s.game && s.game.phase, you ? 'p' : 's'].join('|') : null;
}

// Centralized escape-room lifecycle reset: clears the private draft/error/pending state AND
// bumps a monotonic generation counter. The counter (not just the auth key) is what a submitted
// form's captured authority is checked against at completion time, because a pause followed by a
// resume can return every authority FIELD (room/round/seat/credential/game-phase) to the exact
// values a form captured before the pause (ABA) — a value-equality-only check would then treat
// that stale form as live again. A counter that only ever increases can't be fooled by a round
// trip back to an old value. Called from escapeRoom() on any authKey change, and directly from
// leave()/closedByHost()/the fatal-status handler/the lobby-or-ended render branch, so the state
// is cleared immediately on those transitions rather than lazily on the next escapeRoom() render
// (which may never come, e.g. after leaving the page).
function erReset() {
  local.erAuthKey = null; local.erDraft = ''; local.erError = ''; local.erPending = false; local.erPendingReqId = null;
  local.erGen = (local.erGen || 0) + 1;
}

function escapeRoom() {
  const g = snap.game || {};
  const you = g.you || null; // absent for spectators (LATE_SPECTATORS): no fragment is ever sent to them
  const authKey = erAuthKey(snap, you);
  if (local.erAuthKey !== authKey) { erReset(); local.erAuthKey = authKey; }
  const mins = Math.floor((g.remainingSeconds || 0) / 60), secs = Math.floor((g.remainingSeconds || 0) % 60);
  const status = h('section', { class: 'card stack' },
    modeHeading(snap),
    h('p', { class: 'muted small', text: mins + ':' + String(secs).padStart(2, '0') + ' left · Team score: ' + erTeamScore() }));

  // The mode's own game can finish (success or timeout) well before the operator sends room.end,
  // so snap.phase (room-level) may still read "playing" here. Once g.phase is "ended" the
  // projection has no currentPuzzle and no `you` for ANYONE (see escape_room.py project()), so
  // this must be checked, and the reveal shown, before the spectator/`!you` branch below would
  // otherwise wrongly tell every seated player they are spectating an empty puzzle.
  if (g.phase === 'ended') return h('div', { class: 'stack' }, status, escapeRoomRevealCard());

  const puzzle = g.currentPuzzle || {};
  const promptBlock = h('section', { class: 'card stack' },
    h('p', { class: 'eyebrow', text: 'Puzzle' }),
    h('p', { class: 'status-line', dir: 'auto', text: puzzle.promptEn || '' }),
    puzzle.promptAr ? h('p', { lang: 'ar', dir: 'rtl', text: puzzle.promptAr }) : null,
    puzzle.hintEn ? h('p', { class: 'muted small', dir: 'auto', text: 'Hint: ' + puzzle.hintEn }) : null,
    puzzle.hintAr ? h('p', { class: 'muted small', lang: 'ar', dir: 'rtl', text: puzzle.hintAr }) : null);

  if (!you) {
    return h('div', { class: 'stack' }, status, promptBlock,
      h('p', { class: 'muted', role: 'status', text: g.phase === 'solved' ? 'Solved! Waiting for the host to continue.' : 'Spectating this game. Watch the team solve it.' }));
  }

  const fragment = you.fragment || {};
  const fragCard = h('section', { class: 'card stack my-card revealed', 'aria-label': 'Your clue' },
    h('div', { class: 'eyebrow', text: 'Your clue' }),
    h('p', { dir: 'auto', text: fragment.en || '' }),
    fragment.ar ? h('p', { lang: 'ar', dir: 'rtl', text: fragment.ar }) : null,
    h('p', { class: 'muted small', text: 'Only you can see this clue. Share it out loud.' }));

  let answerUi;
  if (g.phase === 'solved') {
    answerUi = h('section', { class: 'card', role: 'status' }, h('p', { class: 'status-line', text: 'Solved! Waiting for the host to continue.' }));
  } else {
    // A wrong answer only bumps the public revision once the team score has room to drop
    // (room_logic.py: a change confined to the private cooldownUntil key alone never pushes a
    // snapshot), so this page can't rely on a future push to clear the button: it ticks the
    // server-given cooldownSeconds down against the wall clock itself and re-renders until it
    // reaches zero.
    const elapsed = (Date.now() - (local.snapAt || Date.now())) / 1000;
    const cooldown = Math.max(0, (you.cooldownSeconds || 0) - elapsed);
    const onCooldown = cooldown > 0;
    if (onCooldown && !erCooldownTick) {
      erCooldownTick = setTimeout(() => { erCooldownTick = null; if (snap && snap.mode === 'escape_room') render(); }, 250);
    } else if (!onCooldown && erCooldownTick) {
      clearTimeout(erCooldownTick); erCooldownTick = null;
    }
    const sendDisabled = onCooldown || local.erPending;
    const inp = h('input', { id: 'er-answer', maxlength: 80, required: true, dir: 'auto', autocomplete: 'off', placeholder: 'Your answer', value: local.erDraft,
      disabled: sendDisabled, 'aria-describedby': 'er-error', oninput: e => { local.erDraft = e.target.value; } });
    const btn = h('button', { class: 'btn btn-pri', type: 'submit', disabled: sendDisabled,
      text: local.erPending ? 'Sending…' : onCooldown ? 'Wait ' + Math.ceil(cooldown) + 's…' : 'Submit answer' });
    const errEl = h('p', { class: 'form-error', id: 'er-error', role: 'alert', text: local.erError });
    // Full form authority, captured once at build time (not re-read live at submit time): a form
    // kept alive past its own round/room/phase/seat/credential (a detached DOM node, a focus-
    // preservation reattach, a reconnect that re-authenticates the seat) must refuse to send, and
    // a completion that arrives after any of this changed must not touch local/UI state — this is
    // the exact gap the reviewer's lifecycle probe caught (round read live from `snap` at send
    // time, so a stale form silently sent its old text tagged with the *current* round).
    // `gen` guards the ABA case plain field-equality misses: a pause+resume can return every other
    // field to the exact value this form captured, but erReset() (run on the phase change into and
    // back out of "paused") always moves the counter forward, so a form from before the pause can
    // never match again (NOT a DOM `isConnected` check: this page re-renders, and so replaces this
    // very form's own DOM node, while that same submission is still in flight to show "Sending…",
    // so a detachment check would reject the in-flight request that triggered the re-render).
    const authority = { code: snap.code, mode: snap.mode, roomPhase: snap.phase, roundId: snap.roundId,
      seatId: snap.self && snap.self.id, credToken: cred && cred.token, gamePhase: g.phase, gen: local.erGen };
    const isLiveAuthority = () => !!snap && snap.code === authority.code && snap.mode === authority.mode
      && snap.phase === authority.roomPhase && snap.roundId === authority.roundId
      && (snap.self && snap.self.id) === authority.seatId && (cred && cred.token) === authority.credToken
      && (snap.game && snap.game.phase) === authority.gamePhase && local.erGen === authority.gen;
    // Admission-only checks (run once, synchronously, before any request starts): every render()
    // replaces this mode's whole DOM subtree (mount() -> replaceChildren, no node reuse — see
    // ui.js), so a detached form is always a form from a PRIOR render, never the one currently on
    // screen. isLiveAuthority()'s value-equality alone cannot catch that (a detached form can still
    // carry field values and a `gen` that match the live authority byte-for-byte), nor can it catch
    // a form that was built, and remains connected, while the room is paused — equality only
    // compares against whatever phase THIS form's own authority recorded, which for a form built
    // during pause already reads "paused" on both sides. None of this may run at completion time:
    // the very re-render that shows "Sending…" for an admitted, in-flight request detaches that
    // request's own original form node on purpose, and a legitimately in-flight request must
    // survive the room moving to paused/ended while it is outstanding (isLiveAuthority + reqId
    // ownership alone govern completion — see isCurrentRequest below).
    const canAdmit = () => form.isConnected && !form.closest('[inert]')
      && !!snap && snap.phase === 'playing' && !!(snap.game && snap.game.you) && snap.game.phase === 'active'
      && isLiveAuthority();
    const form = h('form', { class: 'guess-form', novalidate: true, onsubmit: async e => {
      e.preventDefault();
      if (local.erPending || !canAdmit()) return; // stale/detached/inert/paused/roleless form: refuse to send
      const text = inp.value.replace(/\s+/g, ' ').trim();
      if (!text) { local.erError = 'Type an answer first.'; errEl.textContent = local.erError; inp.focus(); return; }
      // Scope this reply to its own request: an authKey-triggered erReset() already forces
      // erPending back to false (so a brand-new request can start under a new authority) without
      // waiting for this request's reply, so a bare `local.erPending = false` on completion could
      // clobber a newer, still-unresolved request's pending flag. Only the reply whose reqId still
      // owns `erPendingReqId` may touch pending/draft/error/toast at all.
      const reqId = (local.erReqSeq = (local.erReqSeq || 0) + 1);
      local.erPending = true; local.erPendingReqId = reqId; render();
      const isCurrentRequest = () => isLiveAuthority() && local.erPendingReqId === reqId;
      // Pass this form's own captured authority through explicitly: act()'s default live-global
      // read (code/cred.token/snap.roundId) would re-read whatever the page has moved on to by the
      // time this POST actually dispatches, not what this request was admitted under.
      const r = await act('escape_room.answer', { text }, btn, ['cooldown'], isCurrentRequest, authority);
      const stillOwner = local.erPendingReqId === reqId;
      if (stillOwner) { local.erPending = false; local.erPendingReqId = null; }
      // A snapshot that moved the room on while this was in flight (round/phase/seat/credential
      // change, leave, close, fatal, reset, pause/resume) already re-rendered this page under a
      // new authority (or a newer request already claimed pending); applying a stale success/
      // clear/error here would fight that render, and `snap` may already be null (leave/
      // closedByHost), so this is checked before any dereference.
      if (!stillOwner || !isLiveAuthority()) { render(); return; }
      if (r && r.accepted) {
        local.erDraft = ''; local.erError = '';
        // At teamScore === 0 a wrong answer's only effect is the private cooldownUntil key, which
        // never bumps the public revision (room_logic.py PRIVATE_GAME_KEYS) and so never arrives
        // over SSE — fetch the authoritative own projection directly through the existing GET
        // /state transport so the cooldown/refusal is visible and the input re-enables correctly,
        // without touching the frozen engine/reducer/privacy-revision behavior itself.
        // Two of these private refreshes can be outstanding at once (pending clears as soon as the
        // POST resolves, above, so a second submit can start and issue its own GET before the
        // first GET returns) and a cooldownUntil-only change never moves the public revision, so
        // two same-revision GETs can genuinely return in EITHER order. Revision comparison alone
        // cannot order them; ownership must be tied to issue order instead. refreshSeq is captured
        // at issue time (never at completion), so an older request always carries a smaller number
        // than a newer one no matter which settles first, and erRefreshApplied — the highest seq
        // actually applied so far — only ever moves forward, so a GET issued before the one
        // already applied is rejected as stale even though its revision ties.
        const refreshSeq = (local.erRefreshSeq = (local.erRefreshSeq || 0) + 1);
        try {
          const fresh = await transport.state(authority.code, authority.credToken);
          // Never regress behind a snapshot that already arrived (by push, by a second refresh, or
          // by this very refresh racing an authority change) and never apply an older-issued
          // refresh once a newer-issued one already landed.
          if (isLiveAuthority() && refreshSeq > (local.erRefreshApplied || 0)
            && (fresh.revision === undefined || snap.revision === undefined || fresh.revision >= snap.revision)) {
            local.erRefreshApplied = refreshSeq;
            snap = fresh; local.snapAt = Date.now();
          }
        } catch (e) { /* best-effort refresh only; the SSE push remains authoritative */ }
      }
      render();
    } }, h('label', { for: 'er-answer', class: 'small', text: 'Answer' }), inp, btn);
    answerUi = h('section', { class: 'card stack' }, form, errEl);
  }

  return h('div', { class: 'stack' }, status, promptBlock, fragCard, answerUi);
}

function impostorRevealCard() {
  const g = snap.game;
  const reveal = g.reveal || {};
  return h('section', { class: 'card stack' },
    h('h2', { class: 'card-title', text: 'Last round' }),
    h('p', { text: IMPOSTOR_OUTCOMES[g.outcome] || 'The game ended.' }),
    reveal.impostor ? h('p', { dir: 'auto', text: playerName(snap, reveal.impostor) + ' was the impostor.' }) : null,
    reveal.word ? h('p', { dir: 'auto', text: 'The word was “' + reveal.word + '”.' }) : null);
}

function whoAmIRevealList() {
  const g = snap.game;
  const me = snap.self && snap.self.id;
  const you = g.you || {};
  const assignments = g.assignments || {};
  const items = (g.order || []).map(pid => pid === me ? (you.assignment ? [pid, you.assignment] : null) : assignments[pid] ? [pid, assignments[pid]] : null).filter(Boolean);
  return h('section', { class: 'card' }, h('h2', { class: 'card-title', text: 'Characters' }),
    h('ul', { class: 'who-cards' }, items.map(([pid, a]) => h('li', { class: 'who-card' },
      h('span', { class: 'who-name', dir: 'auto', text: playerName(snap, pid) + (pid === me ? ' (you)' : '') }), h('span', { class: 'char-label', dir: 'auto', text: a.label })))));
}

(async () => {
  try {
    transport = await makeTransport();
  } catch (e) {
    mount(app, h('main', { class: 'page center' }, h('p', { class: 'form-error', role: 'alert', text: describeError(e.code) })));
    return;
  }
  const c = normalizeCode(params.get('code'));
  if (isCodeShape(c) && loadCredential('player', c, isSim)) enter(c);
  else renderJoin();
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && stream && document.body.dataset.conn !== 'live') stream.kick(); });
})();
