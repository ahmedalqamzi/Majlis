// Majlis Party TV display: presentation-only controls (fullscreen toggle, text-size toggle).
// Mounted into a container that sits outside tv.js's #app subtree, so the toolbar is never
// touched by render()'s mount(app, ...) and never needs to be reapplied after an SSE snapshot.
// Sends zero transport/gameplay requests and reads no credential or operator/player state.
import { h, mount } from './ui.js';

function fullscreenSupported() {
  const root = document.documentElement;
  return !!(root && typeof root.requestFullscreen === 'function' && typeof document.exitFullscreen === 'function');
}

function isFullscreen() {
  return !!document.fullscreenElement;
}

function fsLabel() {
  return isFullscreen() ? 'Exit fullscreen' : 'Fullscreen';
}

// requestFullscreen()/exitFullscreen() reject (they never throw synchronously) when the browser
// denies the request (no user gesture, user declined, platform restriction, ...). Swallowing the
// rejection here is what keeps a denial from surfacing as an unhandled promise rejection or
// leaving the button stuck in a transitional state.
function settle(promise, onReject) {
  if (promise && typeof promise.catch === 'function') promise.catch(onReject || (() => {}));
}

export function mountPresentationToolbar(root) {
  if (!root) return null;
  let fsBtn = null, fsHint = null, sizeBtn = null, large = false;

  function updateFsButton() {
    if (!fsBtn) return;
    fsBtn.textContent = fsLabel();
    fsBtn.setAttribute('aria-pressed', String(isFullscreen()));
  }

  function showFsHint(message) {
    if (!fsHint) return;
    fsHint.textContent = message || '';
    fsHint.hidden = !message;
  }

  function onFsClick() {
    showFsHint('');
    if (isFullscreen()) {
      settle(document.exitFullscreen());
    } else {
      settle(document.documentElement.requestFullscreen(), () => showFsHint('Fullscreen was not allowed by the browser.'));
    }
  }

  function applyTextSize() {
    document.body.classList.toggle('tv-text-large', large);
  }

  function onSizeClick() {
    large = !large;
    applyTextSize();
    sizeBtn.textContent = large ? 'Standard text' : 'Large text';
    sizeBtn.setAttribute('aria-pressed', String(large));
  }

  const nodes = [];
  if (fullscreenSupported()) {
    fsBtn = h('button', {
      type: 'button', class: 'btn btn-sm btn-ghost', 'aria-pressed': 'false',
      'aria-label': 'Toggle fullscreen', onclick: onFsClick, text: fsLabel(),
    });
    fsHint = h('span', { class: 'tv-presentation-hint', role: 'status', hidden: true });
    nodes.push(fsBtn, fsHint);
    document.addEventListener('fullscreenchange', updateFsButton);
  } else {
    nodes.push(h('span', {
      class: 'tv-presentation-hint',
      text: 'Fullscreen isn’t available on this display — use your device’s native fullscreen or screen-mirroring controls.',
    }));
  }

  sizeBtn = h('button', {
    type: 'button', class: 'btn btn-sm btn-ghost', 'aria-pressed': 'false',
    'aria-label': 'Toggle large text', onclick: onSizeClick, text: 'Large text',
  });
  nodes.push(sizeBtn);

  mount(root, h('div', { class: 'tv-presentation-toolbar', role: 'group', 'aria-label': 'Display presentation controls' }, nodes));

  return {
    destroy() { document.removeEventListener('fullscreenchange', updateFsButton); },
  };
}
