// Majlis shared authority core (L01A candidate, protocol v1).
//
// Pure-JS port of the accepted Python server at 77ecabd: errors.py,
// textutil.py, content.py, modes/{__init__,who_am_i,feud}.py, room_logic.py
// and the RoomManager in manager.py. HTTP parsing, rate limits, Host/Origin
// checks and bearer parsing stay in the transport (L01B) and are NOT here.
//
// Rules for this file:
// * Classic script, ES2020, strict. No DOM, network, timers, storage, eval,
//   Function(), Math.random, Date or native callbacks. Time is a `now`
//   argument (seconds, double); entropy is an EntropyPool of bytes supplied by
//   the caller (production: SecRandomCopyBytes / SecureRandom).
// * Text semantics are CPython 3.9 + unicodedata 13.0.0, from the generated
//   tables in unicode13.generated.js. String.prototype.normalize, toUpperCase,
//   toLowerCase and \s are never used for protocol decisions: host ICU tracks
//   a newer Unicode and drifts.
// * Python dict get semantics: has(o, k) decides presence; a present JSON
//   null is Python None, never the default.
// * JSON numbers: safe ints are JS numbers, ints beyond 2^53 are PyBigInt
//   boxes holding exact digits, floats are PyFloat boxes so that
//   is_int rejects 1.0 and 1e2 exactly like Python.
"use strict";

var MajlisCore = (function (T) {
  if (!T || T.unidata !== "13.0.0") throw new Error("unicode13 tables missing or wrong version");

  var hasOwn = Object.prototype.hasOwnProperty;
  function has(o, k) { return o !== null && typeof o === "object" && hasOwn.call(o, k); }
  // dict.get(key, default): present key wins even when its value is null.
  function get(o, k, dflt) { return has(o, k) ? o[k] : (dflt === undefined ? null : dflt); }
  function isNone(v) { return v === null || v === undefined; }
  function obj() { return Object.create(null); }
  // Python bool(v) for JSON-decoded values.
  function pyTruthy(v) {
    if (v === null || v === undefined || v === false) return false;
    if (v === true) return true;
    if (typeof v === "number") return v !== 0;
    if (typeof v === "string" || Array.isArray(v)) return v.length > 0;
    if (v instanceof PyFloat) return v.value !== 0; // NaN is truthy in Python too
    if (v instanceof PyBigInt) return true; // only built for |v| > 2^53
    return Object.keys(v).length > 0;
  }

  // ------------------------------------------------------------- PyFloat
  function PyFloat(value) { this.value = value; }
  PyFloat.prototype.toJSON = function () {
    var v = this.value;
    if (v !== v) return "NaN";
    if (v === Infinity) return "Infinity";
    if (v === -Infinity) return "-Infinity";
    return Object.is(v, -0) ? "-0.0" : v;
  };
  // An int outside the IEEE-safe range keeps its exact decimal digits. Every
  // protocol int is range-checked to small bounds, so such a value can only
  // ever fail is_int (as in Python) or be reported back by the trace tools.
  function PyBigInt(digits) { this.digits = digits; }
  function isPyDict(v) {
    return v !== null && typeof v === "object" && !Array.isArray(v) && !(v instanceof PyFloat) && !(v instanceof PyBigInt);
  }
  function isStr(v) { return typeof v === "string"; }
  function isBool(v) { return typeof v === "boolean"; }
  // isinstance(v, int) and not isinstance(v, bool), for values that can pass
  // a range check; isinstance alone also accepts PyBigInt (see validateLimit).
  function isPyInt(v) { return typeof v === "number"; }

  // ------------------------------------------------------- code point utils
  function cps(s) { var out = []; for (var ch of s) out.push(ch.codePointAt(0)); return out; }
  function fromCps(list) {
    var out = "";
    for (var i = 0; i < list.length; i++) out += String.fromCodePoint(list[i]);
    return out;
  }
  // len(str): code points. Lone surrogates count 1, like Python.
  function pyLen(s) { var n = 0; for (var _ of s) n++; return n; } // eslint-disable-line no-unused-vars

  // ------------------------------------------------------------ tables
  function expansionMap(flat) {
    var m = new Map();
    for (var i = 0; i < flat.length;) {
      var cp = flat[i], n = flat[i + 1];
      m.set(cp, flat.slice(i + 2, i + 2 + n));
      i += 2 + n;
    }
    return m;
  }
  var NFD = expansionMap(T.nfd);
  var NFKD = expansionMap(T.nfkd);
  var FOLD = expansionMap(T.fold);
  var UPPER_CODE = expansionMap(T.upperCode);
  var WS = new Set(T.ws);
  var COMP = new Map();
  for (var ci = 0; ci < T.comp.length; ci += 3) COMP.set(T.comp[ci] * 0x110000 + T.comp[ci + 1], T.comp[ci + 2]);
  function rangeLookup(flat, stride) {
    var starts = [];
    for (var i = 0; i < flat.length; i += stride) starts.push(i);
    return function (cp) {
      var lo = 0, hi = starts.length - 1;
      while (lo <= hi) {
        var mid = (lo + hi) >> 1, at = starts[mid];
        if (cp < flat[at]) hi = mid - 1;
        else if (cp > flat[at + 1]) lo = mid + 1;
        else return stride === 3 ? flat[at + 2] : 1;
      }
      return 0;
    };
  }
  var ccc = rangeLookup(T.ccc, 3);
  var rejected = rangeLookup(T.reject, 2);

  // ------------------------------------------------- Unicode 13 normalization
  var SBase = 0xAC00, LBase = 0x1100, VBase = 0x1161, TBase = 0x11A7;
  var LCount = 19, VCount = 21, TCount = 28, NCount = VCount * TCount, SCount = LCount * NCount;

  function decompose(s, compat) {
    var out = [];
    for (var ch of s) {
      var cp = ch.codePointAt(0);
      var si = cp - SBase;
      if (si >= 0 && si < SCount) {
        out.push(LBase + Math.floor(si / NCount), VBase + Math.floor((si % NCount) / TCount));
        if (si % TCount) out.push(TBase + si % TCount);
        continue;
      }
      var m = (compat && NFKD.get(cp)) || NFD.get(cp);
      if (m) { for (var k = 0; k < m.length; k++) out.push(m[k]); } else out.push(cp);
    }
    // Canonical ordering: stable sort of each run of non-starters by ccc.
    for (var i = 0; i < out.length; i++) {
      if (ccc(out[i]) === 0) continue;
      var j = i;
      while (j < out.length && ccc(out[j]) !== 0) j++;
      if (j - i > 1) {
        var run = out.slice(i, j).map(function (c, idx) { return [ccc(c), idx, c]; });
        run.sort(function (a, b) { return a[0] - b[0] || a[1] - b[1]; });
        for (var r = 0; r < run.length; r++) out[i + r] = run[r][2];
      }
      i = j - 1;
    }
    return out;
  }

  function compose(list) {
    if (!list.length) return list;
    var out = [], starterIdx = -1, lastCcc = -1;
    for (var i = 0; i < list.length; i++) {
      var c = list[i], cc = ccc(c);
      if (starterIdx >= 0) {
        var s = out[starterIdx];
        // Hangul LV and LV+T
        if (lastCcc === -1 || out.length - 1 === starterIdx) {
          var li = s - LBase, vi = c - VBase;
          if (li >= 0 && li < LCount && vi >= 0 && vi < VCount) {
            out[starterIdx] = SBase + (li * VCount + vi) * TCount; lastCcc = -1; continue;
          }
          var si = s - SBase, ti = c - TBase;
          if (si >= 0 && si < SCount && si % TCount === 0 && ti > 0 && ti < TCount) {
            out[starterIdx] = s + ti; lastCcc = -1; continue;
          }
        }
        var blocked = out.length - 1 !== starterIdx && (lastCcc === 0 || lastCcc >= cc);
        if (!blocked) {
          var p = COMP.get(s * 0x110000 + c);
          if (p !== undefined) { out[starterIdx] = p; continue; }
        }
      }
      if (cc === 0) { starterIdx = out.length; lastCcc = -1; } else lastCcc = cc;
      out.push(c);
    }
    return out;
  }

  function nfc(s) { return fromCps(compose(decompose(s, false))); }
  function nfkc(s) { return fromCps(compose(decompose(s, true))); }
  function nfd(s) { return fromCps(decompose(s, false)); }
  function nfkd(s) { return fromCps(decompose(s, true)); }

  // --------------------------------------------- str.split/strip/casefold/upper
  function pySplit(s) { // str.split() with no arguments
    var out = [], cur = "", inWord = false;
    for (var ch of s) {
      if (WS.has(ch.codePointAt(0))) { if (inWord) { out.push(cur); cur = ""; inWord = false; } }
      else { cur += ch; inWord = true; }
    }
    if (inWord) out.push(cur);
    return out;
  }
  function pyStrip(s) {
    var list = cps(s), a = 0, b = list.length;
    while (a < b && WS.has(list[a])) a++;
    while (b > a && WS.has(list[b - 1])) b--;
    return fromCps(list.slice(a, b));
  }
  function casefold(s) {
    var out = "";
    for (var ch of s) { var m = FOLD.get(ch.codePointAt(0)); out += m ? fromCps(m) : ch; }
    return out;
  }
  // code.upper() restricted to results that can still fullmatch [A-Z2-9]{6};
  // returns null as soon as any character's uppercase falls outside it.
  function upperForCode(s) {
    var out = "";
    for (var ch of s) {
      var cp = ch.codePointAt(0);
      if ((cp >= 0x41 && cp <= 0x5A) || (cp >= 0x32 && cp <= 0x39)) { out += ch; continue; }
      var m = UPPER_CODE.get(cp);
      if (!m) return null;
      out += fromCps(m);
    }
    return out;
  }

  // ----------------------------------------------------------- textutil.py
  var MAX_NAME_LEN = 24;
  function cleanText(value, maxLen) {
    if (!isStr(value)) return null;
    value = nfc(value);
    for (var ch of value) {
      var cp = ch.codePointAt(0);
      // rejected() already folds in the bidi controls and the isspace exemption
      if (rejected(cp)) return null;
    }
    var collapsed = pySplit(value).join(" ");
    if (!collapsed || pyLen(collapsed) > maxLen) return null;
    return collapsed;
  }
  function cleanName(value) { return cleanText(value, MAX_NAME_LEN); }
  function matchKey(value) { return pySplit(casefold(nfkc(value))).join(" "); }

  // ------------------------------------------------------------- errors.py
  var ERRORS = {
    bad_request: [400, "Malformed request."],
    invalid_json: [400, "Request body must be a JSON object."],
    length_required: [411, "Content-Length is required; chunked bodies are not accepted."],
    body_too_large: [413, "Request body exceeds the size limit."],
    unsupported_media_type: [415, "Content-Type must be application/json."],
    query_not_allowed: [400, "Query strings are not accepted on API routes; send credentials only in the Authorization header."],
    origin_forbidden: [403, "Cross-origin requests are not allowed."],
    host_forbidden: [403, "Host header is not an allowed server origin."],
    not_found: [404, "Not found."],
    method_not_allowed: [405, "Method not allowed."],
    rate_limited: [429, "Too many requests; retry later."],
    too_many_rooms: [503, "Room capacity reached; retry later."],
    too_many_streams: [429, "Too many open event streams."],
    server_busy: [503, "Server is busy."],
    internal_error: [500, "Internal error."],
    room_not_found: [404, "Room not found or expired."],
    room_expired: [410, "Room expired."],
    unauthorized: [401, "Missing or invalid credentials."],
    token_expired: [401, "Credentials expired."],
    forbidden: [403, "This role may not perform that action."],
    invalid_config: [400, "Invalid room configuration."],
    invalid_name: [400, "Name must be 1-24 visible characters."],
    name_taken: [409, "That name is already used in this room."],
    room_full: [409, "Room is full."],
    room_closed: [409, "Room is closed."],
    game_in_progress: [409, "A game is in progress; new players may join between games."],
    spectator_read_only: [403, "Spectators are read-only until the next game starts."],
    invalid_action_id: [400, "actionId must be 1-64 characters of [A-Za-z0-9._:-]."],
    invalid_action: [400, "Action must contain a valid type and optional string roundId."],
    unknown_action: [400, "Unknown action type."],
    invalid_payload: [400, "Invalid action payload."],
    round_required: [400, "This action requires the current roundId."],
    stale_round: [409, "roundId does not match the current round."],
    stale_card: [409, "cardEpoch does not match the current card."],
    invalid_phase: [409, "Action is not valid in the current phase."],
    paused: [409, "Game is paused."],
    wrong_mode: [409, "Action belongs to a different mode."],
    unknown_mode: [400, "Unknown mode."],
    mode_unimplemented: [409, "Mode is not implemented in this server build."],
    mode_not_selected: [409, "Select a mode first."],
    content_missing: [409, "Content pack for this mode is missing."],
    content_invalid: [409, "Content pack for this mode failed validation."],
    content_insufficient: [409, "Content pack has too few items for this game."],
    content_exhausted: [409, "No more content items remain for another round."],
    not_enough_players: [409, "Not enough players for this room or mode."],
    too_many_players: [409, "Too many players for this room or mode."],
    unknown_player: [400, "Unknown player."],
    already_revealed: [409, "Already revealed."],
    no_pending_guess: [409, "That player has no pending guess."],
    already_awarded: [409, "Points for this round were already awarded."],
    buzzer_closed: [409, "Buzzer is not open."],
    buzzer_taken: [409, "Another player already won the buzzer."],
    unknown_answer: [400, "Unknown answer."],
    no_match: [409, "No unrevealed answer matches that text."],
    max_strikes: [409, "Maximum strikes reached."],
    steal_not_available: [409, "A steal is only available after the maximum strikes."],
    no_control: [409, "No player is in control; specify playerId."],
    round_awarded: [409, "This round was already awarded."],
    self_vote: [409, "Players may not vote for themselves."],
    already_voted: [409, "This player has already voted this round."],
    invalid_answer: [400, "That answer is not accepted for this round."],
    already_submitted: [409, "This player already submitted an answer this round."],
    unknown_option: [400, "Unknown vote option."],
    cooldown: [429, "Wait before submitting another answer."],
    already_hinted: [409, "A hint was already used for this puzzle."]
  };
  function PartyError(code) {
    if (!hasOwn.call(ERRORS, code)) code = "internal_error";
    this.code = code;
    this.status = ERRORS[code][0];
  }
  function statusFor(code) { return (hasOwn.call(ERRORS, code) ? ERRORS[code] : ERRORS.internal_error)[0]; }
  function errorBody(code) {
    if (!hasOwn.call(ERRORS, code)) code = "internal_error";
    return { code: code, message: ERRORS[code][1] };
  }

  // ------------------------------------------------- Python-compatible JSON
  // json.loads(str) as CPython 3.9's C scanner: ASCII digits only, strict
  // strings (no raw control characters), no leading BOM, duplicate keys keep
  // the first position with the last value, ints vs floats distinguished.
  // allowConstants: NaN/Infinity/-Infinity (request bodies: yes; content
  // packs: no, parse_constant rejects them). maxDepth stands in for CPython's
  // stack-dependent RecursionError (declared difference, see L01A report).
  function JsonError(msg) { this.message = msg; }
  function parseJson(text, opts) {
    opts = opts || {};
    var allowConstants = opts.allowConstants !== false;
    var maxDepth = opts.maxDepth || 900;
    var i = 0, n = text.length;
    if (n && text.charCodeAt(0) === 0xFEFF) throw new JsonError("Unexpected UTF-8 BOM");
    function ws() {
      while (i < n) {
        var c = text.charCodeAt(i);
        if (c === 0x20 || c === 0x09 || c === 0x0A || c === 0x0D) i++; else break;
      }
    }
    function fail(msg) { throw new JsonError(msg + " at " + i); }
    function isDigit(c) { return c >= 0x30 && c <= 0x39; }
    function hex4(at) {
      if (at + 4 > n) fail("Invalid \\uXXXX escape");
      var v = 0;
      for (var k = 0; k < 4; k++) {
        var c = text.charCodeAt(at + k), d;
        if (c >= 0x30 && c <= 0x39) d = c - 0x30;
        else if (c >= 0x61 && c <= 0x66) d = c - 0x57;
        else if (c >= 0x41 && c <= 0x46) d = c - 0x37;
        else fail("Invalid \\uXXXX escape");
        v = v * 16 + d;
      }
      return v;
    }
    function str() {
      i++; // opening quote
      var out = "", start = i;
      for (;;) {
        if (i >= n) fail("Unterminated string");
        var c = text.charCodeAt(i);
        if (c === 0x22) { out += text.slice(start, i); i++; return out; }
        if (c < 0x20) fail("Invalid control character");
        if (c !== 0x5C) { i++; continue; }
        out += text.slice(start, i);
        if (i + 1 >= n) fail("Unterminated string");
        var e = text.charAt(i + 1);
        if (e === "u") {
          var u = hex4(i + 2);
          i += 6;
          if (u >= 0xD800 && u <= 0xDBFF && text.charCodeAt(i) === 0x5C && text.charAt(i + 1) === "u") {
            var u2 = hex4(i + 2);
            if (u2 >= 0xDC00 && u2 <= 0xDFFF) { out += String.fromCharCode(u, u2); i += 6; start = i; continue; }
          }
          out += String.fromCharCode(u);
        } else {
          var map = { '"': '"', "\\": "\\", "/": "/", b: "\b", f: "\f", n: "\n", r: "\r", t: "\t" };
          if (!hasOwn.call(map, e)) fail("Invalid \\escape");
          out += map[e];
          i += 2;
        }
        start = i;
      }
    }
    function num() {
      var s = i;
      if (text.charCodeAt(i) === 0x2D) i++;
      if (i < n && text.charCodeAt(i) === 0x30) i++;
      else if (i < n && text.charCodeAt(i) >= 0x31 && text.charCodeAt(i) <= 0x39) { while (i < n && isDigit(text.charCodeAt(i))) i++; }
      else { i = s; fail("Expecting value"); }
      var isFloat = false;
      if (i + 1 < n && text.charCodeAt(i) === 0x2E && isDigit(text.charCodeAt(i + 1))) {
        isFloat = true; i += 2;
        while (i < n && isDigit(text.charCodeAt(i))) i++;
      }
      if (i < n && (text.charCodeAt(i) === 0x65 || text.charCodeAt(i) === 0x45)) {
        var j = i + 1;
        if (j < n && (text.charCodeAt(j) === 0x2B || text.charCodeAt(j) === 0x2D)) j++;
        if (j < n && isDigit(text.charCodeAt(j))) {
          while (j < n && isDigit(text.charCodeAt(j))) j++;
          isFloat = true; i = j;
        }
      }
      var lit = text.slice(s, i);
      if (isFloat) return new PyFloat(Number(lit));
      var v = Number(lit);
      if (!Number.isSafeInteger(v)) return new PyBigInt(BigInt(lit).toString());
      return v === 0 ? 0 : v; // Python ints have no -0
    }
    function constant(name, value) {
      if (text.startsWith(name, i)) {
        i += name.length;
        if (!allowConstants) throw new JsonError("non-finite number");
        return new PyFloat(value);
      }
      return undefined;
    }
    function value(depth) {
      if (i >= n) fail("Expecting value");
      var c = text.charAt(i);
      if (c === '"') return str();
      if (c === "{" || c === "[") {
        if (depth >= maxDepth) throw new JsonError("maximum recursion depth exceeded");
        return c === "{" ? object(depth + 1) : array(depth + 1);
      }
      if (c === "n" && text.startsWith("null", i)) { i += 4; return null; }
      if (c === "t" && text.startsWith("true", i)) { i += 4; return true; }
      if (c === "f" && text.startsWith("false", i)) { i += 5; return false; }
      var k;
      if (c === "N" && (k = constant("NaN", NaN)) !== undefined) return k;
      if (c === "I" && (k = constant("Infinity", Infinity)) !== undefined) return k;
      if (c === "-" && text.startsWith("-Infinity", i)) return constant("-Infinity", -Infinity);
      if (c === "-" || isDigit(text.charCodeAt(i))) return num();
      fail("Expecting value");
    }
    function object(depth) {
      i++;
      var o = obj();
      ws();
      if (text.charAt(i) === "}") { i++; return o; }
      for (;;) {
        if (text.charAt(i) !== '"') fail("Expecting property name enclosed in double quotes");
        var key = str();
        ws();
        if (text.charAt(i) !== ":") fail("Expecting ':' delimiter");
        i++; ws();
        Object.defineProperty(o, key, { value: value(depth), writable: true, enumerable: true, configurable: true });
        ws();
        var c = text.charAt(i);
        if (c === "}") { i++; return o; }
        if (c !== ",") fail("Expecting ',' delimiter");
        i++; ws();
      }
    }
    function array(depth) {
      i++;
      var a = [];
      ws();
      if (text.charAt(i) === "]") { i++; return a; }
      for (;;) {
        ws();
        a.push(value(depth));
        ws();
        var c = text.charAt(i);
        if (c === "]") { i++; return a; }
        if (c !== ",") fail("Expecting ',' delimiter");
        i++;
      }
    }
    ws();
    var result = value(0);
    ws();
    if (i !== n) fail("Extra data");
    return result;
  }

  // Strict UTF-8 decode (Python codec "utf-8", or "utf-8-sig" with stripBom).
  // Returns null on any invalid sequence, surrogate, overlong or > U+10FFFF.
  function decodeUtf8(bytes, stripBom) {
    var i = 0, n = bytes.length, out = "";
    if (stripBom && n >= 3 && bytes[0] === 0xEF && bytes[1] === 0xBB && bytes[2] === 0xBF) i = 3;
    while (i < n) {
      var b = bytes[i], cp, need, min;
      if (b < 0x80) { out += String.fromCharCode(b); i++; continue; }
      if (b >= 0xC2 && b <= 0xDF) { cp = b & 0x1F; need = 1; min = 0x80; }
      else if (b >= 0xE0 && b <= 0xEF) { cp = b & 0x0F; need = 2; min = 0x800; }
      else if (b >= 0xF0 && b <= 0xF4) { cp = b & 0x07; need = 3; min = 0x10000; }
      else return null;
      if (i + need >= n) return null; // truncated sequence
      for (var k = 1; k <= need; k++) {
        var c = bytes[i + k];
        if (c === undefined || (c & 0xC0) !== 0x80) return null;
        cp = (cp << 6) | (c & 0x3F);
      }
      if (cp < min || cp > 0x10FFFF || (cp >= 0xD800 && cp <= 0xDFFF)) return null;
      out += String.fromCodePoint(cp);
      i += need + 1;
    }
    return out;
  }

  // httpd._read_json after the transport has checked length and media type:
  // strict UTF-8 (no BOM stripping), json.loads, and the body must be an object.
  function parseRequestBody(bytes) {
    var text = decodeUtf8(bytes, false);
    if (text === null) throw new PartyError("invalid_json");
    var body;
    try { body = parseJson(text, { allowConstants: true }); }
    catch (e) {
      if (e instanceof JsonError) throw new PartyError("invalid_json");
      throw e;
    }
    if (!isPyDict(body)) throw new PartyError("invalid_json");
    return body;
  }

  // ------------------------------------------------------------ content.py
  var SCHEMA_VERSION = 1, MAX_FILE_BYTES = 2 * 1024 * 1024, MAX_ITEMS = 2000, MAX_TEXT = 500, MAX_ID = 64;
  function isText(value, maxLen) {
    if (maxLen === undefined) maxLen = MAX_TEXT;
    return isStr(value) && pyStrip(value) !== "" && pyLen(value) <= maxLen;
  }
  function isInt(value, lo, hi) { return isPyInt(value) && lo <= value && value <= hi; }
  function ContentStatus(mode, status, pack, issues) {
    this.mode = mode; this.status = status; this.pack = pack || null; this.issues = (issues || []).slice();
  }
  ContentStatus.prototype.ok = function () { return this.status === "ok"; };

  function parsePack(mode, data, validateItem, validateItems) {
    if (!isPyDict(data)) return [null, ["root: must be an object"]];
    var issues = [];
    if (!isInt(get(data, "schemaVersion"), SCHEMA_VERSION, SCHEMA_VERSION)) issues.push("schemaVersion: must be 1");
    if (get(data, "mode") !== mode) issues.push("mode: must equal the file's mode id");
    if (!isText(get(data, "title"))) issues.push("title: required non-empty string");
    if (!isText(get(data, "licenseNote"), 2000)) issues.push("licenseNote: required non-empty string");
    var items = get(data, "items");
    var normalized = [];
    if (!Array.isArray(items) || !items.length) issues.push("items: required non-empty array");
    else if (items.length > MAX_ITEMS) issues.push("items: too many items");
    else {
      var seen = new Set();
      for (var index = 0; index < items.length; index++) {
        var path = "items[" + index + "]";
        var before = issues.length;
        var out = validateItem(items[index], path, issues);
        if (issues.length === before && out !== null) {
          if (seen.has(out.id)) issues.push(path + ".id: duplicate id");
          else { seen.add(out.id); normalized.push(out); }
        }
      }
      if (!issues.length && validateItems) validateItems(normalized, issues);
    }
    if (issues.length) return [null, issues];
    return [{ mode: mode, title: data.title, licenseNote: data.licenseNote, items: normalized }, []];
  }

  // bytes: Uint8Array/array of the pack file, or null when the file is absent.
  function loadMode(mode, bytes, validateItem, validateItems) {
    if (bytes === null || bytes === undefined) return new ContentStatus(mode, "content_missing");
    if (bytes.length > MAX_FILE_BYTES) return new ContentStatus(mode, "content_invalid", null, ["file: exceeds size limit"]);
    var text = decodeUtf8(bytes, true);
    if (text === null) return new ContentStatus(mode, "content_invalid", null, ["file: not UTF-8"]);
    var data;
    try { data = parseJson(text, { allowConstants: false }); }
    catch (e) {
      if (e instanceof JsonError) return new ContentStatus(mode, "content_invalid", null, ["file: not valid JSON"]);
      throw e;
    }
    var r = parsePack(mode, data, validateItem, validateItems);
    if (r[0] === null) return new ContentStatus(mode, "content_invalid", null, r[1]);
    return new ContentStatus(mode, "ok", r[0]);
  }

  // ------------------------------------------------------------- helpers
  function deepcopy(v) {
    if (v === null || typeof v !== "object") return v;
    if (v instanceof PyFloat) return new PyFloat(v.value);
    if (v instanceof PyBigInt) return new PyBigInt(v.digits);
    if (Array.isArray(v)) return v.map(deepcopy);
    var o = obj();
    for (var k of Object.keys(v)) o[k] = deepcopy(v[k]);
    return o;
  }
  function deepFreeze(v) {
    if (v !== null && typeof v === "object" && !Object.isFrozen(v)) {
      Object.freeze(v);
      for (var k of Object.keys(v)) deepFreeze(v[k]);
    }
    return v;
  }
  function inList(list, v) { return isStr(v) && list.indexOf(v) >= 0; }

  // ---------------------------------------------------------- MT19937 shuffle
  var MT_N = 624, MT_M = 397;
  function MT(seed) { // seed: BigInt; CPython random.seed(int) == init_by_array(abs(seed))
    var big = seed < 0n ? -seed : seed, key = [];
    do { key.push(Number(big & 0xffffffffn)); big >>= 32n; } while (big > 0n);
    var mt = new Uint32Array(MT_N);
    mt[0] = 19650218;
    for (var a = 1; a < MT_N; a++) {
      var p = mt[a - 1] ^ (mt[a - 1] >>> 30);
      mt[a] = (Math.imul(1812433253, p) + a) >>> 0;
    }
    var i = 1, j = 0, k = Math.max(MT_N, key.length);
    for (; k; k--) {
      var q = mt[i - 1] ^ (mt[i - 1] >>> 30);
      mt[i] = ((mt[i] ^ Math.imul(q, 1664525)) + key[j] + j) >>> 0;
      i++; j++;
      if (i >= MT_N) { mt[0] = mt[MT_N - 1]; i = 1; }
      if (j >= key.length) j = 0;
    }
    for (k = MT_N - 1; k; k--) {
      var r = mt[i - 1] ^ (mt[i - 1] >>> 30);
      mt[i] = ((mt[i] ^ Math.imul(r, 1566083941)) - i) >>> 0;
      i++;
      if (i >= MT_N) { mt[0] = mt[MT_N - 1]; i = 1; }
    }
    mt[0] = 0x80000000;
    this.mt = mt; this.idx = MT_N;
  }
  MT.prototype.u32 = function () {
    var mt = this.mt, y, kk;
    if (this.idx >= MT_N) {
      for (kk = 0; kk < MT_N; kk++) {
        y = (mt[kk] & 0x80000000) | (mt[(kk + 1) % MT_N] & 0x7fffffff);
        mt[kk] = mt[(kk + MT_M) % MT_N] ^ (y >>> 1) ^ ((y & 1) ? 0x9908b0df : 0);
      }
      this.idx = 0;
    }
    y = mt[this.idx++];
    y ^= y >>> 11; y ^= (y << 7) & 0x9d2c5680; y ^= (y << 15) & 0xefc60000; y ^= y >>> 18;
    return y >>> 0;
  };
  MT.prototype.randbelow = function (n) { // n <= 2^31
    var k = 32 - Math.clz32(n), r = this.u32() >>> (32 - k);
    while (r >= n) r = this.u32() >>> (32 - k);
    return r;
  };
  function shuffleInPlace(seed, x) { // random.Random(seed).shuffle(x)
    var rng = new MT(BigInt(seed));
    for (var i = x.length - 1; i > 0; i--) {
      var j = rng.randbelow(i + 1), t = x[i]; x[i] = x[j]; x[j] = t;
    }
    return x;
  }

  // ------------------------------------------------------------- SHA-512
  // Used only to reproduce CPython's random.seed(str, version=2): a ==
  // utf8(a); a += sha512(a).digest(); a = int.from_bytes(a, "big"); then fed
  // into MT() above exactly as an int seed. H0/K are the FIPS 180-4
  // constants (fractional bits of sqrt/cbrt of the first 8/80 primes),
  // verified against Python's hashlib.sha512 for known test vectors.
  var SHA512_MASK64 = (1n << 64n) - 1n;
  var SHA512_H0 = [
    0x6a09e667f3bcc908n, 0xbb67ae8584caa73bn, 0x3c6ef372fe94f82bn, 0xa54ff53a5f1d36f1n,
    0x510e527fade682d1n, 0x9b05688c2b3e6c1fn, 0x1f83d9abfb41bd6bn, 0x5be0cd19137e2179n
  ];
  var SHA512_K = [
    0x428a2f98d728ae22n, 0x7137449123ef65cdn, 0xb5c0fbcfec4d3b2fn, 0xe9b5dba58189dbbcn,
    0x3956c25bf348b538n, 0x59f111f1b605d019n, 0x923f82a4af194f9bn, 0xab1c5ed5da6d8118n,
    0xd807aa98a3030242n, 0x12835b0145706fben, 0x243185be4ee4b28cn, 0x550c7dc3d5ffb4e2n,
    0x72be5d74f27b896fn, 0x80deb1fe3b1696b1n, 0x9bdc06a725c71235n, 0xc19bf174cf692694n,
    0xe49b69c19ef14ad2n, 0xefbe4786384f25e3n, 0x0fc19dc68b8cd5b5n, 0x240ca1cc77ac9c65n,
    0x2de92c6f592b0275n, 0x4a7484aa6ea6e483n, 0x5cb0a9dcbd41fbd4n, 0x76f988da831153b5n,
    0x983e5152ee66dfabn, 0xa831c66d2db43210n, 0xb00327c898fb213fn, 0xbf597fc7beef0ee4n,
    0xc6e00bf33da88fc2n, 0xd5a79147930aa725n, 0x06ca6351e003826fn, 0x142929670a0e6e70n,
    0x27b70a8546d22ffcn, 0x2e1b21385c26c926n, 0x4d2c6dfc5ac42aedn, 0x53380d139d95b3dfn,
    0x650a73548baf63den, 0x766a0abb3c77b2a8n, 0x81c2c92e47edaee6n, 0x92722c851482353bn,
    0xa2bfe8a14cf10364n, 0xa81a664bbc423001n, 0xc24b8b70d0f89791n, 0xc76c51a30654be30n,
    0xd192e819d6ef5218n, 0xd69906245565a910n, 0xf40e35855771202an, 0x106aa07032bbd1b8n,
    0x19a4c116b8d2d0c8n, 0x1e376c085141ab53n, 0x2748774cdf8eeb99n, 0x34b0bcb5e19b48a8n,
    0x391c0cb3c5c95a63n, 0x4ed8aa4ae3418acbn, 0x5b9cca4f7763e373n, 0x682e6ff3d6b2b8a3n,
    0x748f82ee5defb2fcn, 0x78a5636f43172f60n, 0x84c87814a1f0ab72n, 0x8cc702081a6439ecn,
    0x90befffa23631e28n, 0xa4506cebde82bde9n, 0xbef9a3f7b2c67915n, 0xc67178f2e372532bn,
    0xca273eceea26619cn, 0xd186b8c721c0c207n, 0xeada7dd6cde0eb1en, 0xf57d4f7fee6ed178n,
    0x06f067aa72176fban, 0x0a637dc5a2c898a6n, 0x113f9804bef90daen, 0x1b710b35131c471bn,
    0x28db77f523047d84n, 0x32caab7b40c72493n, 0x3c9ebe0a15c9bebcn, 0x431d67c49c100d4cn,
    0x4cc5d4becb3e42b6n, 0x597f299cfc657e2an, 0x5fcb6fab3ad6faecn, 0x6c44198c4a475817n
  ];
  function sha512Rotr(x, n) { return ((x >> n) | (x << (64n - n))) & SHA512_MASK64; }
  function sha512Add(a, b) { return (a + b) & SHA512_MASK64; }
  function sha512(bytes) { // Uint8Array/array of bytes -> Uint8Array(64)
    var ml = bytes.length, bitLen = BigInt(ml) * 8n;
    var r = (ml + 1) % 128, padLen = (112 - r + 128) % 128;
    var total = ml + 1 + padLen + 16, msg = new Uint8Array(total), i, b;
    msg.set(bytes, 0);
    msg[ml] = 0x80;
    for (i = 0; i < 16; i++) msg[total - 1 - i] = Number((bitLen >> BigInt(8 * i)) & 0xffn);
    var H = SHA512_H0.slice();
    for (var off = 0; off < total; off += 128) {
      var W = new Array(80), t;
      for (t = 0; t < 16; t++) {
        var w = 0n;
        for (b = 0; b < 8; b++) w = (w << 8n) | BigInt(msg[off + t * 8 + b]);
        W[t] = w;
      }
      for (t = 16; t < 80; t++) {
        var s0 = sha512Rotr(W[t - 15], 1n) ^ sha512Rotr(W[t - 15], 8n) ^ (W[t - 15] >> 7n);
        var s1 = sha512Rotr(W[t - 2], 19n) ^ sha512Rotr(W[t - 2], 61n) ^ (W[t - 2] >> 6n);
        W[t] = (W[t - 16] + s0 + W[t - 7] + s1) & SHA512_MASK64;
      }
      var a = H[0], bb = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (t = 0; t < 80; t++) {
        var S1 = sha512Rotr(e, 14n) ^ sha512Rotr(e, 18n) ^ sha512Rotr(e, 41n);
        var ch = (e & f) ^ ((~e & SHA512_MASK64) & g);
        var temp1 = (h + S1 + ch + SHA512_K[t] + W[t]) & SHA512_MASK64;
        var S0 = sha512Rotr(a, 28n) ^ sha512Rotr(a, 34n) ^ sha512Rotr(a, 39n);
        var maj = (a & bb) ^ (a & c) ^ (bb & c);
        var temp2 = (S0 + maj) & SHA512_MASK64;
        h = g; g = f; f = e; e = (d + temp1) & SHA512_MASK64;
        d = c; c = bb; bb = a; a = (temp1 + temp2) & SHA512_MASK64;
      }
      H[0] = sha512Add(H[0], a); H[1] = sha512Add(H[1], bb); H[2] = sha512Add(H[2], c); H[3] = sha512Add(H[3], d);
      H[4] = sha512Add(H[4], e); H[5] = sha512Add(H[5], f); H[6] = sha512Add(H[6], g); H[7] = sha512Add(H[7], h);
    }
    var out = new Uint8Array(64);
    for (i = 0; i < 8; i++) for (b = 0; b < 8; b++) out[i * 8 + b] = Number((H[i] >> BigInt(8 * (7 - b))) & 0xffn);
    return out;
  }
  function utf8Encode(s) {
    var bytes = [];
    for (var ch of s) {
      var cp = ch.codePointAt(0);
      if (cp < 0x80) bytes.push(cp);
      else if (cp < 0x800) bytes.push(0xc0 | (cp >> 6), 0x80 | (cp & 0x3f));
      else if (cp < 0x10000) bytes.push(0xe0 | (cp >> 12), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
      else bytes.push(0xf0 | (cp >> 18), 0x80 | ((cp >> 12) & 0x3f), 0x80 | ((cp >> 6) & 0x3f), 0x80 | (cp & 0x3f));
    }
    return new Uint8Array(bytes);
  }
  function stringSeedToBigInt(s) { // random.seed(s, version=2) -> the int random.Random(s) actually seeds with
    var bytes = utf8Encode(s), digest = sha512(bytes);
    var combined = new Uint8Array(bytes.length + digest.length);
    combined.set(bytes, 0); combined.set(digest, bytes.length);
    var v = 0n;
    for (var i = 0; i < combined.length; i++) v = (v << 8n) | BigInt(combined[i]);
    return v;
  }
  function randBelowFromStringSeed(s, n) { // random.Random(s).randrange(n) for a str seed s
    return new MT(stringSeedToBigInt(s)).randbelow(n);
  }

  // -------------------------------------------------------- modes/who_am_i
  var WhoAmI = (function () {
    var MODE_ID = "who_am_i", DEFAULT_POINTS = 1, MAX_AWARD_POINTS = 100, MAX_GUESS_LEN = 80;
    function validateItem(item, path, issues) {
      if (!isPyDict(item)) { issues.push(path + ": must be an object"); return null; }
      var before = issues.length;
      if (!isText(get(item, "id"), MAX_ID)) issues.push(path + ".id: required non-empty string (max 64)");
      if (!isText(get(item, "label"), 120)) issues.push(path + ".label: required non-empty string (max 120)");
      var ar = get(item, "ar");
      if (!isNone(ar) && !isText(ar, 120)) issues.push(path + ".ar: must be a non-empty string when present");
      var difficulty = get(item, "difficulty");
      if (!(isText(difficulty, 32) || isInt(difficulty, 0, 100))) issues.push(path + ".difficulty: required short string or integer 0-100");
      if (issues.length !== before) return null;
      var out = { id: item.id, label: item.label, difficulty: difficulty };
      if (!isNone(ar)) out.ar = ar;
      return out;
    }
    function validateItems(items, issues) {
      var owner = new Map();
      items.forEach(function (item, index) {
        var keys = [["label", matchKey(item.label)]];
        if (has(item, "ar")) keys.push(["ar", matchKey(item.ar)]);
        keys.forEach(function (fk) {
          var first = owner.has(fk[1]) ? owner.get(fk[1]) : null;
          if (first !== null && first !== index) {
            issues.push("items[" + index + "]." + fk[0] + ": collides with display text of items[" + first + "] (case/width-insensitive)");
          } else if (first === null) owner.set(fk[1], index);
        });
      });
    }
    function startRound(state, roundNo) {
      var order = state.order;
      var drawn = state.deck.slice(0, order.length);
      state.deck = state.deck.slice(order.length);
      var a = obj();
      order.forEach(function (p, i) { if (i < drawn.length) a[p] = drawn[i]; });
      state.assignments = a;
      state.roundNo = roundNo;
      state.roundId = "g" + state.gameNo + "r" + roundNo;
      state.roundPhase = "asking";
      state.revealed = []; state.ready = []; state.guesses = obj(); state.solved = obj();
    }
    function initialize(config, players, content) {
      var order = players.map(function (p) { return p.id; });
      if (order.length < 2) return [null, "not_enough_players"];
      var items = deepcopy(content.items);
      if (items.length < order.length) return [null, "content_insufficient"];
      shuffleInPlace(config.seed, items);
      var scores = obj();
      players.forEach(function (p) { scores[p.id] = p.score; });
      var state = { mode: MODE_ID, title: content.title, gameNo: config.gameNo, order: order, deck: items,
        awards: [], scores: scores, points: get(config, "whoAmIPoints", DEFAULT_POINTS), ended: false };
      startRound(state, 1);
      return [state, null];
    }
    function inOrder(state, pid) { return inList(state.order, pid); }
    function ordered(state, pids) { return state.order.filter(function (p) { return pids.indexOf(p) >= 0; }); }
    function reduce(state, actor, action, seq) {
      var kind = get(action, "type");
      var payload = get(action, "payload");
      if (!pyTruthy(payload)) payload = obj(); // `action.get("payload") or {}`
      var role = get(actor, "role"), pid = get(actor, "playerId"), roundId = get(action, "roundId");
      if (!isNone(roundId) && roundId !== state.roundId) return [state, "stale_round"];
      if (!isPyDict(payload)) return [state, "invalid_payload"];
      var s;
      if (kind === "game.end") {
        if (role !== "operator") return [state, "forbidden"];
        if (state.ended) return [state, "invalid_phase"];
        s = deepcopy(state); s.ended = true; s.revealed = s.order.slice(); s.roundPhase = "revealed";
        return [s, null];
      }
      if (state.ended) return [state, "invalid_phase"];
      if (kind === "whoami.ready") {
        if (role !== "player" || !inOrder(state, pid)) return [state, "forbidden"];
        var ready = get(payload, "ready", true);
        if (!isBool(ready)) return [state, "invalid_payload"];
        if (state.roundPhase !== "asking") return [state, "invalid_phase"];
        s = deepcopy(state);
        var current = s.ready.filter(function (p) { return p !== pid; });
        if (ready) current.push(pid);
        s.ready = ordered(s, current);
        return [s, null];
      }
      if (kind === "whoami.guess") {
        if (role !== "player" || !inOrder(state, pid)) return [state, "forbidden"];
        var text = cleanText(get(payload, "text"), MAX_GUESS_LEN);
        if (text === null) return [state, "invalid_payload"];
        if (state.revealed.indexOf(pid) >= 0) return [state, "already_revealed"];
        s = deepcopy(state);
        s.guesses[pid] = { text: text, seq: seq };
        return [s, null];
      }
      var target;
      if (kind === "whoami.dismiss") {
        if (role !== "operator") return [state, "forbidden"];
        target = get(payload, "playerId");
        if (!inOrder(state, target)) return [state, "unknown_player"];
        if (!has(state.guesses, target)) return [state, "no_pending_guess"];
        s = deepcopy(state);
        delete s.guesses[target];
        return [s, null];
      }
      if (kind === "whoami.reveal") {
        if (role !== "operator") return [state, "forbidden"];
        target = get(payload, "playerId");
        s = deepcopy(state);
        if (isNone(target)) {
          if (s.revealed.length === s.order.length) return [state, "already_revealed"];
          s.revealed = s.order.slice();
        } else {
          if (!inOrder(s, target)) return [state, "unknown_player"];
          if (s.revealed.indexOf(target) >= 0) return [state, "already_revealed"];
          s.revealed = ordered(s, s.revealed.concat([target]));
        }
        if (s.revealed.length === s.order.length) s.roundPhase = "revealed";
        return [s, null];
      }
      if (kind === "whoami.award") {
        if (role !== "operator") return [state, "forbidden"];
        target = get(payload, "playerId");
        if (!inOrder(state, target)) return [state, "unknown_player"];
        var points = get(payload, "points", state.points);
        if (!isInt(points, 0, MAX_AWARD_POINTS)) return [state, "invalid_payload"];
        var key = state.roundId + ":" + target;
        if (state.awards.indexOf(key) >= 0) return [state, "already_awarded"];
        s = deepcopy(state);
        s.awards.push(key);
        s.scores[target] = get(s.scores, target, 0) + points;
        s.solved[target] = { points: points, seq: seq };
        if (s.revealed.indexOf(target) < 0) s.revealed = ordered(s, s.revealed.concat([target]));
        if (s.revealed.length === s.order.length) s.roundPhase = "revealed";
        return [s, null];
      }
      if (kind === "round.next") {
        if (role !== "operator") return [state, "forbidden"];
        if (state.deck.length < state.order.length) return [state, "content_exhausted"];
        s = deepcopy(state);
        startRound(s, s.roundNo + 1);
        return [s, null];
      }
      return [state, "unknown_action"];
    }
    function publicItem(item) {
      var out = { label: item.label };
      if (has(item, "ar")) out.ar = item.ar;
      return out;
    }
    function project(state, viewer) {
      var role = get(viewer, "role");
      var me = role === "player" ? get(viewer, "playerId") : null;
      if (!isNone(me) && state.order.indexOf(me) < 0) { role = "display"; me = null; }
      var order = state.order;
      var revealed = state.ended ? order.slice() : state.revealed;
      var isRev = function (p) { return revealed.indexOf(p) >= 0; };
      var A = state.assignments;
      var view = {
        title: state.title,
        round: state.roundNo,
        roundPhase: state.ended ? "ended" : state.roundPhase,
        order: order.slice(),
        ready: state.ready.slice(),
        revealed: order.filter(isRev),
        solved: order.filter(function (p) { return has(state.solved, p); }),
        pendingGuesses: order.filter(function (p) { return has(state.guesses, p); })
      };
      var m = obj();
      if (role === "operator") {
        var g = obj();
        order.forEach(function (p) { if (has(state.guesses, p)) g[p] = state.guesses[p].text; });
        view.guesses = g;
        order.forEach(function (p) { m[p] = deepcopy(A[p]); });
        view.assignments = m;
        view.roundsRemaining = Math.floor(state.deck.length / Math.max(1, order.length));
        view.awardPoints = state.points;
      } else if (role === "player") {
        order.forEach(function (p) { if (p !== me) m[p] = publicItem(A[p]); });
        view.assignments = m;
        var you = {
          revealed: isRev(me),
          ready: state.ready.indexOf(me) >= 0,
          solved: has(state.solved, me),
          guess: has(state.guesses, me) ? state.guesses[me].text : null
        };
        if (isRev(me)) you.assignment = publicItem(A[me]);
        view.you = you;
      } else {
        order.forEach(function (p) { if (isRev(p)) m[p] = publicItem(A[p]); });
        view.assignments = m;
      }
      return view;
    }
    return { MODE_ID: MODE_ID, TITLE: "Who Am I", ACTION_PREFIX: "whoami.", MIN_PLAYERS: 2,
      validateItem: validateItem, validateItems: validateItems, initialize: initialize, reduce: reduce, project: project };
  })();

  // ------------------------------------------------------------ modes/feud
  var Feud = (function () {
    var MODE_ID = "feud", PREFIX = "feud.", HOUSE_LABEL = "House answers", MAX_STRIKES = 3,
      MAX_ANSWERS = 20, MAX_ALIASES = 50, MAX_POINTS = 1000, MAX_MATCH_TEXT = 120;
    function validateItem(item, path, issues) {
      if (!isPyDict(item)) { issues.push(path + ": must be an object"); return null; }
      var before = issues.length;
      if (!isText(get(item, "id"), MAX_ID)) issues.push(path + ".id: required non-empty string (max 64)");
      if (!isText(get(item, "question"))) issues.push(path + ".question: required non-empty string");
      if (get(item, "label") !== HOUSE_LABEL) issues.push(path + '.label: must be exactly "House answers"');
      var answers = get(item, "answers"), outAnswers = [];
      if (!Array.isArray(answers) || !answers.length || answers.length > MAX_ANSWERS) {
        issues.push(path + ".answers: required array of 1-20 answers");
      } else {
        var seen = new Set();
        answers.forEach(function (answer, index) {
          var apath = path + ".answers[" + index + "]";
          if (!isPyDict(answer)) { issues.push(apath + ": must be an object"); return; }
          var abefore = issues.length;
          var aid = get(answer, "id");
          if (!isText(aid, MAX_ID)) issues.push(apath + ".id: required non-empty string (max 64)");
          else if (seen.has(aid)) issues.push(apath + ".id: duplicate answer id");
          if (!isText(get(answer, "text"), 200)) issues.push(apath + ".text: required non-empty string");
          var aliases = get(answer, "aliases");
          if (!Array.isArray(aliases) || aliases.length > MAX_ALIASES) issues.push(apath + ".aliases: required array (max 50)");
          else aliases.forEach(function (alias, j) {
            if (!isText(alias, 200)) issues.push(apath + ".aliases[" + j + "]: must be a non-empty string");
          });
          if (!isInt(get(answer, "points"), 0, MAX_POINTS)) issues.push(apath + ".points: required integer 0-1000");
          if (issues.length === abefore) {
            seen.add(aid);
            outAnswers.push({ id: aid, text: answer.text, aliases: aliases.slice(), points: answer.points });
          }
        });
      }
      if (issues.length !== before) return null;
      return { id: item.id, question: item.question, label: HOUSE_LABEL, answers: outAnswers };
    }
    function startBoard(state, index) {
      state.boardIndex = index;
      state.roundId = "g" + state.gameNo + "b" + (index + 1);
      state.roundPhase = "closed";
      state.revealed = [];
      state.strikes = 0;
      state.buzzer = { open: false, winner: null, winnerSeq: null };
      state.control = null; state.stealFrom = null; state.awardedTo = null; state.awardedPoints = null;
    }
    function initialize(config, players, content) {
      if (players.length < 1) return [null, "not_enough_players"];
      var boards = deepcopy(content.items);
      if (!boards.length) return [null, "content_insufficient"];
      var scores = obj();
      players.forEach(function (p) { scores[p.id] = p.score; });
      var state = { mode: MODE_ID, title: content.title, gameNo: config.gameNo,
        order: players.map(function (p) { return p.id; }), boards: boards, awards: [], scores: scores, ended: false };
      startBoard(state, 0);
      return [state, null];
    }
    function board(state) { return state.boards[state.boardIndex]; }
    function revealedPoints(state) {
      var sum = 0;
      board(state).answers.forEach(function (a) { if (state.revealed.indexOf(a.id) >= 0) sum += a.points; });
      return sum;
    }
    function findAnswer(state, payload) {
      var answers = board(state).answers;
      var answerId = get(payload, "answerId");
      var k;
      if (!isNone(answerId)) {
        for (k = 0; k < answers.length; k++) if (answers[k].id === answerId) return [answers[k], null];
        return [null, "unknown_answer"];
      }
      var text = cleanText(get(payload, "text"), MAX_MATCH_TEXT);
      if (text === null) return [null, "invalid_payload"];
      var key = matchKey(text), matched = null;
      for (k = 0; k < answers.length; k++) {
        var a = answers[k];
        var keys = [matchKey(a.text)].concat(a.aliases.map(matchKey));
        if (keys.indexOf(key) >= 0) {
          if (state.revealed.indexOf(a.id) < 0) return [a, null];
          matched = matched || a;
        }
      }
      if (matched !== null) return [matched, null];
      return [null, "no_match"];
    }
    function reduce(state, actor, action, seq) {
      var kind = get(action, "type");
      var payload = get(action, "payload");
      if (!pyTruthy(payload)) payload = obj(); // `action.get("payload") or {}`
      var role = get(actor, "role"), pid = get(actor, "playerId"), roundId = get(action, "roundId");
      if (!isNone(roundId) && roundId !== state.roundId) return [state, "stale_round"];
      if (!isPyDict(payload)) return [state, "invalid_payload"];
      var s;
      if (kind === "game.end") {
        if (role !== "operator") return [state, "forbidden"];
        if (state.ended) return [state, "invalid_phase"];
        s = deepcopy(state); s.ended = true; s.buzzer.open = false;
        return [s, null];
      }
      if (state.ended) return [state, "invalid_phase"];
      if (kind === "feud.buzz") {
        if (role !== "player" || !inList(state.order, pid)) return [state, "forbidden"];
        if (state.buzzer.winner !== null) return [state, "buzzer_taken"];
        if (state.roundPhase !== "buzzer_open" || !state.buzzer.open) return [state, "buzzer_closed"];
        s = deepcopy(state);
        s.buzzer = { open: false, winner: pid, winnerSeq: seq };
        s.control = pid;
        s.roundPhase = "answering";
        return [s, null];
      }
      if (!kind || !isStr(kind)) return [state, "unknown_action"];
      if (kind.startsWith(PREFIX) || kind === "round.next") {
        if (role !== "operator") return [state, "forbidden"];
      }
      var target;
      if (kind === "feud.open_buzzer") {
        if (state.buzzer.winner !== null) return [state, "buzzer_taken"];
        if (state.roundPhase !== "closed") return [state, "invalid_phase"];
        s = deepcopy(state); s.buzzer.open = true; s.roundPhase = "buzzer_open";
        return [s, null];
      }
      if (kind === "feud.reset_buzzer") {
        if (state.roundPhase === "awarded") return [state, "round_awarded"];
        s = deepcopy(state);
        s.buzzer = { open: false, winner: null, winnerSeq: null };
        s.control = null; s.stealFrom = null; s.roundPhase = "closed";
        return [s, null];
      }
      if (kind === "feud.reveal") {
        var r = findAnswer(state, payload);
        if (r[1]) return [state, r[1]];
        var answer = r[0];
        if (state.revealed.indexOf(answer.id) >= 0) return [state, "already_revealed"];
        s = deepcopy(state);
        var want = s.revealed.concat([answer.id]);
        s.revealed = board(s).answers.filter(function (a) { return want.indexOf(a.id) >= 0; }).map(function (a) { return a.id; });
        return [s, null];
      }
      if (kind === "feud.strike") {
        if (state.roundPhase !== "answering" && state.roundPhase !== "steal") return [state, "invalid_phase"];
        if (state.strikes >= MAX_STRIKES) return [state, "max_strikes"];
        s = deepcopy(state); s.strikes += 1;
        return [s, null];
      }
      if (kind === "feud.steal") {
        target = get(payload, "playerId");
        if (!inList(state.order, target)) return [state, "unknown_player"];
        if (state.roundPhase !== "answering") return [state, "invalid_phase"];
        if (state.strikes < MAX_STRIKES) return [state, "steal_not_available"];
        if (target === state.control) return [state, "invalid_payload"];
        s = deepcopy(state);
        s.stealFrom = s.control; s.control = target; s.roundPhase = "steal";
        return [s, null];
      }
      if (kind === "feud.award") {
        if (state.roundPhase === "awarded") return [state, "round_awarded"];
        target = get(payload, "playerId", state.control);
        if (isNone(target)) return [state, "no_control"];
        if (!inList(state.order, target)) return [state, "unknown_player"];
        var key = state.roundId + ":" + board(state).id;
        if (state.awards.indexOf(key) >= 0) return [state, "already_awarded"];
        s = deepcopy(state);
        var points = revealedPoints(s);
        s.awards.push(key);
        s.scores[target] = get(s.scores, target, 0) + points;
        s.awardedTo = target; s.awardedPoints = points;
        s.buzzer.open = false; s.roundPhase = "awarded";
        return [s, null];
      }
      if (kind === "round.next") {
        if (state.boardIndex + 1 >= state.boards.length) return [state, "content_exhausted"];
        s = deepcopy(state);
        startBoard(s, s.boardIndex + 1);
        return [s, null];
      }
      return [state, "unknown_action"];
    }
    function project(state, viewer) {
      var b = board(state);
      var isRev = function (id) { return state.revealed.indexOf(id) >= 0; };
      var slots = b.answers.map(function (a, index) {
        return isRev(a.id) ? { index: index, revealed: true, id: a.id, text: a.text, points: a.points }
          : { index: index, revealed: false };
      });
      var view = {
        title: state.title, label: HOUSE_LABEL, answerSource: "house",
        board: state.boardIndex + 1, boardCount: state.boards.length, question: b.question,
        roundPhase: state.ended ? "ended" : state.roundPhase,
        slots: slots, strikes: state.strikes, maxStrikes: MAX_STRIKES,
        roundPoints: state.awardedTo !== null ? state.awardedPoints : revealedPoints(state),
        buzzer: { open: state.buzzer.open, winner: state.buzzer.winner },
        control: state.control, stealFrom: state.stealFrom,
        awardedTo: state.awardedTo, awardedPoints: state.awardedPoints
      };
      if (get(viewer, "role") === "operator") {
        view.boardId = b.id;
        view.boardsRemaining = state.boards.length - state.boardIndex - 1;
        view.answers = b.answers.map(function (a) {
          return { id: a.id, text: a.text, aliases: a.aliases.slice(), points: a.points, revealed: isRev(a.id) };
        });
      }
      return view;
    }
    return { MODE_ID: MODE_ID, TITLE: "Feud (House Answers)", ACTION_PREFIX: PREFIX, MIN_PLAYERS: 1,
      MAX_STRIKES: MAX_STRIKES, validateItem: validateItem, validateItems: null,
      initialize: initialize, reduce: reduce, project: project };
  })();

  // ------------------------------------------------------------ modes/impostor
  // Ported from party/server/modes/impostor.py (accepted candidate N03-I-v1).
  // Word matching uses wordKey (NFC), deliberately NOT matchKey (NFKC, used
  // by WhoAmI/Feud display-text collisions) -- the Python oracle's
  // word_key() is NFC-based and must not be conflated with it.
  var Impostor = (function () {
    var MODE_ID = "impostor", PREFIX = "impostor.", MIN_PLAYERS = 3, MAX_PLAYERS = 12,
      MAX_WORD_LEN = 80, MAX_CATEGORY_LEN = 64, MAX_GUESS_LEN = 80, IMPOSTOR_POINTS = 3, CREW_POINTS = 2;
    var DISCUSSION = "discussion", VOTE = "vote", GUESS_WORD = "guess_word", REVEAL = "reveal";
    var IMPOSTOR_SURVIVED = "impostor_survived", IMPOSTOR_GUESSED_WORD = "impostor_guessed_word",
      CREW_WRONG_GUESS = "crew_wrong_guess", CREW_FORFEIT = "crew_forfeit", ABORTED = "aborted";

    function wordKey(value) { return pySplit(casefold(nfc(value))).join(" "); }

    function validateItem(item, path, issues) {
      if (!isPyDict(item)) { issues.push(path + ": must be an object"); return null; }
      var before = issues.length;
      if (!isText(get(item, "id"), MAX_ID)) issues.push(path + ".id: required non-empty string (max 64)");
      var word = get(item, "word");
      if (!isText(word, MAX_WORD_LEN) || cleanText(word, MAX_WORD_LEN) === null) {
        issues.push(path + ".word: required non-empty printable string (max 80)");
      }
      if (!isText(get(item, "category"), MAX_CATEGORY_LEN)) issues.push(path + ".category: required non-empty string (max 64)");
      if (issues.length !== before) return null;
      return { id: item.id, word: item.word, category: item.category };
    }
    function validateItems(items, issues) {
      var owner = new Map();
      items.forEach(function (item, index) {
        var key = wordKey(item.word);
        var first = owner.has(key) ? owner.get(key) : null;
        if (first !== null) {
          issues.push("items[" + index + "].word: duplicates normalized word of items[" + first + "] (case/whitespace-insensitive)");
        } else owner.set(key, index);
      });
    }

    function makeRoundId(gameNo, roundNo) { return "g" + gameNo + "r" + roundNo; }
    function pickImpostor(state, roundNo) {
      var seedStr = "impostor:" + String(state.seed) + ":" + String(state.gameNo) + ":" + String(roundNo);
      return state.order[randBelowFromStringSeed(seedStr, state.order.length)];
    }
    function draw(state) {
      var used = {};
      state.usedKeys.forEach(function (k) { used[k] = true; });
      while (state.deck.length) {
        var item = state.deck.shift();
        var key = wordKey(item.word);
        if (!used[key]) { state.usedKeys.push(key); return item; }
      }
      return null;
    }
    function hasUnseen(state) {
      var used = {};
      state.usedKeys.forEach(function (k) { used[k] = true; });
      return state.deck.some(function (item) { return !used[wordKey(item.word)]; });
    }
    function startRound(state, roundNo, item) {
      state.item = item;
      state.roundNo = roundNo;
      state.roundId = makeRoundId(state.gameNo, roundNo);
      state.impostor = pickImpostor(state, roundNo);
      state.roundPhase = DISCUSSION;
      state.votes = obj();
      state.nominee = null;
      state.outcome = null;
      state.roundPoints = null;
    }

    function initialize(config, players, content) {
      var order = players.map(function (p) { return p.id; });
      if (order.length < MIN_PLAYERS) return [null, "not_enough_players"];
      if (order.length > MAX_PLAYERS) return [null, "too_many_players"];
      var items = deepcopy(content.items);
      if (!items.length) return [null, "content_insufficient"];
      shuffleInPlace(config.seed, items);
      var scores = obj();
      players.forEach(function (p) { scores[p.id] = p.score; });
      var state = {
        mode: MODE_ID, title: content.title, gameNo: config.gameNo, seed: config.seed,
        order: order, deck: items, usedKeys: [], awards: [], scores: scores, ended: false
      };
      var item = draw(state);
      if (item === null) return [null, "content_insufficient"];
      startRound(state, 1, item);
      return [state, null];
    }

    function tally(state) {
      var counts = obj();
      state.order.forEach(function (p) { counts[p] = 0; });
      Object.keys(state.votes).forEach(function (voter) {
        var target = state.votes[voter];
        counts[target] = (counts[target] || 0) + 1;
      });
      return counts;
    }
    function nominee(state) {
      var counts = tally(state), best = 0;
      state.order.forEach(function (p) { if (counts[p] > best) best = counts[p]; });
      if (best === 0) return null;
      var leaders = state.order.filter(function (p) { return counts[p] === best; });
      return leaders.length === 1 ? leaders[0] : null;
    }
    function award(s, outcome, impostorWins) {
      var key = s.roundId;
      if (s.awards.indexOf(key) >= 0) return false;
      s.awards.push(key);
      var points = obj();
      s.order.forEach(function (p) {
        var pts = impostorWins ? (p === s.impostor ? IMPOSTOR_POINTS : 0) : (p === s.impostor ? 0 : CREW_POINTS);
        points[p] = pts;
        s.scores[p] = (s.scores[p] || 0) + pts;
      });
      s.roundPoints = points;
      s.outcome = outcome;
      s.roundPhase = REVEAL;
      return true;
    }
    function resolveVote(s) {
      s.nominee = nominee(s);
      if (s.nominee !== null && s.nominee === s.impostor) { s.roundPhase = GUESS_WORD; return true; }
      return award(s, IMPOSTOR_SURVIVED, true);
    }

    function reduce(state, actor, action, serverSequence) {
      var kind = get(action, "type");
      var payload = get(action, "payload");
      if (isNone(payload)) payload = obj();
      var role = get(actor, "role"), pid = get(actor, "playerId"), actionRoundId = get(action, "roundId");
      if (!isNone(actionRoundId) && actionRoundId !== state.roundId) return [state, "stale_round"];
      if (!isPyDict(payload)) return [state, "invalid_payload"];
      var s;

      if (kind === "game.end") {
        if (role !== "operator") return [state, "forbidden"];
        if (state.ended) return [state, "invalid_phase"];
        s = deepcopy(state);
        s.ended = true;
        if (s.outcome === null) s.outcome = ABORTED;
        return [s, null];
      }

      if (state.ended) return [state, "invalid_phase"];
      var phase = state.roundPhase;

      if (kind === "impostor.advance") {
        if (role !== "operator") return [state, "forbidden"];
        s = deepcopy(state);
        if (phase === DISCUSSION) { s.roundPhase = VOTE; return [s, null]; }
        if (phase === VOTE) { resolveVote(s); return [s, null]; }
        if (phase === GUESS_WORD) {
          if (!award(s, CREW_FORFEIT, false)) return [state, "already_awarded"];
          return [s, null];
        }
        return [state, "invalid_phase"];
      }

      if (kind === "impostor.vote") {
        if (role !== "player" || !inList(state.order, pid)) return [state, "forbidden"];
        if (phase !== VOTE) return [state, "invalid_phase"];
        var target = get(payload, "playerId");
        if (!isStr(target) || !inList(state.order, target)) return [state, "unknown_player"];
        if (target === pid) return [state, "self_vote"];
        if (has(state.votes, pid)) return [state, "already_voted"];
        s = deepcopy(state);
        s.votes[pid] = target;
        if (Object.keys(s.votes).length === s.order.length) resolveVote(s);
        return [s, null];
      }

      if (kind === "impostor.guess_word") {
        if (role !== "player" || !inList(state.order, pid)) return [state, "forbidden"];
        if (phase !== GUESS_WORD) return [state, "invalid_phase"];
        if (pid !== state.impostor) return [state, "forbidden"];
        var text = cleanText(get(payload, "text"), MAX_GUESS_LEN);
        if (text === null) return [state, "invalid_payload"];
        s = deepcopy(state);
        var awarded = (wordKey(text) === wordKey(s.item.word)) ? award(s, IMPOSTOR_GUESSED_WORD, true) : award(s, CREW_WRONG_GUESS, false);
        if (!awarded) return [state, "already_awarded"];
        return [s, null];
      }

      if (kind === "round.next") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== REVEAL) return [state, "invalid_phase"];
        if (!hasUnseen(state)) return [state, "content_exhausted"];
        s = deepcopy(state);
        var item = draw(s);
        startRound(s, s.roundNo + 1, item);
        return [s, null];
      }

      return [state, "unknown_action"];
    }

    function project(state, viewer) {
      var role = get(viewer, "role");
      var me = role === "player" ? get(viewer, "playerId") : null;
      if (!isNone(me) && !inList(state.order, me)) { role = "display"; me = null; }
      var order = state.order;
      var revealed = state.ended || state.roundPhase === REVEAL;
      var counts = tally(state);
      var votes = obj();
      order.forEach(function (p) { if (has(state.votes, p)) votes[p] = state.votes[p]; });
      var tallyView = obj();
      order.forEach(function (p) { tallyView[p] = counts[p]; });
      var view = {
        title: state.title,
        round: state.roundNo,
        roundPhase: state.ended ? "ended" : state.roundPhase,
        order: order.slice(),
        votes: votes,
        tally: tallyView,
        votesNeeded: order.length,
        nominee: state.nominee,
        outcome: state.outcome,
        roundPoints: state.roundPoints !== null ? deepcopy(state.roundPoints) : null,
        reveal: revealed ? { word: state.item.word, impostor: state.impostor } : null
      };
      if (role === "operator") {
        var used = {};
        state.usedKeys.forEach(function (k) { used[k] = true; });
        view.roundsRemaining = state.deck.filter(function (item) { return !used[wordKey(item.word)]; }).length;
      } else if (role === "player") {
        view.you = (me === state.impostor) ? { role: "impostor" } : { role: "crew", word: state.item.word };
      }
      return view;
    }

    return { MODE_ID: MODE_ID, TITLE: "Impostor", ACTION_PREFIX: PREFIX, MIN_PLAYERS: MIN_PLAYERS,
      validateItem: validateItem, validateItems: validateItems, initialize: initialize, reduce: reduce, project: project };
  })();

  // ------------------------------------------------------------- modes/taboo
  // Translated behaviorally from the accepted Python taboo-review pilot
  // (taboo-v1.md) into this shared-core architecture. CLI flags and test
  // counts from that pilot are not copied; the per-turn clock config instead
  // rides room.start's payload.modeConfig.turnSeconds, and expiry is driven
  // by the minimal tick/onPause/onResume clock hooks below rather than a
  // separate scheduler service.
  var Taboo = (function () {
    var MODE_ID = "taboo", PREFIX = "taboo.", MIN_PLAYERS = 4, MAX_PLAYERS = 12,
      MAX_WORD_LEN = 120, MAX_FORBIDDEN_LEN = 120, MIN_FORBIDDEN = 4, MAX_FORBIDDEN = 5,
      MAX_GUESS_LEN = 120, MAX_GUESSES = 20,
      DEFAULT_TURN_SECONDS = 60, MIN_TURN_SECONDS = 10, MAX_TURN_SECONDS = 180;
    var CLUE_TURN = "clue_turn", TURN_COMPLETE = "turn_complete", EXHAUSTED = "exhausted", ENDED = "ended";

    function wordKeyTa(value) { return pySplit(casefold(nfc(value))).join(" "); }

    function validateItem(item, path, issues) {
      if (!isPyDict(item)) { issues.push(path + ": must be an object"); return null; }
      var before = issues.length;
      if (!isText(get(item, "id"), MAX_ID)) issues.push(path + ".id: required non-empty string (max 64)");
      var word = get(item, "word");
      var wordOk = isText(word, MAX_WORD_LEN);
      if (!wordOk) issues.push(path + ".word: required non-empty printable string (max 120)");
      var forbidden = get(item, "forbidden");
      if (!Array.isArray(forbidden) || forbidden.length < MIN_FORBIDDEN || forbidden.length > MAX_FORBIDDEN) {
        issues.push(path + ".forbidden: required array of " + MIN_FORBIDDEN + "-" + MAX_FORBIDDEN + " printable strings (max " + MAX_FORBIDDEN_LEN + " chars)");
      } else {
        var seen = new Set(), wordKeyVal = wordOk ? wordKeyTa(word) : null;
        for (var i = 0; i < forbidden.length; i++) {
          var term = forbidden[i];
          if (!isText(term, MAX_FORBIDDEN_LEN)) {
            issues.push(path + ".forbidden[" + i + "]: required non-empty printable string (max " + MAX_FORBIDDEN_LEN + ")");
            continue;
          }
          var key = wordKeyTa(term);
          if (seen.has(key)) issues.push(path + ".forbidden[" + i + "]: duplicates another forbidden term (case/whitespace-insensitive)");
          else seen.add(key);
          if (wordKeyVal !== null && key === wordKeyVal) issues.push(path + ".forbidden[" + i + "]: must not equal the word");
        }
      }
      if (issues.length !== before) return null;
      return { id: item.id, word: item.word, forbidden: forbidden.slice() };
    }
    function validateItems(items, issues) {
      var owner = new Map();
      items.forEach(function (item, index) {
        var key = wordKeyTa(item.word);
        var first = owner.has(key) ? owner.get(key) : null;
        if (first !== null) issues.push("items[" + index + "].word: duplicates normalized word of items[" + first + "] (case/whitespace-insensitive)");
        else owner.set(key, index);
      });
    }

    function makeRoundId(gameNo, turnNo) { return "g" + gameNo + "r" + turnNo; }
    function teamOf(s, pid) {
      if (s.teams.A.indexOf(pid) >= 0) return "A";
      if (s.teams.B.indexOf(pid) >= 0) return "B";
      return null;
    }
    function nextClueGiver(s, team) {
      var roster = s.teams[team];
      var giver = roster[s.clueIdx[team] % roster.length];
      s.clueIdx[team] = (s.clueIdx[team] + 1) % roster.length;
      return giver;
    }
    function computeResult(s) {
      if (s.teamScores.A === s.teamScores.B) return { winner: null, draw: true, teamScores: { A: s.teamScores.A, B: s.teamScores.B } };
      return { winner: s.teamScores.A > s.teamScores.B ? "A" : "B", draw: false, teamScores: { A: s.teamScores.A, B: s.teamScores.B } };
    }
    function finishExhausted(s) {
      s.roundPhase = EXHAUSTED;
      s.ended = true;
      s.result = computeResult(s);
    }
    // Resolve (score + discard) the active card and deal the next one to the
    // same clue-giver within the same turn; the turn's timer never resets.
    function resolveAndDealNext(s, outcome, awardTeam, solverId) {
      var wordWas = s.card.word;
      if (awardTeam) s.teamScores[awardTeam] += 1;
      s.lastResolved = { word: wordWas, outcome: outcome, solverId: solverId, teamAward: awardTeam || null };
      if (s.deck.length === 0) {
        s.card = null; s.deadlineAt = null; s.guesses = [];
        finishExhausted(s);
      } else {
        s.card = s.deck.shift();
        s.cardEpoch += 1;
        s.guesses = [];
      }
    }
    // Discard the active card with no further card dealt this turn (pass or
    // timer expiry): the turn ends, never awarding points.
    function endTurnNoDeal(s, outcome) {
      var wordWas = s.card.word;
      s.lastResolved = { word: wordWas, outcome: outcome, solverId: null, teamAward: null };
      s.card = null; s.deadlineAt = null; s.guesses = [];
      if (s.deck.length === 0) finishExhausted(s); else s.roundPhase = TURN_COMPLETE;
    }
    function startNextTurn(s, now) {
      s.activeTeam = s.activeTeam === "A" ? "B" : "A";
      s.turnNo += 1;
      s.roundId = makeRoundId(s.gameNo, s.turnNo);
      s.clueGiverId = nextClueGiver(s, s.activeTeam);
      s.card = s.deck.shift();
      s.cardEpoch = 0;
      s.guesses = [];
      s.roundPhase = CLUE_TURN;
      s.deadlineAt = now + s.turnSeconds;
    }
    function checkCardEpoch(state, payload) {
      var ce = get(payload, "cardEpoch");
      if (isBool(ce) || !isPyInt(ce)) return "invalid_payload";
      if (ce !== state.cardEpoch) return "stale_card";
      return null;
    }
    // Strict allowlist: any key outside the documented schema for this
    // action is rejected wholesale rather than silently ignored, so an
    // unexpected field can never ride along with an otherwise-valid action.
    function checkPayloadKeys(payload, allowed) {
      var keys = Object.keys(payload);
      for (var i = 0; i < keys.length; i++) {
        if (allowed.indexOf(keys[i]) < 0) return "invalid_payload";
      }
      return null;
    }

    function initialize(config, players, content) {
      var order = players.map(function (p) { return p.id; });
      if (order.length < MIN_PLAYERS) return [null, "not_enough_players"];
      if (order.length > MAX_PLAYERS) return [null, "too_many_players"];
      var rawModeConfig = get(config, "modeConfig");
      if (isNone(rawModeConfig)) rawModeConfig = obj();
      // Unlike payload defaulting elsewhere, a *present but wrongly-shaped*
      // modeConfig (string/number/array/bool) must reject the start rather
      // than silently falling back to defaults.
      if (!isPyDict(rawModeConfig)) return [null, "invalid_config"];
      var mcKeyErr = checkPayloadKeys(rawModeConfig, ["turnSeconds"]);
      if (mcKeyErr) return [null, "invalid_config"];
      var modeConfig = rawModeConfig;
      var turnSeconds = get(modeConfig, "turnSeconds", DEFAULT_TURN_SECONDS);
      if (isBool(turnSeconds) || !isPyInt(turnSeconds) || turnSeconds < MIN_TURN_SECONDS || turnSeconds > MAX_TURN_SECONDS) {
        return [null, "invalid_config"];
      }
      var items = deepcopy(content.items);
      if (!items.length) return [null, "content_insufficient"];
      shuffleInPlace(config.seed, items);
      var teams = { A: [], B: [] };
      order.forEach(function (id, i) { (i % 2 === 0 ? teams.A : teams.B).push(id); });
      if (teams.A.length === 0 || teams.B.length === 0) return [null, "not_enough_players"];
      var state = {
        mode: MODE_ID, title: content.title, gameNo: config.gameNo, seed: config.seed,
        order: order, teams: teams, clueIdx: { A: 0, B: 0 },
        teamScores: { A: 0, B: 0 },
        deck: items, turnSeconds: turnSeconds,
        turnNo: 0, activeTeam: "B",
        clueGiverId: null, roundId: null, card: null, cardEpoch: 0,
        roundPhase: null, guesses: [], lastResolved: null,
        deadlineAt: null, pausedRemainingSeconds: null,
        ended: false, result: null
      };
      startNextTurn(state, config.now);
      return [state, null];
    }

    function reduce(state, actor, action, serverSequence, now) {
      var kind = get(action, "type");
      var payload = get(action, "payload");
      if (isNone(payload)) payload = obj();
      if (!isPyDict(payload)) return [state, "invalid_payload"];
      var role = get(actor, "role"), pid = get(actor, "playerId");
      var s, ceErr;

      if (kind === "game.end") {
        if (role !== "operator") return [state, "forbidden"];
        if (state.ended) return [state, "invalid_phase"];
        s = deepcopy(state);
        s.card = null; s.deadlineAt = null; s.pausedRemainingSeconds = null;
        s.roundPhase = ENDED; s.ended = true; s.result = computeResult(s);
        return [s, null];
      }

      if (state.ended) return [state, "invalid_phase"];
      var phase = state.roundPhase;
      // Late-adjudication guard (defense in depth; the room manager also
      // reconciles the deadline via tick before every action): once the turn
      // deadline has passed no card can be resolved or scored.
      if (phase === CLUE_TURN && state.deadlineAt !== null && now >= state.deadlineAt) return [state, "invalid_phase"];

      if (kind === "round.next") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== TURN_COMPLETE) return [state, "invalid_phase"];
        if (checkPayloadKeys(payload, [])) return [state, "invalid_payload"];
        s = deepcopy(state);
        startNextTurn(s, now);
        return [s, null];
      }

      if (kind === "taboo.guess") {
        if (role !== "player") return [state, "forbidden"];
        if (phase !== CLUE_TURN) return [state, "invalid_phase"];
        var team = teamOf(state, pid);
        if (team === null || team !== state.activeTeam || pid === state.clueGiverId) return [state, "forbidden"];
        if (checkPayloadKeys(payload, ["cardEpoch", "text"])) return [state, "invalid_payload"];
        ceErr = checkCardEpoch(state, payload);
        if (ceErr) return [state, ceErr];
        var raw = cleanText(get(payload, "text"), MAX_GUESS_LEN);
        if (raw === null) return [state, "invalid_payload"];
        s = deepcopy(state);
        s.guesses.push({ playerId: pid, text: raw });
        if (s.guesses.length > MAX_GUESSES) s.guesses.shift();
        if (wordKeyTa(raw) === wordKeyTa(s.card.word)) resolveAndDealNext(s, "correct", s.activeTeam, pid);
        return [s, null];
      }

      if (kind === "taboo.correct") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== CLUE_TURN) return [state, "invalid_phase"];
        if (checkPayloadKeys(payload, ["cardEpoch"])) return [state, "invalid_payload"];
        ceErr = checkCardEpoch(state, payload);
        if (ceErr) return [state, ceErr];
        s = deepcopy(state);
        resolveAndDealNext(s, "correct", s.activeTeam, null);
        return [s, null];
      }

      if (kind === "taboo.violation") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== CLUE_TURN) return [state, "invalid_phase"];
        if (checkPayloadKeys(payload, ["cardEpoch"])) return [state, "invalid_payload"];
        ceErr = checkCardEpoch(state, payload);
        if (ceErr) return [state, ceErr];
        s = deepcopy(state);
        resolveAndDealNext(s, "violation", s.activeTeam === "A" ? "B" : "A", null);
        return [s, null];
      }

      if (kind === "taboo.skip") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== CLUE_TURN) return [state, "invalid_phase"];
        if (checkPayloadKeys(payload, ["cardEpoch"])) return [state, "invalid_payload"];
        ceErr = checkCardEpoch(state, payload);
        if (ceErr) return [state, ceErr];
        s = deepcopy(state);
        resolveAndDealNext(s, "skip", null, null);
        return [s, null];
      }

      if (kind === "taboo.pass_turn") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== CLUE_TURN) return [state, "invalid_phase"];
        if (checkPayloadKeys(payload, ["cardEpoch"])) return [state, "invalid_payload"];
        ceErr = checkCardEpoch(state, payload);
        if (ceErr) return [state, ceErr];
        s = deepcopy(state);
        endTurnNoDeal(s, "pass");
        return [s, null];
      }

      return [state, "unknown_action"];
    }

    // Autonomous expiry: called by the room manager's poll/sweep with no
    // incoming action. Returns [state, false] when nothing changed so the
    // caller can skip committing a new revision.
    function tick(state, now) {
      if (state.ended || state.roundPhase !== CLUE_TURN || state.deadlineAt === null || now < state.deadlineAt) {
        return [state, false];
      }
      var s = deepcopy(state);
      endTurnNoDeal(s, "expired");
      return [s, true];
    }
    function onPause(state, now) {
      if (state.roundPhase !== CLUE_TURN || state.deadlineAt === null) return state;
      var s = deepcopy(state);
      s.pausedRemainingSeconds = Math.max(0, s.deadlineAt - now);
      s.deadlineAt = null;
      return s;
    }
    function onResume(state, now) {
      if (state.pausedRemainingSeconds === null) return state;
      var s = deepcopy(state);
      s.deadlineAt = now + s.pausedRemainingSeconds;
      s.pausedRemainingSeconds = null;
      return s;
    }
    function nextDeadline(state) { return state.deadlineAt; }

    function project(state, viewer, now) {
      var role = get(viewer, "role");
      var me = role === "player" ? get(viewer, "playerId") : null;
      // A player principal outside this game's roster (a late spectator, or a
      // lobby joiner waiting for the next start) is read-only: public view only.
      if (!isNone(me) && !inList(state.order, me)) { role = "spectator"; me = null; }
      var remainingMs;
      if (state.pausedRemainingSeconds !== null) remainingMs = Math.max(0, Math.round(state.pausedRemainingSeconds * 1000));
      else if (state.deadlineAt !== null) remainingMs = Math.max(0, Math.round((state.deadlineAt - now) * 1000));
      else remainingMs = 0;
      var view = {
        title: state.title,
        gameNo: state.gameNo,
        turnNo: state.turnNo,
        roundPhase: state.roundPhase,
        activeTeam: state.activeTeam,
        clueGiverId: state.clueGiverId,
        teams: { A: state.teams.A.slice(), B: state.teams.B.slice() },
        teamScores: { A: state.teamScores.A, B: state.teamScores.B },
        cardEpoch: state.cardEpoch,
        cardsRemaining: state.deck.length,
        turnSeconds: state.turnSeconds,
        remainingMs: remainingMs,
        guesses: state.guesses.map(function (g) { return { playerId: g.playerId, text: g.text }; }),
        lastResolved: state.lastResolved !== null ? deepcopy(state.lastResolved) : null,
        ended: state.ended,
        result: (state.ended && state.result !== null) ? deepcopy(state.result) : null
      };
      if (role === "operator") {
        view.you = { role: "operator", card: state.card !== null ? { word: state.card.word, forbidden: state.card.forbidden.slice() } : null };
      } else if (role === "player" && me === state.clueGiverId) {
        view.you = { role: "clue_giver", team: teamOf(state, me), card: state.card !== null ? { word: state.card.word, forbidden: state.card.forbidden.slice() } : null };
      } else if (role === "player") {
        view.you = { role: "guesser", team: teamOf(state, me) };
      } else if (role === "spectator") {
        view.you = { role: "spectator" };
      }
      return view;
    }

    return {
      MODE_ID: MODE_ID, TITLE: "Forbidden Words", ACTION_PREFIX: PREFIX, MIN_PLAYERS: MIN_PLAYERS,
      validateItem: validateItem, validateItems: validateItems, initialize: initialize,
      reduce: reduce, project: project, tick: tick, onPause: onPause, onResume: onResume, nextDeadline: nextDeadline
    };
  })();


  var Bluff = (function () {
    var MODE_ID = "bluff", PREFIX = "bluff.", MIN_PLAYERS = 3, MAX_PLAYERS = 12,
      DEFAULT_ROUNDS = 3, MAX_ROUNDS = 10,
      MAX_QUESTION_LEN = 200, MAX_ANSWER_LEN = 160, MAX_ANSWER_BYTES = 1024, MAX_ALIASES = 8;
    var SUBMISSION = "submission", VOTING = "voting", REVEAL = "reveal", FINISHED = "finished";

    function validateItem(item, path, issues) {
      if (!isPyDict(item)) { issues.push(path + ": must be an object"); return null; }
      var before = issues.length;
      if (!isText(get(item, "id"), MAX_ID)) issues.push(path + ".id: required non-empty string (max 64)");
      var question = get(item, "question");
      if (!isPyDict(question) || !isText(get(question, "en"), MAX_QUESTION_LEN) || !isText(get(question, "ar"), MAX_QUESTION_LEN)) {
        issues.push(path + ".question: required {en, ar} non-empty strings (max 200)");
      }
      var trueAnswer = get(item, "trueAnswer");
      var taOk = isPyDict(trueAnswer) &&
        isText(get(trueAnswer, "en"), MAX_ANSWER_LEN) && cleanText(get(trueAnswer, "en"), MAX_ANSWER_LEN) !== null &&
        isText(get(trueAnswer, "ar"), MAX_ANSWER_LEN) && cleanText(get(trueAnswer, "ar"), MAX_ANSWER_LEN) !== null;
      if (!taOk) issues.push(path + ".trueAnswer: required {en, ar} non-empty printable strings (max 160)");
      var aliasesRaw = get(item, "aliases");
      var aliases = { en: [], ar: [] };
      if (!isNone(aliasesRaw)) {
        if (!isPyDict(aliasesRaw)) {
          issues.push(path + ".aliases: must be an object with en/ar arrays");
        } else {
          ["en", "ar"].forEach(function (lang) {
            var arr = get(aliasesRaw, lang);
            if (isNone(arr)) return;
            var ok = Array.isArray(arr) && arr.length <= MAX_ALIASES &&
              arr.every(function (a) { return isText(a, MAX_ANSWER_LEN) && cleanText(a, MAX_ANSWER_LEN) !== null; });
            if (!ok) issues.push(path + ".aliases." + lang + ": must be an array of at most " + MAX_ALIASES + " non-empty printable strings (max 160)");
            else aliases[lang] = arr.slice();
          });
        }
      }
      if (issues.length !== before) return null;
      return { id: item.id, question: { en: question.en, ar: question.ar },
        trueAnswer: { en: trueAnswer.en, ar: trueAnswer.ar }, aliases: aliases };
    }
    function validateItems(items, issues) {
      var byId = new Map(), byQuestion = new Map();
      items.forEach(function (item, index) {
        if (byId.has(item.id)) issues.push("items[" + index + "].id: duplicates id of items[" + byId.get(item.id) + "]");
        else byId.set(item.id, index);
        var qkey = matchKey(item.question.en);
        if (byQuestion.has(qkey)) issues.push("items[" + index + "].question.en: duplicates normalized question of items[" + byQuestion.get(qkey) + "]");
        else byQuestion.set(qkey, index);
      });
    }

    function onlyKeys(o, allowed) {
      return Object.keys(o).every(function (k) { return allowed.indexOf(k) >= 0; });
    }
    function answerKeys(item) {
      var keys = new Set();
      keys.add(matchKey(item.trueAnswer.en));
      keys.add(matchKey(item.trueAnswer.ar));
      item.aliases.en.forEach(function (a) { keys.add(matchKey(a)); });
      item.aliases.ar.forEach(function (a) { keys.add(matchKey(a)); });
      return keys;
    }

    function makeRoundId(gameNo, roundNo) { return "g" + gameNo + "r" + roundNo; }
    function startRound(state, roundNo, item) {
      state.item = item; state.roundNo = roundNo; state.roundId = makeRoundId(state.gameNo, roundNo);
      state.phase = SUBMISSION; state.fakes = obj(); state.excluded = obj(); state.options = null; state.votes = obj();
    }
    // Every public option has exactly the same shape {optionId, text} with
    // text a single string in the game language (state.language): the true
    // answer is cleaned exactly like a submitted fake, so no field, type or
    // translation pair can tell it apart (correction v3: the earlier
    // {en, ar} text gave fakes en === ar and the truth two translations).
    // Option ids are opaque: sha256 over the host-entropy game seed, the room
    // code, the game number, the round number and the post-shuffle slot, cut
    // to 16 hex digits. They carry no author, content or truth position and
    // never repeat across rounds, games or rooms, so an id copied from any
    // other round/game/room is unknown_option here.
    function optionId(s, slot, salt) {
      var material = "bluff-option|v1|" + s.seed + "|" + s.room + "|" + s.gameNo + "|" + s.roundNo + "|" + slot + "|" + salt;
      return "o" + sha256Hex(utf8Encode(material)).slice(0, 16);
    }
    function buildOptions(s) {
      var entries = [];
      s.order.forEach(function (p) { if (has(s.fakes, p)) entries.push({ authorId: p, text: s.fakes[p] }); });
      entries.push({ authorId: null, text: cleanText(s.item.trueAnswer[s.language], MAX_ANSWER_LEN) });
      var roundSeed = BigInt(s.seed) + BigInt(s.roundNo) * 1000003n + 7n;
      shuffleInPlace(roundSeed, entries);
      var used = new Set();
      s.options = entries.map(function (e, i) {
        var salt = 0, id = optionId(s, i, salt);
        while (used.has(id)) { salt += 1; id = optionId(s, i, salt); }
        used.add(id);
        return { optionId: id, authorId: e.authorId, text: e.text };
      });
    }
    function awardRound(s) {
      var trueOpt = s.options.filter(function (o) { return o.authorId === null; })[0];
      var tally = obj(); s.options.forEach(function (o) { tally[o.optionId] = 0; });
      var scoreDelta = obj(); s.order.forEach(function (p) { scoreDelta[p] = 0; });
      var abstained = [];
      s.order.forEach(function (p) {
        var choice = has(s.votes, p) ? s.votes[p] : null;
        if (choice === null) { abstained.push(p); return; }
        tally[choice] += 1;
        var opt = s.options.filter(function (o) { return o.optionId === choice; })[0];
        if (opt.authorId === null) scoreDelta[p] += 100;
        else scoreDelta[opt.authorId] += 100;
      });
      s.order.forEach(function (p) { s.scores[p] = (s.scores[p] || 0) + scoreDelta[p]; });
      // voters: pid -> optionId, the same choices already folded into tally
      // above. Reveal-only (lastResult never exists before a round's own
      // reveal action runs), and every role's project() already exposes
      // every other reveal-only field (trueOptionId, every option's
      // authorId, scoreDelta) verbatim to operator/player/display alike —
      // this is the same disclosure tier, not a new one.
      s.lastResult = { roundNo: s.roundNo, question: deepcopy(s.item.question), trueOptionId: trueOpt.optionId,
        options: deepcopy(s.options), voteTally: tally, voters: deepcopy(s.votes), scoreDelta: scoreDelta, abstained: abstained.slice() };
      s.awardedRounds.push(s.roundId);
    }

    function initialize(config, players, content) {
      var order = players.map(function (p) { return p.id; });
      if (order.length < MIN_PLAYERS) return [null, "not_enough_players"];
      if (order.length > MAX_PLAYERS) return [null, "too_many_players"];
      var options = isPyDict(config.options) ? config.options : obj();
      var roundsReq = get(options, "rounds");
      var rounds = DEFAULT_ROUNDS;
      if (!isNone(roundsReq)) {
        if (typeof roundsReq !== "number" || !Number.isInteger(roundsReq) || roundsReq < 1 || roundsReq > MAX_ROUNDS) {
          return [null, "invalid_config"];
        }
        rounds = roundsReq;
      }
      var language = get(options, "language");
      if (isNone(language)) language = "en";
      if (language !== "en" && language !== "ar") return [null, "invalid_config"];
      var items = deepcopy(content.items);
      if (items.length < 1) return [null, "content_insufficient"];
      if (rounds > items.length) return [null, "content_insufficient"];
      shuffleInPlace(config.seed, items);
      var deck = items.slice(0, rounds);
      var scores = obj();
      players.forEach(function (p) { scores[p.id] = p.score; });
      var state = {
        mode: MODE_ID, title: content.title, gameNo: config.gameNo, seed: String(config.seed),
        room: isStr(config.room) ? config.room : "", language: language, order: order, rounds: rounds, deck: deck.slice(1), scores: scores,
        lastResult: null, awardedRounds: [], ended: false
      };
      startRound(state, 1, deck[0]);
      return [state, null];
    }

    function reduce(state, actor, action, serverSequence) {
      var kind = get(action, "type");
      var payload = get(action, "payload");
      if (isNone(payload)) payload = obj();
      var role = get(actor, "role"), pid = get(actor, "playerId"), actionRoundId = get(action, "roundId");
      if (!isNone(actionRoundId) && actionRoundId !== state.roundId) return [state, "stale_round"];
      if (!isPyDict(payload)) return [state, "invalid_payload"];
      var s;

      if (kind === "game.end") {
        if (role !== "operator") return [state, "forbidden"];
        if (state.ended) return [state, "invalid_phase"];
        s = deepcopy(state);
        s.ended = true;
        return [s, null];
      }

      if (state.ended) return [state, "invalid_phase"];
      var phase = state.phase;

      if (kind === PREFIX + "submit_answer") {
        if (role !== "player" || !inList(state.order, pid)) return [state, "forbidden"];
        if (phase !== SUBMISSION) return [state, "invalid_phase"];
        if (!onlyKeys(payload, ["text"])) return [state, "invalid_payload"];
        var text = cleanText(get(payload, "text"), MAX_ANSWER_LEN);
        if (text === null || utf8Encode(text).length > MAX_ANSWER_BYTES) return [state, "invalid_payload"];
        var key = matchKey(text);
        if (answerKeys(state.item).has(key)) return [state, "invalid_answer"];
        if (has(state.fakes, pid)) {
          if (matchKey(state.fakes[pid]) === key) return [state, null];
          return [state, "already_submitted"];
        }
        var collided = Object.keys(state.fakes).some(function (p) { return matchKey(state.fakes[p]) === key; });
        if (collided) return [state, "invalid_answer"];
        s = deepcopy(state);
        s.fakes[pid] = text;
        return [s, null];
      }

      if (kind === PREFIX + "open_vote") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== SUBMISSION) return [state, "invalid_phase"];
        if (!onlyKeys(payload, ["force"])) return [state, "invalid_payload"];
        var force = get(payload, "force", false);
        if (!isBool(force)) return [state, "invalid_payload"];
        var accounted = Object.keys(state.fakes).length + Object.keys(state.excluded).length;
        if (!force && accounted < state.order.length) return [state, "invalid_phase"];
        s = deepcopy(state);
        if (force) {
          s.order.forEach(function (p) { if (!has(s.fakes, p) && !has(s.excluded, p)) s.excluded[p] = true; });
        }
        buildOptions(s);
        s.phase = VOTING;
        return [s, null];
      }

      if (kind === PREFIX + "vote") {
        if (role !== "player" || !inList(state.order, pid)) return [state, "forbidden"];
        if (phase !== VOTING) return [state, "invalid_phase"];
        if (!onlyKeys(payload, ["optionId"])) return [state, "invalid_payload"];
        var optionId = get(payload, "optionId");
        if (!isStr(optionId)) return [state, "invalid_payload"];
        var opt = state.options.filter(function (o) { return o.optionId === optionId; })[0];
        if (!opt) return [state, "unknown_option"];
        if (opt.authorId === pid) return [state, "self_vote"];
        if (has(state.votes, pid)) {
          if (state.votes[pid] === optionId) return [state, null];
          return [state, "already_voted"];
        }
        s = deepcopy(state);
        s.votes[pid] = optionId;
        return [s, null];
      }

      if (kind === PREFIX + "reveal") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== VOTING) return [state, "invalid_phase"];
        if (!onlyKeys(payload, ["force"])) return [state, "invalid_payload"];
        var forceReveal = get(payload, "force", false);
        if (!isBool(forceReveal)) return [state, "invalid_payload"];
        var votedCount = Object.keys(state.votes).length;
        if (!forceReveal && votedCount < state.order.length) return [state, "invalid_phase"];
        if (inList(state.awardedRounds, state.roundId)) return [state, "already_awarded"];
        s = deepcopy(state);
        awardRound(s);
        s.phase = REVEAL;
        return [s, null];
      }

      if (kind === "round.next") {
        if (role !== "operator") return [state, "forbidden"];
        if (phase !== REVEAL) return [state, "invalid_phase"];
        s = deepcopy(state);
        if (s.roundNo >= s.rounds || !s.deck.length) { s.phase = FINISHED; return [s, null]; }
        var item = s.deck.shift();
        startRound(s, s.roundNo + 1, item);
        return [s, null];
      }

      return [state, "unknown_action"];
    }

    function project(state, viewer) {
      var role = get(viewer, "role");
      var me = role === "player" ? get(viewer, "playerId") : null;
      if (!isNone(me) && !inList(state.order, me)) { role = "display"; me = null; }
      var phase = state.ended ? "ended" : state.phase;
      var accounted = Object.keys(state.fakes).length + Object.keys(state.excluded).length;
      var votedCount = Object.keys(state.votes).length;
      var view = {
        title: state.title, round: state.roundNo, rounds: state.rounds, phase: phase, language: state.language,
        question: deepcopy(state.item.question),
        submittedCount: accounted, totalPlayers: state.order.length, votedCount: votedCount,
        options: null, lastResult: state.lastResult !== null ? deepcopy(state.lastResult) : null
      };
      if (state.options !== null && (state.phase === VOTING || state.phase === REVEAL || state.phase === FINISHED)) {
        view.options = state.options.map(function (o) {
          return (state.phase === VOTING) ?
            { optionId: o.optionId, text: o.text } :
            { optionId: o.optionId, text: o.text, authorId: o.authorId };
        });
      }
      if (role === "operator") {
        view.fakes = deepcopy(state.fakes);
        view.excluded = Object.keys(state.excluded);
        view.votes = deepcopy(state.votes);
        view.trueAnswer = deepcopy(state.item.trueAnswer);
        view.roundsRemaining = state.deck.length;
      } else if (role === "player") {
        var mine = { submitted: has(state.fakes, me) || has(state.excluded, me),
          text: has(state.fakes, me) ? state.fakes[me] : null,
          voted: has(state.votes, me), optionId: has(state.votes, me) ? state.votes[me] : null, ownOptionId: null };
        if (state.options !== null) {
          var own = state.options.filter(function (o) { return o.authorId === me; })[0];
          mine.ownOptionId = own ? own.optionId : null;
        }
        view.you = mine;
      }
      return view;
    }

    // LATE_JOIN_SPECTATE: a join while a Bluff game is playing/paused is
    // admitted as a read-only spectator (room layer) and promoted to a
    // player at the next room.start; every other mode keeps game_in_progress.
    return { MODE_ID: MODE_ID, TITLE: "Bluff", ACTION_PREFIX: PREFIX, MIN_PLAYERS: MIN_PLAYERS, MAX_PLAYERS: MAX_PLAYERS,
      LATE_JOIN_SPECTATE: true,
      validateItem: validateItem, validateItems: validateItems, initialize: initialize, reduce: reduce, project: project };
  })();

  // -------------------------------------------------------- modes/escape_room
  // Ported from party/server/modes/escape_room.py. Cooperative mode: one
  // frozen roster shares a team score and a single authoritative wall-clock
  // timer across three sequential puzzles. HAS_TIMER = true tells
  // room_logic's reduceRoom to forward a synthetic game.pause/game.resume
  // into this module whenever the room itself is paused/resumed, so the
  // elapsed-time accounting freezes with the room instead of continuing to
  // tick in the background. `now` (seconds, double) is always the caller's
  // explicit wall-clock argument -- this file never reads real time itself.
  var EscapeRoom = (function () {
    var MODE_ID = "escape_room", PREFIX = "escape_room.", MIN_PLAYERS = 3, MAX_PLAYERS = 8,
      PUZZLE_COUNT = 3, FRAGMENTS_PER_PUZZLE = MAX_PLAYERS,
      MAX_PROMPT_LEN = 500, MAX_FRAGMENT_LEN = 240, MAX_HINT_LEN = 240, MAX_ANSWER_LEN = 80,
      MIN_ALIASES = 1, MAX_ALIASES = 20,
      SOLVE_POINTS = 100, WRONG_PENALTY = 5, HINT_PENALTY = 20, COOLDOWN_SECONDS = 2.0;
    var ACTIVE = "active", SOLVED = "solved";
    var OUTCOME_SUCCESS = "success", OUTCOME_TIMEOUT = "timeout", OUTCOME_ABORTED = "aborted";
    var HAS_TIMER = true;
    // Room-layer opt-ins, mirroring escape_room.py: cooldownUntil is private
    // per-player state (no public revision for a change confined to it),
    // strict payload schemas, and late joiners spectate.
    var PRIVATE_GAME_KEYS = ["cooldownUntil"], STRICT_PAYLOADS = true, LATE_SPECTATORS = true;
    var PAYLOAD_SCHEMAS = { "escape_room.answer": { text: "str" }, "escape_room.hint": {} };

    function round1(x) { return Math.round(x * 10) / 10; }

    function bilingual(d, path, enKey, arKey, issues, maxLen) {
      var ok = true;
      if (!isText(get(d, enKey), maxLen)) { issues.push(path + "." + enKey + ": required non-empty string (max " + maxLen + ")"); ok = false; }
      if (!isText(get(d, arKey), maxLen)) { issues.push(path + "." + arKey + ": required non-empty string (max " + maxLen + ")"); ok = false; }
      return ok;
    }

    // Puzzle {id, promptEn, promptAr, fragments[8]{en,ar}, hintEn, hintAr, aliases[]}.
    function validateItem(item, path, issues) {
      if (!isPyDict(item)) { issues.push(path + ": must be an object"); return null; }
      var before = issues.length;
      if (!isText(get(item, "id"), MAX_ID)) issues.push(path + ".id: required non-empty string (max 64)");
      bilingual(item, path, "promptEn", "promptAr", issues, MAX_PROMPT_LEN);
      bilingual(item, path, "hintEn", "hintAr", issues, MAX_HINT_LEN);

      var fragments = get(item, "fragments"), outFragments = null;
      if (!Array.isArray(fragments) || fragments.length !== FRAGMENTS_PER_PUZZLE) {
        issues.push(path + ".fragments: required array of exactly " + FRAGMENTS_PER_PUZZLE + " entries");
      } else {
        outFragments = []; var fragOk = true;
        fragments.forEach(function (frag, index) {
          var fpath = path + ".fragments[" + index + "]";
          if (!isPyDict(frag)) { issues.push(fpath + ": must be an object"); fragOk = false; return; }
          if (!bilingual(frag, fpath, "en", "ar", issues, MAX_FRAGMENT_LEN)) { fragOk = false; return; }
          outFragments.push({ en: frag.en, ar: frag.ar });
        });
        if (!fragOk) outFragments = null;
      }

      var aliases = get(item, "aliases"), outAliases = null;
      if (!Array.isArray(aliases) || aliases.length < MIN_ALIASES || aliases.length > MAX_ALIASES) {
        issues.push(path + ".aliases: required array of " + MIN_ALIASES + "-" + MAX_ALIASES + " strings");
      } else {
        outAliases = []; var aliasOk = true; var seen = new Set();
        aliases.forEach(function (alias, index) {
          var apath = path + ".aliases[" + index + "]";
          var cleaned = isText(alias, MAX_ANSWER_LEN) ? cleanText(alias, MAX_ANSWER_LEN) : null;
          if (cleaned === null) { issues.push(apath + ": required non-empty printable string (max " + MAX_ANSWER_LEN + ")"); aliasOk = false; return; }
          var key = matchKey(cleaned);
          if (seen.has(key)) { issues.push(apath + ": duplicates another alias of this puzzle (case/width-insensitive)"); aliasOk = false; return; }
          seen.add(key); outAliases.push(cleaned);
        });
        if (!aliasOk) outAliases = null;
      }

      if (issues.length !== before) return null;
      return { id: item.id, promptEn: item.promptEn, promptAr: item.promptAr, hintEn: item.hintEn, hintAr: item.hintAr,
        fragments: outFragments, aliases: outAliases };
    }
    // Cross-puzzle check: no alias of one puzzle may match an alias of another.
    function validateItems(items, issues) {
      var owner = new Map();
      items.forEach(function (item, index) {
        item.aliases.forEach(function (alias) {
          var key = matchKey(alias);
          var first = owner.has(key) ? owner.get(key) : null;
          if (first !== null && first !== index) {
            issues.push("items[" + index + "].aliases: collides with an alias of items[" + first + "] (case/width-insensitive)");
          } else owner.set(key, index);
        });
      });
    }

    function roundId(gameNo, puzzleIndex) { return "g" + gameNo + "p" + (puzzleIndex + 1); }
    function elapsed(state, now) {
      if (state.runningSince !== null) return state.accumulatedActive + (now - state.runningSince);
      return state.accumulatedActive;
    }
    function remaining(state, now) { return Math.max(0.0, TIMER_SECONDS() - elapsed(state, now)); }
    // Test-only acceleration hook (ESCAPE_ROOM_TIMER_SECONDS equivalent):
    // the JS core takes no environment, so the native host is responsible
    // for choosing this value; it is fixed per-process the same way the
    // Python reference reads the env var once at import time.
    function TIMER_SECONDS() { return 600.0; }
    // Stop the clock permanently (every path that ends the game calls this).
    function freeze(s, now) {
      if (s.runningSince !== null) { s.accumulatedActive += now - s.runningSince; s.runningSince = null; }
    }
    // Returns an ended-by-timeout copy, or null if the timer has not expired.
    // Expiry is detected lazily: always visible in project() once wall-clock
    // time passes the limit, and committed into persisted state the next
    // time any action reaches reduce(), which absorbs that action into the
    // timeout transition instead of applying it.
    function maybeCommitTimeout(state, now) {
      if (state.ended || state.runningSince === null) return null;
      if (remaining(state, now) > 0) return null;
      var s = deepcopy(state);
      freeze(s, now);
      s.ended = true; s.outcome = OUTCOME_TIMEOUT;
      return s;
    }

    function initialize(config, players, content) {
      var order = players.map(function (p) { return p.id; });
      if (order.length < MIN_PLAYERS) return [null, "not_enough_players"];
      if (order.length > MAX_PLAYERS) return [null, "too_many_players"];
      var items = content.items;
      if (items.length < PUZZLE_COUNT) return [null, "content_insufficient"];
      var puzzles = deepcopy(items.slice(0, PUZZLE_COUNT));
      var now = config.now;
      var fragmentOf = obj();
      order.forEach(function (pid, index) { fragmentOf[pid] = index; });
      var scores = obj();
      players.forEach(function (p) { scores[p.id] = p.score; });
      var state = {
        mode: MODE_ID, title: content.title, gameNo: config.gameNo, seed: config.seed,
        order: order, fragmentOf: fragmentOf, puzzles: puzzles, puzzleIndex: 0, phase: ACTIVE,
        roundId: roundId(config.gameNo, 0), hintUsed: new Array(PUZZLE_COUNT).fill(false),
        teamScore: 0, scores: scores, cooldownUntil: obj(),
        accumulatedActive: 0.0, runningSince: now, ended: false, outcome: null
      };
      return [state, null];
    }

    function syncTeamScore(s) {
      s.order.forEach(function (pid) { s.scores[pid] = s.teamScore; });
    }

    function reduce(state, actor, action, serverSequence, now) {
      var timedOut = maybeCommitTimeout(state, now);
      if (timedOut !== null) return [timedOut, null];

      var kind = get(action, "type");
      var payload = get(action, "payload");
      if (isNone(payload)) payload = obj();
      if (!isPyDict(payload)) return [state, "invalid_payload"];
      var role = get(actor, "role"), pid = get(actor, "playerId"), actionRoundId = get(action, "roundId");
      if (!isNone(actionRoundId) && actionRoundId !== state.roundId) return [state, "stale_round"];
      var s;

      if (kind === "game.end") {
        if (role !== "operator") return [state, "forbidden"];
        if (state.ended) return [state, "invalid_phase"];
        s = deepcopy(state);
        freeze(s, now); s.ended = true; s.outcome = OUTCOME_ABORTED;
        return [s, null];
      }

      if (state.ended) return [state, "invalid_phase"];

      if (kind === "game.pause") {
        // Forwarded only for HAS_TIMER modes when the room transitions to
        // paused (room_logic's reduceRoom); role is already gated operator there.
        if (role !== "operator") return [state, "forbidden"];
        if (state.runningSince === null) return [state, null];
        s = deepcopy(state);
        s.accumulatedActive += now - s.runningSince; s.runningSince = null;
        return [s, null];
      }
      if (kind === "game.resume") {
        if (role !== "operator") return [state, "forbidden"];
        if (state.runningSince !== null) return [state, null];
        s = deepcopy(state); s.runningSince = now;
        return [s, null];
      }

      if (state.runningSince === null) {
        // Room-level pause already rejects with "paused" before reaching
        // here for ordinary mode actions; this guards the mode-owned
        // game.pause/game.resume/game.end bypass above from leaving a
        // paused game answerable to round.next/answer/hint.
        return [state, "paused"];
      }

      var phase = state.phase, index = state.puzzleIndex;

      if (kind === "escape_room.answer") {
        if (role !== "player" || !inList(state.order, pid)) return [state, "forbidden"];
        var extraKeys = Object.keys(payload).filter(function (k) { return k !== "text"; });
        if (extraKeys.length || !isStr(get(payload, "text"))) return [state, "invalid_payload"];
        if (phase !== ACTIVE) return [state, "invalid_phase"];
        if ((state.cooldownUntil[pid] || 0.0) > now) return [state, "cooldown"];
        var text = cleanText(get(payload, "text"), MAX_ANSWER_LEN);
        if (text === null) return [state, "invalid_payload"];
        s = deepcopy(state);
        var puzzle = s.puzzles[index], key = matchKey(text);
        if (puzzle.aliases.some(function (alias) { return matchKey(alias) === key; })) {
          s.teamScore += SOLVE_POINTS; s.phase = SOLVED;
          if (index === PUZZLE_COUNT - 1) { freeze(s, now); s.ended = true; s.outcome = OUTCOME_SUCCESS; }
        } else {
          s.teamScore = Math.max(0, s.teamScore - WRONG_PENALTY);
          s.cooldownUntil[pid] = now + COOLDOWN_SECONDS;
        }
        syncTeamScore(s);
        return [s, null];
      }

      if (kind === "escape_room.hint") {
        if (role !== "operator") return [state, "forbidden"];
        if (Object.keys(payload).length) return [state, "invalid_payload"];
        if (phase !== ACTIVE) return [state, "invalid_phase"];
        if (state.hintUsed[index]) return [state, "already_hinted"];
        s = deepcopy(state);
        s.hintUsed[index] = true;
        s.teamScore = Math.max(0, s.teamScore - HINT_PENALTY);
        syncTeamScore(s);
        return [s, null];
      }

      if (kind === "round.next") {
        if (role !== "operator") return [state, "forbidden"];
        if (Object.keys(payload).length) return [state, "invalid_payload"];
        if (phase !== SOLVED) return [state, "invalid_phase"];
        if (index + 1 >= PUZZLE_COUNT) return [state, "invalid_phase"];
        s = deepcopy(state);
        s.puzzleIndex = index + 1; s.phase = ACTIVE; s.roundId = roundId(s.gameNo, s.puzzleIndex);
        return [s, null];
      }

      return [state, "unknown_action"];
    }

    function publicPuzzle(puzzle, hintUsed) {
      var out = { id: puzzle.id, promptEn: puzzle.promptEn, promptAr: puzzle.promptAr };
      if (hintUsed) { out.hintEn = puzzle.hintEn; out.hintAr = puzzle.hintAr; }
      return out;
    }

    // Nobody sees any fragment, alias or solution before the game ends. A
    // player sees only their own fragment for the current puzzle; operator
    // and display see no fragment at all pre-reveal. At end (success,
    // timeout or operator abort) every viewer receives the full reveal.
    function project(state, viewer, now) {
      var role = get(viewer, "role");
      var me = role === "player" ? get(viewer, "playerId") : null;
      if (!isNone(me) && !inList(state.order, me)) { role = "display"; me = null; }
      var order = state.order;
      var rem = remaining(state, now);
      var liveTimeout = !state.ended && state.runningSince !== null && rem <= 0;
      var ended = state.ended || liveTimeout;
      var outcome = state.ended ? state.outcome : (liveTimeout ? OUTCOME_TIMEOUT : null);
      var index = state.puzzleIndex;
      var solvedCount = index + ((state.phase === SOLVED || (ended && outcome === OUTCOME_SUCCESS)) ? 1 : 0);

      var view = {
        title: state.title, phase: ended ? "ended" : state.phase, outcome: outcome,
        puzzleIndex: index, puzzleCount: PUZZLE_COUNT, solvedCount: solvedCount,
        remainingSeconds: round1(rem), order: order.slice(),
        currentPuzzle: ended ? null : publicPuzzle(state.puzzles[index], state.hintUsed[index])
      };

      if (ended) {
        view.reveal = {
          puzzles: state.puzzles.map(function (puzzle) {
            var fragments = obj();
            order.forEach(function (p) { fragments[p] = { en: puzzle.fragments[state.fragmentOf[p]].en, ar: puzzle.fragments[state.fragmentOf[p]].ar }; });
            return { id: puzzle.id, promptEn: puzzle.promptEn, promptAr: puzzle.promptAr,
              answer: puzzle.aliases[0], aliases: puzzle.aliases.slice(), fragments: fragments };
          })
        };
      } else if (role === "player") {
        var fragment = state.puzzles[index].fragments[state.fragmentOf[me]];
        view.you = { fragment: { en: fragment.en, ar: fragment.ar },
          cooldownSeconds: round1(Math.max(0.0, (state.cooldownUntil[me] || 0.0) - now)) };
      }
      return view;
    }

    return { MODE_ID: MODE_ID, TITLE: "Escape Room", ACTION_PREFIX: PREFIX, MIN_PLAYERS: MIN_PLAYERS,
      HAS_TIMER: HAS_TIMER, PRIVATE_GAME_KEYS: PRIVATE_GAME_KEYS, STRICT_PAYLOADS: STRICT_PAYLOADS,
      LATE_SPECTATORS: LATE_SPECTATORS, PAYLOAD_SCHEMAS: PAYLOAD_SCHEMAS,
      validateItem: validateItem, validateItems: validateItems, initialize: initialize, reduce: reduce, project: project };
  })();

  // ---------------------------------------------------------- modes registry
  function ModeSpec(id, title, module, prefix) {
    this.id = id; this.title = title; this.module = module || null; this.implemented = !!module; this.actionPrefix = prefix;
  }
  var REGISTRY = [
    new ModeSpec(WhoAmI.MODE_ID, WhoAmI.TITLE, WhoAmI, WhoAmI.ACTION_PREFIX),
    new ModeSpec(Feud.MODE_ID, Feud.TITLE, Feud, Feud.ACTION_PREFIX),
    new ModeSpec(Impostor.MODE_ID, Impostor.TITLE, Impostor, Impostor.ACTION_PREFIX),
    new ModeSpec("draw_guess", "Draw & Guess", null, "draw_guess."),
    new ModeSpec("drawing_chain", "Drawing Chain", null, "drawing_chain."),
    new ModeSpec(Bluff.MODE_ID, Bluff.TITLE, Bluff, Bluff.ACTION_PREFIX),
    new ModeSpec("werewolf", "Werewolf", null, "werewolf."),
    new ModeSpec(Taboo.MODE_ID, Taboo.TITLE, Taboo, Taboo.ACTION_PREFIX),
    new ModeSpec("wavelength", "Spectrum", null, "wavelength."),
    new ModeSpec(EscapeRoom.MODE_ID, EscapeRoom.TITLE, EscapeRoom, EscapeRoom.ACTION_PREFIX)
  ];
  function getMode(id) {
    if (!isStr(id)) return null;
    for (var i = 0; i < REGISTRY.length; i++) if (REGISTRY[i].id === id) return REGISTRY[i];
    return null;
  }
  function modeForAction(type) {
    for (var i = 0; i < REGISTRY.length; i++) if (type.startsWith(REGISTRY[i].actionPrefix)) return REGISTRY[i];
    return null;
  }
  // contents: Map mode -> ContentStatus
  function catalog(contents) {
    return REGISTRY.map(function (spec) {
      var status = contents.has(spec.id) ? contents.get(spec.id) : null;
      return { id: spec.id, title: spec.title, implemented: spec.implemented,
        content: (spec.implemented && status !== null) ? status.status : null };
    });
  }
  // packs: {mode: Uint8Array|null}; mirrors content.load_all
  function loadAll(packs) {
    var out = new Map();
    REGISTRY.forEach(function (spec) {
      if (!spec.implemented) return;
      var bytes = has(packs, spec.id) ? packs[spec.id] : null;
      out.set(spec.id, loadMode(spec.id, bytes, spec.module.validateItem, spec.module.validateItems));
    });
    return out;
  }

  // ------------------------------------------------------------ room_logic
  var HARD_MIN = 3, HARD_MAX = 12;
  var ROOM_ACTIONS = ["room.set_mode", "room.start", "room.pause", "room.resume", "room.end", "room.reset", "room.close", "round.next"];
  function newRoomState(code, operatorName, minP, maxP) {
    return { code: code, operatorName: operatorName, limits: { min: minP, max: maxP }, phase: "lobby",
      mode: null, gameNo: 0, players: [], game: null };
  }
  // Late spectators: a join while a game is playing/paused is admitted as a
  // read-only spectator (stored outside `players`, promoted by the next
  // valid room.start) by any mode that opts in via the generic LATE_SPECTATORS
  // flag (room_logic.py parity -- currently only EscapeRoom), or by legacy
  // ad-hoc membership in SPECTATOR_MODES (Taboo, Bluff -- predate the flag).
  var SPECTATOR_MODES = ["taboo", "bluff"];
  // Exact payload schemas for room actions in STRICT_PAYLOADS scope
  // (room_logic.ROOM_PAYLOAD_SCHEMAS). Keys optional; others rejected.
  var ROOM_PAYLOAD_SCHEMAS = {
    "room.set_mode": { mode: "str" }, "room.start": {}, "room.pause": {}, "room.resume": {},
    "room.end": {}, "room.reset": { clearScores: "bool" }, "room.close": {}, "round.next": {}
  };
  var MAX_SPECTATORS = HARD_MAX;
  function modeFlag(modeId, flag) {
    var spec = getMode(modeId);
    return !!(spec !== null && spec.implemented && spec.module[flag]);
  }
  function spectatorsOf(state) { var sp = get(state, "spectators"); return Array.isArray(sp) ? sp : []; }
  function nameUsed(state, key) {
    return state.players.some(function (p) { return matchKey(p.name) === key; }) ||
      spectatorsOf(state).some(function (p) { return matchKey(p.name) === key; });
  }
  function isSpectator(state, playerId) {
    return !isNone(playerId) && spectatorsOf(state).some(function (p) { return p.id === playerId; });
  }
  function applyJoin(state, playerId, name) {
    var phase = state.phase, s;
    if (phase === "closed") return [state, "room_closed"];
    var spectating = false;
    if (phase === "playing" || phase === "paused") {
      if ((SPECTATOR_MODES.indexOf(state.mode) < 0 && !modeFlag(state.mode, "LATE_SPECTATORS")) || state.game === null) {
        return [state, "game_in_progress"];
      }
      spectating = true;
    }
    var spectators = spectatorsOf(state);
    // While late joiners are still waiting for promotion, later joiners queue
    // behind them so the next start sees true join order (teams alternate by
    // join order).
    if (spectators.length) spectating = true;
    var key = matchKey(name);
    if (spectating) {
      // Legacy sibling modes (Taboo, Bluff) predate the generic LATE_SPECTATORS
      // flag and share one combined roster cap with seated players; EscapeRoom
      // (and any other generic LATE_SPECTATORS mode) keeps its own independent
      // spectator capacity against the hard ceiling, per room_logic.py parity.
      var legacySpectators = SPECTATOR_MODES.indexOf(state.mode) >= 0;
      var spectatorCap = legacySpectators ? state.limits.max : MAX_SPECTATORS;
      var spectatorCount = legacySpectators ? (state.players.length + spectators.length) : spectators.length;
      if (spectatorCount >= spectatorCap) return [state, "room_full"];
      if (nameUsed(state, key)) return [state, "name_taken"];
      s = deepcopy(state);
      if (!has(s, "spectators")) s.spectators = [];
      s.spectators.push({ id: playerId, name: name, score: 0 });
      return [s, null];
    }
    if (state.players.length >= state.limits.max) return [state, "room_full"];
    if (nameUsed(state, key)) return [state, "name_taken"];
    s = deepcopy(state);
    s.players.push({ id: playerId, name: name, score: 0 });
    return [s, null];
  }
  function promoteSpectators(s) {
    if (!has(s, "spectators")) return;
    var remaining = [];
    s.spectators.forEach(function (sp) {
      if (s.players.length < s.limits.max) s.players.push({ id: sp.id, name: sp.name, score: 0 });
      else remaining.push(sp);
    });
    if (remaining.length) s.spectators = remaining; else delete s.spectators;
  }
  function deepEqual(a, b) {
    if (a === b) return true;
    if (a instanceof PyFloat || b instanceof PyFloat || a instanceof PyBigInt || b instanceof PyBigInt) {
      return JSON.stringify(a) === JSON.stringify(b);
    }
    if (a === null || b === null || typeof a !== "object" || typeof b !== "object") return false;
    if (Array.isArray(a) !== Array.isArray(b)) return false;
    if (Array.isArray(a)) {
      if (a.length !== b.length) return false;
      for (var i = 0; i < a.length; i++) if (!deepEqual(a[i], b[i])) return false;
      return true;
    }
    var ka = Object.keys(a), kb = Object.keys(b);
    if (ka.length !== kb.length) return false;
    for (var j = 0; j < ka.length; j++) {
      if (!hasOwn.call(b, ka[j]) || !deepEqual(a[ka[j]], b[ka[j]])) return false;
    }
    return true;
  }
  // room_logic.public_change: ignore only the mode's PRIVATE_GAME_KEYS.
  function publicChange(oldState, newState) {
    var spec = getMode(get(newState, "mode"));
    var priv = (spec !== null && spec.implemented && spec.module.PRIVATE_GAME_KEYS) || [];
    if (!priv.length) return true;
    function strip(st) {
      var out = obj();
      Object.keys(st).forEach(function (k) { out[k] = st[k]; });
      if (isPyDict(get(st, "game"))) {
        var g = obj();
        Object.keys(st.game).forEach(function (k) { if (priv.indexOf(k) < 0) g[k] = st.game[k]; });
        out.game = g;
      }
      return out;
    }
    return !deepEqual(strip(oldState), strip(newState));
  }
  function strictScope(state, kind, payload) {
    if (modeFlag(state.mode, "STRICT_PAYLOADS")) return true;
    return kind === "room.set_mode" && modeFlag(get(payload, "mode"), "STRICT_PAYLOADS");
  }
  function schemaError(state, kind, action, payload) {
    if (!strictScope(state, kind, payload)) return null;
    if (get(action, "payloadWasNull") === true) return "invalid_payload";
    var schema;
    if (hasOwn.call(ROOM_PAYLOAD_SCHEMAS, kind)) schema = ROOM_PAYLOAD_SCHEMAS[kind];
    else {
      var spec = getMode(state.mode);
      if (spec === null || !kind.startsWith(spec.actionPrefix)) return null;
      var schemas = spec.module.PAYLOAD_SCHEMAS || {};
      if (!hasOwn.call(schemas, kind)) return null;
      schema = schemas[kind];
    }
    if (get(action, "unknownFields") === true) return "invalid_action";
    var keys = Object.keys(payload);
    for (var i = 0; i < keys.length; i++) {
      var expected = hasOwn.call(schema, keys[i]) ? schema[keys[i]] : null;
      if (expected === null) return "invalid_payload";
      var v = payload[keys[i]];
      if (expected === "bool" ? !isBool(v) : !isStr(v)) return "invalid_payload";
    }
    return null;
  }
  function syncScores(s) {
    var scores = s.game ? get(s.game, "scores", obj()) : obj();
    s.players.forEach(function (p) { if (has(scores, p.id)) p.score = scores[p.id]; });
  }
  function contentError(contents, mode) {
    var status = contents.has(mode) ? contents.get(mode) : null;
    if (status === null || status.status === "content_missing") return "content_missing";
    if (!status.ok()) return "content_invalid";
    return null;
  }
  // seed: decimal string (64-bit, JSON-safe) or 0
  function reduceRoom(state, actor, action, seq, contents, seed, now) {
    var role = get(actor, "role"), kind = action.type;
    var payload = get(action, "payload");
    if (!pyTruthy(payload)) payload = obj();
    var roundId = get(action, "roundId"), phase = state.phase, s, err, r;
    if (role === "display") return [state, "forbidden"];
    // Bluff's own accepted engine tests call reduceRoom directly and expect the
    // donor convention ("forbidden") for a spectator action; room_logic.py
    // rejects every mode's spectator writes with "forbidden" unconditionally,
    // so any mode implemented on both the Python and JS backends (currently
    // only escape_room) must also return "forbidden" here to keep parity.
    // Taboo's accepted privacy tests/harness remain the sole exception,
    // depending on "spectator_read_only" as its literal error code.
    if (role === "player" && isSpectator(state, get(actor, "playerId"))) {
      return [state, state.mode === "taboo" ? "spectator_read_only" : "forbidden"];
    }
    var isRoomAction = ROOM_ACTIONS.indexOf(kind) >= 0;
    var spec = isRoomAction ? null : modeForAction(kind);
    if (!isRoomAction && spec === null) return [state, "unknown_action"];
    if (isRoomAction && role !== "operator") return [state, "forbidden"];
    var schemaErr = schemaError(state, kind, action, payload);
    if (schemaErr) return [state, schemaErr];
    if (phase === "closed") return [state, "room_closed"];
    var game = state.game;
    if ((phase === "playing" || phase === "paused") && game !== null && !isNone(roundId) && roundId !== game.roundId) {
      return [state, "stale_round"];
    }
    if (kind === "room.set_mode") {
      var target = get(payload, "mode"), ts = getMode(target);
      if (ts === null) return [state, "unknown_mode"];
      if (!ts.implemented) return [state, "mode_unimplemented"];
      if (phase !== "lobby" && phase !== "ended") return [state, "invalid_phase"];
      s = deepcopy(state); s.mode = target; s.phase = "lobby"; s.game = null;
      promoteSpectators(s);
      return [s, null];
    }
    if (kind === "room.start") {
      if (phase !== "lobby" && phase !== "ended") return [state, "invalid_phase"];
      var ms = getMode(state.mode);
      if (ms === null) return [state, "mode_not_selected"];
      if (!ms.implemented) return [state, "mode_unimplemented"];
      err = contentError(contents, ms.id);
      if (err) return [state, err];
      // Pending spectators are promoted into the roster by this (valid) start;
      // a rejected start leaves them as spectators and the state untouched.
      s = deepcopy(state);
      promoteSpectators(s);
      var count = s.players.length;
      if (count < Math.max(state.limits.min, ms.module.MIN_PLAYERS)) return [state, "not_enough_players"];
      if (count > state.limits.max) return [state, "too_many_players"];
      s.gameNo += 1;
      var modeConfig = get(payload, "modeConfig");
      if (isNone(modeConfig)) modeConfig = obj();
      // Bluff (and any future mode following the same older convention)
      // reads its own config straight off the room.start payload itself
      // (config.options/config.room) rather than through Taboo's newer
      // modeConfig-nested convention (party/web/js/host.js sends
      // {rounds, language} at the payload's top level) -- both are threaded
      // through here so each mode's initialize() reads what it expects.
      r = ms.module.initialize({ seed: seed, gameNo: s.gameNo, now: now, modeConfig: modeConfig, options: payload, room: s.code }, deepcopy(s.players), contents.get(ms.id).pack);
      if (r[1]) return [state, r[1]];
      s.game = r[0]; s.phase = "playing";
      return [s, null];
    }
    if (kind === "room.pause") {
      if (phase !== "playing") return [state, "invalid_phase"];
      s = deepcopy(state); s.phase = "paused";
      var pauseMod = getMode(state.mode);
      if (pauseMod !== null && pauseMod.implemented && game !== null) {
        if (typeof pauseMod.module.onPause === "function") {
          s.game = pauseMod.module.onPause(s.game, now);
        } else if (pauseMod.module.HAS_TIMER) {
          r = pauseMod.module.reduce(game, actor, { type: "game.pause", payload: obj() }, seq, now);
          if (r[1]) return [state, r[1]];
          s.game = r[0];
        }
      }
      return [s, null];
    }
    if (kind === "room.resume") {
      if (phase !== "paused") return [state, "invalid_phase"];
      s = deepcopy(state); s.phase = "playing";
      var resumeMod = getMode(state.mode);
      if (resumeMod !== null && resumeMod.implemented && game !== null) {
        if (typeof resumeMod.module.onResume === "function") {
          s.game = resumeMod.module.onResume(s.game, now);
        } else if (resumeMod.module.HAS_TIMER) {
          r = resumeMod.module.reduce(game, actor, { type: "game.resume", payload: obj() }, seq, now);
          if (r[1]) return [state, r[1]];
          s.game = r[0];
        }
      }
      return [s, null];
    }
    var module;
    if (kind === "room.end") {
      if ((phase !== "playing" && phase !== "paused") || game === null) return [state, "invalid_phase"];
      module = getMode(state.mode).module;
      r = module.reduce(game, actor, { type: "game.end", payload: obj() }, seq, now);
      if (r[1]) return [state, r[1]];
      s = deepcopy(state); s.game = r[0]; s.phase = "ended"; syncScores(s);
      return [s, null];
    }
    if (kind === "room.reset") {
      var clear = get(payload, "clearScores", false);
      if (!isBool(clear)) return [state, "invalid_payload"];
      s = deepcopy(state); s.phase = "lobby"; s.game = null;
      if (clear) s.players.forEach(function (p) { p.score = 0; });
      promoteSpectators(s);
      return [s, null];
    }
    if (kind === "room.close") {
      s = deepcopy(state); s.phase = "closed"; s.game = null; return [s, null];
    }
    if (phase === "paused") return [state, "paused"];
    if (phase !== "playing" || game === null) return [state, "invalid_phase"];
    if (spec !== null && spec.id !== state.mode) return [state, "wrong_mode"];
    if (isNone(roundId)) return [state, "round_required"];
    module = getMode(state.mode).module;
    r = module.reduce(game, actor, action, seq, now);
    if (r[1]) return [state, r[1]];
    s = deepcopy(state); s.game = r[0]; syncScores(s);
    return [s, null];
  }
  // presence: Map playerId -> count
  function projectRoom(state, viewer, revision, presence, contents, now) {
    var role = viewer.role;
    var pid = role === "player" ? get(viewer, "playerId") : null;
    // See reduceRoom's matching comment: Bluff's accepted engine tests expect
    // projectRoom to translate the envelope role to "spectator" and project a
    // display-only game view for a spectating viewer, as does room_logic.py
    // for every generic LATE_SPECTATORS mode (currently EscapeRoom); Taboo's
    // accepted privacy tests expect the envelope role to stay "player" (its
    // own project() already self-detects a spectator for its internal view).
    var selfView = null, gameRole = role;
    if (!isNone(pid)) {
      state.players.forEach(function (p) { if (p.id === pid) selfView = { id: p.id, name: p.name }; });
      if (selfView === null) spectatorsOf(state).forEach(function (p) {
        if (p.id !== pid) return;
        if (state.mode === "taboo") {
          selfView = { id: p.id, name: p.name, spectator: true };
        } else if (state.mode === "bluff") {
          selfView = { id: p.id, name: p.name, spectator: true }; role = "spectator"; gameRole = "display"; pid = null;
        } else {
          selfView = { id: p.id, name: p.name }; role = "spectator"; gameRole = "display"; pid = null;
        }
      });
    }
    var snapRole = role;
    var players = state.players.map(function (p) {
      return { id: p.id, name: p.name, connected: (presence.get(p.id) || 0) > 0, score: p.score };
    });
    var gameView = null, roundId = null, game = state.game, spec = getMode(state.mode);
    if (game !== null && spec !== null && spec.implemented) {
      gameView = spec.module.project(game, { role: gameRole, playerId: pid }, now);
      roundId = game.roundId;
    }
    var snap = { protocol: 1, code: state.code, revision: revision, role: snapRole, self: selfView, mode: state.mode,
      phase: state.phase, roundId: roundId, players: players, game: gameView,
      operatorName: state.operatorName, playerLimits: { min: state.limits.min, max: state.limits.max } };
    var spectators = spectatorsOf(state);
    if (SPECTATOR_MODES.indexOf(state.mode) >= 0 || modeFlag(state.mode, "LATE_SPECTATORS") || spectators.length) {
      snap.spectators = spectators.map(function (p) {
        return { id: p.id, name: p.name, connected: (presence.get(p.id) || 0) > 0 };
      });
    }
    if (role === "operator") snap.modes = catalog(contents);
    return snap;
  }

  // -------------------------------------------------------------- entropy
  // Production feeds bytes from the OS CSPRNG. Derivations (match the oracle
  // harness's FakeSecrets): choice = alphabet[byte % len] (len 32 here, so
  // unbiased); token_urlsafe(32) = base64url(32 bytes) unpadded; token_hex(5)
  // = 5 bytes hex; randbits(64) = 8 bytes big-endian as a decimal string.
  function EntropyPool(bytes) { this.bytes = bytes; this.used = 0; }
  EntropyPool.fromHex = function (hex) {
    var b = new Uint8Array(hex.length / 2);
    for (var i = 0; i < b.length; i++) b[i] = parseInt(hex.substr(i * 2, 2), 16);
    return new EntropyPool(b);
  };
  EntropyPool.prototype.take = function (n) {
    if (this.used + n > this.bytes.length) throw new PartyError("internal_error"); // pool exhausted
    var out = this.bytes.subarray(this.used, this.used + n);
    this.used += n;
    return out;
  };
  var B64URL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
  function base64url(b) {
    var out = "", i;
    for (i = 0; i + 2 < b.length; i += 3) {
      var v = (b[i] << 16) | (b[i + 1] << 8) | b[i + 2];
      out += B64URL[v >> 18] + B64URL[(v >> 12) & 63] + B64URL[(v >> 6) & 63] + B64URL[v & 63];
    }
    if (b.length - i === 1) { out += B64URL[b[i] >> 2] + B64URL[(b[i] & 3) << 4]; }
    else if (b.length - i === 2) {
      var w = (b[i] << 8) | b[i + 1];
      out += B64URL[w >> 10] + B64URL[(w >> 4) & 63] + B64URL[(w & 15) << 2];
    }
    return out;
  }
  function hex(b) { var s = ""; for (var i = 0; i < b.length; i++) s += (b[i] < 16 ? "0" : "") + b[i].toString(16); return s; }
  var Secrets = {
    choice: function (pool, alphabet) { return alphabet[pool.take(1)[0] % alphabet.length]; },
    tokenUrlsafe: function (pool) { return base64url(pool.take(32)); },
    tokenHex: function (pool, n) { return hex(pool.take(n)); },
    randbits64: function (pool) { return BigInt("0x" + hex(pool.take(8))).toString(); }
  };

  // --------------------------------------------------------------- SHA-256
  var K256 = new Uint32Array([
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2]);
  function sha256Hex(bytes) {
    var len = bytes.length, total = ((len + 9 + 63) >> 6) << 6, m = new Uint8Array(total);
    m.set(bytes); m[len] = 0x80;
    var bits = len * 8;
    m[total - 4] = (bits >>> 24) & 255; m[total - 3] = (bits >>> 16) & 255; m[total - 2] = (bits >>> 8) & 255; m[total - 1] = bits & 255;
    m[total - 5] = Math.floor(bits / 4294967296) & 255;
    var H = new Uint32Array([0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19]);
    var W = new Uint32Array(64);
    for (var off = 0; off < total; off += 64) {
      for (var t = 0; t < 16; t++) W[t] = (m[off + 4 * t] << 24) | (m[off + 4 * t + 1] << 16) | (m[off + 4 * t + 2] << 8) | m[off + 4 * t + 3];
      for (t = 16; t < 64; t++) {
        var x = W[t - 15], y = W[t - 2];
        var s0 = ((x >>> 7) | (x << 25)) ^ ((x >>> 18) | (x << 14)) ^ (x >>> 3);
        var s1 = ((y >>> 17) | (y << 15)) ^ ((y >>> 19) | (y << 13)) ^ (y >>> 10);
        W[t] = (W[t - 16] + s0 + W[t - 7] + s1) >>> 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (t = 0; t < 64; t++) {
        var S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        var t1 = (h + S1 + ((e & f) ^ (~e & g)) + K256[t] + W[t]) >>> 0;
        var S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        var t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) >>> 0;
        h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
      }
      H[0] += a; H[1] += b; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
    }
    var out = "";
    for (var k = 0; k < 8; k++) out += ("00000000" + H[k].toString(16)).slice(-8);
    return out;
  }
  function hashToken(token) { // token is ASCII (TOKEN_RE) before this is called
    var b = new Uint8Array(token.length);
    for (var i = 0; i < token.length; i++) b[i] = token.charCodeAt(i);
    return sha256Hex(b);
  }

  // ------------------------------------------------------------ manager.py
  var CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789", CODE_LENGTH = 6;
  var CODE_RE = /^[A-Z2-9]{6}$/, ACTION_ID_RE = /^[A-Za-z0-9._:\-]{1,64}$/,
    ACTION_TYPE_RE = /^[a-z_]{1,24}(?:\.[a-z_]{1,32}){1,2}$/, ROUND_ID_RE = /^[A-Za-z0-9._:\-]{1,32}$/,
    TOKEN_RE = /^[A-Za-z0-9_\-]{32,128}$/;

  var CONFIG_DEFAULTS = {
    min_players: 3, max_players: 12, room_idle_ttl: 7200.0, room_max_age: 43200.0, token_ttl: 43200.0,
    closed_room_grace: 60.0, max_rooms: 64, action_retention: 128, heartbeat_interval: 15.0, sweep_interval: 30.0,
    sse_write_timeout: 10.0, request_timeout: 15.0, max_body_bytes: 16384, max_streams_per_principal: 4,
    max_streams_per_room: 64, max_streams_total: 256, max_connections: 320, request_rate: 30.0, request_burst: 120,
    create_per_minute: 10.0, create_burst: 10, join_per_minute: 60.0, join_burst: 30, action_rate: 10.0,
    action_burst: 30, access_log: false
  };
  // ServerConfig(**overrides). Throws Error("config: ...") where Python raises ValueError.
  function ServerConfig(overrides) {
    overrides = overrides || {};
    var unknown = Object.keys(overrides).filter(function (k) { return !hasOwn.call(CONFIG_DEFAULTS, k); }).sort();
    if (unknown.length) throw new Error("config: unknown config keys: " + unknown.join(", "));
    var self = this;
    Object.keys(CONFIG_DEFAULTS).forEach(function (k) { self[k] = hasOwn.call(overrides, k) ? overrides[k] : CONFIG_DEFAULTS[k]; });
    if (!(HARD_MIN <= this.min_players && this.min_players <= this.max_players && this.max_players <= HARD_MAX)) {
      throw new Error("config: player limits must satisfy 3 <= min <= max <= 12");
    }
    ["room_idle_ttl", "room_max_age", "token_ttl", "heartbeat_interval", "sweep_interval", "sse_write_timeout", "request_timeout"]
      .forEach(function (k) { if (!(self[k] > 0)) throw new Error("config: " + k + " must be positive"); });
    if (this.closed_room_grace < 0) throw new Error("config: closed_room_grace must not be negative");
    ["max_rooms", "action_retention", "max_body_bytes", "max_streams_per_principal", "max_streams_per_room",
      "max_streams_total", "max_connections", "request_burst", "create_burst", "join_burst", "action_burst"]
      .forEach(function (k) { if (Math.trunc(self[k]) < 1) throw new Error("config: " + k + " must be >= 1"); });
    ["request_rate", "create_per_minute", "join_per_minute", "action_rate"]
      .forEach(function (k) { if (!(self[k] > 0)) throw new Error("config: " + k + " must be positive"); });
  }

  function Principal(role, playerId, tokenHash, expiresAt) {
    this.role = role; this.playerId = playerId; this.tokenHash = tokenHash; this.expiresAt = expiresAt;
  }
  Principal.prototype.key = function () { return this.role === "player" ? "player:" + this.playerId : this.role; };
  Principal.prototype.actor = function () { return { role: this.role, playerId: this.playerId }; };

  function Room(code, state, now) {
    this.code = code; this.state = state; this.revision = 1; this.receiptSeq = 0;
    this.tokens = new Map(); this.actions = new Map(); this.streams = new Map(); this.presence = new Map();
    this.streamTotal = 0; this.createdAt = now; this.lastActivity = now; this.closedAt = null; this.expired = false;
  }
  Room.prototype.expiresAt = function (cfg) {
    var d = Math.min(this.createdAt + cfg.room_max_age, this.lastActivity + cfg.room_idle_ttl);
    if (this.closedAt !== null) d = Math.min(d, this.closedAt + cfg.closed_room_grace);
    return d;
  };

  function validateLimit(body, key, dflt) {
    var v = get(body, key, dflt);
    if (isNone(v)) return dflt;
    // A PyBigInt is an int to Python but always fails the 3..12 check that
    // follows, with the same invalid_config.
    if (isBool(v) || !isPyInt(v)) throw new PartyError("invalid_config");
    return v;
  }
  var ENVELOPE_KEYS = ["actionId", "type", "roundId", "payload"];
  function parseAction(body) {
    var kind = get(body, "type");
    if (!isStr(kind) || !ACTION_TYPE_RE.test(kind)) return [null, "invalid_action"];
    var roundId = get(body, "roundId");
    if (!isNone(roundId) && (!isStr(roundId) || !ROUND_ID_RE.test(roundId))) return [null, "invalid_action"];
    var payload = get(body, "payload", obj());
    var payloadWasNull = has(body, "payload") && isNone(payload);
    if (isNone(payload)) payload = obj();
    if (!isPyDict(payload)) return [null, "invalid_payload"];
    var unknownFields = Object.keys(body).some(function (k) { return ENVELOPE_KEYS.indexOf(k) < 0; });
    return [{ type: kind, roundId: roundId, payload: payload, unknownFields: unknownFields,
      payloadWasNull: payloadWasNull }, null];
  }

  // Single-threaded port: every call runs to completion on the engine queue,
  // which gives the total order Python gets from its locks. `now` is passed in
  // by the caller and read once per call, like the oracle's clock read under
  // the room lock. Methods that need randomness take an EntropyPool.
  function RoomManager(config, contents, options) {
    this.config = config; this.contents = contents;
    this.rooms = new Map(); this.streamTotal = 0; this.stopped = false;
    this.freeze = !!(options && options.freezeState);
    this.internalErrors = [];
  }
  RoomManager.prototype._commit = function (room, state) {
    room.state = this.freeze ? deepFreeze(state) : state;
  };
  RoomManager.prototype._expireIfDue = function (room, now) {
    if (room.expired || now >= room.expiresAt(this.config)) { room.expired = true; return true; }
    return false;
  };
  RoomManager.prototype._purgeExpired = function (now) {
    var removed = 0, self = this;
    Array.from(this.rooms.entries()).forEach(function (e) {
      if (self._expireIfDue(e[1], now)) { self.rooms.delete(e[0]); removed++; }
    });
    return removed;
  };
  // Advances a mode's autonomous clock (e.g. Taboo's turn-expiry tick) with
  // no incoming player/operator action, so SSE can push expiry state without
  // a request. No-op for modes that define no `tick` hook.
  RoomManager.prototype._tickRoom = function (room, now) {
    var state = room.state;
    if (state.phase !== "playing" || state.game === null) return;
    var spec = getMode(state.mode);
    if (spec === null || !spec.implemented || typeof spec.module.tick !== "function") return;
    var r = spec.module.tick(state.game, now);
    if (!r[1]) return;
    var s = deepcopy(state); s.game = r[0]; syncScores(s);
    this._commit(room, s);
    room.revision += 1;
  };
  RoomManager.prototype.sweep = function (now) {
    var self = this;
    this.rooms.forEach(function (room) { self._tickRoom(room, now); });
    return this._purgeExpired(now);
  };
  RoomManager.prototype.shutdown = function () { this.stopped = true; };
  RoomManager.prototype._checkLive = function (room, principal, now) {
    if (room.expired || now >= room.expiresAt(this.config)) { room.expired = true; throw new PartyError("room_not_found"); }
    if (principal && now >= principal.expiresAt) throw new PartyError("token_expired");
  };
  RoomManager.prototype.createRoom = function (body, now, pool) {
    var cfg = this.config;
    var operatorName = get(body, "operatorName");
    if (!isNone(operatorName)) {
      operatorName = cleanName(operatorName);
      if (operatorName === null) throw new PartyError("invalid_name");
    } else operatorName = null;
    var minP = validateLimit(body, "minPlayers", cfg.min_players);
    var maxP = validateLimit(body, "maxPlayers", cfg.max_players);
    if (!(HARD_MIN <= minP && minP <= maxP && maxP <= HARD_MAX)) throw new PartyError("invalid_config");
    this._purgeExpired(now);
    if (this.rooms.size >= cfg.max_rooms) throw new PartyError("too_many_rooms");
    var code;
    do {
      code = "";
      for (var i = 0; i < CODE_LENGTH; i++) code += Secrets.choice(pool, CODE_ALPHABET);
    } while (this.rooms.has(code));
    var room = new Room(code, null, now);
    this._commit(room, newRoomState(code, operatorName, minP, maxP));
    var hostToken = Secrets.tokenUrlsafe(pool), displayToken = Secrets.tokenUrlsafe(pool);
    room.tokens.set(hashToken(hostToken), new Principal("operator", null, hashToken(hostToken), now + cfg.token_ttl));
    room.tokens.set(hashToken(displayToken), new Principal("display", null, hashToken(displayToken), now + cfg.token_ttl));
    this.rooms.set(code, room);
    return { code: room.code, hostToken: hostToken, displayToken: displayToken, revision: room.revision };
  };
  RoomManager.prototype.getRoom = function (code, now) {
    if (!isStr(code)) throw new PartyError("room_not_found");
    code = upperForCode(code);
    if (code === null || !CODE_RE.test(code)) throw new PartyError("room_not_found");
    var room = this.rooms.get(code);
    if (!room) throw new PartyError("room_not_found");
    if (this._expireIfDue(room, now)) { this.rooms.delete(code); throw new PartyError("room_not_found"); }
    return room;
  };
  RoomManager.prototype.authenticate = function (room, token, now) {
    if (!isStr(token) || !TOKEN_RE.test(token)) throw new PartyError("unauthorized");
    var digest = hashToken(token);
    this._checkLive(room, null, now);
    var principal = room.tokens.get(digest);
    if (!principal) throw new PartyError("unauthorized");
    this._checkLive(room, principal, now);
    return principal;
  };
  // Returns [status, response].
  RoomManager.prototype.join = function (room, body, token, now, pool) {
    var cfg = this.config;
    if (!isNone(token)) {
      var principal = this.authenticate(room, token, now);
      if (principal.role !== "player") throw new PartyError("forbidden");
      this._checkLive(room, principal, now);
      var resumedBody = { playerId: principal.playerId, playerToken: token, revision: room.revision, resumed: true };
      if (isSpectator(room.state, principal.playerId)) resumedBody.spectator = true;
      return [200, resumedBody];
    }
    var name = cleanName(get(body, "name"));
    if (name === null) throw new PartyError("invalid_name");
    token = Secrets.tokenUrlsafe(pool);
    var digest = hashToken(token);
    this._checkLive(room, null, now);
    var existing = room.state.players.map(function (p) { return p.id; })
      .concat(spectatorsOf(room.state).map(function (p) { return p.id; }));
    var playerId = "p" + Secrets.tokenHex(pool, 5);
    while (existing.indexOf(playerId) >= 0) playerId = "p" + Secrets.tokenHex(pool, 5);
    var r = applyJoin(room.state, playerId, name);
    if (r[1]) throw new PartyError(r[1]);
    this._commit(room, r[0]);
    room.tokens.set(digest, new Principal("player", playerId, digest, now + cfg.token_ttl));
    room.revision += 1;
    room.lastActivity = now;
    var joinedBody = { playerId: playerId, playerToken: token, revision: room.revision };
    if (isSpectator(r[0], playerId)) joinedBody.spectator = true;
    return [201, joinedBody];
  };
  RoomManager.prototype.project = function (room, principal, now) { // no liveness side effects
    return projectRoom(room.state, { role: principal.role, playerId: principal.playerId }, room.revision, room.presence, this.contents, now);
  };
  RoomManager.prototype.snapshot = function (room, principal, now) {
    this._checkLive(room, principal, now);
    this._tickRoom(room, now);
    return this.project(room, principal, now);
  };
  // Returns [status, result, replayed].
  RoomManager.prototype.submitAction = function (room, principal, body, now, pool) {
    var actionId = get(body, "actionId");
    if (!isStr(actionId) || !ACTION_ID_RE.test(actionId)) throw new PartyError("invalid_action_id");
    var pa = parseAction(body), action = pa[0], err = pa[1];
    this._checkLive(room, principal, now);
    this._tickRoom(room, now);
    var key = principal.key();
    var log = room.actions.get(key);
    if (!log) { log = new Map(); room.actions.set(key, log); }
    if (log.has(actionId)) { var prev = log.get(actionId); return [prev[0], prev[1], true]; }
    room.receiptSeq += 1;
    var seq = room.receiptSeq, newState = null;
    if (err === null) {
      // Drawn before the guarded call, like the oracle: a start that fails
      // validation still consumes its 8 seed bytes.
      var seed = action.type === "room.start" ? Secrets.randbits64(pool) : 0;
      try {
        var r = reduceRoom(room.state, principal.actor(), action, seq, this.contents, seed, now);
        newState = r[0]; err = r[1];
      } catch (e) { // `except Exception` in the oracle; kept for diagnostics only
        this.internalErrors.push(String(e && e.stack || e));
        newState = null; err = "internal_error";
      }
    }
    var entry;
    if (err === null) {
      // manager.submit_action: always commit, bump/notify only on a public change.
      var isPublic = publicChange(room.state, newState);
      this._commit(room, newState);
      if (isPublic) room.revision += 1;
      room.lastActivity = now;
      if (newState.phase === "closed" && room.closedAt === null) room.closedAt = now;
      entry = [200, { accepted: true, revision: room.revision }];
    } else {
      entry = [statusFor(err), { accepted: false, revision: room.revision, error: errorBody(err) }];
    }
    log.set(actionId, entry);
    while (log.size > this.config.action_retention) log.delete(log.keys().next().value);
    return [entry[0], entry[1], false];
  };
  RoomManager.prototype.openStream = function (room, principal, now) {
    var cfg = this.config;
    if (this.streamTotal >= cfg.max_streams_total) throw new PartyError("too_many_streams");
    this.streamTotal += 1;
    try {
      this._checkLive(room, principal, now);
      var key = principal.key();
      if ((room.streams.get(key) || 0) >= cfg.max_streams_per_principal || room.streamTotal >= cfg.max_streams_per_room) {
        throw new PartyError("too_many_streams");
      }
      room.streams.set(key, (room.streams.get(key) || 0) + 1);
      room.streamTotal += 1;
      if (principal.role === "player") {
        var previous = room.presence.get(principal.playerId) || 0;
        room.presence.set(principal.playerId, previous + 1);
        if (previous === 0) room.revision += 1;
      }
    } catch (e) {
      this.streamTotal -= 1;
      throw e;
    }
  };
  RoomManager.prototype.closeStream = function (room, principal) {
    var key = principal.key();
    var count = (room.streams.get(key) || 0) - 1;
    if (count > 0) room.streams.set(key, count); else room.streams.delete(key);
    room.streamTotal = Math.max(0, room.streamTotal - 1);
    if (principal.role === "player") {
      var remaining = (room.presence.get(principal.playerId) || 0) - 1;
      if (remaining > 0) room.presence.set(principal.playerId, remaining);
      else {
        room.presence.delete(principal.playerId);
        if (!room.expired) room.revision += 1;
      }
    }
    this.streamTotal = Math.max(0, this.streamTotal - 1);
  };
  // One non-blocking step of next_stream_event: returns ["state", rev, snap],
  // ["heartbeat"], ["error", code], ["close"] or ["wait", seconds]. The caller
  // (transport) re-polls after `seconds` or on the next room change.
  RoomManager.prototype.nextStreamEvent = function (room, principal, lastRevision, heartbeatAt, now) {
    if (this.stopped) return ["close"];
    if (room.expired || now >= room.expiresAt(this.config)) { room.expired = true; return ["error", "room_expired"]; }
    if (now >= principal.expiresAt) return ["error", "token_expired"];
    this._tickRoom(room, now);
    if (room.revision !== lastRevision) return ["state", room.revision, this.project(room, principal, now)];
    if (now >= heartbeatAt) return ["heartbeat"];
    var deadline = Math.min(heartbeatAt, principal.expiresAt, room.expiresAt(this.config));
    var state = room.state;
    if (state.phase === "playing" && state.game !== null) {
      var spec = getMode(state.mode);
      if (spec !== null && spec.implemented && typeof spec.module.nextDeadline === "function") {
        var modeDeadline = spec.module.nextDeadline(state.game);
        if (!isNone(modeDeadline)) deadline = Math.min(deadline, modeDeadline);
      }
    }
    return ["wait", Math.max(0.01, Math.min(deadline - now, 5.0))];
  };

  // httpd._serve_events loop state, minus socket writes: open -> poll* -> end.
  function EventSession(manager, room, principal, now) {
    manager.openStream(room, principal, now);
    this.manager = manager; this.room = room; this.principal = principal;
    this.lastRevision = null; this.heartbeatAt = now + manager.config.heartbeat_interval; this.open = true;
  }
  EventSession.prototype.poll = function (now) {
    if (!this.open) throw new Error("session closed");
    var ev = this.manager.nextStreamEvent(this.room, this.principal, this.lastRevision, this.heartbeatAt, now);
    if (ev[0] === "wait") return ev;
    if (ev[0] === "close" || ev[0] === "error") { this.end(); return ev; }
    if (ev[0] === "state") this.lastRevision = ev[1];
    this.heartbeatAt = now + this.manager.config.heartbeat_interval;
    return ev;
  };
  EventSession.prototype.end = function () {
    if (this.open) { this.open = false; this.manager.closeStream(this.room, this.principal); }
  };

  return {
    version: "l01a-1",
    unicode: { nfc: nfc, nfkc: nfkc, nfd: nfd, nfkd: nfkd, casefold: casefold, pySplit: pySplit, pyStrip: pyStrip,
      pyLen: pyLen, cleanText: cleanText, cleanName: cleanName, matchKey: matchKey, upperForCode: upperForCode,
      decodeUtf8: decodeUtf8, unidata: T.unidata },
    json: { parse: parseJson, parseRequestBody: parseRequestBody, JsonError: JsonError, PyFloat: PyFloat, PyBigInt: PyBigInt, isDict: isPyDict },
    errors: { ERRORS: ERRORS, PartyError: PartyError, statusFor: statusFor, errorBody: errorBody },
    content: { loadMode: loadMode, loadAll: loadAll, parsePack: parsePack, isText: isText, isInt: isInt },
    modes: { REGISTRY: REGISTRY, getMode: getMode, catalog: catalog, WhoAmI: WhoAmI, Feud: Feud, Impostor: Impostor, Taboo: Taboo, Bluff: Bluff, EscapeRoom: EscapeRoom },
    room: { newRoomState: newRoomState, applyJoin: applyJoin, reduceRoom: reduceRoom, projectRoom: projectRoom,
      publicChange: publicChange, isSpectator: isSpectator },
    random: { shuffleInPlace: shuffleInPlace },
    crypto: { sha256Hex: sha256Hex, hashToken: hashToken, base64url: base64url },
    EntropyPool: EntropyPool, Secrets: Secrets, ServerConfig: ServerConfig, RoomManager: RoomManager,
    EventSession: EventSession, deepcopy: deepcopy, deepFreeze: deepFreeze
  };
})(typeof MajlisUnicode13Tables !== "undefined" ? MajlisUnicode13Tables : null);
