// Bluff engine unit tests (test tool, not shipped). Plain classic script
// evaluated in the same JSContext as majlis-core.js; leaves __TEST_RESULT__
// behind for the Swift runner to read. White-box: reaches into module state
// directly where that is the simplest way to assert an internal invariant
// (e.g. which optionId belongs to a given player's fake), in addition to
// exercising the public project() view for leak checks.

(function () {
  "use strict";
  var Bluff = MajlisCore.modes.Bluff;
  var passed = 0, failed = 0, failures = [];

  function ok(label, cond) {
    if (cond) { passed++; } else { failed++; failures.push(label); }
  }
  function eq(label, a, b) { ok(label + " (got " + JSON.stringify(a) + ", want " + JSON.stringify(b) + ")", JSON.stringify(a) === JSON.stringify(b)); }

  function players(ids) { return ids.map(function (id) { return { id: id, score: 0 }; }); }
  function item(id, qEn, qAr, trueEn, trueAr, aliasesEn, aliasesAr) {
    return { id: id, question: { en: qEn, ar: qAr }, trueAnswer: { en: trueEn, ar: trueAr },
      aliases: { en: aliasesEn || [], ar: aliasesAr || [] } };
  }
  function pack(items) { return { title: "Bluff", items: items }; }
  function act(type, roundId, payload) { return { type: type, roundId: roundId, payload: payload || {} }; }
  function operator() { return { role: "operator" }; }
  function player(pid) { return { role: "player", playerId: pid }; }

  var ITEMS = [
    item("b001", "What is the capital of France?", "ما هي عاصمة فرنسا؟", "Paris", "باريس", ["paris"], ["باريس"]),
    item("b002", "What gas do plants absorb for photosynthesis?", "ما الغاز الذي تمتصه النباتات؟", "Carbon dioxide", "ثاني أكسيد الكربون", ["co2"], []),
    item("b003", "How many legs does a spider have?", "كم عدد أرجل العنكبوت؟", "Eight", "ثمانية", ["8"], []),
    item("b004", "What is the largest planet in the solar system?", "ما هو أكبر كوكب في المجموعة الشمسية؟", "Jupiter", "المشتري", [], []),
    item("b005", "What is the chemical symbol for gold?", "ما هو الرمز الكيميائي للذهب؟", "Au", "الذهب", [], []),
    item("b006", "Who wrote Romeo and Juliet?", "من كتب روميو وجوليت؟", "Shakespeare", "شكسبير", [], []),
    item("b007", "What is the freezing point of water in Celsius?", "ما هي درجة تجمد الماء بالسلسيوس؟", "Zero", "صفر", ["0"], []),
    item("b008", "What is the tallest mountain on Earth?", "ما هو أعلى جبل على الأرض؟", "Everest", "إيفرست", [], []),
    item("b009", "What currency is used in Japan?", "ما هي عملة اليابان؟", "Yen", "ين", [], []),
    item("b010", "What is the main language spoken in Brazil?", "ما هي اللغة الرئيسية في البرازيل؟", "Portuguese", "البرتغالية", [], []),
    item("b011", "What organ pumps blood through the body?", "ما هو العضو الذي يضخ الدم؟", "Heart", "القلب", [], []),
    item("b012", "What planet is known as the Red Planet?", "ما هو الكوكب المعروف بالكوكب الأحمر؟", "Mars", "المريخ", [], [])
  ];

  // ---------------------------------------------------------- content validation
  (function testValidateItem() {
    var issues = [];
    var clean = Bluff.validateItem(ITEMS[0], "items[0]", issues);
    eq("validateItem accepts a well-formed item with no issues", issues.length, 0);
    ok("validateItem returns the cleaned fields", clean !== null && clean.id === "b001" && clean.trueAnswer.en === "Paris");

    issues = [];
    var missingId = { question: { en: "Q", ar: "س" }, trueAnswer: { en: "A", ar: "ج" } };
    Bluff.validateItem(missingId, "items[0]", issues);
    ok("validateItem rejects a missing id", issues.some(function (m) { return m.indexOf(".id:") >= 0; }));

    issues = [];
    var missingArAnswer = { id: "x", question: { en: "Q", ar: "س" }, trueAnswer: { en: "A" } };
    Bluff.validateItem(missingArAnswer, "items[0]", issues);
    ok("validateItem rejects a trueAnswer missing the ar field", issues.some(function (m) { return m.indexOf(".trueAnswer:") >= 0; }));

    issues = [];
    var tooManyAliases = { id: "x", question: { en: "Q", ar: "س" }, trueAnswer: { en: "A", ar: "ج" },
      aliases: { en: ["a1", "a2", "a3", "a4", "a5", "a6", "a7", "a8", "a9"] } };
    Bluff.validateItem(tooManyAliases, "items[0]", issues);
    ok("validateItem rejects more than 8 aliases for one language", issues.some(function (m) { return m.indexOf(".aliases.en:") >= 0; }));
  })();

  (function testValidateItems() {
    var cleaned = ITEMS.map(function (it, i) { return Bluff.validateItem(it, "items[" + i + "]", []); });
    var issues = [];
    Bluff.validateItems(cleaned, issues);
    eq("validateItems finds no duplicates in the authored pack", issues.length, 0);

    var dupId = cleaned.slice(0, 2).concat([Object.assign({}, cleaned[0])]);
    issues = [];
    Bluff.validateItems(dupId, issues);
    ok("validateItems catches a duplicate id", issues.some(function (m) { return m.indexOf(".id:") >= 0; }));

    var dupQuestion = cleaned.slice(0, 2).concat([Object.assign({}, cleaned[0], { id: "different-id" })]);
    issues = [];
    Bluff.validateItems(dupQuestion, issues);
    ok("validateItems catches a duplicate normalized question text under a different id", issues.some(function (m) { return m.indexOf(".question.en:") >= 0; }));
  })();

  // -------------------------------------------------------- initialize() shape
  (function testInitializeBounds() {
    var tooFew = Bluff.initialize({ seed: "1", gameNo: 1, options: {} }, players(["a", "b"]), pack(ITEMS));
    eq("initialize rejects fewer than 3 players", tooFew[1], "not_enough_players");

    var tooMany = Bluff.initialize({ seed: "1", gameNo: 1, options: {} }, players(
      ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m"]), pack(ITEMS));
    eq("initialize rejects more than 12 players", tooMany[1], "too_many_players");

    var badRounds = Bluff.initialize({ seed: "1", gameNo: 1, options: { rounds: 11 } }, players(["a", "b", "c"]), pack(ITEMS));
    eq("initialize rejects a rounds option above the 10-round cap", badRounds[1], "invalid_config");

    var zeroRounds = Bluff.initialize({ seed: "1", gameNo: 1, options: { rounds: 0 } }, players(["a", "b", "c"]), pack(ITEMS));
    eq("initialize rejects a rounds option below 1", zeroRounds[1], "invalid_config");

    var exceedsPack = Bluff.initialize({ seed: "1", gameNo: 1, options: { rounds: 3 } }, players(["a", "b", "c"]), pack(ITEMS.slice(0, 2)));
    eq("initialize rejects a rounds option exceeding the pack size", exceedsPack[1], "content_insufficient");

    var configured = Bluff.initialize({ seed: "999", gameNo: 1, options: { rounds: 5 } }, players(["a", "b", "c"]), pack(ITEMS));
    eq("initialize honors a configured rounds option", configured[0].rounds, 5);
    eq("initialize starts at round 1 in the submission phase", [configured[0].roundNo, configured[0].phase], [1, "submission"]);

    var defaulted = Bluff.initialize({ seed: "999", gameNo: 1, options: {} }, players(["a", "b", "c"]), pack(ITEMS));
    eq("initialize defaults to 3 rounds when none is configured", defaulted[0].rounds, 3);
  })();

  // ------------------------------------------------------ full 3-player game
  (function testThreePlayerGame() {
    var order = ["p1", "p2", "p3"];
    var r = Bluff.initialize({ seed: "20260101", gameNo: 1, options: { rounds: 2 } }, players(order), pack(ITEMS));
    ok("3-player initialize succeeds", r[1] === null);
    var s0 = r[0];
    var roundId = s0.roundId;
    var trueEn = s0.item.trueAnswer.en;

    // Reject a fake equal to the true answer or one of its aliases, with no truth hint leaked in the error.
    var rejTrue = Bluff.reduce(s0, player("p1"), act("bluff.submit_answer", roundId, { text: trueEn }), 1);
    eq("submit_answer rejects a fake equal to the true answer", rejTrue[1], "invalid_answer");
    ok("rejected submission does not mutate state (same reference)", rejTrue[0] === s0);

    var aliasText = s0.item.id === "b001" ? "paris" : null;
    if (aliasText) {
      var rejAlias = Bluff.reduce(s0, player("p1"), act("bluff.submit_answer", roundId, { text: "PARIS" }), 1);
      eq("submit_answer rejects a case-insensitive alias match", rejAlias[1], "invalid_answer");
    }

    var s1 = Bluff.reduce(s0, player("p1"), act("bluff.submit_answer", roundId, { text: "Lyon" }), 2)[0];
    ok("p1's valid fake is recorded", s1.fakes.p1 === "Lyon");

    // Idempotent resubmission of the identical (normalized) text is a no-op success.
    var sameAgain = Bluff.reduce(s1, player("p1"), act("bluff.submit_answer", roundId, { text: "  Lyon  " }), 3);
    eq("resubmitting the same normalized fake is a no-op success", sameAgain[1], null);
    eq("resubmitting the same normalized fake does not change the stored text", sameAgain[0].fakes.p1, "Lyon");

    // Conflicting resubmission (a different fake) fails without mutation.
    var conflict = Bluff.reduce(s1, player("p1"), act("bluff.submit_answer", roundId, { text: "Marseille" }), 4);
    eq("resubmitting a different fake after already submitting fails", conflict[1], "already_submitted");
    ok("conflicting resubmission does not mutate state", conflict[0] === s1);

    // Collision with another player's accepted fake is rejected privately, same neutral code.
    var s2 = Bluff.reduce(s1, player("p2"), act("bluff.submit_answer", roundId, { text: "lyon" }), 5);
    eq("a fake colliding (case/whitespace-insensitive) with another player's fake is rejected", s2[1], "invalid_answer");
    ok("the colliding attempt is not recorded", !has_(s2[0].fakes, "p2"));

    var s3 = Bluff.reduce(s1, player("p2"), act("bluff.submit_answer", roundId, { text: "Berlin" }), 6)[0];
    ok("p2's distinct valid fake is recorded", s3.fakes.p2 === "Berlin");

    // Oversize / non-string / unknown-field payloads are rejected without mutation.
    var oversize = Bluff.reduce(s3, player("p3"), act("bluff.submit_answer", roundId, { text: "x".repeat(300) }), 7);
    eq("an oversize fake answer is rejected", oversize[1], "invalid_payload");
    var nonString = Bluff.reduce(s3, player("p3"), act("bluff.submit_answer", roundId, { text: 12345 }), 8);
    eq("a non-string fake answer payload is rejected", nonString[1], "invalid_payload");
    var unknownField = Bluff.reduce(s3, player("p3"), act("bluff.submit_answer", roundId, { text: "Rome", extra: true }), 9);
    eq("an unknown payload field is rejected", unknownField[1], "invalid_payload");

    // Operator-only / player-only role checks.
    var wrongRole1 = Bluff.reduce(s3, operator(), act("bluff.submit_answer", roundId, { text: "Rome" }), 10);
    eq("an operator cannot submit an answer", wrongRole1[1], "forbidden");
    var wrongRole2 = Bluff.reduce(s3, player("p1"), act("bluff.open_vote", roundId, {}), 11);
    eq("a player cannot open the vote", wrongRole2[1], "forbidden");

    // Opening the vote before every eligible player has submitted fails without force.
    var earlyOpen = Bluff.reduce(s3, operator(), act("bluff.open_vote", roundId, {}), 12);
    eq("open_vote fails while a player has not yet submitted and force is not set", earlyOpen[1], "invalid_phase");

    // Replaying a stale roundId is rejected.
    var staleAction = Bluff.reduce(s3, player("p3"), act("bluff.submit_answer", "stale-round-id", { text: "Rome" }), 13);
    eq("an action carrying a stale roundId is rejected", staleAction[1], "stale_round");

    // Unknown action type.
    var unknownAction = Bluff.reduce(s3, player("p3"), act("bluff.not_a_real_action", roundId, {}), 14);
    eq("an unknown action type is rejected", unknownAction[1], "unknown_action");

    // Force-close the submission phase: p3 never submitted, becomes explicitly excluded (no fabricated fake).
    var s4 = Bluff.reduce(s3, operator(), act("bluff.open_vote", roundId, { force: true }), 15)[0];
    eq("force-closing submission moves the game into voting", s4.phase, "voting");
    ok("the missing player is recorded as explicitly excluded, not fabricated", s4.excluded.p3 === true && !has_(s4.fakes, "p3"));
    eq("exactly 3 options are built (2 fakes + 1 true answer)", s4.options.length, 3);

    var trueOpt = s4.options.filter(function (o) { return o.authorId === null; })[0];
    var p1Opt = s4.options.filter(function (o) { return o.authorId === "p1"; })[0];
    var p2Opt = s4.options.filter(function (o) { return o.authorId === "p2"; })[0];
    ok("the true option carries the unmodified true-answer text", trueOpt.text === trueEn);
    ok("p1's option carries p1's fake text", p1Opt.text === "Lyon");
    ok("p2's option carries p2's fake text", p2Opt.text === "Berlin");
    eq("all options share the identical {optionId, text} shape before any authorId is read", Object.keys(s4.options[0]).sort(), ["authorId", "optionId", "text"]);

    // Public projection during voting: identical shape for true/fake options, no authorship leaked.
    var votingViewPlayer = Bluff.project(s4, { role: "player", playerId: "p1" });
    ok("voting-phase player view exposes options without an authorId field", votingViewPlayer.options.every(function (o) { return !("authorId" in o); }));
    ok("voting-phase player view exposes options without any correctness marker", votingViewPlayer.options.every(function (o) { return Object.keys(o).sort().join(",") === "optionId,text"; }));
    var shapes = votingViewPlayer.options.map(function (o) { return Object.keys(o).sort().join(","); });
    ok("the true option's serialized shape is indistinguishable from fake options'", shapes.every(function (sh) { return sh === shapes[0]; }));
    var votingViewDisplay = Bluff.project(s4, { role: "display" });
    ok("display gets the same anonymous option shape as a player", JSON.stringify(votingViewDisplay.options) === JSON.stringify(votingViewPlayer.options));
    ok("player's own-fake pointer (self-private) correctly identifies their own option", votingViewPlayer.you.ownOptionId === p1Opt.optionId);
    var votingViewP3 = Bluff.project(s4, { role: "player", playerId: "p3" });
    ok("the excluded player's self view shows submitted=true with no fake text and no own option", votingViewP3.you.submitted === true && votingViewP3.you.text === null && votingViewP3.you.ownOptionId === null);

    // Self-vote, forged/unknown option, foreign-role rejections.
    var selfVote = Bluff.reduce(s4, player("p1"), act("bluff.vote", roundId, { optionId: p1Opt.optionId }), 16);
    eq("a player cannot vote for their own fake", selfVote[1], "self_vote");
    var foreignOption = Bluff.reduce(s4, player("p1"), act("bluff.vote", roundId, { optionId: "forged-option-id" }), 17);
    eq("voting for an unknown/forged option id is rejected", foreignOption[1], "unknown_option");
    var forgedRole = Bluff.reduce(s4, { role: "player", playerId: "ghost" }, act("bluff.vote", roundId, { optionId: trueOpt.optionId }), 18);
    eq("a playerId not in the room's order cannot vote", forgedRole[1], "forbidden");

    // p1 votes true, p2 votes for p1's fake (fooled).
    var s5 = Bluff.reduce(s4, player("p1"), act("bluff.vote", roundId, { optionId: trueOpt.optionId }), 19)[0];
    var sameVoteAgain = Bluff.reduce(s5, player("p1"), act("bluff.vote", roundId, { optionId: trueOpt.optionId }), 20);
    eq("revoting for the identical option is a no-op success", sameVoteAgain[1], null);
    var changeVote = Bluff.reduce(s5, player("p1"), act("bluff.vote", roundId, { optionId: p2Opt.optionId }), 21);
    eq("revoting for a different option after already voting is rejected", changeVote[1], "already_voted");
    var s6 = Bluff.reduce(s5, player("p2"), act("bluff.vote", roundId, { optionId: p1Opt.optionId }), 22)[0];

    // Reveal before all eligible voters have voted (p3 excluded, never votes) fails without force.
    var earlyReveal = Bluff.reduce(s6, operator(), act("bluff.reveal", roundId, {}), 23);
    eq("reveal fails while an eligible voter has not voted and force is not set", earlyReveal[1], "invalid_phase");

    var s7 = Bluff.reduce(s6, operator(), act("bluff.reveal", roundId, { force: true }), 24)[0];
    eq("force-reveal moves the game into the reveal phase", s7.phase, "reveal");

    // Exact scoring: p1 voted true (+100), p1's fake fooled p2 (+100 to p1); p2 voted wrong (0); p3 abstained (0).
    eq("p1's exact total score after reveal (correct vote + fooled p2)", s7.scores.p1, 200);
    eq("p2's exact total score after reveal (wrong vote)", s7.scores.p2, 0);
    eq("p3's exact total score after reveal (abstained)", s7.scores.p3, 0);
    eq("reveal records p3 as abstained", s7.lastResult.abstained, ["p3"]);
    eq("reveal's true-option id matches the actual true option", s7.lastResult.trueOptionId, trueOpt.optionId);

    // Reveal is exactly-once: replaying it (still phase===voting via a hand-rolled state) does not double-award.
    var replayState = Object.assign({}, s6, { awardedRounds: s7.awardedRounds.slice() });
    var replay = Bluff.reduce(replayState, operator(), act("bluff.reveal", roundId, { force: true }), 25);
    eq("replaying reveal against a round already present in awardedRounds refuses to re-award", replay[1], "already_awarded");

    // Reveal cannot be replayed once the phase has actually advanced past voting.
    var postRevealReplay = Bluff.reduce(s7, operator(), act("bluff.reveal", roundId, { force: true }), 26);
    eq("reveal cannot be invoked again once the phase left voting", postRevealReplay[1], "invalid_phase");

    // Post-reveal projection: full authorship now public to every role.
    var revealView = Bluff.project(s7, { role: "display" });
    ok("post-reveal view exposes authorId on every option", revealView.options.every(function (o) { return "authorId" in o; }));
    ok("post-reveal view's true option has a null authorId", revealView.options.filter(function (o) { return o.optionId === trueOpt.optionId; })[0].authorId === null);

    // round.next advances cleanly; prior round's lastResult persists, current-round working state resets.
    var s8 = Bluff.reduce(s7, operator(), act("round.next", roundId, {}), 27)[0];
    eq("round.next advances to round 2", s8.roundNo, 2);
    eq("round.next resets the phase to submission", s8.phase, "submission");
    ok("round.next clears this round's fakes/votes/options", Object.keys(s8.fakes).length === 0 && Object.keys(s8.votes).length === 0 && s8.options === null);
    ok("round.next preserves the previous round's lastResult for history", s8.lastResult !== null && s8.lastResult.roundNo === 1);
    ok("round-1's roundId is now stale for round 2", s8.roundId !== roundId);
    var staleReplay = Bluff.reduce(s8, player("p1"), act("bluff.submit_answer", roundId, { text: "anything" }), 28);
    eq("round 1's roundId is rejected as stale once round 2 has started", staleReplay[1], "stale_round");

    // round 2: no more rounds configured after this one (rounds:2) -> round.next finishes the game.
    var s9 = Bluff.reduce(s8, operator(), act("bluff.open_vote", s8.roundId, { force: true }), 29)[0];
    var s10 = Bluff.reduce(s9, operator(), act("bluff.reveal", s8.roundId, { force: true }), 30)[0];
    var s11 = Bluff.reduce(s10, operator(), act("round.next", s8.roundId, {}), 31)[0];
    eq("round.next finishes the game once the configured round count is exhausted", s11.phase, "finished");

    // game.end from any point is operator-only and idempotent-guarded against a double end.
    var endForbidden = Bluff.reduce(s11, player("p1"), act("game.end", s8.roundId, {}), 32);
    eq("a player cannot end the game", endForbidden[1], "forbidden");
    var ended = Bluff.reduce(s11, operator(), act("game.end", s8.roundId, {}), 33)[0];
    ok("game.end sets ended=true", ended.ended === true);
    var endAgain = Bluff.reduce(ended, operator(), act("game.end", s8.roundId, {}), 34);
    eq("ending an already-ended game is rejected", endAgain[1], "invalid_phase");
    var actAfterEnd = Bluff.reduce(ended, player("p1"), act("bluff.submit_answer", s8.roundId, { text: "x" }), 35);
    eq("no action is accepted once the game has ended", actAfterEnd[1], "invalid_phase");
  })();

  // ------------------------------------------------------ pre-reveal leak scan
  (function testPreRevealLeakScan() {
    var order = ["p1", "p2", "p3", "p4"];
    var r = Bluff.initialize({ seed: "501", gameNo: 7, options: { rounds: 1 } }, players(order), pack(ITEMS));
    var s = r[0];
    var roundId = s.roundId;
    var secretTrue = "UNIQUE-TRUE-" + s.item.trueAnswer.en;
    s = Object.assign({}, s, { item: Object.assign({}, s.item, { trueAnswer: { en: secretTrue, ar: secretTrue } }) });
    var secretFakes = { p1: "UNIQUE-FAKE-ALPHA", p2: "UNIQUE-FAKE-BRAVO", p3: "UNIQUE-FAKE-CHARLIE" };
    Object.keys(secretFakes).forEach(function (p) {
      s = Bluff.reduce(s, player(p), act("bluff.submit_answer", roundId, { text: secretFakes[p] }), 1)[0];
    });

    function serialize(viewer) { return JSON.stringify(Bluff.project(s, viewer)); }
    var allSecrets = [secretTrue].concat(Object.keys(secretFakes).map(function (k) { return secretFakes[k]; }));
    var viewers = [
      { role: "player", playerId: "p1" }, { role: "player", playerId: "p2" },
      { role: "player", playerId: "p4" }, { role: "display" }
    ];
    viewers.forEach(function (viewer) {
      var json = serialize(viewer);
      // Submission phase: the true answer must never leak, and nobody but the submitter sees another player's fake.
      ok("submission-phase leak scan: " + JSON.stringify(viewer) + " never sees the true answer", json.indexOf(secretTrue) === -1);
      Object.keys(secretFakes).forEach(function (p) {
        var visible = json.indexOf(secretFakes[p]) !== -1;
        var isSelf = viewer.role === "player" && viewer.playerId === p;
        ok("submission-phase leak scan: " + JSON.stringify(viewer) + (isSelf ? " sees own fake " : " never sees ") + p + "'s fake", visible === isSelf);
      });
    });

    // Negative control: deliberately broken projection that forwards the private fakes map must be CAUGHT by this scan.
    var brokenView = Object.assign({}, Bluff.project(s, { role: "display" }), { fakes: Object.assign({}, s.fakes) });
    var brokenJson = JSON.stringify(brokenView);
    ok("negative control: a projection that leaks the private fakes map IS caught by the string scan", brokenJson.indexOf(secretFakes.p1) !== -1);

    // Open voting and re-scan: true text appears as exactly one indistinguishable anonymous option, never with authorship.
    var voting = Bluff.reduce(s, operator(), act("bluff.open_vote", roundId, { force: true }), 2)[0];
    viewers.forEach(function (viewer) {
      var view = Bluff.project(voting, viewer);
      var json = JSON.stringify(view);
      var matchingOptions = view.options.filter(function (o) { return o.text === secretTrue; });
      ok("voting-phase leak scan: " + JSON.stringify(viewer) + " sees the true text in exactly one option, as an anonymous option", matchingOptions.length === 1 && json.indexOf("\"authorId\"") === -1);
      var trueOptionMatch = view.options.filter(function (o) { return o.text === secretTrue; })[0];
      ok("voting-phase leak scan: the true option carries no correctness/authorship marker", trueOptionMatch !== undefined && Object.keys(trueOptionMatch).sort().join(",") === "optionId,text");
    });

    // Negative control: a view that forwards authorId during voting IS caught.
    var brokenVotingView = { options: voting.options };
    ok("negative control: a voting view exposing authorId IS caught by the authorship scan", JSON.stringify(brokenVotingView).indexOf("\"authorId\"") !== -1);

    // Post-reveal: now authorship is intentionally public to everyone.
    var revealedState = Bluff.reduce(voting, operator(), act("bluff.reveal", roundId, { force: true }), 3)[0];
    viewers.forEach(function (viewer) {
      var json = JSON.stringify(Bluff.project(revealedState, viewer));
      ok("post-reveal: " + JSON.stringify(viewer) + " can see the true answer and every fake's authorship", json.indexOf(secretTrue) !== -1 && json.indexOf("\"authorId\":\"p1\"") !== -1);
    });
  })();

  // -------------------------------------------------- deterministic shuffle
  (function testDeterminism() {
    var order = ["p1", "p2", "p3", "p4"];
    function runToVoting(seed, gameNo) {
      var r = Bluff.initialize({ seed: seed, gameNo: gameNo, options: { rounds: 1 } }, players(order), pack(ITEMS));
      var s = r[0], roundId = s.roundId;
      s = Bluff.reduce(s, player("p1"), act("bluff.submit_answer", roundId, { text: "Fake One" }), 1)[0];
      s = Bluff.reduce(s, player("p2"), act("bluff.submit_answer", roundId, { text: "Fake Two" }), 2)[0];
      s = Bluff.reduce(s, operator(), act("bluff.open_vote", roundId, { force: true }), 3)[0];
      return s;
    }
    var a1 = runToVoting("777", 1), a2 = runToVoting("777", 1);
    eq("identical seed/round reproduces the identical option order", a1.options.map(function (o) { return o.text; }), a2.options.map(function (o) { return o.text; }));

    var b = runToVoting("777", 1), rounds2 = [];
    var r2 = Bluff.initialize({ seed: "777", gameNo: 1, options: { rounds: 2 } }, players(order), pack(ITEMS));
    var s2 = r2[0], rid1 = s2.roundId;
    s2 = Bluff.reduce(s2, player("p1"), act("bluff.submit_answer", rid1, { text: "Fake One" }), 1)[0];
    s2 = Bluff.reduce(s2, player("p2"), act("bluff.submit_answer", rid1, { text: "Fake Two" }), 2)[0];
    s2 = Bluff.reduce(s2, operator(), act("bluff.open_vote", rid1, { force: true }), 3)[0];
    var round1TruePos = s2.options.map(function (o) { return o.authorId; }).indexOf(null);
    s2 = Bluff.reduce(s2, operator(), act("bluff.reveal", rid1, { force: true }), 4)[0];
    s2 = Bluff.reduce(s2, operator(), act("round.next", rid1, {}), 5)[0];
    var rid2 = s2.roundId;
    s2 = Bluff.reduce(s2, player("p1"), act("bluff.submit_answer", rid2, { text: "Fake One" }), 6)[0];
    s2 = Bluff.reduce(s2, player("p2"), act("bluff.submit_answer", rid2, { text: "Fake Two" }), 7)[0];
    s2 = Bluff.reduce(s2, operator(), act("bluff.open_vote", rid2, { force: true }), 8)[0];
    var round2TruePos = s2.options.map(function (o) { return o.authorId; }).indexOf(null);
    ok("the true-answer position varies across rounds within the same game (not a fixed slot)", round1TruePos !== round2TruePos || s2.options.length < 2);

    var c1 = runToVoting("777", 1), c2 = runToVoting("888", 1);
    ok("a different seed produces a different option order (overwhelmingly likely for a real shuffle)",
      JSON.stringify(c1.options.map(function (o) { return o.text; })) !== JSON.stringify(c2.options.map(function (o) { return o.text; })));
  })();

  // ------------------------------------------------------- 4 and 12 player games
  function fullGame(label, order, seed) {
    var r = Bluff.initialize({ seed: seed, gameNo: 1, options: { rounds: 1 } }, players(order), pack(ITEMS));
    ok(label + ": initialize succeeds", r[1] === null);
    var s = r[0], roundId = s.roundId;
    order.forEach(function (pid, i) {
      s = Bluff.reduce(s, player(pid), act("bluff.submit_answer", roundId, { text: "Fake-" + pid + "-" + i }), i + 1)[0];
    });
    eq(label + ": every player's fake is recorded", Object.keys(s.fakes).length, order.length);
    s = Bluff.reduce(s, operator(), act("bluff.open_vote", roundId, {}), 100)[0];
    eq(label + ": options total players+1 (every fake plus the true answer)", s.options.length, order.length + 1);
    var trueOpt = s.options.filter(function (o) { return o.authorId === null; })[0];
    order.forEach(function (pid, i) {
      var target = (i === 0) ? trueOpt.optionId : s.options.filter(function (o) { return o.authorId === order[i - 1]; })[0].optionId;
      s = Bluff.reduce(s, player(pid), act("bluff.vote", roundId, { optionId: target }), 200 + i)[0];
    });
    eq(label + ": every player's vote is recorded", Object.keys(s.votes).length, order.length);
    s = Bluff.reduce(s, operator(), act("bluff.reveal", roundId, {}), 300)[0];
    eq(label + ": reveal succeeds with no abstentions", s.lastResult.abstained.length, 0);
    var totalDelta = order.reduce(function (sum, pid) { return sum + s.lastResult.scoreDelta[pid]; }, 0);
    ok(label + ": total points awarded is a positive multiple of 100 (every vote scored exactly once)", totalDelta > 0 && totalDelta % 100 === 0);
  }
  fullGame("4-player full game", ["p1", "p2", "p3", "p4"], "4001");
  fullGame("12-player full game", ["p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "p10", "p11", "p12"], "12001");

  // -------------------------------------------------------- room-level integration
  (function testRoomIntegration() {
    var Room = MajlisCore.room;
    var contents = new Map();
    var packResult = MajlisCore.content.loadMode("bluff", null, Bluff.validateItem, Bluff.validateItems);
    // loadMode with null bytes reports content_missing; build a minimal in-memory status instead for this room test.
    var status = { status: "ok", ok: function () { return true; }, pack: pack(ITEMS) };
    contents.set("bluff", status);

    var room = Room.newRoomState("ABCDEF", "Host", 3, 12);
    var j1 = Room.applyJoin(room, "p1", "Alice"); room = j1[0];
    var j2 = Room.applyJoin(room, "p2", "Bob"); room = j2[0];
    var j3 = Room.applyJoin(room, "p3", "Cara"); room = j3[0];
    eq("room-level: 3 players joined the lobby", room.players.length, 3);

    var setMode = Room.reduceRoom(room, { role: "operator" }, { type: "room.set_mode", payload: { mode: "bluff" } }, 1, contents, "42");
    eq("room-level: operator can select the bluff mode", setMode[1], null);
    room = setMode[0];

    var started = Room.reduceRoom(room, { role: "operator" }, { type: "room.start", payload: { rounds: 2 } }, 2, contents, "42");
    eq("room-level: room.start succeeds and forwards the rounds option into module.initialize", started[1], null);
    room = started[0];
    eq("room-level: room.start's forwarded rounds option reached the Bluff module", room.game.rounds, 2);
    eq("room-level: room enters the playing phase", room.phase, "playing");

    // Pause/resume are fully generic at the room level; confirm a mode action is frozen while paused.
    var paused = Room.reduceRoom(room, { role: "operator" }, { type: "room.pause", payload: {} }, 3, contents, "42")[0];
    var frozenAction = Room.reduceRoom(paused, { role: "player", playerId: "p1" },
      { type: "bluff.submit_answer", roundId: room.game.roundId, payload: { text: "Nope" } }, 4, contents, "42");
    eq("room-level: a mode action is rejected while the room is paused", frozenAction[1], "paused");
    var resumed = Room.reduceRoom(paused, { role: "operator" }, { type: "room.resume", payload: {} }, 5, contents, "42")[0];
    eq("room-level: room.resume returns to the playing phase", resumed.phase, "playing");

    // A late join after the game has started spectates (does not get a player slot) until the next game.
    var lateJoin = Room.applyJoin(resumed, "p4", "Dana");
    eq("room-level: a late join during an active Bluff game is admitted as a spectator", lateJoin[1], null);
    ok("room-level: the late joiner gets no player slot (spectator list only)", lateJoin[0].players.length === 3 && lateJoin[0].spectators.length === 1);

    // Reconnect: an existing player can keep acting on their identity across paused/resumed transitions.
    var submitted = Room.reduceRoom(resumed, { role: "player", playerId: "p1" },
      { type: "bluff.submit_answer", roundId: resumed.game.roundId, payload: { text: "Reconnected Fake" } }, 6, contents, "42");
    eq("room-level: a player's identity/action still works after a pause/resume cycle (reconnect)", submitted[1], null);
    room = submitted[0];
    eq("room-level: room-level score syncing reflects the module's per-player scores field", room.players[0].score, room.game.scores.p1);

    // Stale round id at the room level is rejected before it even reaches the module.
    var staleRoom = Room.reduceRoom(room, { role: "player", playerId: "p2" },
      { type: "bluff.submit_answer", roundId: "not-the-current-round", payload: { text: "x" } }, 7, contents, "42");
    eq("room-level: a stale roundId is rejected by the generic room reducer", staleRoom[1], "stale_round");

    // room.end routes a synthetic game.end into the module and syncs scores.
    var ended = Room.reduceRoom(room, { role: "operator" }, { type: "room.end", payload: {} }, 8, contents, "42")[0];
    eq("room-level: room.end moves the room to ended and the module reports ended", [ended.phase, ended.game.ended], ["ended", true]);

    // New-game cleanup: resetting and starting again invalidates the previous game's round id and gives a fresh state.
    var resetRoom = Room.reduceRoom(ended, { role: "operator" }, { type: "room.reset", payload: { clearScores: false } }, 9, contents, "42")[0];
    eq("room-level: room.reset clears the active game while preserving scores", [resetRoom.phase, resetRoom.game, resetRoom.players[0].score], ["lobby", null, room.players[0].score]);
    var restarted = Room.reduceRoom(resetRoom, { role: "operator" }, { type: "room.start", payload: {} }, 10, contents, "43")[0];
    ok("room-level: a fresh game after reset starts at round 1 with a new roundId", restarted.game.roundNo === 1 && restarted.game.roundId !== room.game.roundId);
    eq("room-level: a fresh game has empty fakes/votes (new-game cleanup)", [Object.keys(restarted.game.fakes).length, Object.keys(restarted.game.votes).length], [0, 0]);
    var staleFromPriorGame = Room.reduceRoom(restarted, { role: "player", playerId: "p1" },
      { type: "bluff.submit_answer", roundId: room.game.roundId, payload: { text: "x" } }, 11, contents, "43");
    eq("room-level: the previous game's roundId is invalid after a new game has started", staleFromPriorGame[1], "stale_round");
  })();

  // =================================================== correction v3 tests
  // Each block below defeats one reproduced reviewer probe (bluff-review-probe.js).

  function signature(o) {
    // Everything about an option's serialization except its opaque id and the
    // literal answer text: key set, value types, nested shape and the
    // equality pattern of any nested strings (the v2 leak was en===ar).
    var sig = { keys: Object.keys(o).sort(), types: {} };
    Object.keys(o).forEach(function (k) {
      var v = o[k];
      if (v !== null && typeof v === "object") {
        var ks = Object.keys(v).sort();
        var vals = ks.map(function (kk) { return v[kk]; });
        sig.types[k] = { nested: ks, distinctValues: new Set(vals.map(String)).size };
      } else sig.types[k] = v === null ? "null" : typeof v;
    });
    return JSON.stringify(sig);
  }
  function uniqueSignatureIndexes(options) {
    var counts = {};
    options.forEach(function (o) { var s = signature(o); counts[s] = (counts[s] || 0) + 1; });
    var out = [];
    options.forEach(function (o, i) { if (counts[signature(o)] === 1) out.push(i); });
    return out;
  }
  var OPTION_ID_RE = /^o[0-9a-f]{16}$/;

  function toVoting(config, order, items, fakes) {
    var r = Bluff.initialize(config, players(order), pack(items));
    if (r[1]) return { error: r[1] };
    var s = r[0], rid = s.roundId;
    order.forEach(function (pid, i) {
      var text = fakes ? fakes[i] : ("Fake answer " + pid);
      if (text === null) return;
      s = Bluff.reduce(s, player(pid), act("bluff.submit_answer", rid, { text: text }), i + 1)[0];
    });
    s = Bluff.reduce(s, operator(), act("bluff.open_vote", rid, { force: true }), 50)[0];
    return { state: s };
  }

  // ---- fix 1: translation-origin disclosure
  (function testTranslationOrigin() {
    ["en", "ar"].forEach(function (lang) {
      var order = ["p1", "p2", "p3", "p4"];
      var r = Bluff.initialize({ seed: "31337", gameNo: 1, room: "LANGRM", options: { rounds: 3, language: lang } }, players(order), pack(ITEMS));
      eq("v3 " + lang + ": initialize accepts language", r[1], null);
      var s = r[0];
      for (var round = 1; round <= 3; round++) {
        var rid = s.roundId;
        var fakesByLang = lang === "en" ? ["Alpha guess", "Bravo guess", "Charlie guess", "Delta guess"]
          : ["تخمين أول", "تخمين ثان", "تخمين ثالث", "تخمين رابع"];
        order.forEach(function (pid, i) { s = Bluff.reduce(s, player(pid), act("bluff.submit_answer", rid, { text: fakesByLang[i] + " " + round }), i)[0]; });
        s = Bluff.reduce(s, operator(), act("bluff.open_vote", rid, {}), 10)[0];
        eq("v3 " + lang + " round " + round + ": voting opened", s.phase, "voting");
        var expectTruth = MajlisCore.unicode.cleanText(s.item.trueAnswer[lang], 160);
        [{ role: "display" }, player("p1"), player("p3")].forEach(function (viewer) {
          var view = Bluff.project(s, viewer);
          eq("v3 " + lang + " round " + round + ": projected language", view.language, lang);
          ok("v3 " + lang + " round " + round + " " + JSON.stringify(viewer) + ": every option is exactly {optionId, text:string}",
            view.options.every(function (o) { return Object.keys(o).sort().join(",") === "optionId,text" && typeof o.text === "string"; }));
          eq("v3 " + lang + " round " + round + " " + JSON.stringify(viewer) + ": no option has a structurally unique signature",
            uniqueSignatureIndexes(view.options), []);
          eq("v3 " + lang + " round " + round + ": the truth appears once, in the game language only",
            view.options.filter(function (o) { return o.text === expectTruth; }).length, 1);
          var other = MajlisCore.unicode.cleanText(s.item.trueAnswer[lang === "en" ? "ar" : "en"], 160);
          if (other !== expectTruth) {
            ok("v3 " + lang + " round " + round + ": the other-language translation of the truth appears nowhere in the view",
              JSON.stringify(view.options).indexOf(JSON.stringify(other)) === -1);
          }
        });
        order.forEach(function (pid) {
          var target = s.options.filter(function (o) { return o.authorId !== pid; })[0].optionId;
          s = Bluff.reduce(s, player(pid), act("bluff.vote", rid, { optionId: target }), 20)[0];
        });
        s = Bluff.reduce(s, operator(), act("bluff.reveal", rid, {}), 30)[0];
        ok("v3 " + lang + " round " + round + ": lastResult options use the same single-string text",
          s.lastResult.options.every(function (o) { return typeof o.text === "string"; }));
        s = Bluff.reduce(s, operator(), act("round.next", rid, {}), 40)[0];
      }
      eq("v3 " + lang + ": full 3-round loop finishes", s.phase, "finished");
    });

    // Numeric answers whose translations are equal ("366"/"366", "Au"/"Au").
    var numeric = [item("n001", "How many days are in a leap year?", "كم عدد أيام السنة الكبيسة؟", "366", "366", [], []),
      item("n002", "What is the chemical symbol for gold?", "ما الرمز الكيميائي للذهب؟", "Au", "Au", [], [])];
    ["en", "ar"].forEach(function (lang) {
      numeric.forEach(function (it) {
        var v = toVoting({ seed: "4242", gameNo: 1, room: "NUMRMX", options: { rounds: 1, language: lang } }, ["p1", "p2", "p3"], [it], ["365", "367", "360"]);
        var view = Bluff.project(v.state, { role: "display" });
        eq("v3 equal-translation " + it.id + " " + lang + ": no structurally unique option", uniqueSignatureIndexes(view.options), []);
        ok("v3 equal-translation " + it.id + " " + lang + ": all option texts are plain strings",
          view.options.every(function (o) { return typeof o.text === "string"; }));
      });
    });

    // Deliberate discriminator injection: rebuilding the v2 {en, ar} text
    // shape (fake en===ar, truth en!==ar) MUST be singled out by the
    // detector, and must point at exactly the true option.
    var v = toVoting({ seed: "17", gameNo: 1, room: "INJECT", options: { rounds: 1 } }, ["p1", "p2", "p3"], [ITEMS[0]], ["Lyon", "Berlin", "Rome"]);
    var injected = v.state.options.map(function (o) {
      return { optionId: o.optionId, text: o.authorId === null ? { en: ITEMS[0].trueAnswer.en, ar: ITEMS[0].trueAnswer.ar } : { en: o.text, ar: o.text } };
    });
    var flagged = uniqueSignatureIndexes(injected);
    var trueIdx = v.state.options.map(function (o) { return o.authorId; }).indexOf(null);
    eq("v3 injection control: the v2 translation discriminator is caught and singles out the true option", flagged, [trueIdx]);
    var injectedFlag = v.state.options.map(function (o) { return o.authorId === null ? { optionId: o.optionId, text: o.text, isTrue: true } : { optionId: o.optionId, text: o.text }; });
    eq("v3 injection control: an extra marker key on the truth is caught", uniqueSignatureIndexes(injectedFlag), [trueIdx]);
    var injectedType = v.state.options.map(function (o) { return o.authorId === null ? { optionId: o.optionId, text: [o.text] } : { optionId: o.optionId, text: o.text }; });
    eq("v3 injection control: a type difference on the truth is caught", uniqueSignatureIndexes(injectedType), [trueIdx]);
    eq("v3 real output: no discriminator at all", uniqueSignatureIndexes(Bluff.project(v.state, { role: "display" }).options), []);

    var badLang = Bluff.initialize({ seed: "1", gameNo: 1, options: { language: "fr" } }, players(["a", "b", "c"]), pack(ITEMS));
    eq("v3: an unknown game language is invalid_config", badLang[1], "invalid_config");
    var badLangType = Bluff.initialize({ seed: "1", gameNo: 1, options: { language: 1 } }, players(["a", "b", "c"]), pack(ITEMS));
    eq("v3: a non-string game language is invalid_config", badLangType[1], "invalid_config");
    var dflt = Bluff.initialize({ seed: "1", gameNo: 1, options: {} }, players(["a", "b", "c"]), pack(ITEMS));
    eq("v3: language defaults to en", dflt[0].language, "en");

    // Fakes matching the truth in EITHER language (or an alias) are still rejected in an en game.
    var paris = Bluff.initialize({ seed: "1", gameNo: 1, room: "PARISX", options: { rounds: 1, language: "en" } }, players(["a", "b", "c"]), pack([ITEMS[0]]))[0];
    eq("v3: an Arabic-translation fake is rejected in an English game", Bluff.reduce(paris, player("a"), act("bluff.submit_answer", paris.roundId, { text: "باريس" }), 1)[1], "invalid_answer");
  })();

  // ---- fix 2: opaque, scoped option ids
  (function testOpaqueOptionIds() {
    var order = ["p1", "p2", "p3"];
    function voting(seed, gameNo, room) {
      return toVoting({ seed: seed, gameNo: gameNo, room: room, options: { rounds: 2 } }, order, ITEMS, ["Fake A", "Fake B", "Fake C"]).state;
    }
    var a = voting("9001", 1, "ROOMAA");
    ok("v3 ids: every option id matches o + 16 hex", a.options.every(function (o) { return OPTION_ID_RE.test(o.optionId); }));
    eq("v3 ids: option ids are unique within a round", new Set(a.options.map(function (o) { return o.optionId; })).size, a.options.length);
    ok("v3 ids: no positional id (o0..o12) is ever issued", a.options.every(function (o) { return !/^o\d{1,2}$/.test(o.optionId); }));
    eq("v3 ids: identical inputs reproduce identical ids (deterministic)", voting("9001", 1, "ROOMAA").options.map(function (o) { return o.optionId; }), a.options.map(function (o) { return o.optionId; }));

    // Reviewer probe: a positional id from game 1 voted in game 2.
    eq("v3 ids: the reviewer's positional 'o0' is unknown_option", Bluff.reduce(a, player("p1"), act("bluff.vote", a.roundId, { optionId: "o0" }), 1)[1], "unknown_option");

    // Foreign room: same seed, same game number, same content, same fakes: only the room differs.
    var foreign = voting("9001", 1, "ROOMBB");
    eq("v3 ids: same seed/game/round/content in another room yields disjoint ids", a.options.filter(function (o) { return foreign.options.some(function (f) { return f.optionId === o.optionId; }); }).length, 0);
    eq("v3 ids: the option order (and so the truth slot) is the same in both rooms -- only the ids differ",
      a.options.map(function (o) { return o.authorId; }), foreign.options.map(function (o) { return o.authorId; }));
    foreign.options.forEach(function (f) {
      var voter = f.authorId === "p1" ? "p2" : "p1";
      eq("v3 ids: a foreign-room id is rejected in a valid current round context", Bluff.reduce(a, player(voter), act("bluff.vote", a.roundId, { optionId: f.optionId }), 2)[1], "unknown_option");
    });

    // Prior game in the same room: game 1 vs game 2 (even with an identical seed).
    var g2same = voting("9001", 2, "ROOMAA"), g2fresh = voting("12345", 2, "ROOMAA");
    [g2same, g2fresh].forEach(function (g2, k) {
      a.options.forEach(function (o) {
        var voter = "p3";
        eq("v3 ids: a prior-game id is rejected in game 2 (" + (k ? "fresh seed" : "same seed") + ")", Bluff.reduce(g2, player(voter), act("bluff.vote", g2.roundId, { optionId: o.optionId }), 3)[1], "unknown_option");
      });
    });

    // Prior round in the same game.
    var s = a, rid1 = s.roundId, r1ids = s.options.map(function (o) { return o.optionId; });
    s = Bluff.reduce(s, operator(), act("bluff.reveal", rid1, { force: true }), 4)[0];
    s = Bluff.reduce(s, operator(), act("round.next", rid1, {}), 5)[0];
    var rid2 = s.roundId;
    ["p1", "p2", "p3"].forEach(function (p, i) { s = Bluff.reduce(s, player(p), act("bluff.submit_answer", rid2, { text: "Second " + i }), 6)[0]; });
    s = Bluff.reduce(s, operator(), act("bluff.open_vote", rid2, {}), 7)[0];
    r1ids.forEach(function (id) {
      eq("v3 ids: a prior-round id is rejected with the current roundId", Bluff.reduce(s, player("p1"), act("bluff.vote", rid2, { optionId: id }), 8)[1], "unknown_option");
    });
    eq("v3 ids: round 2 ids are disjoint from round 1 ids", s.options.filter(function (o) { return r1ids.indexOf(o.optionId) >= 0; }).length, 0);

    // Ids carry no author or truth position: over many seeds the true option's id is not predictable from its slot,
    // and the truth occupies more than one slot.
    var slots = new Set(), idsAtSlot0 = new Set();
    for (var k = 0; k < 24; k++) {
      var g = voting(String(5000 + k), 1, "ROOMCC");
      slots.add(g.options.map(function (o) { return o.authorId; }).indexOf(null));
      idsAtSlot0.add(g.options[0].optionId);
    }
    ok("v3 ids: the truth position varies with the seed (deterministic shuffle kept)", slots.size > 1);
    eq("v3 ids: slot 0 never reuses an id across games (no positional id)", idsAtSlot0.size, 24);

    // Exactly-once scoring still holds with the new ids.
    var t = voting("777", 1, "ROOMDD"), tr = t.options.filter(function (o) { return o.authorId === null; })[0];
    t = Bluff.reduce(t, player("p1"), act("bluff.vote", t.roundId, { optionId: tr.optionId }), 9)[0];
    t = Bluff.reduce(t, operator(), act("bluff.reveal", t.roundId, { force: true }), 10)[0];
    eq("v3 ids: correct vote scores exactly 100", t.scores.p1, 100);
    eq("v3 ids: reveal cannot be applied twice", Bluff.reduce(t, operator(), act("bluff.reveal", t.roundId, { force: true }), 11)[1], "invalid_phase");
    eq("v3 ids: lastResult.trueOptionId is the opaque id", t.lastResult.trueOptionId, tr.optionId);
  })();

  // ---- fix 3: spectators
  (function testSpectators() {
    var Room = MajlisCore.room;
    var contents = new Map();
    contents.set("bluff", { status: "ok", ok: function () { return true; }, pack: pack(ITEMS) });
    var presence = new Map();
    function start(room, seed, payload) { return Room.reduceRoom(room, operator(), { type: "room.start", payload: payload || { rounds: 1 } }, 1, contents, seed); }
    var room = Room.newRoomState("SPECTR", "Host", 3, 6);
    ["Alice", "Bob", "Cara"].forEach(function (n, i) { room = Room.applyJoin(room, "p" + (i + 1), n)[0]; });
    eq("v3 spectators: lobby rooms have no spectators key (other modes unchanged)", "spectators" in room, false);
    room = Room.reduceRoom(room, operator(), { type: "room.set_mode", payload: { mode: "bluff" } }, 1, contents, "1")[0];
    room = start(room, "77")[0];
    var before = JSON.stringify({ players: room.players, order: room.game.order, scores: room.game.scores });

    var j = Room.applyJoin(room, "s1", "Dana");
    eq("v3 spectators: join while playing is accepted", j[1], null);
    room = j[0];
    eq("v3 spectators: participant list/order/scores unchanged by a spectator", JSON.stringify({ players: room.players, order: room.game.order, scores: room.game.scores }), before);
    var paused = Room.reduceRoom(room, operator(), { type: "room.pause", payload: {} }, 2, contents, "1")[0];
    var j2 = Room.applyJoin(paused, "s2", "Eve");
    eq("v3 spectators: join while paused is accepted", j2[1], null);
    room = Room.reduceRoom(j2[0], operator(), { type: "room.resume", payload: {} }, 3, contents, "1")[0];
    eq("v3 spectators: two spectators waiting", room.spectators.map(function (p) { return p.id; }), ["s1", "s2"]);
    eq("v3 spectators: a duplicate name against a spectator is name_taken", Room.applyJoin(room, "x", "dana")[1], "name_taken");
    var full = Room.applyJoin(room, "s3", "Finn")[0];
    eq("v3 spectators: room_full counts spectators", Room.applyJoin(full, "s4", "Gus")[1], "room_full");

    var spectSnap = Room.projectRoom(room, { role: "player", playerId: "s1" }, 9, presence, contents);
    var displaySnap = Room.projectRoom(room, { role: "display" }, 9, presence, contents);
    eq("v3 spectators: snapshot role is spectator", spectSnap.role, "spectator");
    eq("v3 spectators: self marks the spectator", spectSnap.self, { id: "s1", name: "Dana", spectator: true });
    eq("v3 spectators: spectator game view is exactly the display view", JSON.stringify(spectSnap.game), JSON.stringify(displaySnap.game));
    ok("v3 spectators: spectator has no private you-view", !("you" in spectSnap.game));
    eq("v3 spectators: totalPlayers unchanged", spectSnap.game.totalPlayers, 3);
    eq("v3 spectators: spectators listed separately with no score", spectSnap.spectators, [{ id: "s1", name: "Dana", connected: false }, { id: "s2", name: "Eve", connected: false }]);

    var rid = room.game.roundId;
    eq("v3 spectators: spectator submit is forbidden", Room.reduceRoom(room, player("s1"), { type: "bluff.submit_answer", roundId: rid, payload: { text: "Sneaky" } }, 4, contents, "1")[1], "forbidden");
    ["p1", "p2", "p3"].forEach(function (p, i) { room = Room.reduceRoom(room, player(p), { type: "bluff.submit_answer", roundId: rid, payload: { text: "Fake " + i } }, 5, contents, "1")[0]; });
    room = Room.reduceRoom(room, operator(), { type: "bluff.open_vote", roundId: rid, payload: {} }, 6, contents, "1")[0];
    var anyOpt = room.game.options[0].optionId;
    eq("v3 spectators: spectator vote is forbidden", Room.reduceRoom(room, player("s2"), { type: "bluff.vote", roundId: rid, payload: { optionId: anyOpt } }, 7, contents, "1")[1], "forbidden");
    eq("v3 spectators: spectator room action is forbidden", Room.reduceRoom(room, player("s2"), { type: "room.end", payload: {} }, 8, contents, "1")[1], "forbidden");
    var t = room.game.options.filter(function (o) { return o.authorId === null; })[0].optionId;
    ["p1", "p2", "p3"].forEach(function (p) { room = Room.reduceRoom(room, player(p), { type: "bluff.vote", roundId: rid, payload: { optionId: t } }, 9, contents, "1")[0]; });
    room = Room.reduceRoom(room, operator(), { type: "bluff.reveal", roundId: rid, payload: {} }, 10, contents, "1")[0];
    eq("v3 spectators: scores only for participants", room.players.map(function (p) { return p.score; }), [100, 100, 100]);
    ok("v3 spectators: spectators never enter game.scores", !("s1" in room.game.scores) && !("s2" in room.game.scores));
    room = Room.reduceRoom(room, operator(), { type: "room.end", payload: {} }, 11, contents, "1")[0];
    eq("v3 spectators: still spectating after the game ends (admission is at the next game)", room.spectators.length, 2);

    // Promotion at the next game.
    var restarted = start(room, "78", { rounds: 1, language: "ar" });
    eq("v3 spectators: next room.start succeeds", restarted[1], null);
    room = restarted[0];
    eq("v3 spectators: spectators promoted to players with score 0", room.players.map(function (p) { return [p.id, p.score]; }), [["p1", 100], ["p2", 100], ["p3", 100], ["s1", 0], ["s2", 0]]);
    ok("v3 spectators: promoted players are in the new game order", room.game.order.indexOf("s1") >= 0 && room.game.order.indexOf("s2") >= 0);
    ok("v3 spectators: spectator list cleared after promotion", !("spectators" in room));
    var promotedSnap = Room.projectRoom(room, player("s1"), 10, presence, contents);
    eq("v3 spectators: promoted spectator now has the player role and a private view", [promotedSnap.role, promotedSnap.game.you.submitted], ["player", false]);
    eq("v3 spectators: promoted spectator can act", Room.reduceRoom(room, player("s1"), { type: "bluff.submit_answer", roundId: room.game.roundId, payload: { text: "Promoted fake" } }, 12, contents, "1")[1], null);

    // A failed start keeps spectators waiting.
    var r2 = Room.newRoomState("SPECTQ", "Host", 3, 12);
    ["A1", "B1", "C1"].forEach(function (n, i) { r2 = Room.applyJoin(r2, "q" + i, n)[0]; });
    r2 = Room.reduceRoom(r2, operator(), { type: "room.set_mode", payload: { mode: "bluff" } }, 1, contents, "1")[0];
    r2 = start(r2, "5")[0];
    r2 = Room.applyJoin(r2, "qs", "Spec")[0];
    r2 = Room.reduceRoom(r2, operator(), { type: "room.end", payload: {} }, 2, contents, "1")[0];
    var bad = start(r2, "6", { rounds: 99 });
    eq("v3 spectators: a rejected start reports its error", bad[1], "invalid_config");
    eq("v3 spectators: a rejected start leaves the spectator waiting", bad[0].spectators.length, 1);

    // Other modes keep rejecting late joins.
    var impContents = new Map();
    impContents.set("impostor", { status: "ok", ok: function () { return true; }, pack: { title: "Impostor", items: [{ id: "w1", word: "Apple", category: "Fruit" }, { id: "w2", word: "Pear", category: "Fruit" }] } });
    var imp = Room.newRoomState("IMPOST", "Host", 3, 12);
    ["A", "B", "C"].forEach(function (n, i) { imp = Room.applyJoin(imp, "i" + i, n)[0]; });
    imp = Room.reduceRoom(imp, operator(), { type: "room.set_mode", payload: { mode: "impostor" } }, 1, impContents, "1")[0];
    var impStarted = Room.reduceRoom(imp, operator(), { type: "room.start", payload: {} }, 2, impContents, "9");
    if (impStarted[1] === null) {
      eq("v3 spectators: Impostor late join still game_in_progress", Room.applyJoin(impStarted[0], "late", "Late")[1], "game_in_progress");
      ok("v3 spectators: Impostor snapshot has no spectators key", !("spectators" in Room.projectRoom(impStarted[0], { role: "display" }, 1, presence, impContents)));
    } else {
      ok("v3 spectators: Impostor start precondition (" + impStarted[1] + ")", false);
    }
  })();

  function has_(o, k) { return Object.prototype.hasOwnProperty.call(o, k); }

  globalThis.__TEST_RESULT__ = JSON.stringify({ passed: passed, failed: failed, failures: failures });
})();
