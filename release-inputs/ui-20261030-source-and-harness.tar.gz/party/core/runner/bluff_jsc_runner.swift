// Bluff engine JS unit-test runner (macOS CLI, test tool only, not shipped).
//
// Evaluates the generated Unicode tables, majlis-core.js, and a plain test
// script in one JSContext, then reads a global JSON result string the test
// script leaves behind. No native functions are injected into the context.
//
// Usage: bluff_jsc_runner TABLES.js CORE.js TEST.js

import Foundation
import JavaScriptCore

func fail(_ message: String) -> Never {
    FileHandle.standardError.write((message + "\n").data(using: .utf8)!)
    exit(2)
}

let args = CommandLine.arguments
guard args.count == 4 else { fail("usage: bluff_jsc_runner TABLES.js CORE.js TEST.js") }

guard let context = JSContext() else { fail("no JSContext") }
var scriptError: String?
context.exceptionHandler = { _, exception in
    scriptError = exception?.toString() ?? "unknown exception"
}

for path in args[1...3] {
    guard let source = try? String(contentsOfFile: path, encoding: .utf8) else { fail("cannot read \(path)") }
    context.evaluateScript(source, withSourceURL: URL(fileURLWithPath: path))
    if let err = scriptError { fail("script \(path): \(err)") }
}

let probe = context.evaluateScript("""
  JSON.stringify(["window","document","setTimeout","setInterval","fetch","XMLHttpRequest","WebSocket",
    "require","process","crypto","localStorage","navigator","Date"].map(function (n) {
      return [n, typeof globalThis[n]]; }))
""")?.toString() ?? "?"
FileHandle.standardError.write("globals: \(probe)\n".data(using: .utf8)!)

guard let resultValue = context.objectForKeyedSubscript("__TEST_RESULT__"), !resultValue.isUndefined else {
    fail("test script did not set __TEST_RESULT__")
}
let resultJson = resultValue.toString() ?? "null"
print(resultJson)

guard let data = resultJson.data(using: .utf8),
      let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
    fail("could not parse __TEST_RESULT__")
}
let failed = (obj["failed"] as? Int) ?? -1
exit(failed == 0 ? 0 : 1)
