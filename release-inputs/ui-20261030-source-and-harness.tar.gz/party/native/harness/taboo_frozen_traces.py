"""Replays the frozen, independently generated Taboo traces
(tests/fixtures/taboo/frozen_traces.json, written by the contract model
tests/fixtures/taboo/gen_frozen_traces.py which imports nothing from party/)
against

  core  the reviewed core (party/core/majlis-core.js) in the system
        JavaScriptCore, injected clock + injected start seeds: every receipt,
        join/resume envelope and the COMPLETE snapshot of every identity after
        every step must equal the fixture exactly (remainingMs included);
  http  the compiled native host (majlis-party-native-test) over real HTTP:
        same comparisons, except that the deck order is bound on first sight
        (the host draws its own seed) -- each fixture card id must bind to a
        distinct authored card (bijection => no repeats) -- and remainingMs is
        range-checked (real clock) instead of compared to the fake clock.

There is no self-derived oracle: nothing expected is computed from the system
under test except opaque identifiers (room code, player ids, and in http mode
which authored card was dealt), and every binding is checked for consistency.
Exact trace lengths are pinned below.

    python3 -I -B party/native/harness/taboo_frozen_traces.py --mode core|http|both \
        [--bin BUILD/majlis-party-native-test] --evidence DIR [--only NAME ...]

Exit 0 iff every step of every selected scenario matches.
"""
import argparse
import copy
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(HERE)))
sys.path.insert(0, os.path.join(ROOT, "tests"))
FIXTURE = os.path.join(ROOT, "tests", "fixtures", "taboo", "frozen_traces.json")
PACK = os.path.join(ROOT, "party", "content", "taboo.json")
CORE_DIR = [os.path.join(ROOT, "party", "core")]  # --core-dir overrides (mutation controls)
JSC = "/System/Library/Frameworks/JavaScriptCore.framework/Versions/A/Helpers/jsc"
AUTHORED_SHA256 = "158e8ee38d6c7891a2247ce2da0809ed3f6d73a3332d63be868049551606a93b"

EXPECTED_LENGTHS = {
    "winner-n4": 97, "draw-n4": 97, "winner-n5": 98, "draw-n5": 98, "winner-n6": 99, "draw-n6": 99,
    "winner-n7": 100, "draw-n7": 100, "winner-n8": 101, "draw-n8": 101, "winner-n9": 102, "draw-n9": 102,
    "winner-n10": 103, "draw-n10": 103, "winner-n11": 104, "draw-n11": 104, "winner-n12": 105, "draw-n12": 105,
    "rejections-race-replay-n4": 48, "cap20-normalization-n5": 38, "spectators-n4": 37,
    "timer-pause-expiry-reset-core-n4": 25,
}
FULL_GAMES = [n for n in EXPECTED_LENGTHS if n.startswith(("winner-", "draw-"))]
ID_RE = re.compile(r"^p[0-9a-f]{10}$")
CODE_RE = re.compile(r"^[A-Z0-9]{6}$")


def variant_text(word, variant):
    """Guess texts for a correct guess (must normalise to the word)."""
    if variant == "exact":
        return word
    if variant == "upper_ws":
        return "  " + word.upper().replace(" ", "   ") + "  "
    if variant == "lower_ws":
        return "   " + word.lower() + " "
    if variant == "spaces_mixed":
        return "  " + word.swapcase().replace(" ", "  ") + "   "
    raise ValueError(variant)


def stored_text(word, variant):
    # Foundation clean_text: NFC + whitespace collapse (all variants are ASCII).
    return " ".join(variant_text(word, variant).split())


class Mismatch(Exception):
    pass


class Binder(object):
    """Resolves fixture placeholders against observed opaque values.

    Card bindings are scoped to GAME identity: every game (``room.start``)
    deals a freshly shuffled copy of the whole authored pack, so an authored
    card may legitimately appear again in a later game of the same room.
    The game identity is taken from the FIXTURE (the expected ``game.gameNo``
    of the view being unified; the actual ``gameNo`` must equal it, which the
    ordinary unification checks). Within one game the binding stays an exact
    bijection: a fixture card id binds to exactly one authored card and no
    authored card may be bound to two fixture card ids (=> no repeats inside
    a game's deck); a full game must bind all 60 authored cards exactly once
    (check_deck)."""

    def __init__(self, items, fixed_deck):
        self.items = {it["id"]: it for it in items}
        self.by_word = {it["word"]: it for it in items}
        self.fixed = fixed_deck
        self.games = {}      # gameNo -> {"card": {fixture card id -> item}, "used": set(authored ids)}
        self.game_no = None  # game identity of the view currently being unified
        self.ids = {}        # label -> id
        self.code = None

    # -- game scope
    def enter_game(self, game_no, path):
        if not isinstance(game_no, int) or isinstance(game_no, bool) or game_no < 1:
            raise Mismatch("%s: fixture gameNo %r is not a game identity" % (path, game_no))
        self.game_no = game_no
        self.games.setdefault(game_no, {"card": {}, "used": set()})

    def _scope(self, path):
        if self.game_no is None:
            raise Mismatch("%s: card placeholder outside any game" % path)
        return self.games[self.game_no]

    @property
    def card(self):
        """Fixture card id -> authored item for the CURRENT game."""
        return self._scope("binder")["card"] if self.game_no is not None else {}

    @property
    def used(self):
        """Authored ids bound in the CURRENT game."""
        return self._scope("binder")["used"] if self.game_no is not None else set()

    def cards_bound(self):
        return sum(len(g["card"]) for g in self.games.values())

    # -- binding helpers
    def bind_label(self, label, actual, path):
        if label == "CODE":
            if self.code is None:
                if not isinstance(actual, str) or not CODE_RE.match(actual):
                    raise Mismatch("%s: bad room code %r" % (path, actual))
                self.code = actual
            return self.code
        if label not in self.ids:
            if not isinstance(actual, str) or not ID_RE.match(actual) or actual in self.ids.values():
                raise Mismatch("%s: cannot bind @%s to %r" % (path, label, actual))
            self.ids[label] = actual
        return self.ids[label]

    def item_for(self, cid, actual, path):
        scope = self._scope(path)
        if cid in scope["card"]:
            return scope["card"][cid]
        if self.fixed:
            item = self.items[cid]
        else:
            word = actual.get("word") if isinstance(actual, dict) else actual
            item = self.by_word.get(word)
            if item is None:
                raise Mismatch("%s: %r is not an authored word (fixture card %s)" % (path, word, cid))
        if item["id"] in scope["used"]:
            raise Mismatch("%s: authored card %s dealt twice in game %d (fixture card %s)"
                           % (path, item["id"], self.game_no, cid))
        scope["card"][cid] = item
        scope["used"].add(item["id"])
        return item

    def word(self, cid):
        if self.fixed:
            # Core mode: the fixture card id IS the authored id of the seeded
            # deck. Request bodies are resolved before the run (no game scope
            # yet); the views' unification binds and checks uniqueness.
            return self.items[cid]["word"]
        scope = self._scope("body")
        if cid not in scope["card"]:
            raise Mismatch("guess references card %s before it was observed in game %r" % (cid, self.game_no))
        return scope["card"][cid]["word"]

    # -- resolution of request bodies (no actual counterpart)
    def resolve_body(self, value):
        if isinstance(value, dict):
            if "$guess" in value:
                return variant_text(self.word(value["$guess"]), value["variant"])
            return {k: self.resolve_body(v) for k, v in value.items()}
        if isinstance(value, list):
            return [self.resolve_body(v) for v in value]
        if isinstance(value, str) and value.startswith("@"):
            if value[1:] == "CODE":
                return self.code
            return self.ids[value[1:]]
        return value

    # -- unify expected (with placeholders) against actual
    def unify(self, exp, act, path, loose_ms):
        if isinstance(exp, dict) and len(exp) in (1, 2) and any(k in exp for k in ("$card", "$word", "$guessStored")):
            if "$card" in exp:
                item = self.item_for(exp["$card"], act, path)
                want = {"word": item["word"], "forbidden": list(item["forbidden"])}
            elif "$word" in exp:
                item = self.item_for(exp["$word"], act, path)
                want = item["word"]
            else:
                want = stored_text(self.word(exp["$guessStored"]), exp["variant"])
            if want != act:
                raise Mismatch("%s: expected %r got %r" % (path, want, act))
            return
        if isinstance(exp, str) and exp.startswith("@"):
            if self.bind_label(exp[1:], act, path) != act:
                raise Mismatch("%s: expected %s=%r got %r" % (path, exp, self.ids.get(exp[1:], self.code), act))
            return
        if isinstance(exp, dict):
            if not isinstance(act, dict):
                raise Mismatch("%s: expected object got %r" % (path, act))
            if path.endswith(".game") and "gameNo" in exp:
                # Game identity comes from the fixture; actual gameNo must
                # equal it (checked below with every other key).
                self.enter_game(exp["gameNo"], path)
            if set(exp) != set(act):
                raise Mismatch("%s: key set %s != expected %s" % (path, sorted(act), sorted(exp)))
            for k in exp:
                if k == "remainingMs" and loose_ms is not None:
                    a = act[k]
                    ok = isinstance(a, int) and not isinstance(a, bool) and (
                        a == 0 if exp[k] == 0 else 0 < a <= loose_ms)
                    if not ok:
                        raise Mismatch("%s.remainingMs: %r not consistent with expected %r" % (path, a, exp[k]))
                    continue
                self.unify(exp[k], act[k], path + "." + k, loose_ms)
            return
        if isinstance(exp, list):
            if not isinstance(act, list) or len(exp) != len(act):
                raise Mismatch("%s: expected list len %d got %r" % (path, len(exp), act))
            for i, (e, a) in enumerate(zip(exp, act)):
                self.unify(e, a, "%s[%d]" % (path, i), loose_ms)
            return
        if type(exp) is not type(act) and not (isinstance(exp, (int, float)) and isinstance(act, (int, float))
                                                and not isinstance(exp, bool) and not isinstance(act, bool)):
            raise Mismatch("%s: expected %r got %r" % (path, exp, act))
        if exp != act:
            raise Mismatch("%s: expected %r got %r" % (path, exp, act))


def expand(scen, catalog):
    """Yields (step, expected_views_by_viewer) with "=" deltas expanded."""
    prev_per = prev_players = None
    for step in scen["steps"]:
        views = copy.deepcopy(step["views"])
        per = prev_per if views["per"] == "=" else views["per"]
        public = views["public"]
        if public["players"] == "=":
            public["players"] = prev_players
        prev_per, prev_players = per, public["players"]
        expected = {}
        for who, entry in per.items():
            snap = copy.deepcopy(public)
            snap["role"] = entry["role"]
            snap["self"] = copy.deepcopy(entry["self"])
            if views["game"] is None:
                snap["game"] = None
            else:
                game = copy.deepcopy(views["game"])
                if entry.get("you", "-") != "-":
                    game["you"] = copy.deepcopy(entry["you"])
                snap["game"] = game
            if entry["role"] == "operator":
                snap["modes"] = copy.deepcopy(catalog)
            expected[who] = snap
        yield step, expected


# ------------------------------------------------------------------ core mode
def run_core(scen, doc, items, pack_bytes, workdir, log):
    binder = Binder(items, fixed_deck=True)
    steps = list(expand(scen, doc["catalog"]))
    program = {"packsHex": {"taboo": pack_bytes.hex()}, "config": {}, "steps": []}
    # Request bodies never reference player ids (asserted below); card words
    # resolve from the fixed (seeded) deck.
    for step, expected in steps:
        p = {"op": step["op"], "now": step["now"], "viewers": sorted(expected)}
        if step["op"] == "create":
            p["bodyText"] = json.dumps(step["body"])
        elif step["op"] == "join":
            p["bodyText"] = json.dumps({"name": step["name"]})
            p["label"] = step["label"]
        elif step["op"] == "resume":
            p["label"] = step["label"]
        elif step["op"] == "action":
            body = binder.resolve_body(step["body"])
            if "@" in json.dumps(step["body"]):
                raise AssertionError("fixture request body references an id placeholder")
            p["bodyText"] = json.dumps(body)
            p["as"] = step["as"]
            if "seedHex" in step:
                p["seedHex"] = step["seedHex"]
        program["steps"].append(p)
    prog_path = os.path.join(workdir, scen["name"] + ".program.json")
    with open(prog_path, "w") as handle:
        json.dump(program, handle)
    core_dir = CORE_DIR[0]
    cmd = [JSC, os.path.join(core_dir, "unicode13.generated.js"), os.path.join(core_dir, "majlis-core.js"),
           os.path.join(HERE, "taboo_core_driver.js"), "--", prog_path]
    proc = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
    if proc.returncode != 0:
        raise Mismatch("jsc exit %d: %s" % (proc.returncode, proc.stderr.decode()[-2000:]))
    lines = [json.loads(l) for l in proc.stdout.decode().splitlines() if l.strip()]
    with open(os.path.join(workdir, scen["name"] + ".core.jsonl"), "w") as handle:
        for l in lines:
            handle.write(json.dumps(l, sort_keys=True) + "\n")
    if len(lines) != len(steps):
        raise Mismatch("core produced %d step outputs, fixture has %d" % (len(lines), len(steps)))
    for (step, expected), out in zip(steps, lines):
        where = "%s step %d (%s)" % (scen["name"], step["i"], step["op"])
        if out["internalErrors"] != 0:
            raise Mismatch(where + ": internal error recorded")
        if step["op"] != "view":
            binder.unify(step["expect"], {"status": out["status"], "body": out["body"]}, where + " response", None)
        if set(out["views"]) != set(expected):
            raise Mismatch("%s: viewer set %s != %s" % (where, sorted(out["views"]), sorted(expected)))
        for who in sorted(expected):
            binder.unify(expected[who], out["views"][who], "%s view[%s]" % (where, who), None)
    return binder


# ------------------------------------------------------------------ http mode
FAST = ["--heartbeat", "0.2", "--sweep-interval", "0.1", "--request-rate", "2000", "--request-burst", "5000",
        "--create-per-minute", "6000", "--create-burst", "500", "--join-per-minute", "6000", "--join-burst", "500",
        "--action-rate", "2000", "--action-burst", "5000"]


def start_native(binary, content_dir, timeout=15.0):
    import select
    cmd = [binary, "--host", "127.0.0.1", "--port", "0", "--content-dir", content_dir, "--exit-on-stdin-eof"] + FAST
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    ready, _, _ = select.select([proc.stdout], [], [], timeout)
    if not ready:
        stop_native(proc)
        raise RuntimeError("native host did not print a banner within %.0fs" % timeout)
    banner = json.loads(proc.stdout.readline().decode("utf-8"))
    return proc, banner["port"]


def stop_native(proc):
    try:
        proc.stdin.close()
    except Exception:
        pass
    try:
        proc.wait(timeout=5)
    except Exception:
        proc.kill()
        proc.wait(timeout=5)


def run_http(scen, doc, items, binary, content_dir, workdir):
    from support import Api
    binder = Binder(items, fixed_deck=False)
    steps = list(expand(scen, doc["catalog"]))
    proc, port = start_native(binary, content_dir)
    api = Api(port)
    tokens = {}
    turn_ms = 180000
    transcript = open(os.path.join(workdir, scen["name"] + ".http.jsonl"), "w")
    try:
        for step, expected in steps:
            where = "%s step %d (%s)" % (scen["name"], step["i"], step["op"])
            op = step["op"]
            if op == "create":
                resp = api.request("POST", "/api/rooms", body=step["body"])
                if resp.status == 201:
                    tokens["operator"], tokens["display"] = resp.json["hostToken"], resp.json["displayToken"]
            elif op == "join":
                resp = api.join(binder.code, step["name"])
                if resp.status == 201:
                    tokens[step["label"]] = resp.json["playerToken"]
            elif op == "resume":
                resp = api.join(binder.code, None, token=tokens[step["label"]])
            elif op == "action":
                body = binder.resolve_body(step["body"])
                resp = api.request("POST", "/api/rooms/%s/actions" % binder.code,
                                   raw_body=json.dumps(body).encode("utf-8"), token=tokens[step["as"]],
                                   headers={"Content-Type": "application/json"})
            else:
                raise Mismatch(where + ": op not supported over http")
            red = copy.deepcopy(resp.json)
            if isinstance(red, dict):
                for k in list(red):
                    if k.endswith("Token"):
                        red[k] = "<token>"
            binder.unify(step["expect"], {"status": resp.status, "body": red}, where + " response", None)
            views = {}
            for who in sorted(expected):
                st = api.state(binder.code, tokens[who])
                views[who] = st.json
                if st.status != 200:
                    raise Mismatch("%s: state for %s returned %d %s" % (where, who, st.status, st.text[:200]))
                game = expected[who].get("game")
                if game:
                    turn_ms = game["turnSeconds"] * 1000
                binder.unify(expected[who], st.json, "%s view[%s]" % (where, who), turn_ms)
            transcript.write(json.dumps({"i": step["i"], "status": resp.status, "body": red, "views": views},
                                        sort_keys=True) + "\n")
    finally:
        transcript.close()
        stop_native(proc)
    return binder


def check_deck(scen, binder, items):
    """Full games: exactly one game, binding all 60 authored cards exactly once.
    Every scenario: each game's binding is a bijection (no authored card under
    two fixture ids within one game) -- re-checked here independently of the
    incremental check in item_for."""
    for game_no, g in sorted(binder.games.items()):
        ids = [it["id"] for it in g["card"].values()]
        if len(ids) != len(set(ids)) or set(ids) != g["used"]:
            raise Mismatch("%s: game %d binding is not a bijection (%d fixture cards, %d authored ids)"
                           % (scen["name"], game_no, len(ids), len(set(ids))))
    if scen["name"] in FULL_GAMES:
        if sorted(binder.games) != [1]:
            raise Mismatch("%s: full-game scenario spans games %s" % (scen["name"], sorted(binder.games)))
        g = binder.games[1]
        if len(g["card"]) != 60 or g["used"] != set(it["id"] for it in items):
            raise Mismatch("%s: %d cards bound, %d distinct authored ids (need all 60 once)"
                           % (scen["name"], len(g["card"]), len(g["used"])))


# ------------------------------------------------- binder negative controls
# Deterministic: the REAL fixture's expected views are materialized with a
# chosen authored-card assignment per game (instead of a random host
# shuffle) and unified by the real Binder + check_deck, exactly as http mode
# does. No host, no randomness, no retry.
def _placeholder_cids(node, out):
    if isinstance(node, dict):
        for key in ("$card", "$word", "$guessStored"):
            if key in node and isinstance(node[key], str):
                if node[key] not in out:
                    out.append(node[key])
        for v in node.values():
            _placeholder_cids(v, out)
    elif isinstance(node, list):
        for v in node:
            _placeholder_cids(v, out)


def game_card_order(scen, doc):
    """gameNo -> fixture card ids in order of first appearance in the views."""
    order = {}
    for step, expected in expand(scen, doc["catalog"]):
        for who in sorted(expected):
            game = expected[who].get("game")
            if game:
                _placeholder_cids(game, order.setdefault(game["gameNo"], []))
    return order


def materialize(exp, assign, game_no):
    """Concrete 'actual' value for an expected view; assign[(gameNo, cid)] -> item."""
    if isinstance(exp, dict):
        if "$card" in exp:
            item = assign[(game_no, exp["$card"])]
            return {"word": item["word"], "forbidden": list(item["forbidden"])}
        if "$word" in exp:
            return assign[(game_no, exp["$word"])]["word"]
        if "$guessStored" in exp:
            return stored_text(assign[(game_no, exp["$guessStored"])]["word"], exp["variant"])
        if "gameNo" in exp:
            game_no = exp["gameNo"]
        return {k: materialize(v, assign, game_no) for k, v in exp.items()}
    if isinstance(exp, list):
        return [materialize(v, assign, game_no) for v in exp]
    if isinstance(exp, str) and exp.startswith("@"):
        if exp == "@CODE":
            return "TABOO1"
        return "p" + hashlib.sha256(exp.encode("utf-8")).hexdigest()[:10]
    return exp


def replay_assignment(scen, doc, items, assign):
    """Unifies every expected view of scen against its materialization."""
    binder = Binder(items, fixed_deck=False)
    for step, expected in expand(scen, doc["catalog"]):
        where = "%s step %d (%s)" % (scen["name"], step["i"], step["op"])
        for who in sorted(expected):
            actual = materialize(expected[who], assign, None)
            binder.unify(expected[who], actual, "%s view[%s]" % (where, who), None)
    check_deck(scen, binder, items)
    return binder


def binder_controls(doc, items):
    """Returns [(name, expect_pass, passed_as_expected, detail)]."""
    scen_by = {s["name"]: s for s in doc["scenarios"]}
    by_id = {it["id"]: it for it in items}
    authored = [it["id"] for it in items]
    out = []

    def run(name, scen_name, build, expect_pass, must_contain=None):
        scen = scen_by[scen_name]
        order = game_card_order(scen, doc)
        assign = build(order)
        try:
            b = replay_assignment(scen, doc, items, assign)
            ok, detail = expect_pass, "unified %d steps; %s" % (len(scen["steps"]), ", ".join(
                "game %d: %d cards" % (k, len(v["card"])) for k, v in sorted(b.games.items())))
        except Mismatch as exc:
            ok = (not expect_pass) and (must_contain is None or must_contain in str(exc))
            detail = "Mismatch: " + str(exc)[:400]
        out.append((name, expect_pass, ok, detail))

    def distinct(order):
        # game 1 gets authored cards in authored order; later games get a
        # fresh run of authored cards starting after game 1's.
        assign, k = {}, 0
        for g in sorted(order):
            for cid in order[g]:
                assign[(g, cid)] = by_id[authored[k % 60]]
                k += 1
        return assign

    def reuse_across_games(order):
        # Reviewer's case: game 2 deals authored cards that game 1 already
        # used (first card of game 2 == first card of game 1, etc.).
        assign = {}
        for g in sorted(order):
            for i, cid in enumerate(order[g]):
                assign[(g, cid)] = by_id[authored[i]]
        return assign

    def dup_within(game):
        def build(order):
            assign = reuse_across_games(order)
            first, second = order[game][0], order[game][1]
            assign[(game, second)] = assign[(game, first)]
            return assign
        return build

    def full_identity(order):
        return {(g, cid): by_id[cid] for g in order for cid in order[g]}

    def full_dup_last(order):
        assign = full_identity(order)
        cids = order[1]
        assign[(1, cids[-1])] = assign[(1, cids[0])]
        return assign

    run("spectators-n4: distinct cards in both games passes", "spectators-n4", distinct, True)
    run("spectators-n4: game-2 cards repeat game-1 cards (cross-game reuse) passes", "spectators-n4",
        reuse_across_games, True)
    run("spectators-n4: duplicate within game 1 fails", "spectators-n4", dup_within(1), False, "dealt twice in game 1")
    run("spectators-n4: duplicate within game 2 fails", "spectators-n4", dup_within(2), False, "dealt twice in game 2")
    run("winner-n4: all 60 authored cards once passes", "winner-n4", full_identity, True)
    run("winner-n4: 60th card repeats the 1st within the game fails", "winner-n4", full_dup_last, False,
        "dealt twice in game 1")
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["core", "http", "both"], default="both")
    ap.add_argument("--bin")
    ap.add_argument("--evidence", required=True)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--max-seconds", type=float, default=1500.0)
    ap.add_argument("--core-dir", help="party/core directory for core mode (default: this checkout)")
    ap.add_argument("--binder-controls-only", action="store_true",
                    help="run only the deterministic game-scoped binder controls")
    args = ap.parse_args()
    if args.core_dir:
        CORE_DIR[0] = os.path.abspath(args.core_dir)
    print("core dir", CORE_DIR[0])
    os.makedirs(args.evidence, exist_ok=True)
    started = time.time()

    with open(PACK, "rb") as handle:
        pack_bytes = handle.read()
    if hashlib.sha256(pack_bytes).hexdigest() != AUTHORED_SHA256:
        print("FAIL authored pack hash", hashlib.sha256(pack_bytes).hexdigest())
        return 1
    items = json.loads(pack_bytes.decode("utf-8"))["items"]
    with open(FIXTURE, "rb") as handle:
        raw = handle.read()
    doc = json.loads(raw.decode("utf-8"))
    print("fixture sha256", hashlib.sha256(raw).hexdigest(), "scenarios", len(doc["scenarios"]))
    names = [s["name"] for s in doc["scenarios"]]
    if sorted(names) != sorted(EXPECTED_LENGTHS):
        print("FAIL scenario set", names)
        return 1

    controls = binder_controls(doc, items)
    for name, expect_pass, ok, detail in controls:
        print("%s binder control [expect %s] %s: %s" % ("PASS" if ok else "FAIL", "pass" if expect_pass else "FAIL",
                                                         name, detail), flush=True)
    controls_ok = all(c[2] for c in controls)
    print("binder controls %d/%d behaved as expected" % (sum(1 for c in controls if c[2]), len(controls)), flush=True)
    if args.binder_controls_only:
        with open(os.path.join(args.evidence, "binder_controls.json"), "w") as handle:
            json.dump([{"control": c[0], "expectPass": c[1], "asExpected": c[2], "detail": c[3]} for c in controls],
                      handle, indent=1)
        return 0 if controls_ok else 1

    content_dir = tempfile.mkdtemp(prefix="taboo-frozen-content-")
    shutil.copyfile(PACK, os.path.join(content_dir, "taboo.json"))
    results = []
    modes = ["core", "http"] if args.mode == "both" else [args.mode]
    try:
        for scen in doc["scenarios"]:
            if args.only and scen["name"] not in args.only:
                continue
            n = len(scen["steps"])
            if n != EXPECTED_LENGTHS[scen["name"]]:
                results.append((scen["name"], "fixture", False, "length %d != pinned %d" % (n, EXPECTED_LENGTHS[scen["name"]])))
                continue
            for mode in modes:
                if mode == "http" and not scen["http"]:
                    continue
                if time.time() - started > args.max_seconds:
                    results.append((scen["name"], mode, False, "wall-clock budget exhausted"))
                    continue
                t = time.time()
                try:
                    if mode == "core":
                        binder = run_core(scen, doc, items, pack_bytes, args.evidence, None)
                    else:
                        if not args.bin:
                            raise Mismatch("--bin required for http mode")
                        binder = run_http(scen, doc, items, os.path.abspath(args.bin), content_dir, args.evidence)
                    check_deck(scen, binder, items)
                    detail = "%d steps, %d viewers max, %d cards bound (%s), %.1fs" % (
                        n, max(len(s["views"]["per"]) if s["views"]["per"] != "=" else 0 for s in scen["steps"]),
                        binder.cards_bound(),
                        ", ".join("game %d: %d" % (k, len(v["card"])) for k, v in sorted(binder.games.items())),
                        time.time() - t)
                    results.append((scen["name"], mode, True, detail))
                except (Mismatch, subprocess.TimeoutExpired, RuntimeError, OSError) as exc:
                    results.append((scen["name"], mode, False, str(exc)[:1500]))
                r = results[-1]
                print("%s %s [%s] %s" % ("PASS" if r[2] else "FAIL", r[0], r[1], r[3]), flush=True)
    finally:
        shutil.rmtree(content_dir, ignore_errors=True)
    passed = sum(1 for r in results if r[2])
    with open(os.path.join(args.evidence, "summary.json"), "w") as handle:
        json.dump({"fixtureSha256": hashlib.sha256(raw).hexdigest(), "results": [
            {"scenario": r[0], "mode": r[1], "pass": r[2], "detail": r[3]} for r in results],
            "passed": passed, "total": len(results),
            "binderControls": [{"control": c[0], "expectPass": c[1], "asExpected": c[2], "detail": c[3]}
                               for c in controls]}, handle, indent=1)
    print("%d/%d scenario runs passed" % (passed, len(results)))
    return 0 if results and passed == len(results) and controls_ok else 1


if __name__ == "__main__":
    sys.exit(main())
