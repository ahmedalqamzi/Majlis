"""Correction v7: closes the 4 frozen-scope gaps bluff-v6-final-decision.md left open
(majlis:bluff-primary-ui-integration-v1:delivery-correction-v7), scoped ONLY to the missing
semantic-privacy-oracle wiring and the operator/display exact voter-mapping surfaces. Does NOT
rerun bluff_display_native_browser_e2e.py or bluff_voter_reveal_evidence_v6.py (both already
committed, unchanged, cited by path/hash in HANDOFF.md) and does not repeat their 40-ish
checks; it adds only the targeted work the decision named:

  [gapA] bluff_privacy (bp) is actually CALLED against raw GET /state AND raw SSE "state"
         frames, at every boundary the decision listed: submission/voting, post-vote
         (pre-reveal), post-submit reconnect, post-vote reconnect, and the next-round
         boundary - for operator, every player, and display, in both EN and AR. (v6 imported
         bp and never called it; bluff_display_native_browser_e2e.py calls it only at
         submission-0/submission-full/voting/reveal over GET /state, EN only, and never over
         raw SSE or at the two reconnect boundaries or the next-round boundary.)
  [gapB] a planted pre-reveal voter-disclosure negative control that the SAME scan() rejects -
         not a DOM negative control (v6's gap2) and not a mutated-field allow-list unit test
         (test_bluff_privacy_checker.py); this plants real voter-authorship fields into a real
         pre-reveal payload captured above and re-scans it with the identical scan() call used
         for the real evidence, proving the oracle has teeth on the actual wire data.
  [gapC] exact voter NAME -> OPTION mapping (not "Voted by" substring presence, which is all
         bluff_display_native_browser_e2e.py checks) on the REAL rendered operator (host.js,
         <li class="who-row">) and display (tv.js, <li class="tv-who-card">) DOM, in EN and AR,
         using one shared structural parser generalised from v6's player-only
         parse_voted_by_per_option (<li class="bluff-option">) so all three surfaces are
         checked by the same comparison rather than three bespoke substring checks.
  [capability gap] the native SwiftUI OperatorView.swift screen itself cannot be rendered here:
         this CLT-only route has no iOS simulator/device runtime (only `swiftc -typecheck`,
         which bluff-native-compiler-v6 already used and which review-evidence/review-
         identity.json already records as exit 0 for the repaired helper). host.html is a
         separate, real, server-routed operator surface (test-loopback only; 404 in
         production - party/native/Sources/Support.swift StaticRoot.productionFiles) that
         renders the identical engine-produced voters field through its own JS twin
         (host.js:538-553); it is exercised here as the actual supported operator render path,
         explicitly NOT a stand-in for native SwiftUI rendering.

Uses the compiled native test-loopback binary (party/native/build.sh), driven entirely over
real HTTP/SSE (tests/support.py Api + SSEClient) plus real headless-Chrome tabs for the DOM
checks, serving the checked-out party/web source directly (not the stale majlis-ios/PartyWeb
bundle - same pre-existing, out-of-scope staleness bluff-native-compiler-v6/HANDOFF.md already
flagged).

  python3 bluff_semantic_privacy_v7.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR
Needs Google Chrome and python websocket-client. Exit 0 iff every check passes.
"""
import hashlib, json, os, re, socket, subprocess, sys, tempfile, threading, time
import urllib.error, urllib.request

results = {
    "label": "Correction v7: role/phase-aware semantic privacy oracle (bluff_privacy.scan) "
              "actually run over raw GET /state AND raw SSE at submission/voting, post-vote, "
              "both reconnect boundaries and the next-round boundary (EN+AR); a planted "
              "pre-reveal voter-disclosure payload the SAME scanner rejects; exact structural "
              "voter-name->option mapping on operator/display real rendered DOM (EN+AR); and "
              "the native-SwiftUI-render capability gap stated explicitly.",
    "checks": [],
}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


# -------------------------------------------------------------- shared structural voter parser
# Generalises v6's parse_voted_by_per_option (party/native/harness/bluff_voter_reveal_evidence_v6.py)
# to the three distinct "Voted by: ..." markup shapes actually produced by the three JS renderers
# that all consume the identical game.lastResult.voters field:
#   play.js   (player) : <li class="bluff-option...">...<span class="muted small">Voted by: a, b</span>...</li>
#   host.js   (operator): <li class="who-row...">...<div class="who-voters muted small" ...>Voted by: a, b</div>...</li>
#   tv.js     (display) : <li class="tv-who-card...">...<span class="tv-sub" ...>Voted by: a, b</span>...</li>
# All three key an option's li/div solely by the option's own TEXT (never optionId, which is
# never put in the DOM by design pre- or post-reveal) - the one stable anchor across all three.
SURFACE_LI = {
    "player": re.compile(r'<li class="bluff-option[^"]*">(.*?)</li>', re.S),
    "operator": re.compile(r'<li class="who-row[^"]*">(.*?)</li>', re.S),
    "display": re.compile(r'<li class="tv-who-card[^"]*">(.*?)</li>', re.S),
}
VOTED_BY_RE = re.compile(r"Voted by:\s*([^<]*)<")


def parse_voted_by(surface, dom_html, option_text_by_id):
    """Returns {optionId: [name, ...]} read off the REAL rendered DOM of ``surface``
    ("player"/"operator"/"display"), keyed back to optionId via the option's own text."""
    out = {}
    text_to_id = {v: k for k, v in option_text_by_id.items()}
    for li in SURFACE_LI[surface].findall(dom_html):
        oid = None
        for text, tid in text_to_id.items():
            if text and text in li:
                oid = tid
                break
        if oid is None:
            continue
        m = VOTED_BY_RE.search(li)
        names = [n.strip() for n in m.group(1).split(",")] if m else []
        out[oid] = [n for n in names if n]
    return out


def inject_voter_name_leak(surface, dom_html, fake_voter_name, real_option_text):
    """[gapC negative control, DOM layer] Mirrors v6's inject_semantic_leak, generalised to
    all three surfaces: plants a voter name onto the TRUE-ANSWER option's own li, proving
    parse_voted_by + the comparison actually catch a mismatch rather than vacuously agreeing."""
    rx = SURFACE_LI[surface]
    for m in rx.finditer(dom_html):
        li = m.group(1)
        if real_option_text and real_option_text in li:
            vm = VOTED_BY_RE.search(li)
            if vm:
                insert_at = m.start(1) + vm.start(1)
                return dom_html[:insert_at] + fake_voter_name + ", " + dom_html[insert_at:]
            insert_at = m.end(1)
            planted = f'<span class="muted small">Voted by: {fake_voter_name}</span>'
            return dom_html[:insert_at] + planted + dom_html[insert_at:]
    return dom_html


# ------------------------------------------------------------------- planted wire-level leak
def plant_authorship_leak(payload, viewer, truth):
    """[gapB] Deep-copies a REAL captured pre-reveal payload for ``viewer`` and plants the
    exact class of disclosure the brief named: authorId on every pre-reveal option (what a
    buggy renderer/engine would leak if it forgot the reveal gate on authorship), so the
    SAME scan() call used for the real evidence above is re-run against it and must reject it.
    Only meaningful pre-reveal (post-reveal, authorId is on the allow-list)."""
    poisoned = json.loads(json.dumps(payload))
    game = poisoned.get("game") or {}
    opts = game.get("options")
    planted = False
    if isinstance(opts, list):
        truth_options = {o["optionId"]: o.get("authorId") for o in (truth.get("options") or [])}
        for o in opts:
            if isinstance(o, dict) and "optionId" in o and "authorId" not in o:
                o["authorId"] = truth_options.get(o["optionId"])
                planted = True
    return poisoned, planted


def main():
    repo, scratch, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "party", "web", "tests"))
    sys.path.insert(0, os.path.join(repo, "tests"))
    import real_e2e as base  # Tab, CHROME, PHONE
    import bluff_privacy as bp
    from support import Api, SSEClient, load_fixture

    pack = load_fixture("bluff")

    build_out = os.path.join(scratch, "build")
    build_log = open(os.path.join(out, "build.log"), "w")
    r = subprocess.run(["sh", os.path.join(repo, "party", "native", "build.sh"), build_out],
                        cwd=repo, env=dict(os.environ), stdout=build_log, stderr=subprocess.STDOUT)
    check("build.sh exit 0 (test-loopback binary built from THIS checkout)", r.returncode == 0, r.returncode)
    binary = os.path.join(build_out, "majlis-party-native-test")
    results["binary_sha256"] = sha(binary) if r.returncode == 0 else None

    web_dir = os.path.join(repo, "party", "web")
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    slog = open(os.path.join(out, "server-stderr.log"), "w")
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir,
           "--content-dir", content_dir, "--exit-on-stdin-eof", "--access-log",
           "--heartbeat", "0.2", "--request-rate", "2000", "--request-burst", "5000",
           "--create-per-minute", "6000", "--create-burst", "500",
           "--join-per-minute", "6000", "--join-burst", "500",
           "--action-rate", "2000", "--action-burst", "5000"]
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    banner_line = srv.stdout.readline()

    def drain():
        for _ in iter(srv.stdout.readline, b""):
            pass
    threading.Thread(target=drain, daemon=True).start()
    try:
        banner = json.loads(banner_line) if banner_line else {}
    except Exception:
        banner = {}
    check("test-loopback banner: surface=test-loopback, serving the current party/web source",
          banner.get("surface") == "test-loopback" and banner.get("event") == "listening", banner)

    api = Api(port)
    base_url = f"http://127.0.0.1:{port}"
    chrome = None
    tabs = {}
    sse_clients = []

    def new_sse(path, token):
        c = SSEClient(port, path, token=token)
        sse_clients.append(c)
        return c

    try:
        profile = tempfile.mkdtemp(prefix="majlis-bluff-semantic-privacy-v7-")
        dport_s = socket.socket(); dport_s.bind(("127.0.0.1", 0)); dport = dport_s.getsockname()[1]; dport_s.close()
        chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                                   "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                   "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version", timeout=2).read())
                browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("headless Chrome reachable over CDP", browser is not None)

        def new_tab(name, vp):
            ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
            tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.viewport(vp)
            tabs[name] = t
            return t

        def seed_credential(t, role, token, code):
            t.goto(base_url + "/index.html")
            rec = json.dumps({"token": token, "savedAt": int(time.time() * 1000)})
            t.eval(f"(() => {{ localStorage.setItem('majlisParty.v1.{role}.{code}', {json.dumps(rec)}); return true; }})()")

        def run_round(language, names, label):
            created = api.create_room()
            check(f"[{label}] POST /api/rooms returns code+hostToken+displayToken (test-loopback only)",
                  created.status == 201 and set(created.json) == {"code", "hostToken", "displayToken", "revision"}, created.text[:200])
            code = created.json["code"]
            host_token, display_token = created.json["hostToken"], created.json["displayToken"]

            operator = new_tab(f"{label}-operator", base.PHONE)
            seed_credential(operator, "operator", host_token, code)
            operator.goto(f"{base_url}/host.html#code={code}")
            operator.wait("document.body.textContent.includes('Choose a game')", what="operator lobby")

            display = new_tab(f"{label}-display", base.PHONE)
            seed_credential(display, "display", display_token, code)
            display.goto(f"{base_url}/tv.html#code={code}")

            pid, tokens, players = {}, {}, {}
            for nm in names:
                p = new_tab(f"{label}-{nm}", base.PHONE)
                p.goto(f"{base_url}/play.html?code={code}")
                p.type_into("#join-name", nm)
                p.click("__btn('Join game')", "Join game")
                p.wait("document.body.textContent.includes('You’re in')", what="lobby")
                rec = p.eval(f"JSON.parse(localStorage.getItem('majlisParty.v1.player.{code}'))")
                pid[nm], tokens[nm], players[nm] = rec["playerId"], rec["token"], p

            operator.click("__btn('Bluff')", "select Bluff mode")
            operator.wait("!!document.querySelector('.mode-tile.selected')", what="bluff selected")
            operator.eval(
                "(() => { const l = document.querySelector('#bluff-language'); if (l) { l.value = %r; "
                "l.dispatchEvent(new Event('change', { bubbles: true })); } })()" % language)
            operator.eval("(() => { const s = document.querySelector('#bluff-rounds'); if (s) { s.value = '2'; "
                           "s.dispatchEvent(new Event('change', { bubbles: true })); } })()")
            operator.click("__btn('Start Bluff')", "start bluff")
            for nm, p in players.items():
                p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} submission form")

            # -------------------------------------------------------------------------- [gapA]
            def oracle_boundary(stage, played_questions_en=()):
                """Scans the REAL current state of every real surface, over BOTH raw GET
                /state and one raw SSE "state" frame, against bp.scan() built from the
                operator's own private snapshot - never from the payload under test.
                ``played_questions_en`` must list any ENGLISH question text already revealed
                in an earlier round THIS game (e.g. round 1's, once round 2 has started):
                build_truth treats any item not in that set as a still-secret bank item, so a
                prior round's own already-revealed lastResult would otherwise be flagged as a
                false-positive content-bank leak - that is a harness bookkeeping fact, not
                something bp.scan can read off the payload under test."""
                hs = api.state(code, host_token).json
                truth = bp.build_truth(hs, pack, played_questions_en, list(tokens.values()) + [host_token, display_token])
                leaks = bp.scan(hs, {"role": "operator"}, truth, surface="state")
                check(f"[{label}][{stage}][gapA] operator GET /state: oracle finds zero leaks", not leaks, leaks)
                sse = new_sse(f"/api/rooms/{code}/events", host_token)
                item = sse.next_state(timeout=8)
                leaks = bp.scan(item["json"], {"role": "operator"}, truth, surface="sse")
                check(f"[{label}][{stage}][gapA] operator SSE state frame: oracle finds zero leaks", not leaks, leaks)
                sse.close()
                for nm in names:
                    pst = api.state(code, tokens[nm]).json
                    leaks = bp.scan(pst, {"role": "player", "id": pid[nm], "token": tokens[nm]}, truth, surface="state")
                    check(f"[{label}][{stage}][gapA] {nm} GET /state: oracle finds zero leaks", not leaks, leaks)
                    sse = new_sse(f"/api/rooms/{code}/events", tokens[nm])
                    item = sse.next_state(timeout=8)
                    leaks = bp.scan(item["json"], {"role": "player", "id": pid[nm], "token": tokens[nm]}, truth, surface="sse")
                    check(f"[{label}][{stage}][gapA] {nm} SSE state frame: oracle finds zero leaks", not leaks, leaks)
                    sse.close()
                dst = api.state(code, display_token).json
                leaks = bp.scan(dst, {"role": "display"}, truth, surface="state")
                check(f"[{label}][{stage}][gapA] display GET /state: oracle finds zero leaks", not leaks, leaks)
                sse = new_sse(f"/api/rooms/{code}/events", display_token)
                item = sse.next_state(timeout=8)
                leaks = bp.scan(item["json"], {"role": "display"}, truth, surface="sse")
                check(f"[{label}][{stage}][gapA] display SSE state frame: oracle finds zero leaks", not leaks, leaks)
                sse.close()
                return hs, truth

            oracle_boundary("submission-empty")

            fakes = {nm: f"{label} fake answer from {nm}" for nm in names}
            for nm, p in players.items():
                p.type_into("#bluff-answer", fakes[nm])
                p.click("__btn('Submit fake answer')", f"{nm} submits fake answer")
                p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} submitted")
            hs_sub, truth_sub = oracle_boundary("submission-full")

            operator.click("__btn('Open voting')", "open voting")
            for nm, p in players.items():
                p.wait("!!document.querySelector('.bluff-option-btn')", what=f"{nm} voting options")
            display.wait("!!document.querySelectorAll('.tv-who-card').length", what="display voting options")
            hs_vote, truth_vote = oracle_boundary("voting")

            # ---------------------------------------------------------------- [gapB]
            # game.options only exists once voting is open (build_truth's own votingOpen =
            # game.options is not None), so the planted payload must be captured here -
            # pre-reveal, voting open - not during the submission phase, when there is no
            # game.options list on the wire yet for authorId to be planted onto.
            player0 = names[0]
            own_state_pre = api.state(code, tokens[player0]).json
            poisoned, planted = plant_authorship_leak(own_state_pre, player0, truth_vote)
            check(f"[{label}][gapB] planted payload actually differs from the one real reveal-gated field (authorId)", planted)
            leaks_before = bp.scan(own_state_pre, {"role": "player", "id": pid[player0], "token": tokens[player0]}, truth_vote, surface="state")
            leaks_after = bp.scan(poisoned, {"role": "player", "id": pid[player0], "token": tokens[player0]}, truth_vote, surface="state")
            check(f"[{label}][gapB] the real captured pre-reveal payload itself is clean (baseline for the control)", not leaks_before, leaks_before)
            check(f"[{label}][gapB] the SAME scan() call REJECTS the planted pre-reveal authorship leak with an authorship/truth-metadata finding "
                  f"(proves the oracle has teeth on real wire data, not just a DOM substring or a synthetic unit fixture)",
                  bool(leaks_after) and any(f.rule in ("authorship", "truth-metadata") for f in leaks_after),
                  [f.as_dict() for f in leaks_after])

            # ---------------------------------------------------------------- reconnect #1 (post-submit-equivalent
            # here, since voting is already open; this is the post-submit/pre-vote boundary for whichever
            # player reconnects, exercised at the wire level with the oracle, not just a seat-continuity check)
            reload_target = names[0]
            before_pid = pid[reload_target]
            players[reload_target].reload()
            players[reload_target].wait("!!document.querySelector('.bluff-option-btn')", what=f"{reload_target} reconnected pre-vote")
            after_pid = players[reload_target].eval(f"JSON.parse(localStorage.getItem('majlisParty.v1.player.{code}')).playerId")
            check(f"[{label}][gapA] {reload_target} reload reconnects into the SAME seat before voting", after_pid == before_pid,
                  {"before": before_pid, "after": after_pid})
            oracle_boundary("post-submit-reconnect")

            for nm, p in players.items():
                p.eval("(() => { const b = [...document.querySelectorAll('.bluff-option-btn')].find(x => !x.disabled); b.click(); })()")
                p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} voted")

            # ---------------------------------------------------------------- reconnect #2 (post-vote, pre-reveal)
            reload_target2 = names[1]
            before_pid2 = pid[reload_target2]
            players[reload_target2].reload()
            players[reload_target2].wait("document.body.textContent.includes('Waiting for everyone else')",
                                          what=f"{reload_target2} reconnected post-vote")
            after_pid2 = players[reload_target2].eval(f"JSON.parse(localStorage.getItem('majlisParty.v1.player.{code}')).playerId")
            check(f"[{label}][gapA] {reload_target2} reload reconnects into the SAME seat after voting, before reveal",
                  after_pid2 == before_pid2, {"before": before_pid2, "after": after_pid2})
            oracle_boundary("post-vote-reconnect")

            operator.click("__btn('Reveal')", "reveal")
            for nm, p in players.items():
                p.wait("document.body.textContent.includes('scored')", what=f"{nm} reveal view")
            display.wait("document.body.textContent.includes('real answer was')", what="display reveal view")
            hs_rev = api.state(code, host_token).json
            last = hs_rev["game"]["lastResult"]
            options = last["options"]
            option_text_by_id = {o["optionId"]: o["text"] for o in options}

            # ---------------------------------------------------------------- [gapC]
            engine_voters = last["voters"]
            expected = {}
            for pid_, oid in engine_voters.items():
                nm = next((n for n, i in pid.items() if i == pid_), pid_)
                expected.setdefault(oid, []).append(nm)
            expected_sets = {oid: sorted(v) for oid, v in expected.items() if v}
            for surface, tab in (("operator", operator), ("display", display)):
                dom = tab.html()
                rendered = parse_voted_by(surface, dom, option_text_by_id)
                rendered_sets = {oid: sorted(v) for oid, v in rendered.items() if v}
                check(f"[{label}][gapC] real rendered {surface} DOM: exact structural voter NAME->OPTION mapping matches the engine's own lastResult.voters "
                      f"(not just 'Voted by' substring presence)",
                      rendered_sets == expected_sets, {"rendered": rendered_sets, "expected": expected_sets})
            # retained for parity, same shared parser, player surface (v6 proved this per-surface;
            # this reuses the shared generaliser rather than recounting it as new scope)
            dom_p = players[names[0]].html()
            rendered_p = parse_voted_by("player", dom_p, option_text_by_id)
            check(f"[{label}][gapC] real rendered player DOM: exact structural voter NAME->OPTION mapping (shared parser, player surface)",
                  {oid: sorted(v) for oid, v in rendered_p.items() if v} == expected_sets or not expected_sets,
                  {"rendered": rendered_p})

            # ---------------------------------------------------------------- [gapC negative control]
            true_opt_text = option_text_by_id.get(last["trueOptionId"])
            op_dom_poisoned = inject_voter_name_leak("operator", operator.html(), "Totally Wrong Name", true_opt_text)
            poisoned_rendered = parse_voted_by("operator", op_dom_poisoned, option_text_by_id)
            poisoned_for_true = sorted(poisoned_rendered.get(last["trueOptionId"], []))
            expected_for_true = sorted(expected.get(last["trueOptionId"], []))
            check(f"[{label}][gapC] planted voter-name leak on the operator DOM IS rejected by the same structural comparison",
                  poisoned_for_true != expected_for_true and "Totally Wrong Name" in poisoned_for_true,
                  {"poisoned": poisoned_for_true, "expected": expected_for_true})

            oracle_boundary("reveal")

            # ---------------------------------------------------------------- next-round boundary
            round1_question_en = last["question"]["en"]
            operator.click("__btn('Next round')", "round.next")
            for nm, p in players.items():
                p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} round2 submission form")
            oracle_boundary("next-round-submission-empty", played_questions_en=(round1_question_en,))

            api.action(code, host_token, "room.end")
            for c in sse_clients:
                c.close()
            sse_clients.clear()
            return True

        run_round("en", ["Aisha", "Omar", "Noora"], "en-round")
        run_round("ar", ["Fatima", "Yusuf", "Khalid"], "ar-round")

        check("every page script ran on every tab without a JS exception",
              not any(t.page_errors() for t in tabs.values()),
              {k: t.page_errors()[:2] for k, t in tabs.items() if t.page_errors()})

    except Exception:
        import traceback
        check("run completed without an exception", False, traceback.format_exc()[-2000:])
    finally:
        for c in sse_clients:
            try: c.close()
            except Exception: pass
        for t in list(tabs.values()):
            try: t.ws.close()
            except Exception: pass
        if chrome is not None:
            chrome.terminate()
            try: chrome.wait(10)
            except Exception: chrome.kill()
        try:
            srv.stdin.close()
            srv.wait(10)
        except Exception:
            srv.kill()
        results["server_exit"] = srv.returncode

    # ---------------------------------------------------------------- stated capability gap
    results["capability_gap"] = (
        "Native SwiftUI OperatorView.swift cannot be rendered in this CLT-only route (no iOS "
        "simulator/device runtime available; only `swiftc -typecheck` against the extracted "
        "construct, already exercised and recorded exit 0 in review-evidence/review-identity.json "
        "from bluff-native-compiler-v6). host.html above is a separate, real, test-loopback-only "
        "web operator surface (production 404s host.html/tv.html by design - "
        "party/native/Sources/Support.swift StaticRoot.productionFiles) driven over the identical "
        "engine/HTTP/SSE contract and exercised here as the actual supported operator render path; "
        "it is not a substitute for, and is not claimed to be, native SwiftUI rendering."
    )
    p_ = sum(1 for c in results["checks"] if c["pass"])
    f_ = len(results["checks"]) - p_
    results["summary"] = {"pass": p_, "fail": f_, "total": len(results["checks"])}
    json.dump(results, open(os.path.join(out, "bluff-semantic-privacy-v7-results.json"), "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps(results["summary"]))
    sys.exit(0 if f_ == 0 and p_ > 0 else 1)


if __name__ == "__main__":
    main()
