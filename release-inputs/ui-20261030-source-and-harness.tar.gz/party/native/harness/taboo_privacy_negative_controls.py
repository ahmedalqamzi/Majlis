"""Exact role-allowlist privacy oracle (tests/taboo_privacy.envelope_leaks)
run against the REAL compiled native host, plus planted role-specific
negative controls.

For the baseline and for every mutant, the harness copies party/core +
party/native into a scratch tree (the checkout is never modified), applies
exactly one single-occurrence textual mutation (none for the baseline),
builds with the real build.sh, launches the test-loopback host on a dynamic
port and drives one scripted Taboo game over real HTTP + SSE:

  operator + display + 4 roster players (A1 Aisha, B1 Omar, A2 Noora,
  B2 Khalid) with an SSE stream each; a late spectator (Layla) joining while
  playing and a second one (Hamad) while paused, both with SSE streams;
  three turns (so a former clue-giver exists on each team), rejected
  receipts (spectator read-only, opponent forbidden), an anonymous join
  error (name taken), spectator/player resume envelopes and a room end.

A second and third short script (ErrorDrive) run on hosts started with
``--token-ttl`` / ``--room-max-age`` of a few seconds: a 4-player game with a
late spectator and a former clue-giver, one SSE stream per role (operator,
display, clue_giver, teammate, opponent, former_giver, spectator), then
every stream must deliver the live SSE ``error`` frame (``token_expired`` /
``room_expired``); the HTTP error bodies returned afterwards by GET state and
by a rejected stream open are recorded as well.

EVERY envelope received is checked with the exact oracle for the viewer's
role at that moment: create/join/resume bodies, accepted and rejected
receipts, HTTP error bodies, GET state snapshots, every SSE ``state`` frame
and every SSE ``error`` frame (role context is taken from the revision the
frame carries). The expected ``lastResolved`` word is the exact historical
value at that revision (``NO_RESOLVED_WORD`` before anything resolved, so a
non-null ``lastResolved`` is then a leak), and submitted guess texts are
frozen by revision (``guess_log``: a frame may only show guesses accepted
at or before its own revision). Roles: operator, display, clue_giver
(current), teammate, opponent, former_giver (a player who gave clues on an
earlier turn and is not the current giver), spectator, anonymous.

The baseline must produce zero findings anywhere. A mutant control passes
only when (a) the oracle flags every targeted role, (b) it flags no
non-targeted role, and (c) the findings occur in the expected envelope
kinds. The two reviewer probe payloads (operator ``debugLeak``, guesser
``deckMetadata``) are also replayed through the same oracle.

    python3 -I -B party/native/harness/taboo_privacy_negative_controls.py SCRATCH_DIR EVIDENCE_DIR [--only NAME ...]

Exit 0 iff the baseline is clean, both probes are detected and every
control passes.
"""
import argparse
import json
import os
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, HERE)

from taboo_harness_common import build_binary, start_native, stop_native, taboo_content_dir  # noqa: E402

CARD = "{ word: state.card.word, forbidden: state.card.forbidden.slice() }"
GUESSES_LINE = "guesses: state.guesses.map(function (g) { return { playerId: g.playerId, text: g.text }; }),"
LAST_RESOLVED_LINE = "lastResolved: state.lastResolved !== null ? deepcopy(state.lastResolved) : null,"
SSE_ERROR_LINE = 'return { kind: "error", frame: "event: error\\ndata: " + dumps({ ok: false, error: errorBody(ev[1]) }) + "\\n\\n" };'
NOT_FORMER = ["operator", "display", "clue_giver", "teammate", "opponent", "spectator"]
ALL_SNAPSHOT_ROLES = ["operator", "display", "clue_giver", "teammate", "opponent", "former_giver", "spectator"]

# name: (file, old, new, targeted roles, expected envelope kinds)
MUTANTS = {
    "teammate-opponent-card": (
        "core/majlis-core.js",
        'view.you = { role: "guesser", team: teamOf(state, me) };',
        'view.you = { role: "guesser", team: teamOf(state, me), card: state.card !== null ? ' + CARD + ' : null };',
        ["teammate", "opponent", "former_giver"], ["snapshot"]),
    "former-giver-card": (
        "core/majlis-core.js",
        'view.you = { role: "guesser", team: teamOf(state, me) };',
        'view.you = { role: "guesser", team: teamOf(state, me) };\n'
        '        (function () { var t = teamOf(state, me), r = state.teams[t], prev = r[(state.clueIdx[t] + r.length - 1) % r.length];\n'
        '          if (t !== state.activeTeam && state.turnNo >= 2 && prev === me && state.card !== null) view.you.card = ' + CARD + '; })();',
        ["former_giver"], ["snapshot"]),
    "clue-giver-future-card": (
        "core/majlis-core.js",
        'view.you = { role: "clue_giver", team: teamOf(state, me), card: state.card !== null ? ' + CARD + ' : null };',
        'view.you = { role: "clue_giver", team: teamOf(state, me), card: state.card !== null ? (state.deck.length ? { word: state.deck[0].word, forbidden: state.deck[0].forbidden.slice() } : ' + CARD + ') : null };',
        ["clue_giver"], ["snapshot"]),
    "spectator-card": (
        "core/majlis-core.js",
        'view.you = { role: "spectator" };',
        'view.you = { role: "spectator", card: state.card !== null ? ' + CARD + ' : null };',
        ["spectator"], ["snapshot"]),
    "display-card": (
        "core/majlis-core.js",
        '        view.you = { role: "spectator" };\n      }\n      return view;',
        '        view.you = { role: "spectator" };\n      } else if (role === "display") {\n'
        '        view.you = { role: "display", card: state.card !== null ? ' + CARD + ' : null };\n      }\n      return view;',
        ["display"], ["snapshot"]),
    "guesser-deck-metadata": (
        "core/majlis-core.js",
        'view.you = { role: "guesser", team: teamOf(state, me) };',
        'view.you = { role: "guesser", team: teamOf(state, me) };\n'
        '        view.deckMetadata = state.deck.slice(0, 2).map(function (c) { return { id: c.id, difficulty: 3 }; });',
        ["teammate", "opponent", "former_giver"], ["snapshot"]),
    "operator-future-deck": (
        "core/majlis-core.js",
        'view.you = { role: "operator", card: state.card !== null ? ' + CARD + ' : null };',
        'view.you = { role: "operator", card: state.card !== null ? ' + CARD + ' : null, nextWord: state.deck.length ? state.deck[0].word : null };',
        ["operator"], ["snapshot"]),
    "lastresolved-forbidden": (
        "core/majlis-core.js",
        's.lastResolved = { word: wordWas, outcome: outcome, solverId: solverId, teamAward: awardTeam || null };',
        's.lastResolved = { word: wordWas, outcome: outcome, solverId: solverId, teamAward: awardTeam || null, forbidden: s.card.forbidden.slice() };',
        ALL_SNAPSHOT_ROLES, ["snapshot"]),
    "spectator-join-envelope": (
        "core/majlis-core.js",
        "if (isSpectator(room.state, playerId)) joinedBody.spectator = true;",
        "if (isSpectator(room.state, playerId)) { joinedBody.spectator = true; joinedBody.hint = room.state.game && room.state.game.card ? room.state.game.card.word : null; }",
        ["spectator"], ["join"]),
    "spectator-resume-envelope": (
        "core/majlis-core.js",
        "if (isSpectator(room.state, principal.playerId)) resumedBody.spectator = true;",
        "if (isSpectator(room.state, principal.playerId)) { resumedBody.spectator = true; resumedBody.forbidden = room.state.game && room.state.game.card ? room.state.game.card.forbidden.slice() : null; }",
        ["spectator"], ["join"]),
    "rejected-receipt-card-id": (
        "core/majlis-core.js",
        "entry = [statusFor(err), { accepted: false, revision: room.revision, error: errorBody(err) }];",
        "entry = [statusFor(err), { accepted: false, revision: room.revision, error: errorBody(err), cardId: room.state.game && room.state.game.card ? room.state.game.card.id : null }];",
        ["spectator", "opponent"], ["receipt"]),
    "join-error-envelope": (
        "native/majlis-native.js",
        "        var r = S.manager.join(room, body, t, now, new C.EntropyPool(entropy));\n        return resp(r[0], r[1]);",
        "        var r;\n        try { r = S.manager.join(room, body, t, now, new C.EntropyPool(entropy)); }\n"
        "        catch (e) { if (e instanceof PartyError && room.state.game && room.state.game.card) return resp(statusFor(e.code), { ok: false, error: errorBody(e.code), word: room.state.game.card.word }); throw e; }\n"
        "        return resp(r[0], r[1]);",
        ["anonymous"], ["error"]),
    # Reviewer's exact live mutant (DECISION.md defect 1, privacy-mutant.diff):
    # while nothing has resolved, project the NEXT (future) card's word as a
    # schema-valid skipped lastResolved.
    "future-resolved": (
        "core/majlis-core.js",
        LAST_RESOLVED_LINE,
        'lastResolved: state.lastResolved !== null ? deepcopy(state.lastResolved) : (state.deck.length ? '
        '{ word: state.deck[0].word, outcome: "skip", solverId: null, teamAward: null } : null),',
        NOT_FORMER, ["snapshot"]),
    # A guess that is only submitted LATER (the first card's word, guessed
    # correctly by A2 later in turn 1) echoed into earlier frames. A final
    # global guess set would allow it; the revision-frozen allowance must not.
    "early-frame-later-guess": (
        "core/majlis-core.js",
        GUESSES_LINE,
        GUESSES_LINE[:-1] + '.concat(state.turnNo === 1 && state.cardEpoch === 0 && state.card !== null && '
        'state.lastResolved === null ? [{ playerId: state.clueGiverId, text: state.card.word }] : []),',
        NOT_FORMER, ["snapshot"]),
    # Live SSE error frame carrying the active card word.
    "sse-error-envelope": (
        "native/majlis-native.js",
        SSE_ERROR_LINE,
        SSE_ERROR_LINE.replace("error: errorBody(ev[1]) }", "error: errorBody(ev[1]), word: session.room.state.game && "
                               "session.room.state.game.card ? session.room.state.game.card.word : null }"),
        ["operator", "display", "clue_giver", "teammate", "opponent", "former_giver", "spectator"], ["error"]),
}

PROBE_ITEMS = [{"word": "privatewordalpha", "forbidden": ["forbiddenalpha"], "id": "authored-card-007", "difficulty": 3}]
PROBES = [
    ("operator", {"game": {"you": {"role": "operator", "card": {"word": "privatewordalpha", "forbidden": ["forbiddenalpha"]}},
                           "debugLeak": "privatewordalpha"}}),
    ("guesser", {"game": {"you": {"role": "guesser"}, "deckMetadata": [{"id": "authored-card-007", "difficulty": 3}]}}),
]
# Reviewer's synthetic probe (privacy-probe.json): nothing resolved yet, the
# active card is Beach, lastResolved carries the future card Coffee.
FUTURE_PROBE_ITEMS = [{"id": "tab-001", "word": "Beach", "forbidden": ["sand", "sea", "sun", "swim", "towel"]},
                      {"id": "tab-002", "word": "Coffee", "forbidden": ["drink", "cup", "caffeine", "morning", "bean"]}]
FUTURE_PROBE = {"game": {"lastResolved": {"word": "Coffee", "outcome": "skip", "solverId": None, "teamAward": None}}}


class Drive(object):
    """One scripted game; collects every envelope with its role context."""

    def __init__(self, port, items):
        import support
        self.support = support
        self.api = support.Api(port)
        self.port = port
        self.items = items
        self.records = []        # {transport, kind, who, role, payload, ctx, drive}
        self.contexts = []       # (revision, ctx); ctx_at picks the highest revision <= R
        self.streams = {}
        self.guess_log = []      # (accepted receipt revision, submitted text)
        self.drive_name = "main"
        self.former = set()
        self.last_word = None
        self.active = None
        self.who_ids = {}
        self.tokens = {}
        self.spectators = set()

    # ---- context tracking
    def snapshot_ctx(self):
        op = self.api.state(self.code, self.tokens["operator"])
        assert op.status == 200, op.text
        snap = op.json
        g = snap.get("game")
        ctx = {"revision": snap["revision"], "giver": None, "activeTeam": None, "teams": None,
               "active": None, "lastWord": self.last_word, "former": sorted(self.former)}
        if g:
            ctx.update(giver=g["clueGiverId"], activeTeam=g["activeTeam"], teams=g["teams"])
            card = (g.get("you") or {}).get("card")
            ctx["active"] = {"word": card["word"], "forbidden": list(card["forbidden"])} if card else None
            self.active = ctx["active"]
        self.contexts.append((snap["revision"], ctx))
        return snap, ctx

    def ctx_at(self, revision):
        best, best_rev = None, None
        for rev, ctx in self.contexts:
            if rev <= revision and (best_rev is None or rev >= best_rev):
                best, best_rev = ctx, rev
        return best or {"revision": 0, "giver": None, "teams": None, "active": None, "lastWord": None, "former": []}

    def role_of(self, who, ctx):
        if who in ("operator", "display"):
            return who
        pid = self.who_ids[who]
        if who in self.spectators:
            return "spectator"
        if ctx["teams"] is None:
            return "teammate"     # pre-game lobby member (no game object)
        if pid == ctx["giver"]:
            return "clue_giver"
        if pid in ctx["former"]:
            return "former_giver"
        team = "A" if pid in ctx["teams"]["A"] else "B"
        return "teammate" if team == ctx["activeTeam"] else "opponent"

    def record(self, transport, kind, who, role, payload, ctx):
        self.records.append({"transport": transport, "kind": kind, "who": who, "role": role,
                             "payload": payload, "ctx": ctx, "drive": self.drive_name})

    # ---- request helpers
    def act(self, who, kind, payload=None, round_id=None, resolves=False):
        """Submit an action; after an accepted one, refresh the role context
        (resolves=True: the active card becomes the expected lastResolved)."""
        word = self.active["word"] if (resolves and self.active) else None
        r = self.api.action(self.code, self.tokens[who], kind, round_id=round_id, payload=payload or {})
        if not isinstance(r.json, dict) or "accepted" not in r.json:
            raise AssertionError("action %s by %s: unexpected response %d %s" % (kind, who, r.status, r.text))
        if r.json["accepted"] is True:
            if resolves:
                self.last_word = word
            if kind == "taboo.guess":
                self.guess_log.append((r.json["revision"], (payload or {})["text"]))
            if kind == "room.end":
                self.active = None
            _, ctx = self.snapshot_ctx()
            # The state after this action holds from the receipt's revision on.
            self.contexts.append((r.json["revision"], ctx))
        ctx = self.ctx_at(10 ** 9)
        self.record("http", "receipt", who, self.role_of(who, ctx), r.json, ctx)
        return r

    def join(self, who, name, spectator):
        r = self.api.join(self.code, name)
        assert r.status == 201, r.text
        self.tokens[who] = r.json["playerToken"]
        self.who_ids[who] = r.json["playerId"]
        if spectator:
            self.spectators.add(who)
        self.record("http", "join", who, "spectator" if spectator else "teammate", r.json, self.ctx_at(10 ** 9))
        return r

    def open_stream(self, who):
        self.streams[who] = self.support.SSEClient(self.port, "/api/rooms/%s/events" % self.code, token=self.tokens[who])
        assert self.streams[who].status == 200

    def checkpoint(self, label):
        snap, ctx = self.snapshot_ctx()
        for who in list(self.tokens):
            r = self.api.state(self.code, self.tokens[who])
            assert r.status == 200, (who, r.text)
            role = self.role_of(who, ctx)
            self.record("http", "snapshot", who, role, r.json, dict(ctx, label=label))
        return snap

    def drain_streams(self):
        """Wait until every stream delivered the latest revision; record every frame."""
        final_rev = self.api.state(self.code, self.tokens["operator"]).json["revision"]
        for who, stream in self.streams.items():
            deadline = time.time() + 10
            last = -1
            while last < final_rev:
                if time.time() > deadline:
                    raise AssertionError("SSE %s did not reach revision %d" % (who, final_rev))
                item = stream.next(timeout=max(0.1, deadline - time.time()))
                if item is None:
                    raise AssertionError("SSE %s closed" % who)
                if item.get("event") == "state":
                    snap = item["json"]
                    last = snap["revision"]
                    ctx = self.ctx_at(snap["revision"])
                    self.record("sse", "snapshot", who, self.role_of(who, ctx), snap, ctx)
                elif item.get("event") == "error":
                    ctx = self.ctx_at(10 ** 9)
                    self.record("sse", "error", who, self.role_of(who, ctx), item["json"], ctx)

    # ---- script
    def run(self):
        api = self.api
        r = api.create_room(minPlayers=4, maxPlayers=12, operatorName="Host")
        assert r.status == 201, r.text
        self.code = r.json["code"]
        self.tokens["operator"], self.tokens["display"] = r.json["hostToken"], r.json["displayToken"]
        self.record("http", "create", "operator", "anonymous", r.json, None)
        self.contexts.append((r.json["revision"], {"revision": r.json["revision"], "giver": None, "teams": None,
                                                    "active": None, "lastWord": None, "former": [], "activeTeam": None}))
        for who, name in (("A1", "Aisha"), ("B1", "Omar"), ("A2", "Noora"), ("B2", "Khalid")):
            self.join(who, name, False)
        for who in ("operator", "display", "A1", "B1", "A2", "B2"):
            self.open_stream(who)
        self.act("operator", "room.set_mode", {"mode": "taboo"})
        self.act("operator", "room.start", {"modeConfig": {"turnSeconds": 120}})
        snap = self.checkpoint("t1-clue")
        rid = snap["roundId"]
        assert snap["game"]["clueGiverId"] == self.who_ids["A1"], "rotation: A1 gives first"

        # late spectator while playing
        self.join("S1", "Layla", True)
        self.snapshot_ctx()
        self.open_stream("S1")
        r = self.act("S1", "taboo.guess", {"cardEpoch": snap["game"]["cardEpoch"], "text": "spectator try"}, rid)
        assert r.status == 403 and r.json["error"]["code"] == "spectator_read_only", r.text
        r = self.act("B1", "taboo.guess", {"cardEpoch": snap["game"]["cardEpoch"], "text": "opponent try"}, rid)
        assert r.status == 403 and r.json["error"]["code"] == "forbidden", r.text
        e = api.join(self.code, "aisha")
        assert e.status == 409 and e.json["error"]["code"] == "name_taken", e.text
        self.record("http", "error", "anon", "anonymous", e.json, self.ctx_at(10 ** 9))
        bad = api.state(self.code, "x" * 43)
        assert bad.status == 401, bad.text
        self.record("http", "error", "anon", "anonymous", bad.json, self.ctx_at(10 ** 9))
        self.checkpoint("t1-spectator")

        # teammate wrong guess, then a correct one
        r = self.act("A2", "taboo.guess", {"cardEpoch": 0, "text": "first try"}, rid)
        assert r.json["accepted"] is True, r.text
        snap = self.checkpoint("t1-wrong")
        word = self.active["word"]
        r = self.act("A2", "taboo.guess", {"cardEpoch": 0, "text": word}, rid, resolves=True)
        assert r.json["accepted"] is True, r.text
        snap = self.checkpoint("t1-after-correct")
        assert snap["game"]["teamScores"]["A"] == 1, snap["game"]["teamScores"]
        self.act("operator", "taboo.skip", {"cardEpoch": snap["game"]["cardEpoch"]}, rid, resolves=True)
        snap = self.checkpoint("t1-after-skip")
        self.act("operator", "taboo.pass_turn", {"cardEpoch": snap["game"]["cardEpoch"]}, rid, resolves=True)
        self.checkpoint("t1-turn-complete")
        self.former.add(self.who_ids["A1"])
        self.act("operator", "round.next", {}, rid)
        snap = self.checkpoint("t2-clue")
        rid = snap["roundId"]
        assert snap["game"]["clueGiverId"] == self.who_ids["B1"], "rotation: B1 gives second"

        # pause, second spectator, resumes
        self.act("operator", "room.pause")
        self.snapshot_ctx()
        self.join("S2", "Hamad", True)
        self.snapshot_ctx()
        self.open_stream("S2")
        for who in ("S1", "A1"):
            r = api.join(self.code, None, token=self.tokens[who])
            assert r.status == 200 and r.json.get("resumed") is True, r.text
            ctx = self.ctx_at(10 ** 9)
            self.record("http", "join", who, self.role_of(who, ctx), r.json, ctx)
        self.checkpoint("t2-paused")
        self.act("operator", "room.resume")
        snap = self.checkpoint("t2-resumed")
        self.act("operator", "taboo.correct", {"cardEpoch": snap["game"]["cardEpoch"]}, rid, resolves=True)
        snap = self.checkpoint("t2-after-correct")
        self.act("operator", "taboo.pass_turn", {"cardEpoch": snap["game"]["cardEpoch"]}, rid, resolves=True)
        self.former.add(self.who_ids["B1"])
        self.act("operator", "round.next", {}, rid)
        snap = self.checkpoint("t3-clue")
        rid = snap["roundId"]
        assert snap["game"]["clueGiverId"] == self.who_ids["A2"], "rotation: A2 gives third"
        r = self.act("A1", "taboo.guess", {"cardEpoch": 0, "text": "third turn guess"}, rid)
        assert r.json["accepted"] is True, r.text
        self.checkpoint("t3-former-giver-guess")
        self.act("operator", "room.end")
        self.checkpoint("ended")
        self.drain_streams()

    def close(self):
        for stream in self.streams.values():
            stream.close()


class ErrorDrive(Drive):
    """Live SSE error-frame coverage. The host runs with a short token TTL
    (expect=token_expired) or a short room max age (expect=room_expired)."""

    LIFETIME = 4.0
    WHO_ALL = ("operator", "display", "A1", "B1", "A2", "B2", "S1")

    def __init__(self, port, items, expect):
        Drive.__init__(self, port, items)
        self.expect = expect
        self.drive_name = "sse-error-" + expect

    def run(self):
        api = self.api
        started = time.time()
        r = api.create_room(minPlayers=4, maxPlayers=12, operatorName="Host")
        assert r.status == 201, r.text
        self.code = r.json["code"]
        self.tokens["operator"], self.tokens["display"] = r.json["hostToken"], r.json["displayToken"]
        self.record("http", "create", "operator", "anonymous", r.json, None)
        self.contexts.append((r.json["revision"], {"revision": r.json["revision"], "giver": None, "teams": None,
                                                    "active": None, "lastWord": None, "former": [], "activeTeam": None}))
        for who, name in (("A1", "Aisha"), ("B1", "Omar"), ("A2", "Noora"), ("B2", "Khalid")):
            self.join(who, name, False)
        self.act("operator", "room.set_mode", {"mode": "taboo"})
        self.act("operator", "room.start", {"modeConfig": {"turnSeconds": 120}})
        snap = self.checkpoint("e-t1")
        rid = snap["roundId"]
        self.join("S1", "Layla", True)
        self.snapshot_ctx()
        self.act("operator", "taboo.pass_turn", {"cardEpoch": snap["game"]["cardEpoch"]}, rid, resolves=True)
        self.former.add(self.who_ids["A1"])
        self.act("operator", "round.next", {}, rid)
        snap = self.checkpoint("e-t2")
        assert snap["game"]["clueGiverId"] == self.who_ids["B1"], "rotation: B1 gives second"
        for who in self.WHO_ALL:
            self.open_stream(who)
        setup = time.time() - started
        assert setup < self.LIFETIME - 1.0, "setup took %.2fs, too close to the %.1fs lifetime" % (setup, self.LIFETIME)
        # Every stream must deliver a live SSE error frame with the expected code.
        got = {}
        for who in self.WHO_ALL:
            stream = self.streams[who]
            deadline = time.time() + self.LIFETIME + 10
            while who not in got:
                if time.time() > deadline:
                    raise AssertionError("SSE %s: no error frame before the deadline" % who)
                item = stream.next(timeout=max(0.1, deadline - time.time()))
                if item is None:
                    raise AssertionError("SSE %s closed without an error frame" % who)
                if item.get("event") == "state":
                    snap = item["json"]
                    ctx = self.ctx_at(snap["revision"])
                    self.record("sse", "snapshot", who, self.role_of(who, ctx), snap, ctx)
                elif item.get("event") == "error":
                    ctx = self.ctx_at(10 ** 9)
                    got[who] = item["json"]
                    self.record("sse", "error", who, self.role_of(who, ctx), item["json"], dict(ctx, label="sse-error"))
        codes = sorted(set(((e or {}).get("error") or {}).get("code") for e in got.values()))
        assert codes == [self.expect], "SSE error codes %s (expected %s)" % (codes, self.expect)
        # HTTP error bodies after expiry (GET state, and a rejected stream open).
        for who in self.WHO_ALL:
            r = api.state(self.code, self.tokens[who])
            assert r.status in (401, 404, 410) and isinstance(r.json, dict), (who, r.status, r.text)
            ctx = self.ctx_at(10 ** 9)
            self.record("http", "error", who, self.role_of(who, ctx), r.json, dict(ctx, label="http-after-expiry"))
        late = self.support.SSEClient(self.port, "/api/rooms/%s/events" % self.code, token=self.tokens["A2"])
        try:
            assert late.status != 200, "stream opened after expiry"
            body = json.loads(late.body.decode("utf-8"))
        finally:
            late.close()
        ctx = self.ctx_at(10 ** 9)
        self.record("sse-open", "error", "A2", self.role_of("A2", ctx), body, dict(ctx, label="stream-open-after-expiry"))


def scan(drive, legacy_global_guesses=False):
    """legacy_global_guesses=True reproduces the previous (rejected) guess
    allowance -- the FINAL global set of submitted texts -- for comparison
    evidence only; the oracle verdict always uses the revision-frozen log."""
    from taboo_privacy import envelope_leaks, NO_RESOLVED_WORD
    findings = []
    for rec in drive.records:
        ctx = rec["ctx"] or {}
        role = rec["role"]
        if rec["kind"] in ("join", "create", "error", "receipt"):
            viewer = "anonymous" if role == "anonymous" else role
        else:
            viewer = role
        log = drive.logs.get(rec.get("drive", "main"), []) if hasattr(drive, "logs") else drive.guess_log
        last = ctx.get("lastWord")
        kwargs = {"active": ctx.get("active"), "last_word": last if isinstance(last, str) else NO_RESOLVED_WORD}
        if rec["kind"] == "snapshot":
            if legacy_global_guesses:
                kwargs["guess_texts"] = set(t for _, t in log)
            else:
                kwargs["guess_log"] = log
        leaks = envelope_leaks(rec["kind"], rec["payload"], drive.items, viewer, **kwargs)
        if leaks:
            findings.append({"transport": rec["transport"], "kind": rec["kind"], "who": rec["who"], "role": role,
                             "drive": rec.get("drive"), "label": ctx.get("label"),
                             "revision": (rec["payload"] or {}).get("revision"),
                             "leaks": [[list(p), reason] for p, reason in leaks][:8]})
    return findings


def run_variant(binary, content_dir, items):
    """Main scripted game plus the two live SSE error drives; returns the main
    Drive (its .records extended with the error drives' records, .logs holding
    each drive's own revision-frozen guess log), findings, error."""
    drive = None
    error = None
    proc = None
    try:
        proc, port = start_native(binary, content_dir)
        drive = Drive(port, items)
        drive.logs = {"main": drive.guess_log}
        drive.run()
    except Exception:
        error = traceback.format_exc()
    finally:
        if drive:
            drive.close()
        stop_native(proc)
    for expect, flag in (("token_expired", "--token-ttl"), ("room_expired", "--room-max-age")):
        if error is not None or drive is None:
            break
        sub = None
        proc = None
        try:
            proc, port = start_native(binary, content_dir, extra=[flag, str(ErrorDrive.LIFETIME)])
            sub = ErrorDrive(port, items, expect)
            sub.run()
        except Exception:
            error = traceback.format_exc()
        finally:
            if sub:
                sub.close()
                drive.records.extend(sub.records)
                drive.logs[sub.drive_name] = sub.guess_log
            stop_native(proc)
    return drive, scan(drive) if drive else [], error


def coverage(drive):
    cov = {}
    for rec in drive.records:
        key = "%s/%s/%s" % (rec["transport"], rec["kind"], rec["role"])
        cov[key] = cov.get(key, 0) + 1
    return dict(sorted(cov.items()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scratch")
    ap.add_argument("evidence")
    ap.add_argument("--only", nargs="*")
    args = ap.parse_args()
    scratch, evid = os.path.abspath(args.scratch), os.path.abspath(args.evidence)
    os.makedirs(scratch, exist_ok=True)
    os.makedirs(evid, exist_ok=True)
    from taboo_privacy import pre_reveal_leaks
    with open(os.path.join(ROOT, "party", "content", "taboo.json"), encoding="utf-8") as handle:
        items = json.load(handle)["items"]
    content_dir = taboo_content_dir(ROOT, scratch)
    report = {"probes": [], "baseline": None, "mutants": {}}
    ok = True

    for role, payload in PROBES:
        leaks = pre_reveal_leaks(payload, PROBE_ITEMS, role, active=PROBE_ITEMS[0])
        detected = bool(leaks)
        report["probes"].append({"role": role, "payload": payload, "detected": detected,
                                 "leaks": [[list(p), r] for p, r in leaks]})
        print("%s reviewer probe (%s): %s" % ("PASS" if detected else "FAIL", role, leaks), flush=True)
        ok = ok and detected
    for role in ALL_SNAPSHOT_ROLES:
        leaks = pre_reveal_leaks(FUTURE_PROBE, FUTURE_PROBE_ITEMS, role, active=FUTURE_PROBE_ITEMS[0], last_word=None)
        detected = bool(leaks)
        report["probes"].append({"role": role, "payload": FUTURE_PROBE, "probe": "future-resolved (privacy-probe.json)",
                                 "detected": detected, "leaks": [[list(p), r] for p, r in leaks]})
        print("%s reviewer future-resolved probe (%s): %s" % ("PASS" if detected else "FAIL", role, leaks), flush=True)
        ok = ok and detected

    base = build_binary(ROOT, scratch, "privacy-baseline")
    drive, findings, error = run_variant(base["test"], content_dir, items)
    cov = coverage(drive) if drive else {}
    clean = not findings and error is None
    report["baseline"] = {"build": base, "clean": clean, "error": error, "findings": findings,
                          "envelopes": len(drive.records) if drive else 0, "coverage": cov}
    print("%s baseline: %d envelopes, %d findings, error=%s" % ("PASS" if clean else "FAIL",
          report["baseline"]["envelopes"], len(findings), (error or "none").strip().splitlines()[-1]), flush=True)
    print("baseline coverage " + json.dumps(cov), flush=True)
    ok = ok and clean

    for name, (rel, old, new, targeted, kinds) in MUTANTS.items():
        if args.only and name not in args.only:
            continue
        info = build_binary(ROOT, scratch, "privacy-" + name, [(rel, old, new)])
        drive, findings, error = run_variant(info["test"], content_dir, items)
        flagged_roles = sorted(set(f["role"] for f in findings))
        flagged_kinds = sorted(set(f["kind"] for f in findings))
        transports = sorted(set(f["transport"] for f in findings))
        passed = (error is None and set(targeted) <= set(flagged_roles) and set(flagged_roles) <= set(targeted)
                  and set(flagged_kinds) <= set(kinds) and bool(findings))
        report["mutants"][name] = {"build": info, "targeted": targeted, "expectedKinds": kinds,
                                   "flaggedRoles": flagged_roles, "flaggedKinds": flagged_kinds,
                                   "transports": transports, "findingCount": len(findings),
                                   "sample": findings[:6], "error": error, "control_passed": passed}
        if name == "early-frame-later-guess" and drive:
            # Comparison evidence: the previous final-global guess allowance.
            main_only = [f for f in scan(drive, legacy_global_guesses=True) if f.get("drive") == "main"]
            frozen_main = [f for f in findings if f.get("drive") == "main"]
            report["mutants"][name]["mainDriveFindingsRevisionFrozen"] = len(frozen_main)
            report["mutants"][name]["mainDriveFindingsLegacyGlobalSet"] = len(main_only)
            print("     early-frame-later-guess main-drive findings: revision-frozen %d, legacy final global set %d"
                  % (len(frozen_main), len(main_only)), flush=True)
            passed = passed and len(frozen_main) > 0
            report["mutants"][name]["control_passed"] = passed
        if name == "future-resolved" and drive:
            injected = [v for v in drive.records if v["kind"] == "snapshot" and v.get("ctx")
                        and v["ctx"].get("lastWord") is None and (v["payload"].get("game") or {}).get("lastResolved")]
            flagged_ids = set((f["transport"], f["who"], f["revision"], f["drive"]) for f in findings)
            caught = [v for v in injected if (v["transport"], v["who"], v["payload"].get("revision"), v["drive"]) in flagged_ids]
            report["mutants"][name]["injectedFutureWordEnvelopes"] = len(injected)
            report["mutants"][name]["injectedFlagged"] = len(caught)
            print("     future-resolved: %d injected future-word envelopes, %d flagged" % (len(injected), len(caught)),
                  flush=True)
            passed = passed and len(injected) > 0 and len(caught) == len(injected)
            report["mutants"][name]["control_passed"] = passed
        print("%s mutant %s: flagged roles %s kinds %s transports %s (%d findings)%s" % (
            "PASS" if passed else "FAIL", name, flagged_roles, flagged_kinds, transports, len(findings),
            "" if error is None else " ERROR " + error.strip().splitlines()[-1]), flush=True)
        ok = ok and passed

    with open(os.path.join(evid, "taboo_privacy_negative_controls.json"), "w") as handle:
        json.dump(report, handle, indent=1, default=str)
    total = len(report["mutants"])
    passed = sum(1 for m in report["mutants"].values() if m["control_passed"])
    print("controls %d/%d passed; baseline clean=%s; probes detected=%d/%d" % (
        passed, total, report["baseline"]["clean"], sum(1 for p in report["probes"] if p["detected"]),
        len(report["probes"])))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
