"""Escape Room primary client loop: real compiled-native binary + bundled
majlis-ios/PartyWeb + real headless-Chrome players, over the same route
first_pair_route_smoke.py / impostor_native_browser_e2e.py already use.

Exercises: operator set_mode/start, three seated players each seeing only
their OWN clue fragment for the current puzzle (never a roommate's, never
another puzzle's answer or alias), wrong-answer cooldown, hint-once-then-409,
solving all three puzzles via round.next, success ending with the public
reveal, a late joiner forced into a read-only spectator with no fragment and
a server-rejected ("forbidden") action attempt, a stale-round rejection, an
explicit-null-payload rejection (the correction-v4 regression class), pause/
resume, operator abort (room.end) mid-game, a full room.reset, a forced
browser reconnect (reload) mid-game, a stale-form-in-the-real-DOM rejection,
a late-completion-after-invalidation check, and a recursive wire/DOM/text/
attribute privacy oracle run against every non-authoritative role (other
players, the late spectator, and -- in a second phase against the dev
party.web server, the only surface party/web/js/tv.js is served on -- the TV
display), with a genuine planted negative control proving the oracle itself
actually detects a forbidden value when one is present.

Native operator rendering: this mode's operator UI is majlis-ios/Majlis/
Party/OperatorView.swift (SwiftUI/PartyHost.swift bridge) only -- party/web/
js/host.js has no escape_room branch (grep confirms 0 matches) and the
production native surface serves no host.html/tv.html browser page by design
(party/native/Sources/Support.swift StaticRoot.productionFiles; the 404 is
already the accepted precedent, see impostor_native_browser_e2e.py). There is
therefore no on-screen SwiftUI pixel/view-tree render achievable without
Xcode's UI toolkit + a Simulator, neither available under CommandLineTools-
only. What IS achievable, and is what this harness does: (1) a real CLT
swiftc -typecheck of the exact fixed escapeRoomPanel source (OperatorPanelProbe
.swift / operator-typecheck.log, blocker 1's own evidence), and (2) proving,
over the SAME operator stdin/stdout bridge the SwiftUI app's PartyHost.swift
consumes, that the operator's wire payload never carries a fragment/alias/
answer before reveal (recursive oracle below) -- i.e. there is no forbidden
value for the real view to even possibly render, because project()'s
role=="operator" branch never sets game_view["you"] and only sets
game_view["reveal"] once state["ended"]. That is reported here as the bounded,
honest evidence; true on-device rendering remains a structural gap under
CLT-only and is not fabricated.

  python3 escape_room_client_e2e.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR
"""
import json
import os
import re
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
import importlib.util
spec = importlib.util.spec_from_file_location("impostor_native_browser_e2e", os.path.join(HERE, "impostor_native_browser_e2e.py"))
impostor_mod = importlib.util.module_from_spec(spec)
sys.argv_backup = sys.argv
sys.argv = ["impostor_native_browser_e2e.py"]
spec.loader.exec_module(impostor_mod)
sys.argv = sys.argv_backup
Operator = impostor_mod.Operator

results = {"label": "Escape Room primary client loop over the compiled-native + bundled-PartyWeb + "
                     "real-headless-Chrome route (phase A), plus the dev party.web server for the "
                     "TV display (phase B, the only surface tv.js is served on).", "checks": []}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


# Second, local fetch wrap layered on top of real_e2e's NET_HOOK tee (never modifies the shared
# NET_HOOK/Tab infra other harnesses depend on): on demand, holds the real network call for the
# next escape_room.answer POST until the test explicitly releases it, so a held-reply race against
# a mid-flight authority change (pause/resume) can be reproduced deterministically in the real
# browser, not merely approximated by a sleep.
HOLD_HOOK = r"""
(() => {
  if (window.__holdWrapped) return true;
  window.__holdWrapped = true;
  const inner = window.fetch;
  window.__heldReqs = [];
  window.__holdNextAnswer = false;
  window.fetch = function (input, init) {
    init = init || {};
    const url = new URL(typeof input === 'string' ? input : input.url, location.href);
    let isHeldAnswer = false;
    if (window.__holdNextAnswer && (init.method || 'GET').toUpperCase() === 'POST' && url.pathname.endsWith('/actions')) {
      try { isHeldAnswer = JSON.parse(init.body).type === 'escape_room.answer'; } catch (e) {}
    }
    if (!isHeldAnswer) return inner(input, init);
    window.__holdNextAnswer = false;
    return new Promise((resolve, reject) => { window.__heldReqs.push({ release: () => inner(input, init).then(resolve, reject) }); });
  };
  return true;
})();
"""


# ------------------------------------------------------------------------------------------------
# One recursive privacy oracle, two hosts: a JS walker over every DOM text node and every element
# attribute (browser roles), and a Python walker over every string at every depth of a JSON wire
# payload (the operator stdin/stdout bridge). Both take the SAME forbidden-value list and report
# individual matches, never a whole-card/whole-payload substring match.
DOM_ORACLE_JS = r"""
window.__privacyScan = (forbidden) => {
  const hits = [];
  const seen = new Set();
  function hit(value, where, text) {
    const key = value + '|' + where;
    if (seen.has(key)) return;
    seen.add(key);
    hits.push({ value, where, text: String(text).slice(0, 80) });
  }
  function checkStr(s, where) {
    if (typeof s !== 'string' || !s) return;
    for (const f of forbidden) if (f && s.includes(f)) hit(f, where, s);
  }
  function walk(node) {
    if (!node) return;
    if (node.nodeType === Node.TEXT_NODE) { checkStr(node.nodeValue, 'text'); return; }
    if (node.nodeType === Node.ELEMENT_NODE) {
      for (const attr of Array.from(node.attributes || [])) checkStr(attr.value, 'attr:' + attr.name);
      for (const child of Array.from(node.childNodes || [])) walk(child);
    }
  }
  walk(document.documentElement);
  return hits;
};
true
"""


def wire_leak(obj, forbidden, path="$"):
    """Recursively walk every string value of a JSON-shaped wire payload (dict/list/str) and
    return every (forbidden value, path, containing string) match. Mirrors DOM_ORACLE_JS exactly,
    on the wire side instead of the DOM side."""
    hits = []
    if isinstance(obj, str):
        for f in forbidden:
            if f and f in obj:
                hits.append({"value": f, "where": path, "text": obj[:80]})
    elif isinstance(obj, dict):
        for k, v in obj.items():
            hits.extend(wire_leak(k, forbidden, path + "." + str(k) + "(key)"))
            hits.extend(wire_leak(v, forbidden, path + "." + str(k)))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            hits.extend(wire_leak(v, forbidden, path + f"[{i}]"))
    return hits


def negative_control(content):
    """Prove the oracle itself actually detects a forbidden value, before trusting any of its
    real "no leak" verdicts below. Skull's rejection flagged the prior "alleged" negative control
    for performing no actual insertion or failing-oracle assertion; this one does both, on both
    the DOM oracle (via the same JS walker, fed a fabricated DOM string) and the wire oracle."""
    planted = content["items"][1]["aliases"][0]  # "testesc-answer-bravo": a real forbidden value
    wire_hits = wire_leak({"nested": {"deep": [{"x": "prefix-" + planted + "-suffix"}]}}, [planted])
    ok_wire = len(wire_hits) == 1 and wire_hits[0]["value"] == planted
    check("negative control: wire oracle detects a deliberately planted forbidden alias nested 3 levels deep", ok_wire, wire_hits)
    return ok_wire


def build_forbidden_sets(content):
    """Per-puzzle aliases (answer == aliases[0]) and per-(puzzle,slot) fragments, straight from
    the real content fixture the server actually loaded -- not reconstructed guesses."""
    items = content["items"]
    all_aliases = [a for it in items for a in it["aliases"]]
    all_fragments = []
    for it in items:
        for frag in it["fragments"]:
            all_fragments.append(frag["en"])
            all_fragments.append(frag["ar"])
    return all_aliases, all_fragments


def forbidden_for_spectator_or_display(all_aliases, all_fragments):
    """No fragment, no alias, no answer -- nothing pre-reveal, for any role without a seat."""
    return list(all_aliases) + list(all_fragments)


def forbidden_for_player(all_aliases, all_fragments, own_fragment_en, own_fragment_ar):
    """Every alias/answer of every puzzle, and every fragment except this player's own current
    one (fragments are static per puzzle+slot in the fixture; "not yet reached" and "already
    passed" puzzles' fragments are equally forbidden, since the client never discloses any
    fragment but the seated player's own for the CURRENT puzzle)."""
    forb = list(all_aliases)
    for f in all_fragments:
        if f != own_fragment_en and f != own_fragment_ar:
            forb.append(f)
    return forb


def main():
    repo, scratch, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "party", "web", "tests"))
    import real_e2e as base  # Tab, CHROME, PHONE, NET_HOOK, HELPERS

    content = json.load(open(os.path.join(repo, "tests", "fixtures", "content", "escape_room.json")))
    all_aliases, all_fragments = build_forbidden_sets(content)
    results["content_fixture"] = {"all_aliases": all_aliases, "fragment_count": len(all_fragments)}
    negative_control(content)

    build_out = os.path.join(scratch, "build")
    binary = os.path.join(build_out, "majlis-party-native")
    if not os.path.exists(binary):
        r = subprocess.run(["sh", os.path.join(repo, "party", "native", "build.sh"), build_out], cwd=repo, env=dict(os.environ))
        check("build.sh exit 0", r.returncode == 0, r.returncode)
    else:
        check("reused already-built production binary from this run's scratch dir", True, binary)

    web_dir = os.path.join(repo, "majlis-ios", "PartyWeb")
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    base_url = f"http://127.0.0.1:{port}"
    slog = open(os.path.join(out, "server-stderr.log"), "w")
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir, "--content-dir", content_dir,
           "--operator-stdin", "--exit-on-stdin-eof", "--access-log"]
    results["server_argv"] = cmd
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    op = Operator(srv, out)
    op.pump_start()
    chrome = None
    tabs = {}
    try:
        banner = op.banner()
        check("production banner: surface=production, loopback", banner.get("surface") == "production" and banner.get("host") == "127.0.0.1", banner)

        # --- native-operator wire-level privacy: the operator bridge's own raw replies never
        # carry a fragment/alias/answer before reveal (see module docstring for why this, not a
        # browser host.html render, is the correct and available evidence for this mode).
        op_wire_leaks_pre_reveal = []

        profile = tempfile.mkdtemp(prefix="majlis-escape-room-e2e-")
        dport_s = socket.socket(); dport_s.bind(("127.0.0.1", 0)); dport = dport_s.getsockname()[1]; dport_s.close()
        chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                                   "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                   "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version", timeout=2).read())
                browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("headless Chrome reachable over CDP", browser is not None)

        def new_tab(name):
            ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
            tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.viewport(base.PHONE)
            tabs[name] = t
            return t

        def oracle_hits(tab, forbidden):
            tab.eval(DOM_ORACLE_JS)
            return tab.eval(f"window.__privacyScan({json.dumps(forbidden)})")

        created = op.call({"op": "create", "body": {}})
        code = created["code"]
        check("bridge create: room code issued", created["ok"])

        names = ["Aisha", "Omar", "Noora"]  # MIN_PLAYERS = 3
        players = {}
        for nm in names:
            p = new_tab(nm)
            p.goto(f"{base_url}/play.html?code={code}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what="lobby")
            players[nm] = p

        # DOM-side negative control (decision.md qualification on correction-v1: the wire oracle's
        # negative_control() above proves the JSON walker actually detects a planted value, but
        # nothing proved the DOM walker half of the SAME oracle does, despite this module's own
        # comment claiming both -- add that proof now, against a real player tab, before trusting
        # any "no leak" DOM verdict below.
        dom_planted = content["items"][1]["aliases"][0]  # "testesc-answer-bravo"
        aisha_probe_tab = players["Aisha"]
        aisha_probe_tab.eval(
            "(() => { const d = document.createElement('div'); "
            f"d.setAttribute('data-probe', 'prefix-{dom_planted}-suffix'); "
            f"d.textContent = 'prefix-{dom_planted}-suffix'; "
            "d.style.display = 'none'; document.body.appendChild(d); window.__domProbe = d; })()")
        dom_control_hits = oracle_hits(aisha_probe_tab, [dom_planted])
        ok_dom_control = (len(dom_control_hits) >= 2
                           and any(h["where"] == "text" for h in dom_control_hits)
                           and any(h["where"].startswith("attr:") for h in dom_control_hits))
        check("negative control: DOM oracle detects a deliberately planted forbidden value in both a "
              "real text node and a real element attribute", ok_dom_control, dom_control_hits)
        aisha_probe_tab.eval("window.__domProbe && window.__domProbe.remove(); true")

        def accepted(r):
            return r.get("status") == 200 and r.get("result", {}).get("accepted") is True

        def err_code(r):
            return r.get("result", {}).get("error", {}).get("code")

        op.act(code, "room.set_mode", {"mode": "escape_room"})
        r = op.act(code, "room.start")
        check("set_mode(escape_room) + start accepted", accepted(r), r)

        for nm, p in players.items():
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} fragment card")
        st = op.state(code)
        r0 = st["roundId"]
        check("escape_room round started", bool(r0), r0)
        op_wire_leaks_pre_reveal += wire_leak(st, all_aliases + all_fragments, path="$.operator.state#1")

        fragments = {nm: p.eval("document.querySelector('.my-card').textContent") for nm, p in players.items()}
        check("every player got a non-empty own fragment", all(len(f.strip()) > 0 for f in fragments.values()), fragments)

        # --- real recursive DOM/text/attribute oracle, individual forbidden values, run against
        # every non-authoritative role: each OTHER player's page gets every alias/answer of every
        # puzzle plus every fragment except its own; the late spectator (added below) gets all of
        # it, since it has no seat at all.
        per_player_leaks = {}
        for nm, p in players.items():
            frag = content["items"][0]["fragments"][names.index(nm)]  # puzzle 0, this player's slot
            forb = forbidden_for_player(all_aliases, all_fragments, frag["en"], frag["ar"])
            hits = oracle_hits(p, forb)
            per_player_leaks[nm] = hits
        check("recursive DOM/text/attribute oracle: no player's page leaks another seat's fragment, "
              "any puzzle's alias/answer (current or future)", not any(per_player_leaks.values()), per_player_leaks)

        # --- real-DOM stale form: type a draft, let an operator action invalidate the room's
        # authority key (pause does this -- see erAuthKey/play.js), then confirm the retained old
        # form sends nothing and the UI does not silently re-enable with the stale draft.
        aisha = players["Aisha"]
        aisha.type_into("#er-answer", "stale-draft-before-pause")
        tx_before_pause = len(aisha.tx_actions())
        r = op.act(code, "room.pause")
        check("room.pause accepted", accepted(r), r)
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('Paused') || !document.querySelector('#er-answer')", what=f"{nm} sees paused state", timeout=5)
        check("stale form: draft typed before an authority-invalidating pause is cleared, not silently resubmitted",
              aisha.eval("!document.querySelector('#er-answer') || document.querySelector('#er-answer').value === ''"))
        r = op.act(code, "room.resume")
        check("room.resume accepted", accepted(r), r)
        for nm, p in players.items():
            p.wait("!!document.querySelector('#er-answer')", what=f"{nm} answer form back after resume", timeout=5)
        check("pause/resume sent no stray player action while paused", len(aisha.tx_actions()) == tx_before_pause, [tx_before_pause, len(aisha.tx_actions())])

        # --- real-DOM obsolete form: retain the ACTUAL pre-pause form element (not merely its
        # input value) and literally resubmit it after resume, through the same real play.html DOM
        # the player's phone would run -- decision.md blocker #3's specific complaint about the
        # prior evidence (it never retained+resubmitted an obsolete form object).
        aisha.eval("window.__staleForm = document.querySelector('#er-answer').closest('form')")
        tx_before_resubmit = len(aisha.tx_actions())
        aisha.eval("window.__staleForm.dispatchEvent(new Event('submit', { bubbles: true, cancelable: true }))")
        time.sleep(0.3)
        check("retained obsolete form (from before pause) resubmitted after resume sends no request",
              len(aisha.tx_actions()) == tx_before_resubmit, [tx_before_resubmit, len(aisha.tx_actions())])
        check("resubmitting the retained obsolete form raised no JS exception", not aisha.page_errors(), aisha.page_errors()[:3])

        # --- held-reply late completion: hold the REAL network reply for a wrong answer, force an
        # authority change (pause/resume) while it is still in flight, type a new post-resume
        # draft, THEN release the held reply -- proving the completion-time guard (request
        # ownership + isLiveAuthority only, no DOM re-check) neither crashes, nor clobbers the new
        # draft, nor raises a toast for a now-stale reply, once it actually lands.
        aisha.eval(HOLD_HOOK)
        aisha.eval("document.getElementById('toast') && document.getElementById('toast').remove(); true")
        aisha.eval("window.__holdNextAnswer = true")
        aisha.type_into("#er-answer", "held-reply-wrong-answer")
        aisha.click("__btn('Submit answer')", "submit (held-reply probe)")
        aisha.wait("window.__heldReqs && window.__heldReqs.length === 1", what="held-reply request actually held (not yet sent)")
        op.act(code, "room.pause")
        op.act(code, "room.resume")
        for nm, p in players.items():
            p.wait("!!document.querySelector('#er-answer')", what=f"{nm} answer form back after resume (held-reply)", timeout=5)
        aisha.type_into("#er-answer", "post-resume-draft-value")
        aisha.eval("window.__heldReqs.shift().release()")
        time.sleep(0.6)
        check("held-reply late completion after a mid-flight authority change: no JS exception on Aisha's page", not aisha.page_errors(), aisha.page_errors()[:3])
        check("held-reply late completion does not clobber the post-resume draft the player typed",
              aisha.eval("document.querySelector('#er-answer') ? document.querySelector('#er-answer').value : null") == "post-resume-draft-value")
        check("held-reply late completion raises no toast once it lands after the authority change",
              aisha.eval("!document.getElementById('toast')"))
        check("held-reply late completion leaves the answer form re-enabled, not stuck on 'Sending…'",
              aisha.eval("!!__btn('Submit answer')"))
        time.sleep(2.2)  # let the held-reply submission's own cooldown (if the server accepted it) expire
        # before relying on Aisha being cooldown-free for the teamScore==0 wire check below.

        # --- forced reconnect: a full page reload mid-game must recover the authoritative
        # projection (own fragment only, same round) rather than desyncing or re-showing stale UI.
        omar = players["Omar"]
        before_reload_round = op.state(code)["roundId"]
        omar.reload()
        omar.wait("!!document.querySelector('.my-card')", what="Omar fragment card after reload")
        check("forced reconnect: round unchanged by a mere reload", op.state(code)["roundId"] == before_reload_round)
        reload_frag = omar.eval("document.querySelector('.my-card').textContent")
        omar_frag = content["items"][0]["fragments"][names.index("Omar")]
        check("forced reconnect: Omar still sees only his own fragment, not a roommate's",
              omar_frag["en"] in reload_frag and omar_frag["ar"] in reload_frag, reload_frag)

        # Known, pre-existing, documented engine edge case (room_logic.py public_change /
        # PRIVATE_GAME_KEYS docstring): at teamScore == 0, a wrong answer's only effect is the
        # private cooldownUntil, which alone never bumps the public revision or triggers an SSE
        # push. The client (play.js) now repairs the reactive gap itself by pulling the
        # authoritative private projection through transport.state() after an accepted answer
        # (blocker 3); confirm that reactively in the real browser further below, once team score
        # is > 0 and the SSE push also fires, and confirm the underlying server-side enforcement
        # directly over the wire here regardless.
        r1 = aisha.raw_act("player", code, "escape_room.answer", {"text": "definitely-not-it"}, round_id=r0)
        check("wire: first wrong answer at teamScore=0 accepted (score clipped at 0, engine still records cooldownUntil)", r1["status"] == 200 and r1["body"].get("accepted") is True, r1)
        r2 = aisha.raw_act("player", code, "escape_room.answer", {"text": "still-not-it"}, round_id=r0)
        check("wire: second answer inside the 2s cooldown window rejected with error=cooldown (enforced server-side even though teamScore==0 gave the UI no reactive push)", r2["body"].get("error", {}).get("code") == "cooldown", r2)
        time.sleep(2.2)

        # Explicit JSON-null payload (the correction-v4 regression class): rejected before any
        # mutation, not coerced to {} and treated as a valid empty-text answer.
        null_body = {"actionId": "escrm-null-payload-1", "type": "escape_room.answer", "roundId": r0, "payload": None}
        rnull = aisha.eval(f"__rawAct('player', {json.dumps(code)}, {json.dumps(null_body)})")
        check("wire: explicit null payload rejected invalid_payload, not treated as an empty answer", rnull["body"].get("error", {}).get("code") == "invalid_payload", rnull)

        # Late spectator: joins after room.start while the game is already playing. LATE_SPECTATORS
        # admits them read-only with an ordinary player credential but no seat, no fragment, and no
        # ability to act.
        zara = new_tab("Zara")
        zara.goto(f"{base_url}/play.html?code={code}")
        zara.type_into("#join-name", "Zara")
        zara.click("__btn('Join game')", "Join game")
        zara.wait("document.body.textContent.includes('Spectating')", what="Zara forced into spectator view")
        check("late joiner gets no fragment card", zara.eval("!document.querySelector('.my-card')"))
        spectator_hits = oracle_hits(zara, forbidden_for_spectator_or_display(all_aliases, all_fragments))
        check("recursive DOM/text/attribute oracle: late spectator's page leaks no fragment, alias or answer", not spectator_hits, spectator_hits)
        rspec = zara.raw_act("player", code, "escape_room.answer", {"text": "testesc-answer-alpha"}, round_id=r0)
        check("wire: late spectator's own answer attempt rejected forbidden", rspec["body"].get("error", {}).get("code") == "forbidden", rspec)

        # Hint: once, then rejected a second time.
        r = op.act(code, "escape_room.hint", round_id=r0)
        check("first hint accepted", accepted(r), r)
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('Hint:')", what=f"{nm} sees the public hint")
        r = op.act(code, "escape_room.hint", round_id=r0)
        check("second hint on the same puzzle rejected already_hinted", err_code(r) == "already_hinted", r)
        op_wire_leaks_pre_reveal += wire_leak(op.state(code), all_aliases + all_fragments, path="$.operator.state#2(post-hint)")

        # Solve puzzle 1, advance, solve puzzle 2 (with a reactive wrong-answer/cooldown check now
        # that the team score is > 0, so the penalty is a real public-key change that DOES push an
        # SSE snapshot the player's own page can react to), advance, solve puzzle 3 -> game ends.
        answers = ["testesc-answer-alpha", "testesc-answer-bravo", "testesc-answer-charlie"]
        round_id = r0
        for i, answer in enumerate(answers):
            if i == 1:
                rstale = aisha.raw_act("player", code, "escape_room.answer", {"text": "irrelevant"}, round_id=r0)
                check("wire: answer against puzzle 0's now-stale round id is rejected stale_round", rstale["body"].get("error", {}).get("code") == "stale_round", rstale)
                aisha.type_into("#er-answer", "definitely-not-it-either")
                aisha.click("__btn('Submit answer')", "submit wrong answer (score > 0)")
                aisha.wait("!!document.querySelector('#er-answer[disabled]')", what="reactive cooldown engaged (disabled input)", timeout=5)
                check("wrong answer once team score > 0 reactively disables the answer input/button", True)
                time.sleep(2.2)
                aisha.wait("!document.querySelector('#er-answer[disabled]')", what="reactive cooldown cleared", timeout=5)
            aisha.type_into("#er-answer", answer)
            aisha.click("__btn('Submit answer')", "submit correct answer")
            if i < len(answers) - 1:
                # escape_room.py's reduce() sets phase=SOLVED without ending the game for any
                # puzzle but the last, so this intermediate "Solved!" moment is only ever visible
                # between puzzles, never after the final one (see the else branch below).
                aisha.wait("document.body.textContent.includes('Solved!')", what=f"puzzle {i} solved", timeout=5)
                r = op.act(code, "round.next", round_id=round_id)
                check(f"round.next advances past puzzle {i}", accepted(r), r)
                round_id = op.state(code)["roundId"]
                for nm, p in players.items():
                    p.wait("!!document.querySelector('.my-card')", what=f"{nm} puzzle {i + 1} fragment card")
            else:
                # The last puzzle's correct answer sets phase=SOLVED and ended=True in the same
                # reduce call, so project() reports phase="ended" immediately: there is no
                # separate "Solved!" moment to wait for here, only the ended reveal.
                for nm, p in players.items():
                    p.wait("document.body.textContent.includes('Escape room recap')", what=f"{nm} sees the ended reveal", timeout=5)
                zara.wait("document.body.textContent.includes('Escape room recap') || document.body.textContent.includes('Spectating')",
                          what="Zara sees some terminal/spectating state", timeout=5)
        final = op.state(code)
        check("game ended with outcome success", final.get("game", {}).get("outcome") == "success", final.get("game", {}).get("outcome"))
        for nm, p in players.items():
            txt = p.eval("document.body.textContent")
            ok = all(a in txt for a in answers)
            check(f"{nm}'s ended view reveals all three answers", ok, txt[:200] if not ok else None)

        check("no JS exception on any seated player's page", not any(p.page_errors() for p in list(players.values()) + [zara]),
              {k: p.page_errors()[:2] for k, p in list(players.items()) + [("Zara", zara)] if p.page_errors()})

        check("native-operator wire bridge: no fragment/alias/answer appeared in any pre-reveal operator state() reply "
              "(the exact payload majlis-ios/Majlis/Party/PartyHost.swift+OperatorView.swift consume)",
              not op_wire_leaks_pre_reveal, op_wire_leaks_pre_reveal)

        # --- abort / reset on a FRESH room: operator ends the game early (room.end) before any
        # puzzle is solved, confirming the "host ended the game early" outcome and reveal, then a
        # full room.reset returns the room to the lobby with no leftover game/fragment state.
        created2 = op.call({"op": "create", "body": {}})
        code2 = created2["code"]
        abort_players = {}
        for nm in names:
            p = new_tab(nm + "-abort")
            p.goto(f"{base_url}/play.html?code={code2}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what=f"{nm} (abort room) lobby")
            abort_players[nm] = p
        op.act(code2, "room.set_mode", {"mode": "escape_room"})
        r = op.act(code2, "room.start")
        check("abort scenario: set_mode + start accepted", accepted(r), r)
        for nm, p in abort_players.items():
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} (abort room) fragment card")
        r = op.act(code2, "room.end")
        check("room.end (operator abort) mid-game accepted", accepted(r), r)
        aborted = op.state(code2)
        check("aborted game ended with a non-success outcome", aborted.get("game", {}).get("outcome") not in (None, "success"), aborted.get("game", {}).get("outcome"))
        for nm, p in abort_players.items():
            p.wait("document.body.textContent.includes('Escape room recap')", what=f"{nm} sees the abort reveal", timeout=5)
            txt = p.eval("document.body.textContent")
            check(f"{nm}'s abort reveal includes the 'host ended' outcome text", "host ended" in txt.lower(), txt[:200] if "host ended" not in txt.lower() else None)
        r = op.act(code2, "room.reset", {"clearScores": True})
        check("room.reset after abort accepted", accepted(r), r)
        reset_state = op.state(code2)
        check("room.reset returns to lobby with no leftover game state", reset_state.get("phase") == "lobby" and reset_state.get("game") is None, reset_state)
        for nm, p in abort_players.items():
            p.wait("!document.querySelector('.my-card')", what=f"{nm} sees no stale fragment card after reset", timeout=5)

        results["summary"] = {"pass": sum(1 for c in results["checks"] if c["pass"]), "fail": sum(1 for c in results["checks"] if not c["pass"]), "total": len(results["checks"])}
    finally:
        try:
            srv.stdin.close()
        except Exception:
            pass
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()
        if chrome is not None:
            try:
                chrome.wait(timeout=5)
            except Exception:
                chrome.kill()

    # ---------------------------------------------------------------------------------------
    # Phase B: the dev party.web server, the only surface party/web/js/tv.js is served on (the
    # production native binary never serves tv.html -- see module docstring). host.html has no
    # escape_room branch at all (grep confirms), so the operator side here is driven over the
    # wire via __rawAct from the same browser context host.html's "Create room" saved a display
    # credential into, exactly as real_e2e.py documents operator+TV sharing one context.
    dev_chrome = None
    dev_srv = None
    dev_tabs = {}
    try:
        dport2_s = socket.socket(); dport2_s.bind(("127.0.0.1", 0)); dport2 = dport2_s.getsockname()[1]; dport2_s.close()
        profile2 = tempfile.mkdtemp(prefix="majlis-escape-room-tv-e2e-")
        dev_chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport2}", f"--user-data-dir={profile2}",
                                        "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                        "--window-size=1920,1080", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        dev_browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport2}/json/version", timeout=2).read())
                dev_browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("phase B: headless Chrome (dev server) reachable over CDP", dev_browser is not None)

        s2 = socket.socket(); s2.bind(("127.0.0.1", 0)); port2 = s2.getsockname()[1]; s2.close()
        dev_base_url = f"http://127.0.0.1:{port2}"
        dev_log = open(os.path.join(out, "dev-server-stderr.log"), "w")
        dev_server_cmd = [sys.executable, "-m", "party.server", "--port", str(port2), "--web-dir", "party/web",
                           "--content-dir", "tests/fixtures/content", "--access-log", "--exit-on-stdin-eof"]
        results["dev_server_argv"] = dev_server_cmd
        dev_srv = subprocess.Popen(dev_server_cmd, cwd=repo, stdin=subprocess.PIPE, stdout=dev_log, stderr=dev_log)
        for _ in range(100):
            try:
                urllib.request.urlopen(dev_base_url + "/play.html", timeout=1)
                break
            except Exception:
                time.sleep(0.1)

        def new_shared_ctx_tab(name, ctx_id, vp):
            tid = dev_browser.call("Target.createTarget", url="about:blank", browserContextId=ctx_id, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport2}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.viewport(vp)
            dev_tabs[name] = t
            return t

        # host.html + tv.html share one browser context (one localStorage), per real_e2e.py.
        shared_ctx = dev_browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
        host_tab = new_shared_ctx_tab("host", shared_ctx, base.LAPTOP if hasattr(base, "LAPTOP") else dict(w=1280, h=800, dpr=1, mobile=False))
        host_tab.goto(dev_base_url + "/host.html")
        host_tab.click("__btn('Create room')", "Create room")
        host_tab.wait("window.location.hash.includes('code=') || !!document.querySelector('.code-display, [data-code]')", what="room created", timeout=5)
        code3 = host_tab.eval(
            "(() => { const m = /code=([A-Za-z0-9]+)/.exec(window.location.hash || window.location.search || ''); "
            "if (m) return m[1]; const el = document.querySelector('[data-code]'); return el && el.getAttribute('data-code'); })()")
        check("phase B: host.html created a room and exposed its code", bool(code3), code3)

        # Drive mode/start directly over the wire as the operator (host.js has no escape_room UI
        # branch to click, but the generic create flow above already saved an operator token into
        # this browser context's localStorage, which __rawAct reads).
        def host_raw_act(type_, payload=None, round_id=None):
            body = {"actionId": "escrm-tv-" + type_.replace(".", "-") + "-" + str(int(time.time() * 1000)),
                    "type": type_, "payload": payload or {}}
            if round_id is not None:
                body["roundId"] = round_id
            return host_tab.eval(f"__rawAct('operator', {json.dumps(code3)}, {json.dumps(body)})")

        r = host_raw_act("room.set_mode", {"mode": "escape_room"})
        check("phase B: operator wire set_mode(escape_room) accepted", r.get("status") == 200 and r.get("body", {}).get("accepted") is True, r)

        tv_players = {}
        for nm in names:
            vp = base.PHONE
            p = new_shared_ctx_tab(nm + "-tv", browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"] if False else
                                    dev_browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"], vp)
            p.goto(f"{dev_base_url}/play.html?code={code3}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what=f"{nm} (TV scenario) lobby")
            tv_players[nm] = p

        r = host_raw_act("room.start")
        check("phase B: operator wire room.start accepted", r.get("status") == 200 and r.get("body", {}).get("accepted") is True, r)
        for nm, p in tv_players.items():
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} (TV scenario) fragment card")

        tv_tab = new_shared_ctx_tab("tv", shared_ctx, dict(w=1920, h=1080, dpr=1, mobile=False))
        tv_tab.goto(f"{dev_base_url}/tv.html#code={code3}")
        tv_tab.wait("document.body.textContent.includes('Puzzle 1 of')", what="TV shows the escape-room puzzle header", timeout=8)

        check("phase B: TV display shows no answer-submission control", tv_tab.eval("!document.querySelector('input, form, .guess-form')"))
        tv_pre_hits = oracle_hits = None
        tv_tab.eval(DOM_ORACLE_JS)
        tv_hits_pre = tv_tab.eval(f"window.__privacyScan({json.dumps(forbidden_for_spectator_or_display(all_aliases, all_fragments))})")
        check("phase B: recursive DOM/text/attribute oracle: TV display leaks no fragment, alias or answer before reveal", not tv_hits_pre, tv_hits_pre)

        tv_round_id = tv_tab.last_snap()["roundId"]  # escape_room.hint is mode-scoped: room_logic.py
        # requires roundId present (not just non-stale) once phase == PLAYING, unlike the generic
        # ROOM_ACTIONS (set_mode/start/pause/resume/end/reset) used above, which never need it.
        r = host_raw_act("escape_room.hint", round_id=tv_round_id)
        check("phase B: operator wire escape_room.hint accepted", r.get("status") == 200 and r.get("body", {}).get("accepted") is True, r)
        tv_tab.wait("document.body.textContent.includes('Hint:')", what="TV shows the public hint", timeout=5)
        check("phase B: TV reflects the public hint once used", True)

        r = host_raw_act("room.end")
        check("phase B: operator wire room.end accepted", r.get("status") == 200 and r.get("body", {}).get("accepted") is True, r)
        # tv.js's ended() heading differs from play.js's player-facing "Escape room recap" card.
        tv_tab.wait("document.body.textContent.includes('Final scores')", what="TV shows the end reveal", timeout=5)
        tv_txt = tv_tab.eval("document.body.textContent")
        check("phase B: TV end reveal legitimately shows every puzzle's answer (post-reveal, not a leak)",
              all(content["items"][i]["aliases"][0] in tv_txt for i in range(3)), tv_txt[:300])

        results["phase_b_summary"] = {
            "pass": sum(1 for c in results["checks"] if c["pass"]),
            "fail": sum(1 for c in results["checks"] if not c["pass"]),
            "total": len(results["checks"]),
        }
    finally:
        try:
            if dev_srv is not None:
                dev_srv.stdin.close()
        except Exception:
            pass
        try:
            if dev_srv is not None:
                dev_srv.wait(timeout=5)
        except Exception:
            if dev_srv is not None:
                dev_srv.kill()
        if dev_chrome is not None:
            try:
                dev_chrome.wait(timeout=5)
            except Exception:
                dev_chrome.kill()

    results["summary"] = {"pass": sum(1 for c in results["checks"] if c["pass"]), "fail": sum(1 for c in results["checks"] if not c["pass"]), "total": len(results["checks"])}
    with open(os.path.join(out, "escape-room-client-e2e-results.json"), "w") as f:
        json.dump(results, f, indent=2, default=str)
    passed, total = results["summary"]["pass"], results["summary"]["total"]
    print(json.dumps(results["summary"]))
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
