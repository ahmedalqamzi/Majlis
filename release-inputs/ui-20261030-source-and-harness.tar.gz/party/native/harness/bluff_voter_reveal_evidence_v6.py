"""Correction v6 targeted evidence: closes the 5 gaps majlis:bluff-primary-ui-integration-v1
correction-v5 review left open (bluff-v5-review-decision.md), scoped ONLY to the changed
voter-rendering surface (OperatorView.swift bluffPanel's reveal case + its JS twins
host.js/play.js/tv.js, which all implement the identical pid->optionId grouping). Does NOT
rerun the full accepted v3/v5 suites; those are reused unmodified and cited by path below.

Uses the production-binary + real-browser pattern from bluff_native_browser_e2e.py (private
stdin operator bridge, never over the network) so gap 5 (room.reset/new-game) is exercised
through the SAME native OperatorView route (Button("Play Again") { send("room.reset") },
OperatorView.swift) rather than host.js's web route, which the v5 decision explicitly said
lacks a same-room restart and is a separate, out-of-scope web gap.

Gaps closed here, each tagged in its own check name:
  [gap1] exact voter NAME -> OPTION mapping (not just "Voted by" substring presence),
         structurally parsed per <li class="bluff-option"> from the real rendered player
         DOM, cross-checked against the engine's own last.voters/last.options, in EN and AR.
  [gap2] a planted semantic voter-disclosure negative control that the rendered-DOM checker
         actually rejects (proves the checker has teeth, not just that no leak occurred).
  [gap3] a reconnect AFTER submission (round-N, post-submit-pre-vote) and a second reconnect
         AFTER voting (round-N, post-vote-pre-reveal) - the v5 harness only reconnected
         before round2's submission.
  [gap4] expected score award derived independently from the engine's own awardRound() rule
         (majlis-core.js:1474-1496: voter gets +100 if their vote hit the true option,
         otherwise the FAKED option's author gets +100; abstainers get 0) from the raw
         votes/options/trueOptionId, compared to lastResult.scoreDelta - not just checking
         after==before+delta (that only proves arithmetic self-consistency, not that the
         award itself is correct).
  [gap5] room.reset via the native operator bridge (same route OperatorView.swift's real
         "Play Again" button calls), then spectator promotion at the next room.start,
         exercised entirely over the private stdin bridge - the real native operator/bridge
         route, not host.js.

  python3 bluff_voter_reveal_evidence_v6.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR
Needs Google Chrome and python websocket-client. Exit 0 iff every check passes.
"""
import json, os, queue, re, secrets, socket, subprocess, sys, tempfile, threading, time
import urllib.error, urllib.request

results = {
    "label": "Correction v6: exact voter name->option mapping, a rendered-DOM negative "
              "control, post-submit/post-vote reconnects, independently-derived score "
              "awards, and room.reset/spectator-promotion over the native operator bridge "
              "(OperatorView.swift's real route) - the 5 gaps bluff-v5-review-decision.md "
              "left open, scoped to the changed voter-rendering surface only.",
    "checks": [],
}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


class Operator:
    def __init__(self, proc, out):
        self.proc, self.lines, self.lock = proc, queue.Queue(), threading.Lock()
        self.transcript = open(os.path.join(out, "operator-bridge-v6.jsonl"), "w")
        self.raw = []

    def pump_start(self):
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        for ln in self.proc.stdout:
            self.lines.put(ln.decode("utf-8"))

    def banner(self, timeout=10):
        return json.loads(self.lines.get(timeout=timeout))

    def call(self, req):
        with self.lock:
            self.proc.stdin.write(json.dumps(req, ensure_ascii=False).encode() + b"\n")
            self.proc.stdin.flush()
            ln = self.lines.get(timeout=10)
        self.raw.append(ln)
        self.transcript.write(json.dumps({"req": req, "reply": json.loads(ln)}, ensure_ascii=False) + "\n")
        self.transcript.flush()
        return json.loads(ln)

    def act(self, code, type_, payload=None, round_id=None, action_id=None):
        body = {"actionId": action_id or secrets.token_hex(8), "type": type_, "payload": payload or {}}
        if round_id is not None:
            body["roundId"] = round_id
        r = self.call({"op": "action", "code": code, "body": body})
        time.sleep(0.12)
        return r

    def state(self, code):
        return self.call({"op": "state", "code": code})["state"]


# -------------------------------------------------------------- [gap1]/[gap2] structural DOM parsing
# Mirrors play.js's reveal rendering exactly (party/web/js/play.js ~472-485): each
# <li class="bluff-option"> holds the option text and, if any, a "Voted by: a, b" line.
# This is a structural per-option parse, NOT a whole-document substring search - the thing
# the v5 decision said was missing ("Voted by" text was checked, not the actual mapping).
LI_RE = re.compile(r'<li class="bluff-option[^"]*">(.*?)</li>', re.S)
VOTED_BY_RE = re.compile(r"Voted by:\s*([^<]*)<")


def parse_voted_by_per_option(dom_html, option_text_by_id):
    """Returns {optionId: [name, ...]} read off the REAL rendered DOM, keyed back to
    optionId via each <li>'s option text (play.js never puts optionId itself in the DOM -
    by design, options are anonymous pre-reveal and text is the only stable DOM anchor
    post-reveal too)."""
    out = {}
    text_to_id = {v: k for k, v in option_text_by_id.items()}
    for li in LI_RE.findall(dom_html):
        oid = None
        for text, tid in text_to_id.items():
            if text and text in li:
                oid = tid
                break
        if oid is None:
            continue
        m = VOTED_BY_RE.search(li)
        names = [n.strip() for n in m.group(1).split(",")] if m else []
        out[oid] = [n for n in names if n]
    return out


def inject_semantic_leak(dom_html, fake_voter_name, real_option_text):
    """[gap2] Plants a voter name onto the TRUE-ANSWER option's own <li> (attributes a vote
    to it that it did not receive) to prove parse_voted_by_per_option + the comparison below
    actually catches a mismatch, rather than always vacuously agreeing with whatever the real
    markup says. Must target the true option's <li> specifically (matched by its option text),
    not just the first <li> in the document, else the planted name lands on an unrelated
    option and the comparison for the true option never changes. And when that <li> already
    has a real "Voted by: ..." span, the fake name must be inserted INTO that existing span's
    name list, not appended as a second trailing span - VOTED_BY_RE.search (same as
    parse_voted_by_per_option uses) only returns the FIRST match, so a second span is silently
    invisible to the very comparison this control is supposed to defeat."""
    for m in LI_RE.finditer(dom_html):
        li = m.group(1)
        if real_option_text and real_option_text in li:
            vm = VOTED_BY_RE.search(li)
            if vm:
                insert_at = m.start(1) + vm.start(1)
                return dom_html[:insert_at] + fake_voter_name + ", " + dom_html[insert_at:]
            insert_at = m.end(1)
            planted = f'<span class="muted small">Voted by: {fake_voter_name}</span>'
            return dom_html[:insert_at] + planted + dom_html[insert_at:]
    return dom_html


def http_get(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, dict(r.headers), r.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


def award_round_reference(votes, options, true_option_id, order):
    """[gap4] Independent re-implementation of majlis-core.js's awardRound() scoring rule
    (party/core/majlis-core.js:1474-1496), from raw inputs only - NOT from lastResult.
    voter -> +100 if their vote == trueOptionId; else -> that fake option's author gets
    +100; no vote cast -> nobody scores for that player this round."""
    author_of = {o["optionId"]: o.get("authorId") for o in options}
    delta = {p: 0 for p in order}
    for p in order:
        choice = votes.get(p)
        if choice is None:
            continue
        if choice == true_option_id:
            delta[p] += 100
        else:
            author = author_of.get(choice)
            if author is not None:
                delta[author] += 100
    return delta


def main():
    repo, scratch, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "party", "web", "tests"))
    sys.path.insert(0, os.path.join(repo, "tests"))
    import real_e2e as base  # Tab, NET_HOOK, CHROME, PHONE
    import bluff_privacy as bp

    with open(os.path.join(repo, "tests", "fixtures", "content", "bluff.json"), encoding="utf-8") as f:
        pack = json.load(f)

    build_out = os.path.join(scratch, "build")
    build_log = open(os.path.join(out, "build.log"), "w")
    r = subprocess.run(["sh", os.path.join(repo, "party", "native", "build.sh"), build_out],
                        cwd=repo, env=dict(os.environ), stdout=build_log, stderr=subprocess.STDOUT)
    check("build.sh exit 0 (production + test binaries built from THIS checkout, with the OperatorView.swift fix present)",
          r.returncode == 0, r.returncode)
    # NOTE: the production binary serves majlis-ios/PartyWeb (the bundled asset copy), which
    # this run discovered is STALE - majlis-ios/PartyWeb/js/play.js lacks the entire voters-
    # disclosure ("Voted by: ...") rendering that party/web/js/play.js has (diffed below,
    # saved to evidence/compiler-v6/stale-bundle-diff.txt). That staleness is a separate,
    # pre-existing bundling-pipeline defect, out of scope for this correction (which only
    # touches OperatorView.swift) and NOT fixed here. To actually exercise the CURRENT
    # voter-rendering source for gap1/gap2, this harness uses the test-loopback binary
    # serving party/web directly (same surface bluff_display_native_browser_e2e.py uses to
    # reach host.js/tv.js) while still driving the operator ONLY over the same private
    # stdin bridge protocol OperatorView.swift's production app uses (--operator-stdin is
    # shared, unconditional CLI code in main.swift/Server.swift - identical on both binaries).
    diff_log = subprocess.run(["diff", "-u", os.path.join(repo, "party", "web", "js", "play.js"),
                                os.path.join(repo, "majlis-ios", "PartyWeb", "js", "play.js")],
                               capture_output=True, text=True).stdout
    open(os.path.join(out, "stale-bundle-diff.txt"), "w").write(diff_log or "(no diff - bundle is current)")
    results["stale_production_bundle_note"] = ("majlis-ios/PartyWeb/js/play.js differs from party/web/js/play.js "
                                                 "(diff saved to stale-bundle-diff.txt); see finding in HANDOFF" if diff_log
                                                 else "bundle matched source at run time")

    binary = os.path.join(build_out, "majlis-party-native-test")

    web_dir = os.path.join(repo, "party", "web")
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    base_url = f"http://127.0.0.1:{port}"
    slog = open(os.path.join(out, "server-stderr.log"), "w")
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir, "--content-dir", content_dir,
           "--operator-stdin", "--exit-on-stdin-eof", "--access-log"]
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    op = Operator(srv, out)
    op.pump_start()
    chrome = None
    tabs = {}
    try:
        banner = op.banner()
        check("test-loopback banner: surface=test-loopback, loopback, serving the CURRENT party/web source (operator still driven only over the private stdin bridge, same protocol as OperatorView.swift's production route)",
              banner.get("surface") == "test-loopback" and banner.get("event") == "listening", banner)

        profile = tempfile.mkdtemp(prefix="majlis-bluff-voter-evidence-v6-")
        dport_s = socket.socket(); dport_s.bind(("127.0.0.1", 0)); dport = dport_s.getsockname()[1]; dport_s.close()
        chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                                   "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                   "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version", timeout=2).read())
                browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("headless Chrome reachable over CDP", browser is not None)

        def new_tab(name, vp):
            ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
            tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.call("Emulation.setFocusEmulationEnabled", enabled=True)
            t.viewport(vp)
            tabs[name] = t
            return t

        def run_language_round(language, names, label):
            created = op.call({"op": "create", "body": {}})
            code = created["code"]
            check(f"[{label}] bridge create: room code only", created["ok"] and re.fullmatch(r"[A-Z0-9]{6}", code) is not None)
            players, pid, tokens = {}, {}, {}
            for nm in names:
                p = new_tab(f"{label}-{nm}", base.PHONE)
                p.goto(f"{base_url}/play.html?code={code}")
                p.type_into("#join-name", nm)
                p.click("__btn('Join game')", "Join game")
                p.wait("document.body.textContent.includes('You’re in')", what="lobby")
                rec = json.loads(p.storage()[f"majlisParty.v1.player.{code}"])
                pid[nm] = rec["playerId"]; tokens[nm] = rec["token"]
                players[nm] = p
            op.act(code, "room.set_mode", {"mode": "bluff"})
            r = op.act(code, "room.start", {"rounds": 2, "language": language})
            check(f"[{label}] bridge start(rounds=2, language={language}) accepted", r["ok"] and r["status"] == 200, r.get("status"))

            rid = op.state(code)["roundId"]
            fakes = {nm: f"{label} fake answer from {nm}" for nm in names}
            for nm, p in players.items():
                p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} submission form")
                p.type_into("#bluff-answer", fakes[nm])
                p.click("__btn('Submit fake answer')", f"{nm} submits fake answer")
                p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} submitted")

            # ---------------------------------------------------- [gap3] reconnect AFTER submission, before voting
            reload_target = names[0]
            before_pid = pid[reload_target]
            players[reload_target].reload()
            players[reload_target].wait("document.body.textContent.includes('Waiting for everyone else')",
                                         what=f"{reload_target} reconnected post-submit")
            after_pid = players[reload_target].eval(f"JSON.parse(localStorage.getItem('majlisParty.v1.player.{code}')).playerId")
            check(f"[{label}][gap3] {reload_target} reload AFTER submission (pre-vote) reconnects into the SAME seat, submission preserved",
                  after_pid == before_pid, {"before": before_pid, "after": after_pid})

            r = op.act(code, "bluff.open_vote", {"force": False}, round_id=rid)
            check(f"[{label}] bridge open_vote accepted once all submitted", r["ok"] and r["status"] == 200, r.get("status"))
            for nm, p in players.items():
                p.wait("!!document.querySelector('.bluff-option-btn')", what=f"{nm} voting options")

            vote_choice = {}
            for nm, p in players.items():
                chosen_text = p.eval(
                    "(() => { const b = [...document.querySelectorAll('.bluff-option-btn')].find(x => !x.disabled); "
                    "const t = b.textContent; b.click(); return t; })()")
                vote_choice[nm] = chosen_text
                p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} voted")

            # ---------------------------------------------------- [gap3] reconnect AFTER voting, before reveal
            reload_target2 = names[1]
            before_pid2 = pid[reload_target2]
            players[reload_target2].reload()
            players[reload_target2].wait("document.body.textContent.includes('Waiting for everyone else')",
                                          what=f"{reload_target2} reconnected post-vote")
            after_pid2 = players[reload_target2].eval(f"JSON.parse(localStorage.getItem('majlisParty.v1.player.{code}')).playerId")
            check(f"[{label}][gap3] {reload_target2} reload AFTER voting (pre-reveal) reconnects into the SAME seat, vote preserved",
                  after_pid2 == before_pid2, {"before": before_pid2, "after": after_pid2})

            before_scores = {nm: next((pl["score"] for pl in op.state(code)["players"] if pl["id"] == pid[nm]), None) for nm in names}

            r = op.act(code, "bluff.reveal", {"force": False}, round_id=rid)
            check(f"[{label}] bridge reveal accepted once all voted", r["ok"] and r["status"] == 200, r.get("status"))
            for nm, p in players.items():
                p.wait("document.body.textContent.includes('scored')", what=f"{nm} reveal view")

            op_state = op.state(code)
            last = op_state["game"]["lastResult"]
            options = last["options"]
            option_text_by_id = {o["optionId"]: o["text"] for o in options}
            engine_voters = last["voters"]  # pid -> optionId, straight from the engine

            # ---------------------------------------------------- [gap1] exact name->option mapping, structural DOM parse
            for nm, p in players.items():
                dom = p.html()
                if os.environ.get("BLUFF_V6_DEBUG_DOM"):
                    open(os.path.join(out, f"debug-dom-{label}-{nm}.html"), "w").write(dom)
                rendered = parse_voted_by_per_option(dom, option_text_by_id)
                # Build the expected per-option voter-name set from the SAME engine voters
                # field the SwiftUI votersByOption()/host.js/play.js/tv.js all consume,
                # resolved to display names the same way (player id -> its own join name).
                expected = {}
                for pid_, oid in engine_voters.items():
                    name = next((n for n, i in pid.items() if i == pid_), pid_)
                    expected.setdefault(oid, []).append(name)
                rendered_sets = {oid: sorted(v) for oid, v in rendered.items() if v}
                expected_sets = {oid: sorted(v) for oid, v in expected.items() if v}
                check(f"[{label}][gap1] {nm}: rendered 'Voted by' names map to the CORRECT option per structural DOM parse (not just substring presence)",
                      rendered_sets == expected_sets, {"rendered": rendered_sets, "expected": expected_sets})

            # ---------------------------------------------------- [gap2] planted negative control, proven to be caught
            sample_dom = players[names[0]].html()
            poisoned = inject_semantic_leak(sample_dom, "Totally Wrong Name", option_text_by_id[last["trueOptionId"]])
            poisoned_rendered = parse_voted_by_per_option(poisoned, option_text_by_id)
            expected_for_true = sorted(expected.get(last["trueOptionId"], []))
            poisoned_for_true = sorted(poisoned_rendered.get(last["trueOptionId"], []))
            check(f"[{label}][gap2] planted semantic voter-disclosure negative control IS rejected: a name wrongly attributed to the true-answer option is caught by the structural comparison (checker has teeth, this is not a vacuous pass)",
                  poisoned_for_true != expected_for_true and "Totally Wrong Name" in poisoned_for_true,
                  {"poisoned": poisoned_for_true, "expected": expected_for_true})

            # ---------------------------------------------------- [gap4] independently-derived score award
            # last["voters"] is a deepcopy of the engine's internal s.votes taken at the
            # moment reveal ran (majlis-core.js:1495) - the same raw per-voter choices
            # awardRound() itself consumed, not a value we are trusting after the fact.
            reference_delta = award_round_reference(engine_voters, options, last["trueOptionId"], list(pid.values()))
            engine_delta = last["scoreDelta"]
            check(f"[{label}][gap4] engine scoreDelta matches an INDEPENDENT re-derivation of majlis-core.js's awardRound() rule from raw votes/options/trueOptionId (not just totals arithmetic)",
                  reference_delta == engine_delta, {"reference": reference_delta, "engine": engine_delta})
            after_scores = {nm: next((pl["score"] for pl in op_state["players"] if pl["id"] == pid[nm]), None) for nm in names}
            exact = all(after_scores[nm] == before_scores[nm] + reference_delta.get(pid[nm], 0) for nm in names)
            check(f"[{label}][gap4] every player's real score change equals the independently-derived award exactly",
                  exact, {"before": before_scores, "after": after_scores, "reference_delta": {n: reference_delta.get(pid[n], 0) for n in names}})

            r = op.act(code, "round.next", round_id=rid)
            check(f"[{label}] round.next accepted from reveal", r["ok"] and r["status"] == 200, r.get("status"))
            return code, players, pid, tokens

        code, players, pid, tokens = run_language_round("en", ["Aisha", "Omar", "Noora"], "en-round1")

        # ---------------------------------------------------- finish game, then [gap5] native room.reset + spectator promotion
        for nm, p in players.items():
            p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} round2 submission form")
            p.type_into("#bluff-answer", f"round2 fake from {nm}")
            p.click("__btn('Submit fake answer')", f"{nm} submits fake answer round2")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} submitted round2")
        rid2 = op.state(code)["roundId"]
        op.act(code, "bluff.open_vote", {"force": False}, round_id=rid2)
        for nm, p in players.items():
            p.wait("!!document.querySelector('.bluff-option-btn')", what=f"{nm} round2 voting options")
            p.eval("(() => { const b = [...document.querySelectorAll('.bluff-option-btn')].find(x => !x.disabled); b.click(); })()")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} voted round2")
        op.act(code, "bluff.reveal", {"force": False}, round_id=rid2)
        r = op.act(code, "round.next", round_id=rid2)
        check("round2 reveal -> round.next moves game.phase to finished (2 rounds configured)",
              r["ok"] and op.state(code)["game"]["phase"] == "finished", op.state(code)["game"].get("phase"))

        # ---------------------------------------------------- [gap5] spectator join + promotion via the NATIVE
        # bridge's room.reset/room.start - majlis-core.js's LATE_JOIN_SPECTATE: true (Bluff
        # spec) only queues a join as a spectator while room.state.phase is "playing"/
        # "paused" (applyJoin, majlis-core.js:1746-1757); promotion into real players only
        # happens on the NEXT room.start (majlis-core.js:1805-1812), not on room.reset
        # itself. So the late join must happen here, before room.end/room.reset, to exercise
        # the real spectator path at all - joining after reset would just be an ordinary
        # lobby join and would prove nothing about promotion.
        late = new_tab("en-round1-LateLina", base.PHONE)
        late.goto(f"{base_url}/play.html?code={code}")
        late.type_into("#join-name", "Late Lina")
        late.click("__btn('Join game')", "Late Lina joins while room.state.phase == 'playing'")
        late.wait("(window.__rx || []).some(r => r.path.endsWith('/events') && r.chunks.length > 0)", what="Late Lina first SSE snapshot arrives")
        late_snap0 = late.last_snap()
        late_snap_spectating = bool(late_snap0) and (late_snap0.get("role") == "spectator" or (late_snap0.get("self") or {}).get("spectator") is True)
        check("[gap5] a player who joins while the room is still 'playing' (LATE_JOIN_SPECTATE) is admitted as a READ-ONLY spectator, confirmed on her own real rendered client's SSE snapshot (not asserted from engine state alone)",
              late_snap_spectating, late_snap0)
        late_pid = json.loads(late.storage()[f"majlisParty.v1.player.{code}"])["playerId"]
        pre_promo_state = op.state(code)
        check("[gap5] operator bridge state shows Late Lina queued under spectators, NOT yet in players, while the game is still active",
              any(sp.get("id") == late_pid for sp in (pre_promo_state.get("spectators") or []))
              and not any(pl.get("id") == late_pid for pl in pre_promo_state.get("players", [])),
              pre_promo_state.get("spectators"))

        r = op.act(code, "room.end")
        check("[gap5] room.end accepted over the native operator bridge (same bridge OperatorView.swift's controls use)", r["ok"] and r["status"] == 200, r.get("status"))
        late.wait("document.body.textContent.includes('Game over')", timeout=15, what="Late Lina sees room.end over her live SSE connection")
        r = op.act(code, "room.reset")
        check("[gap5] room.reset accepted over the SAME native operator stdin bridge OperatorView.swift's real 'Play Again' button calls (Button(\"Play Again\") { send(\"room.reset\") })",
              r["ok"] and r["status"] == 200, r.get("status"))
        reset_state = op.state(code)
        check("[gap5] after native-bridge room.reset: room returns to lobby phase with the game state cleared, same room code (same instance, not a new room); Late Lina still only a queued spectator, not yet promoted",
              reset_state.get("phase") == "lobby" and any(sp.get("id") == late_pid for sp in (reset_state.get("spectators") or [])),
              {"phase": reset_state.get("phase"), "spectators": reset_state.get("spectators")})

        # play.js:85 ("Ended is terminal: keep the final scores and stop reconnecting")
        # deliberately closes the SSE stream once phase == 'ended' and never reconnects it -
        # that is correct, by-design client behavior, not a bug, so Late Lina's existing live
        # connection will never itself observe the later room.reset/room.start transitions.
        # The real-world equivalent of what happens next is the same thing gap3 already
        # exercises: a returning player reloads play.html and resumes from whatever seat the
        # engine now has them in - so that is what the promotion check below does.
        r = op.act(code, "room.set_mode", {"mode": "bluff"})
        r = op.act(code, "room.start", {"rounds": 1, "language": "en"})
        check("[gap5] native-bridge room.start after room.reset starts a fresh game with the SAME room/players (new-game lifecycle via the real operator route)",
              r["ok"] and r["status"] == 200, r.get("status"))
        post_reset_state = op.state(code)
        check("[gap5] post-reset-and-restart native bridge state carries the original three named players through (room identity preserved across reset, not a throwaway room)",
              {p["name"] for p in post_reset_state.get("players", [])} >= {"Aisha", "Omar", "Noora"},
              [p["name"] for p in post_reset_state.get("players", [])])
        check("[gap5] Late Lina is PROMOTED from spectator to a real scored player at the next native-bridge room.start - the actual promotion event, not merely her later presence",
              any(pl.get("id") == late_pid and pl.get("score") == 0 for pl in post_reset_state.get("players", []))
              and not (post_reset_state.get("spectators") or []),
              post_reset_state.get("players"))

        late.reload()
        late.wait("!!document.querySelector('#bluff-answer')", timeout=20, what="Late Lina promoted-player submission form (after reload, same as gap3's reconnect pattern)")
        late_snap_after = late.last_snap()
        check("[gap5] on her own real rendered client, Late Lina now sees an active-player view (can submit, no longer role=spectator) after reloading post native-bridge reset+restart",
              late_snap_after.get("role") != "spectator" and not (late_snap_after.get("self") or {}).get("spectator"),
              late_snap_after.get("role"))

        op.act(code, "room.end")

        # ---------------------------------------------------- [gap1]/[gap4] language variant: AR round, smaller scope (lifecycle already proven above)
        run_language_round("ar", ["Fatima", "Yusuf", "Khalid"], "ar-round1")

        check("every page script ran on every player tab without a JS exception",
              not any(p.page_errors() for p in tabs.values()), {k: p.page_errors()[:2] for k, p in tabs.items() if p.page_errors()})

    except Exception:
        import traceback
        check("run completed without an exception", False, traceback.format_exc()[-2000:])
    finally:
        for t in list(tabs.values()):
            try: t.ws.close()
            except Exception: pass
        if chrome is not None:
            chrome.terminate()
            try: chrome.wait(10)
            except Exception: chrome.kill()
        try:
            srv.stdin.close()
            srv.wait(10)
        except Exception:
            srv.kill()
        results["server_exit"] = srv.returncode

    p_ = sum(1 for c in results["checks"] if c["pass"])
    f_ = len(results["checks"]) - p_
    results["summary"] = {"pass": p_, "fail": f_, "total": len(results["checks"])}
    json.dump(results, open(os.path.join(out, "bluff-voter-reveal-evidence-v6-results.json"), "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps(results["summary"]))
    sys.exit(0 if f_ == 0 and p_ > 0 else 1)


if __name__ == "__main__":
    main()
