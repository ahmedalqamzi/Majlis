"""Shared, bounded helpers for the Taboo native harnesses (test-only).

* build_binary(): copies party/core + party/native of a source tree into a
  scratch directory (the checkout is never modified), optionally applies ONE
  exact single-occurrence textual mutation, and runs the real build.sh with a
  wall-clock limit; the compiler log and exit code are kept beside the build.
* start_native()/stop_native(): launch a built host on a dynamic loopback port
  (``--port 0``) with ``--exit-on-stdin-eof`` and bounded waits; stop always
  closes stdin, then terminates/kills, then reaps.
"""
import hashlib
import json
import os
import select
import shutil
import subprocess
import time

FAST = ["--heartbeat", "0.2", "--sweep-interval", "0.1", "--request-rate", "2000", "--request-burst", "5000",
        "--create-per-minute", "6000", "--create-burst", "500", "--join-per-minute", "6000", "--join-burst", "500",
        "--action-rate", "2000", "--action-burst", "5000"]


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


class BuildError(Exception):
    pass


def build_binary(repo, scratch, name, mutations=(), timeout=900):
    """mutations: sequence of (rel_path_under_party, old, new); each `old`
    must occur exactly once. Returns dict with binary paths, hashes, log."""
    root = os.path.join(scratch, name)
    shutil.rmtree(root, ignore_errors=True)
    for sub in ("core", "native"):
        shutil.copytree(os.path.join(repo, "party", sub), os.path.join(root, "party", sub),
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "harness"))
    applied = []
    for rel, old, new in mutations:
        path = os.path.join(root, "party", rel)
        with open(path, encoding="utf-8") as handle:
            text = handle.read()
        count = text.count(old)
        if count != 1:
            raise BuildError("mutation anchor occurs %d times (expected 1) in %s: %r" % (count, rel, old[:120]))
        with open(path, "w", encoding="utf-8") as handle:
            handle.write(text.replace(old, new, 1))
        applied.append({"file": "party/" + rel, "sha256": sha256_file(path)})
    out = os.path.join(root, "build")
    log_path = os.path.join(root, "build.log")
    started = time.time()
    with open(log_path, "wb") as log:
        proc = subprocess.run(["sh", os.path.join(root, "party", "native", "build.sh"), out], cwd=root,
                              stdout=log, stderr=subprocess.STDOUT, timeout=timeout, env=dict(os.environ))
    info = {"name": name, "exit": proc.returncode, "log": log_path, "seconds": round(time.time() - started, 1),
            "mutations": applied}
    if proc.returncode != 0:
        with open(log_path, encoding="utf-8", errors="replace") as handle:
            raise BuildError("build %s exit %d: %s" % (name, proc.returncode, handle.read()[-3000:]))
    for kind, fname in (("production", "majlis-party-native"), ("test", "majlis-party-native-test")):
        path = os.path.join(out, fname)
        info[kind] = path
        info[kind + "Sha256"] = sha256_file(path)
    info["embeddedSourcesSha256"] = sha256_file(os.path.join(out, "gen", "EmbeddedSources.swift"))
    return info


def start_native(binary, content_dir, extra=(), timeout=15.0, fast=True):
    cmd = [binary, "--host", "127.0.0.1", "--port", "0", "--content-dir", content_dir, "--exit-on-stdin-eof"]
    cmd += (FAST if fast else []) + list(extra)
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    ready, _, _ = select.select([proc.stdout], [], [], timeout)
    if not ready:
        stop_native(proc)
        raise RuntimeError("native host printed no banner within %.0fs" % timeout)
    line = proc.stdout.readline().decode("utf-8")
    try:
        banner = json.loads(line)
    except ValueError:
        stop_native(proc)
        raise RuntimeError("bad banner %r" % line[:200])
    return proc, banner["port"]


def stop_native(proc):
    if proc is None:
        return None
    try:
        proc.stdin.close()
    except Exception:
        pass
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=5)
    for stream in (proc.stdout, proc.stderr):
        try:
            if stream is not None:
                stream.close()
        except Exception:
            pass
    return proc.returncode


def taboo_content_dir(repo, scratch):
    """Private content dir holding only a byte-identical copy of the authored pack."""
    path = os.path.join(scratch, "content-taboo-only")
    os.makedirs(path, exist_ok=True)
    shutil.copyfile(os.path.join(repo, "party", "content", "taboo.json"), os.path.join(path, "taboo.json"))
    return path
