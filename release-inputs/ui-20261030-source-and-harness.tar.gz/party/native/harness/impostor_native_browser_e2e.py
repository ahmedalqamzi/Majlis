"""Compiled native host + REAL headless-Chrome browser, serving the EXACT bundled
production player assets (majlis-ios/PartyWeb), for Impostor.

Closes the one gap Skull's SOURCE-HOST-ACCEPTANCE.md identified: the 12 prior
browser diagnostics drove the dev Python server (party/web sources), and the
58 native tests drove the native host over raw HTTP (API only, no browser, no
DOM). This harness drives 3 isolated headless-Chrome player contexts against
play.html served by the real compiled production native binary, with the
operator controlled only through its private stdin bridge (--operator-stdin),
never over the network -- exactly the production_lan_e2e.py pattern, extended
to Impostor. It also hashes the served player assets against the checkout's
bundled majlis-ios/PartyWeb files, and the binary's own file-type/argv/banner,
to establish the server executable is actually native, not a Python fallback,
and that it served the exact bundled bytes (not party/web dev sources).

There is no operator/display *browser* page on the production native surface
by design (host.html/tv.html are 404 there, verified by production_lan_e2e.py)
-- operator control and operator-side privacy are therefore checked via the
real stdin/stdout bridge's own raw replies, using the same accepted whole
-payload scanner (tests/impostor_privacy.pre_reveal_leaks / text_leaks) that
the native negative-controls harness uses. "display" privacy is structurally
out of scope on this surface and is reported as such, not fabricated.

  python3 impostor_native_browser_e2e.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR
Needs Google Chrome and python websocket-client. Exit 0 iff every check passes.
"""
import hashlib, json, os, queue, re, secrets, socket, subprocess, sys, tempfile, threading, time
import urllib.error, urllib.request

REPO = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else None


def sha(path_or_bytes):
    h = hashlib.sha256()
    if isinstance(path_or_bytes, bytes):
        h.update(path_or_bytes)
    else:
        with open(path_or_bytes, "rb") as f:
            h.update(f.read())
    return h.hexdigest()


results = {
    "label": "Compiled native production binary + real headless-Chrome players against the "
              "exact bundled majlis-ios/PartyWeb player assets. Operator via private stdin "
              "bridge only, never over the network.",
    "checks": [],
}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


class Operator:
    def __init__(self, proc, out):
        self.proc, self.lines, self.lock = proc, queue.Queue(), threading.Lock()
        self.transcript = open(os.path.join(out, "operator-bridge.jsonl"), "w")
        self.raw = []

    def pump_start(self):
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        for ln in self.proc.stdout:
            self.lines.put(ln.decode("utf-8"))

    def banner(self, timeout=10):
        return json.loads(self.lines.get(timeout=timeout))

    def call(self, req):
        with self.lock:
            self.proc.stdin.write(json.dumps(req, ensure_ascii=False).encode() + b"\n")
            self.proc.stdin.flush()
            ln = self.lines.get(timeout=10)
        self.raw.append(ln)
        self.transcript.write(json.dumps({"req": req, "reply": json.loads(ln)}, ensure_ascii=False) + "\n")
        self.transcript.flush()
        return json.loads(ln)

    def decoded(self, since=0):
        return "\n".join(json.dumps(json.loads(ln), ensure_ascii=False) for ln in self.raw[since:])

    def act(self, code, type_, payload=None, round_id=None, action_id=None):
        body = {"actionId": action_id or secrets.token_hex(8), "type": type_, "payload": payload or {}}
        if round_id is not None:
            body["roundId"] = round_id
        r = self.call({"op": "action", "code": code, "body": body})
        time.sleep(0.12)
        return r

    def state(self, code):
        return self.call({"op": "state", "code": code})["state"]


def http_get(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, dict(r.headers), r.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


def main():
    repo, scratch, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "party", "web", "tests"))
    sys.path.insert(0, os.path.join(repo, "tests"))
    import real_e2e as base  # Tab, NET_HOOK, CHROME, PHONE, SMALL, decoded_text
    from impostor_privacy import pre_reveal_leaks, text_leaks

    with open(os.path.join(repo, "tests", "fixtures", "content", "impostor.json"), encoding="utf-8") as f:
        items = json.load(f)["items"]

    # ---------------------------------------------------------------- build + identity
    build_out = os.path.join(scratch, "build")
    build_log = open(os.path.join(out, "build.log"), "w")
    r = subprocess.run(["sh", os.path.join(repo, "party", "native", "build.sh"), build_out],
                        cwd=repo, env=dict(os.environ), stdout=build_log, stderr=subprocess.STDOUT)
    check("build.sh exit 0 (production + test binaries built from this checkout)", r.returncode == 0, r.returncode)
    binary = os.path.join(build_out, "majlis-party-native")
    results["binary_path"] = binary
    results["binary_sha256"] = sha(binary)
    file_out = subprocess.run(["file", binary], capture_output=True, text=True).stdout.strip()
    results["binary_file_type"] = file_out
    check("server executable is a real Mach-O binary, not a script/interpreter wrapper",
          "Mach-O" in file_out and "executable" in file_out, file_out)
    strings_out = subprocess.run(["strings", "-a", binary], capture_output=True, text=True).stdout
    check("binary contains no Python/CPython fallback markers", "CPython" not in strings_out and "python3" not in strings_out.lower(), None)
    check("binary carries the MajlisNative Swift module identity (compiled, not interpreted)",
          "MajlisNative" in strings_out, None)

    # ---------------------------------------------------------------- start, serving the exact bundled assets
    web_dir = os.path.join(repo, "majlis-ios", "PartyWeb")
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    base_url = f"http://127.0.0.1:{port}"
    slog = open(os.path.join(out, "server-stderr.log"), "w")
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir, "--content-dir", content_dir,
           "--operator-stdin", "--exit-on-stdin-eof", "--access-log"]
    results["server_argv"] = cmd
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    results["server_pid"] = srv.pid
    op = Operator(srv, out)
    op.pump_start()
    chrome = None
    tabs = {}
    try:
        banner = op.banner()
        results["banner"] = banner
        check("production banner: surface=production, loopback, memory-only persistence",
              banner.get("surface") == "production" and banner.get("host") == "127.0.0.1" and banner.get("url") == base_url
              and banner.get("event") == "listening", banner)

        # ---------------------------------------------------- served bytes == bundled checkout bytes
        manifest = open(os.path.join(web_dir, "MANIFEST.txt"), encoding="utf-8").read().splitlines()
        rel_paths = [ln for ln in manifest if ln and not ln.startswith("Generated") and not ln.startswith("Files copied")]
        asset_hash = {}
        for rel in rel_paths:
            st, _, body = http_get(base_url + "/" + rel)
            local = sha(os.path.join(web_dir, rel))
            served = sha(body)
            asset_hash[rel] = {"status": st, "local_sha256": local, "served_sha256": served, "match": st == 200 and local == served}
        results["served_asset_hashes"] = asset_hash
        check("every bundled PartyWeb file served by the native host is byte-identical (sha256) to the checkout's majlis-ios/PartyWeb",
              all(v["match"] for v in asset_hash.values()), {k: v["match"] for k, v in asset_hash.items()})
        st, _, _ = http_get(base_url + "/host.html")
        st2, _, _ = http_get(base_url + "/tv.html")
        check("operator/display pages are not served on this production surface (404) - no browser route exists for them here",
              st == 404 and st2 == 404, [st, st2])

        # ---------------------------------------------------- real headless-Chrome players
        profile = tempfile.mkdtemp(prefix="majlis-impostor-native-browser-")
        dport_s = socket.socket(); dport_s.bind(("127.0.0.1", 0)); dport = dport_s.getsockname()[1]; dport_s.close()
        chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                                   "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                   "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version", timeout=2).read())
                browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("headless Chrome reachable over CDP", browser is not None)

        def new_tab(name, vp):
            ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
            tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.call("Emulation.setFocusEmulationEnabled", enabled=True)
            t.viewport(vp)
            tabs[name] = t
            return t

        created = op.call({"op": "create", "body": {}})
        code = created["code"]
        check("bridge create: room code only, no credential leaked in the reply", created["ok"] and re.fullmatch(r"[A-Z0-9]{6}", code) is not None)

        names = ["Aisha", "Omar", "Noora"]
        players = {}
        for nm in names:
            p = new_tab(nm, base.PHONE)
            p.goto(f"{base_url}/play.html?code={code}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what="lobby")
            players[nm] = p
        pid = {}
        tokens = {}
        for nm, p in players.items():
            rec = json.loads(p.storage()[f"majlisParty.v1.player.{code}"])
            pid[nm] = rec["playerId"]
            tokens[nm] = rec["token"]
        check("three distinct player seats issued, each isolated browser context holds only its own seat",
              len(set(pid.values())) == 3 and all(sorted(k for k in players[nm].storage() if k.startswith("majlisParty."))
                  == sorted([f"majlisParty.v1.player.{code}", "majlisParty.v1.last.player"]) for nm in names))
        name_of = {v: k for k, v in pid.items()}
        players["Aisha"].shot(out, "01-lobby")

        op.act(code, "room.set_mode", {"mode": "impostor"})
        r = op.act(code, "room.start")
        check("bridge set_mode(impostor) + start accepted", r["ok"] and r["status"] == 200, r.get("status"))

        # Raw-byte checks are scoped to bytes received since the previous scan
        # of the same connection, not the whole connection history: once a
        # round's reveal has legitimately shown its word/impostor to everyone,
        # that content stays in the connection's cumulative buffer forever and
        # would otherwise falsely "leak" on every later round's scan.
        op_offset = {"n": 0}
        player_offsets = {nm: 0 for nm in players}

        def op_privacy(stage, expect_phase):
            st = op.state(code)
            check(f"[{stage}] operator bridge roundPhase={expect_phase}", st["game"]["roundPhase"] == expect_phase, st["game"]["roundPhase"])
            leaks = pre_reveal_leaks(st, items, "operator")
            check(f"[{stage}] operator bridge state: no pre-reveal leak via whole-payload scanner", not leaks, leaks)
            leaks_txt = text_leaks(op.decoded(since=op_offset["n"]), items)
            check(f"[{stage}] operator bridge raw bytes: no secret item text leaked", not leaks_txt or expect_phase == "reveal", leaks_txt if expect_phase != "reveal" else None)
            op_offset["n"] = len(op.raw)

        def player_privacy(stage, expect_phase, word, current_imp):
            for nm, p in players.items():
                snap = p.last_snap()
                role = "impostor" if nm == current_imp else "crew"
                own = word if role == "crew" else None
                dleaks = pre_reveal_leaks(snap, items, role, own)
                check(f"[{stage}] {nm} ({role}) browser SSE snapshot: no pre-reveal leak via whole-payload scanner", not dleaks, dleaks)
                rx = p.rx_raw(since=player_offsets[nm])
                player_offsets[nm] = len(p.rx())
                tleaks = text_leaks(base.decoded_text(rx), items, own)
                check(f"[{stage}] {nm} ({role}) raw wire bytes received by this browser: no secret-item leak", not tleaks, tleaks)
                dom = p.html()
                own_word_leak = (word in dom) if role == "impostor" else False
                check(f"[{stage}] {nm}: rendered DOM never shows the secret word to the impostor", not own_word_leak)

        for nm, p in players.items():
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} role card (discussion)")
        hs = op.state(code)
        check("round g1r1 started with an order of 3 player ids", hs["roundId"] == "g1r1" and sorted(hs["game"]["order"]) == sorted(pid.values()), hs["roundId"])

        def current_impostor():
            for nm, p in players.items():
                you = (p.last_snap() or {}).get("game", {}).get("you", {})
                if you.get("role") == "impostor":
                    return nm
            return None

        def crew_word():
            for nm, p in players.items():
                you = (p.last_snap() or {}).get("game", {}).get("you", {})
                if you.get("role") == "crew" and you.get("word"):
                    return you["word"]
            return None

        def wait_for(get, pred, timeout=10.0, what=None):
            end = time.time() + timeout
            last = None
            while time.time() < end:
                last = get()
                if pred(last):
                    return last
                time.sleep(0.15)
            raise TimeoutError(f"timed out waiting for {what}; last={last!r}")

        imp = wait_for(current_impostor, lambda v: v, what="impostor revealed to itself")
        word1 = wait_for(crew_word, lambda v: v, what="crew word1")
        check("exactly one browser-rendered player is the impostor; the other two share the crew word", imp in names, imp)
        op_privacy("round1-discussion", "discussion")
        player_privacy("round1-discussion", "discussion", word1, imp)
        players["Aisha"].shot(out, "02-discussion")

        op.act(code, "impostor.advance", round_id="g1r1")
        for nm, p in players.items():
            p.wait("!!document.querySelector('.who-cards')", what=f"{nm} vote ui")
        op_privacy("round1-vote", "vote")
        player_privacy("round1-vote", "vote", word1, imp)

        crew = [n for n in names if n != imp]

        def vote(nm, target):
            players[nm].click(f"__btn({json.dumps(target)})", f"{nm} votes {target}")

        vote(crew[0], imp)
        vote(crew[1], imp)
        vote(imp, crew[0])
        wait_for(lambda: op.state(code)["game"]["roundPhase"], lambda ph: ph == "guess_word", timeout=10, what="vote resolves to guess_word")
        g1 = op.state(code)["game"]
        check("round1: crew unanimously caught the real impostor via browser clicks", g1["nominee"] == pid[imp], {"nominee": g1["nominee"], "impostor": pid[imp]})
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('Guess the word') || !!document.querySelector('#impostor-guess')" if nm == imp
                   else "true", what=f"{nm} guess_word phase")
        op_privacy("round1-guess_word", "guess_word")
        player_privacy("round1-guess_word", "guess_word", word1, imp)
        players[imp].shot(out, "03-guess-word")

        players[imp].type_into("#impostor-guess", word1)
        players[imp].click("__btn('Submit guess')", "submit correct guess")
        wait_for(lambda: op.state(code)["game"]["roundPhase"], lambda ph: ph == "reveal", timeout=10, what="reveal")
        rv = op.state(code)["game"]
        check("round1: correct guess (rendered + submitted through the real DOM) awards the impostor",
              rv["outcome"] == "impostor_guessed_word" and rv["roundPoints"][pid[imp]] == 3 and all(rv["roundPoints"][pid[c]] == 0 for c in crew), rv["roundPoints"])
        check("positive control: the operator bridge's own reveal now does carry the word (it is not a dead scanner)",
              rv["reveal"]["word"] == word1 and word1 in op.decoded())
        # The reveal legitimately puts word1 on the wire; skip past it so the
        # next round's text_leaks scan isn't tripped by this round's own
        # already-authorized reveal still sitting in the cumulative buffer.
        op_offset["n"] = len(op.raw)
        for nm, p in players.items():
            p.wait(f"document.body.textContent.includes({json.dumps(word1)})", what=f"{nm} sees the reveal")
        players["Noora"].shot(out, "04-reveal")

        op.act(code, "round.next", round_id="g1r1")
        wait_for(lambda: op.state(code)["roundId"], lambda rid: rid == "g1r2", what="round g1r2")
        for nm, p in players.items():
            p.wait("!!document.querySelector('.my-card') && document.body.textContent.includes('Talk it out')", what=f"{nm} round2 discussion")
        imp2 = wait_for(current_impostor, lambda v: v, what="impostor2")
        word2 = wait_for(crew_word, lambda v: v, what="word2")
        check("round2: a fresh word/impostor assignment, distinct round id", op.state(code)["roundId"] == "g1r2")
        op_privacy("round2-discussion", "discussion")
        player_privacy("round2-discussion", "discussion", word2, imp2)

        # ---------------------------------------------------- reload / reconnect mid-round2
        reload_target = [n for n in names if n != imp2][0]
        before_pid = pid[reload_target]
        players[reload_target].reload()
        players[reload_target].wait("!!document.querySelector('.my-card')", what=f"{reload_target} reconnected")
        snap_after = players[reload_target].last_snap()
        check(f"{reload_target} reloads mid-round2 and reconnects into the SAME seat/round (server-authoritative, not a new join)",
              snap_after["self"]["id"] == before_pid and snap_after["roundId"] == "g1r2", snap_after.get("roundId"))
        check(f"after reload, {reload_target} still has no pre-reveal leak via the whole-payload scanner",
              not pre_reveal_leaks(snap_after, items, "crew" if reload_target != imp2 else "impostor", word2 if reload_target != imp2 else None))
        players[reload_target].shot(out, "05-reload-reconnect")

        op.act(code, "room.end")
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('Game over')", what=f"{nm} game over")
        check("every page script ran on every player tab without a JS exception",
              not any(p.page_errors() for p in players.values()), {k: p.page_errors()[:2] for k, p in players.items() if p.page_errors()})

        # ---------------------------------------------------- credential hygiene over the wire
        all_rx = "\n".join(base.decoded_text(p.rx_raw()) for p in players.values())
        check("no operator credential (hostToken) anywhere in player-received bytes", "hostToken" not in all_rx)
        leaks = []
        for nm, tok in tokens.items():
            for t in tabs.values():
                if tok in t.eval("document.documentElement.outerHTML + location.href") or tok in t.console_text():
                    leaks.append((nm, t.name))
        check("no player token in any DOM, URL or console of any tab", not leaks, leaks)

    except Exception:
        import traceback
        check("run completed without an exception", False, traceback.format_exc()[-2000:])
    finally:
        for t in list(tabs.values()):
            try: t.ws.close()
            except Exception: pass
        if chrome is not None:
            chrome.terminate()
            try: chrome.wait(10)
            except Exception: chrome.kill()
        try:
            srv.stdin.close()
            srv.wait(10)
        except Exception:
            srv.kill()
        results["server_exit"] = srv.returncode

    p_ = sum(1 for c in results["checks"] if c["pass"])
    f_ = len(results["checks"]) - p_
    results["summary"] = {"pass": p_, "fail": f_, "total": len(results["checks"])}
    json.dump(results, open(os.path.join(out, "impostor-native-browser-results.json"), "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps(results["summary"]))
    sys.exit(0 if f_ == 0 and p_ > 0 else 1)


if __name__ == "__main__":
    main()
