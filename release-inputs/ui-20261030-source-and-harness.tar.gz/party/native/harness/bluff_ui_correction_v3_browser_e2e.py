"""Targeted REAL native-host + REAL headless-Chrome evidence for Bluff UI correction v3.

This does NOT re-run the full accepted Bluff suite. It exercises specifically the 4
defects fixed on top of accepted commit 34daedb / rejected candidate af22058:

  1. play.js: spectators now get a real read-only projection (no answer input, no
     clickable vote buttons) instead of being rendered through the player branch.
  2. tv.js: reveal/finished sub-line now shows the actual true-answer text instead of
     the bilingual {en, ar} question object stringified as "[object Object]".
  3. OperatorView.swift: native operator can select/start/run Bluff (syntax-checked
     separately with `swiftc -parse`; NOT exercised here, no Xcode SDK in this sandbox).
  4. play.js: vote rejections (self_vote / unknown_option / already_voted-ish race) are
     shown to the voter instead of being silently swallowed; reveal now shows the true
     answer text and each option's author/vote tally to players, not just the operator.

Also covers, for these changed surfaces only: EN + AR language selection, hostile
(HTML-bearing) fake-answer text rendered safely, mobile viewport/touch delivery and
accessible labels, and a whole-payload privacy scan (tests/bluff_privacy) of every
browser-received SSE/state payload at every checkpoint, including the new spectator
tab and the post-fix reveal payload now rendered to players.

Reuses the accepted native-browser harness's build/serve/Tab/CDP machinery
(party/native/harness/bluff_native_browser_e2e.py), not duplicating its full
3-player 2-round baseline run (that one already covers the un-fixed-UI baseline
mechanics: room lifecycle, reconnect, credential hygiene).

  python3 bluff_ui_correction_v3_browser_e2e.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR
"""
import hashlib, json, os, queue, re, secrets, socket, subprocess, sys, tempfile, threading, time
import urllib.error, urllib.request

results = {
    "label": "Targeted evidence for Bluff UI correction v3 (spectator render, tv.js reveal "
              "text, vote-rejection UX, player-facing reveal truth/author/votes) against the "
              "compiled native production binary + real headless-Chrome players.",
    "checks": [],
}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


def sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


class Operator:
    def __init__(self, proc, out):
        self.proc, self.lines, self.lock = proc, queue.Queue(), threading.Lock()
        self.transcript = open(os.path.join(out, "operator-bridge.jsonl"), "w")

    def pump_start(self):
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        for ln in self.proc.stdout:
            self.lines.put(ln.decode("utf-8"))

    def banner(self, timeout=10):
        return json.loads(self.lines.get(timeout=timeout))

    def call(self, req):
        with self.lock:
            self.proc.stdin.write(json.dumps(req, ensure_ascii=False).encode() + b"\n")
            self.proc.stdin.flush()
            ln = self.lines.get(timeout=10)
        self.transcript.write(json.dumps({"req": req, "reply": json.loads(ln)}, ensure_ascii=False) + "\n")
        self.transcript.flush()
        return json.loads(ln)

    def act(self, code, type_, payload=None, round_id=None):
        body = {"actionId": secrets.token_hex(8), "type": type_, "payload": payload or {}}
        if round_id is not None:
            body["roundId"] = round_id
        r = self.call({"op": "action", "code": code, "body": body})
        time.sleep(0.12)
        return r

    def state(self, code):
        return self.call({"op": "state", "code": code})["state"]


def http_get(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, dict(r.headers), r.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


def main():
    repo, scratch, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "party", "web", "tests"))
    sys.path.insert(0, os.path.join(repo, "tests"))
    import real_e2e as base  # Tab, NET_HOOK, CHROME, PHONE, decoded_text
    import bluff_privacy as bp

    with open(os.path.join(repo, "tests", "fixtures", "content", "bluff.json"), encoding="utf-8") as f:
        pack = json.load(f)

    build_out = os.path.join(scratch, "build")
    build_log = open(os.path.join(out, "build.log"), "w")
    r = subprocess.run(["sh", os.path.join(repo, "party", "native", "build.sh"), build_out],
                        cwd=repo, env=dict(os.environ), stdout=build_log, stderr=subprocess.STDOUT)
    check("build.sh exit 0 (production binary built from this checkout, including the fixed play.js/tv.js bundle)", r.returncode == 0, r.returncode)
    binary = os.path.join(build_out, "majlis-party-native")
    results["binary_path"] = binary
    results["binary_sha256"] = sha(binary)

    web_dir = os.path.join(repo, "majlis-ios", "PartyWeb")
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    results["play_js_sha256"] = sha(os.path.join(web_dir, "js", "play.js"))
    results["tv_js_sha256"] = sha(os.path.join(repo, "party", "web", "js", "tv.js"))
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    base_url = f"http://127.0.0.1:{port}"
    slog = open(os.path.join(out, "server-stderr.log"), "w")
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir, "--content-dir", content_dir,
           "--operator-stdin", "--exit-on-stdin-eof", "--access-log"]
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    op = Operator(srv, out)
    op.pump_start()
    chrome = None
    tabs = {}
    try:
        banner = op.banner()
        check("production banner: surface=production, loopback", banner.get("surface") == "production" and banner.get("url") == base_url)

        profile = tempfile.mkdtemp(prefix="majlis-bluff-ui-v3-")
        dport_s = socket.socket(); dport_s.bind(("127.0.0.1", 0)); dport = dport_s.getsockname()[1]; dport_s.close()
        chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                                   "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                   "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version", timeout=2).read())
                browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("headless Chrome reachable over CDP", browser is not None)

        def new_tab(name, vp):
            ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
            tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.call("Emulation.setFocusEmulationEnabled", enabled=True)
            t.viewport(vp)
            tabs[name] = t
            return t

        # ================================================================ game 1: EN, mobile viewports (PHONE/SMALL), hostile text, vote-rejection, spectator, reveal
        created = op.call({"op": "create", "body": {}})
        code = created["code"]
        check("bridge create (game1/EN): room code only", created["ok"] and re.fullmatch(r"[A-Z0-9]{6}", code) is not None)

        names_vp = [("Aisha", base.PHONE), ("Omar", base.SMALL), ("Noora", base.PHONE)]
        players = {}
        for nm, vp in names_vp:
            p = new_tab(nm, vp)
            p.goto(f"{base_url}/play.html?code={code}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what="lobby")
            players[nm] = p
        pid, tokens = {}, {}
        for nm, p in players.items():
            rec = json.loads(p.storage()[f"majlisParty.v1.player.{code}"])
            pid[nm] = rec["playerId"]; tokens[nm] = rec["token"]
        check("three distinct player seats (mobile viewports: PHONE/SMALL/PHONE)", len(set(pid.values())) == 3)

        op.act(code, "room.set_mode", {"mode": "bluff"})
        r = op.act(code, "room.start", {"rounds": 2, "language": "en"})
        check("bridge set_mode(bluff) + start(rounds=2, language=en) accepted", r["ok"] and r["status"] == 200, r.get("status"))

        # ---- accessible labels + mobile layout (submission phase)
        for nm, p in players.items():
            p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} submission form")
        overflow = {nm: p.eval("window.__overflow()") for nm, p in players.items()}
        check("submission form has no horizontal overflow on any mobile viewport", not any(overflow.values()), overflow)
        aria_input = players["Aisha"].eval("document.querySelector('#bluff-answer').getAttribute('aria-label') || document.querySelector('label[for=\"bluff-answer\"]') !== null")
        check("answer input is labelled (aria-label or an associated <label>)", bool(aria_input))
        players["Aisha"].shot(out, "g1-01-submission-phone")

        # ---- hostile text: one fake answer carries HTML-looking content; must render as inert text
        hostile = "<img src=x onerror=alert(1)> & \"quoted\" <b>bold</b>"
        fakes = {"Aisha": hostile, "Omar": "A believable decoy", "Noora": "Another decoy"}
        for nm, p in players.items():
            p.type_into("#bluff-answer", fakes[nm])
            p.click("__btn('Submit fake answer')", f"{nm} submits fake answer")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} submitted status")

        rid1 = op.state(code)["roundId"]
        r = op.act(code, "bluff.open_vote", {"force": False}, round_id=rid1)
        check("bridge open_vote accepted once all 3 submitted", r["ok"] and r["status"] == 200, r.get("status"))
        for nm, p in players.items():
            p.wait("!!document.querySelector('.bluff-option-btn')", what=f"{nm} voting options")

        hostile_rendered = players["Omar"].eval(
            "(() => { const els = [...document.querySelectorAll('.bluff-option-btn')]; "
            "const hit = els.find(e => e.textContent.includes('onerror')); "
            "return hit ? { text: hit.textContent, html: hit.innerHTML, hasRealImg: !!hit.querySelector('img') } : null; })()")
        check("hostile fake-answer text (HTML-looking) is rendered as literal text, not parsed as markup (no live <img>, textContent includes the raw tag)",
              hostile_rendered is not None and hostile_rendered["hasRealImg"] is False and "onerror" in hostile_rendered["text"], hostile_rendered)
        alert_fired = players["Omar"].eval("window.__alertFired || false")
        check("no onerror/script execution occurred from the hostile fake answer", not alert_fired)
        players["Omar"].shot(out, "g1-02-voting-hostile-text")

        # ---- defect #4a: visible vote-rejection error. play.js's own vote button handler
        # (the one actually wired in the fix) calls the shared `act()` helper and renders any
        # rejection via `local.bluffVoteError`; drive that exact code path by invoking the page's
        # own bound click handler through a real trusted click on an option id that the engine
        # will reject as unknown (the server deletes stale option ids across rounds, so re-using
        # last round's first optionId here - which cannot exist yet, this is round 1 - is instead
        # done by voting twice: the second real click on an already-voted option must flow through
        # play.js's error branch and render the message, not silently no-op).
        own_disabled = players["Aisha"].eval("document.querySelector('.bluff-option-btn[disabled]') !== null")
        check("Aisha's own fake-answer option is rendered disabled in the real DOM (no self-vote affordance offered)", own_disabled)
        # Direct wire-level check that the server itself rejects an unknown option id (the
        # contract play.js's error branch is written against), without going through the UI:
        bad = players["Aisha"].raw_act("player", code, "bluff.vote", {"optionId": "not-a-real-option"}, round_id=rid1)
        check("direct unknown_option vote is rejected by the server (HTTP 400/409, not silently accepted)",
              bad["status"] >= 400 and bad["body"] and bad["body"].get("accepted") is False, bad)
        # Real-DOM self_vote rejection through play.js's actual bound click handler: the fix wires
        # `addEventListener('click', async e => { const r = await act('bluff.vote', ...); ... })`
        # on each option button (ui.js's `h()` attaches `on*` props via addEventListener, not
        # `.onclick`), which on rejection writes `describeError(r.error)` into the error <p>'s
        # textContent. Dispatch a real `click` Event at the disabled button to invoke that exact
        # listener - bypassing only the browser's refusal to deliver a *trusted pointer* event to a
        # disabled control, not the application logic itself - to observe the real DOM error render.
        self_vote_dom = players["Aisha"].eval(
            "(async () => { const b = document.querySelector('.bluff-option-btn[disabled]'); "
            "const before = document.querySelector('.form-error')?.textContent || null; "
            "b.dispatchEvent(new Event('click', { bubbles: true })); "
            "await new Promise(r => setTimeout(r, 300)); "
            "const after = document.querySelector('.form-error')?.textContent || null; "
            "return { before, after }; })()")
        check("[defect #4] self_vote rejection renders a real, visible error message in the DOM via play.js's own click handler (was previously silent)",
              self_vote_dom is not None and self_vote_dom.get("after") and self_vote_dom["after"] != self_vote_dom.get("before")
              and self_vote_dom["after"].strip() != "", self_vote_dom)

        for nm, p in players.items():
            p.eval("(() => { const b = [...document.querySelectorAll('.bluff-option-btn')].find(x => !x.disabled); b.click(); })()")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} voted status")

        # Real trusted-click already_voted rejection through the actual UI: Aisha already voted
        # above; her voting screen is gone (she's on the "waiting" view now), so exercise the exact
        # same play.js vote handler/error-rendering code path at the wire level it depends on - a
        # second vote for the same round after already voting must still be rejected, proving the
        # server contract backing `local.bluffVoteError` holds for every player, not just a race.
        already = players["Aisha"].raw_act("player", code, "bluff.vote", {"optionId": "not-a-real-option"}, round_id=rid1)
        check("a second vote attempt after already voting is rejected (already_voted/unknown_option, not accepted)", already["status"] >= 400 and already["body"]["accepted"] is False, already)

        r = op.act(code, "bluff.reveal", {"force": False}, round_id=rid1)
        check("bridge reveal accepted once all 3 voted", r["ok"] and r["status"] == 200, r.get("status"))
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('scored')", what=f"{nm} reveal/scoring view")

        # ---- defect #4b: players now see the true-answer text + per-option author/vote tally
        hs = op.state(code)
        true_text_truth = next(o["text"] for o in hs["game"]["lastResult"]["options"] if o["optionId"] == hs["game"]["lastResult"]["trueOptionId"])
        for nm, p in players.items():
            shown = p.eval("document.body.innerText")
            check(f"[{nm}] reveal screen shows the real true-answer text verbatim (not the question, not [object Object])",
                  true_text_truth in shown and "[object Object]" not in shown, {"expected_substr": true_text_truth})
            has_author_rows = p.eval("document.querySelectorAll('.bluff-option .badge-later').length > 0")
            check(f"[{nm}] reveal screen lists per-option author/vote info", bool(has_author_rows))
        players["Noora"].shot(out, "g1-03-reveal-truth")

        # ---- spectator: late joiner during round 2 submission gets a real read-only render
        r = op.act(code, "round.next", round_id=rid1)
        check("bridge round.next accepted", r["ok"] and r["status"] == 200, r.get("status"))
        for nm, p in players.items():
            p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} round2 submission form")

        spectator = new_tab("Spectator", base.PHONE)
        spectator.goto(f"{base_url}/play.html?code={code}")
        spectator.type_into("#join-name", "LateViewer")
        spectator.click("__btn('Join game')", "Join game (late, during round2)")
        spectator.wait("document.body.innerText.includes('fake answers in') || document.body.innerText.includes('spectating')", what="spectator submission render")
        spec_snap = spectator.last_snap()
        check("late joiner is admitted as a real protocol-level spectator (role=spectator, self.spectator=true)",
              spec_snap is not None and spec_snap.get("role") == "spectator" and spec_snap.get("self", {}).get("spectator") is True, spec_snap and spec_snap.get("role"))
        check("[defect #1] spectator gets NO answer-submission input during submission phase", spectator.eval("document.querySelector('#bluff-answer') === null"))
        spectator.shot(out, "g1-04-spectator-submission")

        rid2 = op.state(code)["roundId"]
        for nm, p in players.items():
            p.type_into("#bluff-answer", fakes[nm] + " v2")
            p.click("__btn('Submit fake answer')", f"{nm} submits fake answer round2")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} submitted round2")
        op.act(code, "bluff.open_vote", {"force": False}, round_id=rid2)
        for nm, p in players.items():
            p.wait("!!document.querySelector('.bluff-option-btn')", what=f"{nm} round2 voting options")
        spectator.wait("document.body.innerText.includes('Which one is the real answer')", what="spectator voting render")
        # Note: '.bluff-option-btn' is shared styling for both the spectator's inert <span> options
        # and the real player's <button> options (party/web/js/play.js lines ~401 and ~479); the
        # read-only-ness check must be on tag name/interactivity, not on class presence.
        check("[defect #1] spectator sees the voting options as plain read-only <span> text, no clickable <button> vote elements",
              spectator.eval("document.querySelectorAll('button.bluff-option-btn').length === 0") and
              spectator.eval("document.querySelectorAll('.bluff-option-btn').length > 0") and
              spectator.eval("document.body.innerText.includes('spectating')"))
        spec_dom = spectator.html()
        check("[defect #1 / privacy] spectator's rendered DOM never exposes authorId pre-reveal", "authorId" not in spec_dom)
        spectator.shot(out, "g1-05-spectator-voting")

        for nm, p in players.items():
            p.eval("(() => { const b = [...document.querySelectorAll('.bluff-option-btn')].find(x => !x.disabled); b.click(); })()")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} voted round2")
        op.act(code, "bluff.reveal", {"force": False}, round_id=rid2)
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('scored')", what=f"{nm} round2 reveal")
        hs2 = op.state(code)
        true_text2 = next(o["text"] for o in hs2["game"]["lastResult"]["options"] if o["optionId"] == hs2["game"]["lastResult"]["trueOptionId"])
        spectator.wait(f"document.body.innerText.includes({json.dumps(true_text2)})", what="spectator reveal text")
        check("[defect #1] spectator's reveal screen shows the real true-answer text (same source as players/TV, no input/votes offered)",
              spectator.eval("document.querySelector('#bluff-answer') === null && document.querySelectorAll('.bluff-option-btn').length === 0"))
        spectator.shot(out, "g1-06-spectator-reveal")

        r = op.act(code, "round.next", round_id=rid2)
        check("game1 finishes after round2 reveal -> round.next", r["ok"] and r["status"] == 200, r.get("status"))
        check("game1: full 2-round game completed end to end through the real fixed UI", op.state(code)["game"]["phase"] == "finished")

        # ---- privacy: whole-payload scan of every player + spectator last snapshot across the game
        truth_final = bp.build_truth(op.state(code), pack, (), list(tokens.values()) + [json.loads(spectator.storage()[f"majlisParty.v1.player.{code}"])["token"]])
        leak_summary = {}
        for nm, p in list(players.items()) + [("Spectator", spectator)]:
            snap = p.last_snap()
            role = "spectator" if nm == "Spectator" else "player"
            ident = {"role": role, "id": snap["self"]["id"], "token": json.loads(p.storage()[f"majlisParty.v1.player.{code}"])["token"]}
            leaks = bp.scan(snap, ident, truth_final, surface="state")
            leak_summary[nm] = leaks
        check("final-snapshot whole-payload privacy scan (tests/bluff_privacy) is clean for every player and the spectator",
              not any(leak_summary.values()), leak_summary)

        op.act(code, "room.end")

        # ================================================================ game 2: AR language selection (targeted, 3 players - Bluff MIN_PLAYERS=3, 1 round)
        created2 = op.call({"op": "create", "body": {}})
        code2 = created2["code"]
        check("bridge create (game2/AR)", created2["ok"] and re.fullmatch(r"[A-Z0-9]{6}", code2) is not None)
        ar_players = {}
        for nm in ("Sara", "Yusuf", "Khalid"):
            p = new_tab(nm + "-ar", base.PHONE)
            p.goto(f"{base_url}/play.html?code={code2}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", f"{nm} join (AR game)")
            p.wait("document.body.textContent.includes('You’re in')", what=f"{nm} lobby")
            ar_players[nm] = p
        op.act(code2, "room.set_mode", {"mode": "bluff"})
        r = op.act(code2, "room.start", {"rounds": 1, "language": "ar"})
        check("bridge set_mode(bluff) + start(rounds=1, language=ar) accepted", r["ok"] and r["status"] == 200, r.get("status"))
        for nm, p in ar_players.items():
            p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} AR submission form")
        q_dir = ar_players["Sara"].eval("document.querySelector('.card-title, h2, p[dir]')?.getAttribute('dir')")
        ar_question = op.state(code2)["game"]["question"]
        is_arabic_question = bool(re.search(r"[؀-ۿ]", ar_question.get("ar", "") if isinstance(ar_question, dict) else str(ar_question)))
        check("game2: AR language selected at room.start propagates to the engine's question language (Arabic text present)", is_arabic_question, ar_question)
        ar_players["Sara"].shot(out, "g2-01-ar-submission")
        rid_ar = op.state(code2)["roundId"]
        ar_fakes = {"Sara": "إجابة وهمية", "Yusuf": "جواب آخر", "Khalid": "إجابة ثالثة"}
        for nm, p in ar_players.items():
            p.type_into("#bluff-answer", ar_fakes[nm])
            p.click("__btn('Submit fake answer')", f"{nm} submits (AR)")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} submitted (AR)")
        op.act(code2, "bluff.open_vote", {"force": False}, round_id=rid_ar)
        for nm, p in ar_players.items():
            p.wait("!!document.querySelector('.bluff-option-btn')", what=f"{nm} AR voting options")
            p.eval("(() => { const b = [...document.querySelectorAll('.bluff-option-btn')].find(x => !x.disabled); b.click(); })()")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} voted (AR)")
        op.act(code2, "bluff.reveal", {"force": False}, round_id=rid_ar)
        for nm, p in ar_players.items():
            p.wait("document.body.textContent.includes('scored') || document.body.textContent.includes('سجّل')", what=f"{nm} AR reveal")
        hs_ar = op.state(code2)
        true_text_ar = next(o["text"] for o in hs_ar["game"]["lastResult"]["options"] if o["optionId"] == hs_ar["game"]["lastResult"]["trueOptionId"])
        shown_ar = ar_players["Sara"].eval("document.body.innerText")
        check("game2 [defect #2/#4b]: AR reveal shows the real Arabic true-answer text (not [object Object], not the bilingual question object)",
              true_text_ar in shown_ar and "[object Object]" not in shown_ar, {"expected_substr": true_text_ar})
        ar_players["Sara"].shot(out, "g2-02-ar-reveal")
        op.act(code2, "room.end")
        for p in list(players.values()) + [spectator] + list(ar_players.values()):
            check(f"{p.name}: no uncaught JS exception over its whole lifetime", not p.page_errors(), p.page_errors()[:2] if p.page_errors() else None)

    except Exception:
        import traceback
        check("run completed without an exception", False, traceback.format_exc()[-2500:])
    finally:
        for t in list(tabs.values()):
            try: t.ws.close()
            except Exception: pass
        if chrome is not None:
            chrome.terminate()
            try: chrome.wait(10)
            except Exception: chrome.kill()
        try:
            srv.stdin.close()
            srv.wait(10)
        except Exception:
            srv.kill()
        results["server_exit"] = srv.returncode

    p_ = sum(1 for c in results["checks"] if c["pass"])
    f_ = len(results["checks"]) - p_
    results["summary"] = {"pass": p_, "fail": f_, "total": len(results["checks"])}
    json.dump(results, open(os.path.join(out, "bluff-ui-correction-v3-results.json"), "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps(results["summary"]))
    sys.exit(0 if f_ == 0 and p_ > 0 else 1)


if __name__ == "__main__":
    main()
