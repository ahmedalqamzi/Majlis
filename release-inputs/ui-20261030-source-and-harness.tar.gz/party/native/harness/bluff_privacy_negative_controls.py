"""Planted-secret negative controls for Bluff privacy (correction v3), run
against REAL compiled native hosts over HTTP + SSE.

Same architecture as the accepted Impostor controls
(party/native/harness/impostor_privacy_negative_controls.py; its
``build_binary``/``start_native``/``stop_native`` are reused unchanged):
each mutant copies party/core + party/native into a scratch directory
(never the checkout), applies exactly ONE textual mutation (anchor must
occur exactly once), builds it with build.sh and runs the resulting
binary as the HTTP server.

The driver plays a 3-player Bluff room (2 rounds) and, after every
revision-changing step, records the operator's private ground truth
(tests/bluff_privacy.build_truth) keyed by revision. It scans, with the
exact path/role/phase checker tests/bluff_privacy.scan:

  state      GET /state for operator, display, every player, the spectator
  sse        every parsed SSE ``state`` event of a display, a player and the
             spectator stream (against the truth of that event's revision)
             plus a raw-byte token scan of each stream
  join       the late joiner's join response (admitted as spectator)
  reconnect  the spectator's and a player's join-with-token resume response
  action     accepted receipts and rejected receipts (truth submitted,
             spectator acting)
  error      HTTP error envelopes (unknown option, forbidden)
  cross      the voting options of every non-operator viewer compared

at checkpoints submission-0 / submission / voting / voting-voted / reveal
/ round2-submission.

A control passes only when the UNMUTATED baseline is clean in every cell,
and the mutant is caught, with one of its expected rule classes, in every
targeted cell. Cells outside the target are reported (not required clean,
since one planted field can legitimately trip several classes).

Usage: python3 bluff_privacy_negative_controls.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR [mutant ...]
"""
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
REPO_FOR_IMPORT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, os.path.join(REPO_FOR_IMPORT, "tests"))
sys.path.insert(0, HERE)

import impostor_privacy_negative_controls as ipc  # noqa: E402  (reuse build/start/stop helpers)

CORE = "core/majlis-core.js"
BASELINE_RUNS = 4
DISTINCT_TRANSLATION = ("translation-discriminator-v2", "truth-in-other-language")
NONOP = ("display", "player", "spectator")
ALL = ("operator",) + NONOP
PRE = ("submission-0", "submission", "voting", "voting-voted")
VOTE = ("voting", "voting-voted")
SNAP = ("state", "sse")

# Anchors (each occurs exactly once in party/core/majlis-core.js)
A_OPTS = "{ optionId: o.optionId, text: o.text } :"
A_OPROLE = "      if (role === \"operator\") {\n        view.fakes = deepcopy(state.fakes);"
A_YOU = "view.you = mine;"
A_TRUTH = "entries.push({ authorId: null, text: cleanText(s.item.trueAnswer[s.language], MAX_ANSWER_LEN) });"
A_ID = "return \"o\" + sha256Hex(utf8Encode(material)).slice(0, 16);"
A_OWN = "mine.ownOptionId = own ? own.optionId : null;"
A_PROJECT = "return projectRoom(room.state, { role: principal.role, playerId: principal.playerId }, room.revision, room.presence, this.contents);"
A_SSE = "if (room.revision !== lastRevision) return [\"state\", room.revision, this.project(room, principal)];"
A_RESUME = "if (isSpectator(room.state, principal.playerId)) resumed.spectating = true;"
A_JOINED = "if (isSpectator(room.state, playerId)) joined.spectating = true;"
A_REJECT = "entry = [statusFor(err), { accepted: false, revision: room.revision, error: errorBody(err) }];"
A_SPECROLE = "      role = \"spectator\";\n    }"
A_SPECVIEW = "gameView = spectating ? spec.module.project(game, { role: \"display\", playerId: null })"


def cells(checkpoints, roles, surfaces):
    return {(c, r, s) for c in checkpoints for r in roles for s in surfaces}


def pre(code):  # inject just before the operator branch of Bluff.project
    return A_OPROLE.replace("      if (role", "      " + code + "\n      if (role", 1)


MUTANTS = {
    # name: (rel, old, new, targeted cells, expected rules)
    "trueanswer-to-every-role": (
        CORE, A_OPROLE, pre("view.trueAnswer = deepcopy(state.item.trueAnswer);"),
        cells(PRE + ("reveal",), NONOP, SNAP), {"truth-metadata", "truth-text"}),
    "trueoptionid-pre-reveal": (
        CORE, A_OPROLE, pre("if (state.options !== null) view.trueOptionId = state.options.filter(function (o) { return o.authorId === null; })[0].optionId;"),
        cells(VOTE + ("reveal",), ALL, SNAP), {"truth-metadata"}),
    "istrue-on-options": (
        CORE, A_OPTS, "{ optionId: o.optionId, text: o.text, isTrue: o.authorId === null } :",
        cells(VOTE, ALL, SNAP), {"truth-metadata"}),
    "aliases-to-every-role": (
        CORE, A_OPROLE, pre("view.aliases = deepcopy(state.item.aliases);"),
        cells(PRE + ("reveal",), ALL, SNAP), {"truth-metadata"}),
    "authorid-pre-reveal": (
        CORE, A_OPTS, "{ optionId: o.optionId, text: o.text, authorId: o.authorId } :",
        cells(VOTE, ALL, SNAP), {"authorship", "option-shape"}),
    "other-fakes-to-players-by-key": (
        CORE, A_YOU, "view.you = mine; view.submissions = deepcopy(state.fakes);",
        cells(PRE, ("player",), SNAP), {"raw-private-state"}),
    "other-fakes-to-players-by-value": (
        CORE, A_YOU, "view.you = mine; view.title = Object.keys(state.fakes).filter(function (p) { return p !== me; }).map(function (p) { return state.fakes[p]; }).join(\" / \");",
        cells(("submission", "voting", "voting-voted"), ("player",), SNAP), {"other-submission"}),
    "votes-to-every-role": (
        CORE, A_OPROLE, pre("view.votes = deepcopy(state.votes);"),
        cells(PRE, NONOP, SNAP), {"raw-private-state"}),
    "translation-discriminator-v2": (
        CORE, A_TRUTH, "entries.forEach(function (e) { e.text = { en: e.text, ar: e.text }; }); entries.push({ authorId: null, text: deepcopy(s.item.trueAnswer) });",
        cells(VOTE, NONOP, SNAP), {"option-shape", "truth-text"}),
    "truth-in-other-language": (
        CORE, A_TRUTH, "entries.push({ authorId: null, text: cleanText(s.item.trueAnswer[s.language === \"en\" ? \"ar\" : \"en\"], MAX_ANSWER_LEN) });",
        cells(VOTE, NONOP, SNAP), {"truth-text"}),
    "positional-option-ids": (
        CORE, A_ID, "return \"o\" + slot + (salt ? \"_\" + salt : \"\");",
        cells(VOTE + ("reveal",), ALL, SNAP), {"option-shape"}),
    "content-bank-next-question": (
        CORE, A_OPROLE, pre("view.title = state.deck.length ? state.deck[0].question.en : state.title;"),
        cells(PRE + ("reveal",), ALL, SNAP), {"content-bank"}),
    "own-token-hash-in-snapshot": (
        CORE, A_PROJECT, "return (function (sn) { sn.operatorName = principal.tokenHash; return sn; })(projectRoom(room.state, { role: principal.role, playerId: principal.playerId }, room.revision, room.presence, this.contents));",
        cells(PRE + ("reveal",), ALL, SNAP), {"token"}),
    "own-option-id-points-at-truth": (
        CORE, A_OWN, "mine.ownOptionId = state.options.filter(function (o) { return o.authorId === null; })[0].optionId;",
        cells(VOTE, ("player",), SNAP), {"own-metadata"}),
    "per-viewer-option-order": (
        CORE, A_OPROLE, pre("if (role === \"player\" && view.options !== null && me !== state.order[0]) view.options.reverse();"),
        cells(VOTE, ("cross",), ("cross",)), {"option-shape"}),
    "sse-only-truth-leak": (
        CORE, A_SSE, "if (room.revision !== lastRevision) return [\"state\", room.revision, (function (sn) { if (sn.game && room.state.game && room.state.mode === \"bluff\") sn.game.trueAnswer = room.state.game.item.trueAnswer; return sn; })(this.project(room, principal))];",
        cells(PRE, NONOP, ("sse",)), {"truth-metadata", "truth-text"}),
    "reconnect-only-fakes-leak": (
        CORE, A_RESUME, A_RESUME + " if (room.state.game && room.state.game.fakes) resumed.fakes = room.state.game.fakes;",
        cells(("submission",), ("spectator", "player"), ("reconnect",)), {"raw-private-state"}),
    "spectator-join-truth-leak": (
        CORE, A_JOINED, A_JOINED + " if (joined.spectating) joined.hint = room.state.game.item.trueAnswer.en;",
        cells(("submission",), ("spectator",), ("join",)), {"raw-private-state", "truth-text"}),
    "rejected-receipt-truth-leak": (
        CORE, A_REJECT, "entry = [statusFor(err), { accepted: false, revision: room.revision, error: errorBody(err), detail: (room.state.game && room.state.game.item) ? room.state.game.item.trueAnswer : null }];",
        cells(("submission",), ("player", "spectator"), ("action",)), {"raw-private-state", "truth-metadata", "truth-text"}),
    "spectator-served-operator-view": (
        CORE, A_SPECVIEW, "gameView = spectating ? spec.module.project(game, { role: \"operator\", playerId: null })",
        cells(PRE + ("reveal",), ("spectator",), SNAP), {"raw-private-state", "truth-metadata"}),
    "spectator-labelled-player": (
        CORE, A_SPECROLE, "      role = \"player\";\n    }",
        cells(PRE + ("reveal",), ("spectator",), SNAP), {"role"}),
}


def drive_and_scan(port, pack, distinct_translation=False):
    """Play the room and return {cell: [finding dicts]} for every cell.

    ``distinct_translation``: mutants that only change how the translation
    is serialised are inert on items whose EN and AR answers are equal
    (bluff-005 "Au", bluff-020 "366"); for those controls the room is
    re-created (fresh host-entropy seed) until round 1 draws an item whose
    translations differ, so the control cannot pass or fail by luck."""
    import support  # tests/support.py
    import bluff_privacy as bp

    api = support.Api(port)
    out = {}
    timeline = {}  # revision -> truth
    played = []

    for _attempt in range(60):
        r = api.create_room()
        code, host, display = r.json["code"], r.json["hostToken"], r.json["displayToken"]
        tokens = [host, display]
        players = []
        for nm in ("Aisha", "Omar", "Noora"):
            jr = api.join(code, nm)
            players.append({"id": jr.json["playerId"], "token": jr.json["playerToken"], "name": nm})
            tokens.append(jr.json["playerToken"])
        api.action(code, host, "room.set_mode", payload={"mode": "bluff"})
        api.action(code, host, "room.start", payload={"rounds": 2})
        ta = api.state(code, host).json["game"]["trueAnswer"]
        if not distinct_translation or ta["en"].casefold() != ta["ar"].casefold():
            break
    P = {p["name"]: p for p in players}
    spectator = {}

    def record():
        op = api.state(code, host).json
        t = bp.build_truth(op, pack, played, tokens)
        timeline[op["revision"]] = t
        return op, t

    def add(cell, findings):
        out.setdefault(cell, []).extend(f.as_dict() for f in findings)

    viewers = lambda: ([("operator", host, None), ("display", display, None)] +
                       [("player", p["token"], p["id"]) for p in players] +
                       ([("spectator", spectator["token"], spectator["id"])] if spectator else []))

    def checkpoint(label):
        op, t = record()
        opts = {}
        for role, token, pid in viewers():
            resp = api.state(code, token)
            v = {"role": role, "id": pid, "token": token}
            add((label, role, "state"), bp.scan(resp.json, v, t, "state"))
            add((label, role, "state"), bp.scan_raw(resp.text, v, t))
            if role != "operator" and isinstance(resp.json.get("game"), dict):
                opts[role + ":" + (pid or "")] = resp.json["game"].get("options")
        add((label, "cross", "cross"), bp.cross_viewer(opts) if t["votingOpen"] else [])
        streams_seen[label] = op["revision"]
        return op, t

    streams_seen = {}
    sse = {"display": support.SSEClient(port, "/api/rooms/%s/events" % code, token=display),
           "player": support.SSEClient(port, "/api/rooms/%s/events" % code, token=P["Aisha"]["token"])}
    sse_viewer = {"display": {"role": "display", "id": None, "token": display},
                  "player": {"role": "player", "id": P["Aisha"]["id"], "token": P["Aisha"]["token"]}}
    time.sleep(0.2)

    op, t = checkpoint("submission-0")
    rid = op["roundId"]
    q = op["game"]["question"]["en"]
    api.action(code, P["Omar"]["token"], "bluff.submit_answer", rid, {"text": "Omar invented answer"})
    record()
    api.action(code, P["Noora"]["token"], "bluff.submit_answer", rid, {"text": "Noora invented answer"})
    record()
    # truth submitted -> rejected receipt
    rec = api.action(code, P["Aisha"]["token"], "bluff.submit_answer", rid, {"text": t["truth"]["en"]})
    op, t = record()
    add(("submission", "player", "action"), bp.scan(rec.json, sse_viewer["player"], t, "action"))
    # late joiner -> spectator
    jr = api.join(code, "Late Viewer")
    spectator.update({"id": jr.json["playerId"], "token": jr.json["playerToken"]})
    tokens.append(spectator["token"])
    op, t = record()
    sv = {"role": "spectator", "id": spectator["id"], "token": spectator["token"]}
    add(("submission", "spectator", "join"), bp.scan(jr.json, sv, t, "join"))
    rj = api.join(code, None, token=spectator["token"])
    add(("submission", "spectator", "reconnect"), bp.scan(rj.json, sv, t, "reconnect"))
    rj = api.join(code, None, token=P["Omar"]["token"])
    add(("submission", "player", "reconnect"), bp.scan(rj.json, {"role": "player", "id": P["Omar"]["id"], "token": P["Omar"]["token"]}, t, "reconnect"))
    sa = api.action(code, spectator["token"], "bluff.submit_answer", rid, {"text": "spectator text"})
    add(("submission", "spectator", "action"), bp.scan(sa.json, sv, t, "action"))
    sse["spectator"] = support.SSEClient(port, "/api/rooms/%s/events" % code, token=spectator["token"])
    sse_viewer["spectator"] = sv
    time.sleep(0.2)
    checkpoint("submission")

    ok = api.action(code, P["Aisha"]["token"], "bluff.submit_answer", rid, {"text": "Aisha invented answer"})
    op, t = record()
    add(("submission", "player", "action"), bp.scan(ok.json, sse_viewer["player"], t, "action"))
    api.action(code, host, "bluff.open_vote", rid)
    record()
    op, t = checkpoint("voting")
    true_id = next(o["optionId"] for o in t["options"] if o["authorId"] is None)
    by_author = {o["authorId"]: o["optionId"] for o in t["options"]}
    bad = api.action(code, P["Aisha"]["token"], "bluff.vote", rid, {"optionId": "o0"})
    add(("voting", "player", "error"), bp.scan(bad.json, sse_viewer["player"], t, "action"))
    api.action(code, P["Aisha"]["token"], "bluff.vote", rid, {"optionId": true_id})
    record()  # one ground-truth entry per revision, so every SSE event is judged exactly
    api.action(code, P["Omar"]["token"], "bluff.vote", rid, {"optionId": by_author[P["Noora"]["id"]]})
    record()
    checkpoint("voting-voted")
    api.action(code, P["Noora"]["token"], "bluff.vote", rid, {"optionId": by_author[P["Aisha"]["id"]]})
    record()
    api.action(code, host, "bluff.reveal", rid)
    record()
    checkpoint("reveal")
    played.append(q)
    api.action(code, host, "round.next", rid)
    record()
    checkpoint("round2-submission")

    time.sleep(0.4)
    for label, client in sse.items():
        client.close()
        v = sse_viewer[label]
        raw = client.raw_text()
        revs = sorted(timeline)
        role = v["role"]
        events = []
        while True:
            try:
                item = client.items.get_nowait()
            except Exception:
                break
            if item and item.get("event") == "state" and item.get("json"):
                events.append(item["json"])
        bounds = sorted(streams_seen.items(), key=lambda kv: kv[1])
        for ev in events:
            rv = ev["revision"]
            t = timeline.get(rv) or timeline[max([x for x in revs if x <= rv] or revs[:1])]
            label_cp = next((cp for cp, crev in bounds if rv <= crev), "round2-submission")
            add((label_cp, role, "sse"), bp.scan(ev, v, t, "sse"))
        add(("stream", role, "sse-raw"), bp.scan_raw(raw, v, timeline[max(timeline)]))
        out.setdefault(("stream", role, "sse-count"), []).append({"events": len(events)})
    return out


def judge(results, targeted, expected, baseline=False, universe=None):
    flagged = {cell: [f for f in fs if "rule" in f] for cell, fs in results.items()}
    if baseline:
        dirty = {k: v for k, v in flagged.items() if v}
        return not dirty, dirty
    missed = {}
    for cell in targeted:
        if universe is not None and cell not in universe:
            continue  # e.g. the spectator does not exist yet at submission-0
        hits = [f for f in flagged.get(cell, []) if f["rule"] in expected]
        if not hits:
            missed[cell] = flagged.get(cell, "cell not produced")
    return not missed, missed


def key(cell):
    return "|".join(cell)


def main():
    repo, scratch, evid = (os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3]))
    only = sys.argv[4:]
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    pack = json.load(open(os.path.join(content_dir, "bluff.json"), encoding="utf-8"))
    os.makedirs(evid, exist_ok=True)
    report = {"baseline": None, "mutants": {}}
    all_ok = True

    binary = ipc.build_binary(repo, scratch)
    proc, port = ipc.start_native(binary, content_dir)
    try:
        # several independent rooms (fresh host-entropy seeds, so different
        # items, option orders and truth slots); every cell must stay clean
        runs = [drive_and_scan(port, pack) for _ in range(BASELINE_RUNS)]
    finally:
        ipc.stop_native(proc)
    baseline = {}
    for run in runs:
        for cell, fs in run.items():
            baseline.setdefault(cell, []).extend(fs)
    base_ok, dirty = judge(baseline, set(), set(), baseline=True)
    report["baseline"] = {"runs": BASELINE_RUNS, "clean": base_ok, "dirty": {key(k): v for k, v in dirty.items()},
                          "cells": sorted(key(k) for k in baseline)}
    all_ok = all_ok and base_ok
    print(json.dumps({"baseline_clean": base_ok, "cells": len(baseline), "dirty": len(dirty)}), flush=True)
    if not base_ok:
        print(json.dumps({key(k): v for k, v in dirty.items()}, ensure_ascii=False, indent=1)[:4000])

    for name, (rel, old, new, targeted, expected) in MUTANTS.items():
        if only and name not in only:
            continue
        binary = ipc.build_binary(repo, scratch, rel, old, new)
        proc, port = ipc.start_native(binary, content_dir)
        try:
            results = drive_and_scan(port, pack, distinct_translation=name in DISTINCT_TRANSLATION)
            err = None
        except Exception as e:  # a mutant that breaks the protocol is reported, not hidden
            results, err = {}, repr(e)
        finally:
            ipc.stop_native(proc)
        caught, missed = judge(results, targeted, expected, universe=set(baseline))
        caught = caught and err is None
        report["mutants"][name] = {
            "anchor": old, "mutation": new, "expected_rules": sorted(expected), "control_passed": caught,
            "driver_error": err, "targeted": sorted(key(c) for c in targeted),
            "missed": {key(k): v for k, v in missed.items()},
            "caught_cells": {key(k): sorted({f["rule"] for f in v if "rule" in f}) for k, v in results.items()
                             if any("rule" in f for f in v)},
        }
        all_ok = all_ok and caught
        print(json.dumps({"mutant": name, "control_passed": caught, "targeted": len(targeted), "missed": len(missed),
                          "driver_error": err}), flush=True)

    with open(os.path.join(evid, "bluff_privacy_negative_controls.json"), "w") as f:
        json.dump(report, f, indent=2, default=str, ensure_ascii=False)
    print("ALL PLANTED LEAKS DETECTED IN EVERY TARGETED CELL, BASELINE CLEAN" if all_ok
          else "FAILED: see bluff_privacy_negative_controls.json")
    return 0 if all_ok else 1


if __name__ == "__main__":
    sys.exit(main())
