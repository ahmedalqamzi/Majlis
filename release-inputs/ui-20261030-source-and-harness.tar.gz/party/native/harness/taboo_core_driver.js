// Test-only JavaScriptCore driver for the reviewed core (never embedded).
//
//   jsc unicode13.generated.js majlis-core.js taboo_core_driver.js -- PROGRAM.json
//
// Executes a resolved step program against MajlisCore.RoomManager with an
// injected clock (`now` per step) and injected entropy, exactly as the native
// transport calls it (request bodies go through MajlisCore.json.parseRequestBody),
// and prints one JSON line per step: {status, body, views:{viewer: snapshot}}.
// Tokens are replaced with "<token>" in printed bodies; ids are printed as-is.
(function (argv) {
  "use strict";
  var C = MajlisCore;
  var prog = JSON.parse(read(argv[0]));
  var packs = {};
  Object.keys(prog.packsHex).forEach(function (mode) {
    var hex = prog.packsHex[mode], u = new Uint8Array(hex.length / 2);
    for (var i = 0; i < u.length; i++) u[i] = parseInt(hex.substr(i * 2, 2), 16);
    packs[mode] = u;
  });
  var contents = C.content.loadAll(packs);
  var manager = new C.RoomManager(new C.ServerConfig(prog.config || {}), contents);
  var tokens = {}, room = null, counter = 0;

  function utf8(s) {
    var b = unescape(encodeURIComponent(s)), u = new Uint8Array(b.length);
    for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i);
    return u;
  }
  function pool(n, salt) {
    var u = new Uint8Array(n);
    for (var i = 0; i < n; i++) u[i] = (salt * 131 + i * 17 + 7) & 255;
    return new C.EntropyPool(u);
  }
  function hexPool(hex) { return C.EntropyPool.fromHex(hex); }
  function parse(text) { return C.json.parseRequestBody(utf8(text)); }
  function redact(body) {
    if (body === null || typeof body !== "object") return body;
    var out = {};
    Object.keys(body).forEach(function (k) {
      out[k] = /Token$/.test(k) ? "<token>" : body[k];
    });
    return out;
  }
  function errOut(e) {
    if (e instanceof C.errors.PartyError) return { status: e.status, body: { ok: false, error: C.errors.errorBody(e.code) } };  // transport envelope (majlis-native.js)
    throw e;
  }
  function principalFor(who, now) { return manager.authenticate(room, tokens[who], now); }

  prog.steps.forEach(function (step) {
    var now = step.now, out;
    counter += 1;
    try {
      if (step.op === "create") {
        var created = manager.createRoom(parse(step.bodyText), now, pool(6 + 64, 1));
        room = manager.getRoom(created.code, now);
        tokens.operator = created.hostToken; tokens.display = created.displayToken;
        out = { status: 201, body: redact(created) };
      } else if (step.op === "join" || step.op === "resume") {
        var bearer = step.op === "resume" ? tokens[step.label] : null;
        var r = manager.join(room, parse(step.op === "resume" ? "{}" : step.bodyText), bearer, now, pool(32 + 5 * 8, 100 + counter));
        if (step.op === "join") tokens[step.label] = r[1].playerToken;
        out = { status: r[0], body: redact(r[1]) };
      } else if (step.op === "action") {
        var principal = principalFor(step.as, now);
        var a = manager.submitAction(room, principal, parse(step.bodyText), now,
          step.seedHex ? hexPool(step.seedHex) : pool(8, 500 + counter));
        out = { status: a[0], body: a[1] };
      } else if (step.op === "view") {
        out = { status: null, body: null };
      } else throw new Error("bad op " + step.op);
    } catch (e) { out = errOut(e); }
    out.views = {};
    (step.viewers || []).forEach(function (who) {
      try { out.views[who] = manager.snapshot(room, principalFor(who, now), now); }
      catch (e) { out.views[who] = errOut(e); }
    });
    out.internalErrors = manager.internalErrors.length;
    print(JSON.stringify(out));
  });
})(arguments);
