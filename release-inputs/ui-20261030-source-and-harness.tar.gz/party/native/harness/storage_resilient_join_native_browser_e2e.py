"""Compiled native host + REAL headless-Chrome browser, serving the EXACT bundled production
player assets (majlis-ios/PartyWeb), proving the storage-resilient player join/resume layer
(session.js + play.js) over a full bounded Impostor round.

Pattern follows party/native/harness/impostor_native_browser_e2e.py (3 isolated player browser
contexts against the compiled production binary, operator only via the private stdin bridge).
This harness adds one isolated player ("Noora") whose `window.localStorage` getter/setItem/
getItem/removeItem all throw for the whole run, injected via CDP before any page script runs --
simulating a denied/unavailable storage backend without relying on any real browser's actual
quota or permission behavior.

Checks: the storage-denied player still joins and plays a full round from page memory; her
localStorage holds zero majlisParty keys the entire time (persistence genuinely never worked,
it is not silently falling back to writing anyway); the temporary-seat notice is visible in her
rendered DOM; leaving and returning to the room ("Back to room") and a real network drop/recover
both resume the SAME playerId with no duplicate seat (checked against the operator bridge's own
player list, never just the client's own say-so); pre-reveal payloads/DOM are scanned for the
secret word/role with the accepted whole-payload scanner, including the storage-denied player.

  python3 storage_resilient_join_native_browser_e2e.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR
Needs Google Chrome and python websocket-client. Exit 0 iff every check passes.
"""
import hashlib, json, os, queue, re, secrets, socket, subprocess, sys, tempfile, threading, time
import urllib.error, urllib.request


def sha(path_or_bytes):
    h = hashlib.sha256()
    if isinstance(path_or_bytes, bytes):
        h.update(path_or_bytes)
    else:
        with open(path_or_bytes, "rb") as f:
            h.update(f.read())
    return h.hexdigest()


results = {
    "label": "Compiled native production binary + real headless-Chrome players (one with "
              "localStorage fully denied) against the exact bundled majlis-ios/PartyWeb player "
              "assets. Operator via private stdin bridge only, never over the network.",
    "checks": [],
}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


# Thrown from every localStorage entry point, before any page script (including session.js's
# module-level code) ever runs. A JS object with throwing getters/methods -- not merely absent --
# so session.js's `try { return window.localStorage } catch {...}` and the per-call try/catch
# around setItem/getItem/removeItem are both genuinely exercised, not bypassed by `undefined`.
DENY_STORAGE = r"""
Object.defineProperty(window, 'localStorage', {
  configurable: true,
  get() { throw new DOMException('denied for this harness run', 'SecurityError'); }
});
"""


class Operator:
    def __init__(self, proc, out):
        self.proc, self.lines, self.lock = proc, queue.Queue(), threading.Lock()
        self.transcript = open(os.path.join(out, "operator-bridge.jsonl"), "w")
        self.raw = []

    def pump_start(self):
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        for ln in self.proc.stdout:
            self.lines.put(ln.decode("utf-8"))

    def banner(self, timeout=10):
        return json.loads(self.lines.get(timeout=timeout))

    def call(self, req):
        with self.lock:
            self.proc.stdin.write(json.dumps(req, ensure_ascii=False).encode() + b"\n")
            self.proc.stdin.flush()
            ln = self.lines.get(timeout=10)
        self.raw.append(ln)
        self.transcript.write(json.dumps({"req": req, "reply": json.loads(ln)}, ensure_ascii=False) + "\n")
        self.transcript.flush()
        return json.loads(ln)

    def decoded(self, since=0):
        return "\n".join(json.dumps(json.loads(ln), ensure_ascii=False) for ln in self.raw[since:])

    def act(self, code, type_, payload=None, round_id=None, action_id=None):
        body = {"actionId": action_id or secrets.token_hex(8), "type": type_, "payload": payload or {}}
        if round_id is not None:
            body["roundId"] = round_id
        r = self.call({"op": "action", "code": code, "body": body})
        time.sleep(0.12)
        return r

    def state(self, code):
        return self.call({"op": "state", "code": code})["state"]


def http_get(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, dict(r.headers), r.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


def main():
    repo, scratch, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "party", "web", "tests"))
    sys.path.insert(0, os.path.join(repo, "tests"))
    import real_e2e as base  # Tab, NET_HOOK, CHROME, PHONE, decoded_text
    from impostor_privacy import pre_reveal_leaks, text_leaks

    with open(os.path.join(repo, "tests", "fixtures", "content", "impostor.json"), encoding="utf-8") as f:
        items = json.load(f)["items"]

    build_out = os.path.join(scratch, "build")
    build_log = open(os.path.join(out, "build.log"), "w")
    env = dict(os.environ)
    env.setdefault("SWIFTC", "/Library/Developer/CommandLineTools/usr/bin/swiftc")
    env.setdefault("SDK", "/Library/Developer/CommandLineTools/SDKs/MacOSX.sdk")
    env.setdefault("TARGET", "arm64-apple-macosx13.0")
    r = subprocess.run(["sh", os.path.join(repo, "party", "native", "build.sh"), build_out],
                        cwd=repo, env=env, stdout=build_log, stderr=subprocess.STDOUT, timeout=120)
    check("build.sh exit 0 (production + test binaries built from this checkout)", r.returncode == 0, r.returncode)
    binary = os.path.join(build_out, "majlis-party-native")
    results["binary_path"] = binary
    results["binary_sha256"] = sha(binary)

    web_dir = os.path.join(repo, "majlis-ios", "PartyWeb")
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    base_url = f"http://127.0.0.1:{port}"
    slog = open(os.path.join(out, "server-stderr.log"), "w")
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir, "--content-dir", content_dir,
           "--operator-stdin", "--exit-on-stdin-eof", "--access-log"]
    results["server_argv"] = cmd
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    results["server_pid"] = srv.pid
    op = Operator(srv, out)
    op.pump_start()
    chrome = None
    tabs = {}
    try:
        banner = op.banner()
        results["banner"] = banner
        check("production banner: surface=production, loopback", banner.get("surface") == "production" and banner.get("url") == base_url)

        manifest = open(os.path.join(web_dir, "MANIFEST.txt"), encoding="utf-8").read().splitlines()
        rel_paths = [ln for ln in manifest if ln and not ln.startswith("Generated") and not ln.startswith("Files copied")]
        asset_hash = {}
        for rel in rel_paths:
            st, _, body = http_get(base_url + "/" + rel)
            local = sha(os.path.join(web_dir, rel))
            served = sha(body)
            asset_hash[rel] = st == 200 and local == served
        check("every bundled PartyWeb file served by the native host is byte-identical (sha256) to the checkout's majlis-ios/PartyWeb, incl. session.js and play.js",
              all(asset_hash.values()), asset_hash)

        profile = tempfile.mkdtemp(prefix="majlis-storage-resilience-native-browser-")
        dport_s = socket.socket(); dport_s.bind(("127.0.0.1", 0)); dport = dport_s.getsockname()[1]; dport_s.close()
        chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                                   "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                   "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version", timeout=2).read())
                browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("headless Chrome reachable over CDP", browser is not None)

        def new_tab(name, vp, deny_storage=False):
            ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
            tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            if deny_storage:
                t.call("Page.addScriptToEvaluateOnNewDocument", source=DENY_STORAGE)
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.call("Emulation.setFocusEmulationEnabled", enabled=True)
            t.viewport(vp)
            tabs[name] = t
            return t

        created = op.call({"op": "create", "body": {}})
        code = created["code"]
        check("bridge create: room code only, no credential leaked in the reply", created["ok"] and re.fullmatch(r"[A-Z0-9]{6}", code) is not None)

        names = ["Aisha", "Omar", "Noora"]
        storage_denied = "Noora"
        players = {}
        for nm in names:
            p = new_tab(nm, base.PHONE, deny_storage=(nm == storage_denied))
            p.goto(f"{base_url}/play.html?code={code}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what="lobby")
            players[nm] = p

        # The override makes `localStorage` itself throw on read, so even devtools' own attempt to
        # enumerate it must raise -- the strongest available proof that denial is real and total,
        # not a silent bypass that happens to leave no keys behind.
        try:
            players[storage_denied].storage()
            storage_access_threw = False
            noora_storage_detail = "enumerating localStorage unexpectedly succeeded"
        except RuntimeError as e:
            storage_access_threw = "SecurityError" in str(e)
            noora_storage_detail = str(e)[:200]
        check(f"{storage_denied} (storage denied): the page's own localStorage getter still throws after joining -- denial is real and total",
              storage_access_threw, noora_storage_detail)
        noora_dom = players[storage_denied].html()
        check(f"{storage_denied} (storage denied): the page shows the accessible temporary-seat notice",
              "Temporary seat" in noora_dom and "closing or reloading" in noora_dom)
        players[storage_denied].shot(out, "00-storage-denied-notice")
        for nm in names:
            if nm != storage_denied:
                dom = players[nm].html()
                check(f"{nm} (storage working): no temporary-seat notice is shown when persistence succeeded",
                      "Temporary seat" not in dom)
                players[nm].shot(out, "00b-durable-no-notice")
                break

        pid = {}
        tokens = {}
        for nm, p in players.items():
            if nm == storage_denied:
                continue
            rec = json.loads(p.storage()[f"majlisParty.v1.player.{code}"])
            pid[nm] = rec["playerId"]
            tokens[nm] = rec["token"]
        # Noora's identity is recovered from the server/operator projection instead of her own
        # (intentionally empty) localStorage.
        st0 = op.state(code)
        name_of_pid = {}
        check("three distinct player seats issued (bridge state agrees with the two durable browsers)",
              len(st0.get("players", [])) == 3, st0.get("players"))

        def wait_for(get, pred, timeout=10.0, what=None):
            end = time.time() + timeout
            last = None
            while time.time() < end:
                last = get()
                if pred(last):
                    return last
                time.sleep(0.15)
            raise TimeoutError(f"timed out waiting for {what}; last={last!r}")

        def self_id_of(nm):
            snap = players[nm].last_snap()
            return snap["self"]["id"] if snap and snap.get("self") else None

        # ---------------------------------------------------- local leave/back for the storage-denied player
        # "Leave room" is only offered from the lobby screen, so this and the network-drop/recover
        # proof run here, before the round starts, while the storage-denied seat still has nothing
        # but page memory behind it.
        before_pid = self_id_of(storage_denied)
        before_players = len(op.state(code).get("players", []))
        noora_page = players[storage_denied]
        noora_page.click("__btn('Leave room')", "Leave room")
        noora_page.confirm(accept=True)
        noora_page.wait("document.body.textContent.includes('Back to room')", what="back-to-room button present (from page memory, not storage)")
        noora_page.click(f"__btn('Back to room {code}')", "Back to room")
        noora_page.wait("!!document.querySelector('.in-room, .card-title')", what="re-entered room")
        after_pid = self_id_of(storage_denied)
        after_players = len(op.state(code).get("players", []))
        check(f"{storage_denied} (storage denied): local leave/back resumes the SAME seat with no duplicate join",
              after_pid == before_pid and after_players == before_players == 3,
              {"before_pid": before_pid, "after_pid": after_pid, "before_players": before_players, "after_players": after_players})

        # ---------------------------------------------------- real network drop/recover for the storage-denied player
        # Strengthened per Skull's review: a stale last_snap() read plus "not fatal" is not proof of
        # a real interruption/reconnect. This requires (1) an actually-observed non-live connection
        # state during the drop, (2) actually-observed fresh SSE bytes arriving after recovery (not
        # just the pre-drop snapshot read again), and (3) a fresh frame confirming the same identity,
        # cross-checked against the operator bridge's own player list (never just the client's say-so).
        rx_before = noora_page.rx_count()
        noora_page.call("Network.emulateNetworkConditions", offline=True, latency=0, downloadThroughput=0, uploadThroughput=0)
        noora_page.wait("document.body.dataset.conn === 'reconnecting'", timeout=10, what="an actually-observed interruption (conn leaves live)")
        interrupted_conn = noora_page.eval("document.body.dataset.conn")
        noora_page.call("Network.emulateNetworkConditions", offline=False, latency=0, downloadThroughput=-1, uploadThroughput=-1)
        noora_page.wait("document.body.dataset.conn === 'live'", timeout=15, what="reconnect reaches live again after network drop")
        wait_for(lambda: noora_page.rx_count(), lambda v: v > rx_before, timeout=10,
                 what="fresh post-reconnect SSE bytes (not the stale pre-drop snapshot)")
        fresh_snap = noora_page.last_snap()
        after_drop_pid = fresh_snap["self"]["id"] if fresh_snap and fresh_snap.get("self") else None
        op_after_drop = op.state(code)
        after_drop_players = len(op_after_drop.get("players", []))
        bridge_pid_for_noora = next((p["id"] for p in op_after_drop.get("players", []) if p.get("name") == storage_denied), None)
        check(f"{storage_denied} (storage denied): stream interruption/reconnect keeps the SAME seat, no duplicate join",
              interrupted_conn == "reconnecting" and after_drop_pid == before_pid
              and bridge_pid_for_noora == before_pid and after_drop_players == 3,
              {"interrupted_conn": interrupted_conn, "after_drop_pid": after_drop_pid,
               "bridge_pid_for_noora": bridge_pid_for_noora, "after_drop_players": after_drop_players})

        op.act(code, "room.set_mode", {"mode": "impostor"})
        r = op.act(code, "room.start")
        check("bridge set_mode(impostor) + start accepted", r["ok"] and r["status"] == 200, r.get("status"))

        for nm, p in players.items():
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} role card (discussion)")
        hs = op.state(code)
        check("round g1r1 started with 3 players in the order", hs["roundId"] == "g1r1" and len(hs["game"]["order"]) == 3, hs["roundId"])
        pid_to_name = {}
        for p_ in hs["players"]:
            pid_to_name[p_["id"]] = p_["name"]

        def current_impostor_name():
            for nm, p in players.items():
                you = (p.last_snap() or {}).get("game", {}).get("you", {})
                if you.get("role") == "impostor":
                    return nm
            return None

        def crew_word():
            for nm, p in players.items():
                you = (p.last_snap() or {}).get("game", {}).get("you", {})
                if you.get("role") == "crew" and you.get("word"):
                    return you["word"]
            return None

        imp = wait_for(current_impostor_name, lambda v: v, what="impostor revealed to itself")
        word1 = wait_for(crew_word, lambda v: v, what="crew word1")
        check("exactly one browser-rendered player is the impostor (any of the three, including the storage-denied one)", imp in names, imp)

        noora_pid_round1 = self_id_of(storage_denied)
        check(f"{storage_denied} (storage denied) still has a real, projected seat with an id, purely from page memory", bool(noora_pid_round1))

        def op_privacy(stage, expect_phase):
            s = op.state(code)
            check(f"[{stage}] operator bridge roundPhase={expect_phase}", s["game"]["roundPhase"] == expect_phase, s["game"]["roundPhase"])
            leaks = pre_reveal_leaks(s, items, "operator")
            check(f"[{stage}] operator bridge state: no pre-reveal leak via whole-payload scanner", not leaks, leaks)

        def player_privacy(stage, word, current_imp):
            # Scans EVERY captured pre-reveal SSE payload this tab has received so far (snaps()),
            # not only the most recent one -- a leak in an earlier frame that was since overwritten
            # in the DOM must still be caught.
            for nm, p in players.items():
                role = "impostor" if nm == current_imp else "crew"
                own = word if role == "crew" else None
                all_leaks = []
                for i, snap in enumerate(p.snaps()):
                    dleaks = pre_reveal_leaks(snap, items, role, own)
                    if dleaks:
                        all_leaks.append((i, dleaks))
                check(f"[{stage}] {nm} ({role}) ALL captured browser SSE snapshots (not only the latest): no pre-reveal leak via whole-payload scanner",
                      not all_leaks, all_leaks)
                dom = p.html()
                own_word_leak = (word in dom) if role == "impostor" else False
                check(f"[{stage}] {nm}: rendered DOM never shows the secret word to the impostor", not own_word_leak)

        def negative_control(stage, word):
            # Required planted forbidden-value negative control: proves the SAME scanner that just
            # passed the clean operator trace actually catches a leak, rather than being a no-op.
            import copy
            poisoned = copy.deepcopy(op.state(code))
            poisoned.setdefault("game", {})["__planted_leak_probe"] = word
            caught = pre_reveal_leaks(poisoned, items, "operator")
            check(f"[{stage}] negative control: a deliberately planted forbidden secret value IS caught by the same scanner that passed the clean trace",
                  bool(caught))

        op_privacy("round1-discussion", "discussion")
        player_privacy("round1-discussion", word1, imp)
        negative_control("round1-discussion", word1)
        players["Aisha"].shot(out, "01-lobby-and-discussion")

        op.act(code, "impostor.advance", round_id="g1r1")
        for nm, p in players.items():
            p.wait("!!document.querySelector('.who-cards')", what=f"{nm} vote ui")
        op_privacy("round1-vote", "vote")
        player_privacy("round1-vote", word1, imp)

        crew = [n for n in names if n != imp]

        def vote(nm, target):
            players[nm].click(f"__btn({json.dumps(target)})", f"{nm} votes {target}")

        vote(crew[0], imp)
        vote(crew[1], imp)
        vote(imp, crew[0])
        wait_for(lambda: op.state(code)["game"]["roundPhase"], lambda ph: ph == "guess_word", timeout=10, what="vote resolves to guess_word")
        g1 = op.state(code)["game"]
        check("round1: crew unanimously caught the real impostor via browser clicks (incl. the storage-denied player's own vote)",
              g1["nominee"] is not None, g1.get("nominee"))

        players[imp].type_into("#impostor-guess", word1)
        players[imp].click("__btn('Submit guess')", "submit correct guess")
        wait_for(lambda: op.state(code)["game"]["roundPhase"], lambda ph: ph == "reveal", timeout=10, what="reveal")
        rv = op.state(code)["game"]
        check("round1: a usable action/scoring/reveal flow completed for all three seats, incl. the storage-denied one",
              rv["outcome"] is not None and rv["roundPoints"], rv.get("outcome"))
        check("positive control: the operator bridge's own reveal now does carry the word (the pre-reveal scanner above is not a dead no-op)",
              rv["reveal"]["word"] == word1 and word1 in op.decoded())
        for nm, p in players.items():
            p.wait(f"document.body.textContent.includes({json.dumps(word1)})", what=f"{nm} sees the reveal")
        players[storage_denied].shot(out, "02-storage-denied-reveal")
        check(f"{storage_denied} (storage denied): the same seat (proven earlier via leave/back and a network drop) carried its identity through the whole round",
              self_id_of(storage_denied) == before_pid, {"round_end_pid": self_id_of(storage_denied), "original_pid": before_pid})

        # ---------------------------------------------------- terminal room_closed, wired through the
        # ACTUAL production path (play.js's onSnapshot -> closedByHost() -> clearCredential()), not a
        # direct helper call, with a genuinely failing removal on a durable (non-storage-denied) seat.
        # Deliberately uses room.close, not room.end: room.end sets phase "ended", and play.js's own
        # onSnapshot self-closes a player's SSE stream the instant it sees "ended" ("ended is terminal:
        # keep the final scores and stop reconnecting") -- so a player who had already seen "ended"
        # would no longer be subscribed to receive the later "closed" push, and closedByHost() would
        # never run on her page. room.close carries no such precondition and is still delivered to this
        # still-live stream, which is exactly the production path a real closed-by-host room takes.
        durable_nm = next(nm for nm in names if nm != storage_denied)
        durable_page = players[durable_nm]
        durable_key = f"majlisParty.v1.player.{code}"
        had_stale_before = durable_page.eval(f"localStorage.getItem({json.dumps(durable_key)}) !== null")
        check(f"{durable_nm}: durable credential genuinely present in real localStorage before the terminal event", had_stale_before)
        durable_page.eval(
            "window.__origRemoveItem = Storage.prototype.removeItem;"
            "Storage.prototype.removeItem = function(k) { throw new DOMException('simulated removal failure (harness)', 'SecurityError'); };"
            "true"
        )
        op.act(code, "room.close")
        durable_page.wait("document.body.textContent.includes('Room closed')", timeout=15,
                           what=f"{durable_nm}: production closedByHost() actually rendered the terminal room_closed screen")
        still_stale_after_failed_removal = durable_page.eval(f"localStorage.getItem({json.dumps(durable_key)}) !== null")
        durable_page.eval("Storage.prototype.removeItem = window.__origRemoveItem; true")
        check(f"{durable_nm}: production room_closed path ran clearCredential(), whose real removeItem call genuinely threw and was caught (stale storage entry survives, exactly like the failed-removal unit check)",
              still_stale_after_failed_removal)
        check(f"{durable_nm}: despite the failed removal, the production page itself shows no active seat (in-memory tombstone from the real room_closed path, not a direct clearCredential() call)",
              "Room closed" in durable_page.html() and "card-title" in durable_page.html())

        # ---------------------------------------------------- failed-removal re-entry: the DOM/storage
        # checks above would still pass even if clearCredential() were entirely removed from the
        # production path (the terminal screen renders from closedByHost()'s own markup regardless).
        # This section instead drives the real renderJoin()/enter() module through actual clicks: no
        # resume affordance is offered for the closed room, the real join path -- not a storage read --
        # refuses to resume the old credential, and a genuinely fresh join still obtains a new seat.
        pre_rejoin_pid = self_id_of(durable_nm)
        durable_page.click("__btn('Join another room')", "Join another room")
        durable_page.wait("!!document.querySelector('#join-code')", what=f"{durable_nm}: real renderJoin() mounted the join form")
        check(f"{durable_nm}: renderJoin(), run live after the closed-room terminal screen, offers no \"Back to room\" resume affordance (the in-memory tombstone, not a removed button label)",
              "Back to room" not in durable_page.html())
        durable_page.type_into("#join-code", code)
        durable_page.type_into("#join-name", durable_nm + " Retry")
        durable_page.click("__btn('Join game')", "attempt to rejoin the closed room by code")
        durable_page.wait("document.body.textContent.includes('The host closed this room.')", timeout=10,
                           what=f"{durable_nm}: the real join path rejects the closed room instead of resuming the old credential")
        check(f"{durable_nm}: a direct attempt to re-enter the closed room through the actual join() module is refused, not silently resumed",
              "The host closed this room." in durable_page.html())
        fresh = op.call({"op": "create", "body": {}})
        fresh_code = fresh["code"]
        check("bridge create (fresh room for the re-entry proof): room code only, no credential leaked in the reply",
              fresh["ok"] and re.fullmatch(r"[A-Z0-9]{6}", fresh_code) is not None)
        durable_page.type_into("#join-code", fresh_code)
        durable_page.type_into("#join-name", durable_nm + " Fresh")
        durable_page.click("__btn('Join game')", "join a brand-new room through the real path")
        durable_page.wait("document.body.textContent.includes('You’re in')", what=f"{durable_nm}: fresh re-entry through the production join path succeeded")
        fresh_pid = self_id_of(durable_nm)
        check(f"{durable_nm}: fresh re-entry obtained a brand-new valid seat through the real join() module, not a resumed/reused old credential",
              fresh_pid is not None and fresh_pid != pre_rejoin_pid,
              {"old_pid": pre_rejoin_pid, "fresh_pid": fresh_pid, "fresh_room": fresh_code})

        check("every page script ran on every player tab without a JS exception, incl. the storage-denied one",
              not any(p.page_errors() for p in players.values()), {k: p.page_errors()[:2] for k, p in players.items() if p.page_errors()})

        all_rx = "\n".join(base.decoded_text(p.rx_raw()) for p in players.values())
        check("no operator credential (hostToken) anywhere in player-received bytes", "hostToken" not in all_rx)
        # The storage-denied player's token was never written to her (denied) localStorage, so it
        # is recovered here from her own already-received join response bytes -- never from a
        # storage read -- purely to extend the hygiene scan to her credential too. The value itself
        # is kept in this local variable only and is never placed in a check detail/artifact.
        noora_token = None
        for entry in reversed(players[storage_denied].rx()):
            if entry.get("path", "").endswith("/join"):
                try:
                    noora_token = json.loads("".join(entry["chunks"])).get("playerToken")
                except Exception:
                    noora_token = None
                break
        check(f"{storage_denied} (storage denied): her memory-only token was recovered from her own join response for hygiene scanning (never from her denied localStorage)",
              bool(noora_token))
        all_tokens = dict(tokens)
        if noora_token:
            all_tokens[storage_denied] = noora_token
        leaks = []
        for nm, tok in all_tokens.items():
            for t in tabs.values():
                if tok in t.eval("document.documentElement.outerHTML + location.href") or tok in t.console_text():
                    leaks.append((nm, t.name))
        check(f"no durable player's token -- including {storage_denied}'s memory-only token -- leaked into any DOM, URL or console of any tab",
              not leaks, [l[1] for l in leaks])

    except Exception:
        import traceback
        check("run completed without an exception", False, traceback.format_exc()[-2000:])
    finally:
        for t in list(tabs.values()):
            try: t.ws.close()
            except Exception: pass
        if chrome is not None:
            chrome.terminate()
            try: chrome.wait(10)
            except Exception: chrome.kill()
        try:
            srv.stdin.close()
            srv.wait(10)
        except Exception:
            srv.kill()
        results["server_exit"] = srv.returncode

    p_ = sum(1 for c in results["checks"] if c["pass"])
    f_ = len(results["checks"]) - p_
    results["summary"] = {"pass": p_, "fail": f_, "total": len(results["checks"])}
    json.dump(results, open(os.path.join(out, "storage-resilient-join-native-browser-results.json"), "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps(results["summary"]))
    sys.exit(0 if f_ == 0 and p_ > 0 else 1)


if __name__ == "__main__":
    main()
