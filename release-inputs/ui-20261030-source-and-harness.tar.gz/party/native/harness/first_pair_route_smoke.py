"""Smoke: the SAME native-binary + bundled-PartyWeb + real-headless-Chrome
route used by impostor_native_browser_e2e.py also plays a first-pair mode
(Who Am I) correctly. Not a full privacy re-audit of Who Am I (that is
already covered by production_lan_e2e.py / the Python-dev-server browser
diagnostics and the native HTTP-API tests) -- this only checks that pointing
this specific route (compiled production binary, --web-dir majlis-ios/
PartyWeb, operator over the private stdin bridge, real isolated-context
headless-Chrome players) at a different mode doesn't regress or misrepresent
the already-accepted modes. One focused run, no privacy scanning, no retries.

  python3 first_pair_route_smoke.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR
"""
import importlib.util
import json
import os
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("impostor_native_browser_e2e", os.path.join(HERE, "impostor_native_browser_e2e.py"))
impostor_mod = importlib.util.module_from_spec(spec)
sys.argv_backup = sys.argv
sys.argv = ["impostor_native_browser_e2e.py"]  # keep its module-level REPO probe harmless
spec.loader.exec_module(impostor_mod)
sys.argv = sys.argv_backup

Operator, http_get, sha = impostor_mod.Operator, impostor_mod.http_get, impostor_mod.sha

results = {"label": "First-pair (Who Am I) smoke over the same compiled-native + bundled-PartyWeb + "
                     "real-headless-Chrome route used for Impostor's gap verification.", "checks": []}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


def main():
    repo, scratch, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "party", "web", "tests"))
    import real_e2e as base  # Tab, CHROME, PHONE, NET_HOOK

    build_out = os.path.join(scratch, "build")
    binary = os.path.join(build_out, "majlis-party-native")
    if not os.path.exists(binary):
        r = subprocess.run(["sh", os.path.join(repo, "party", "native", "build.sh"), build_out], cwd=repo, env=dict(os.environ))
        check("build.sh exit 0", r.returncode == 0, r.returncode)
    else:
        check("reused already-built production binary from this run's scratch dir", True, binary)

    web_dir = os.path.join(repo, "majlis-ios", "PartyWeb")
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    base_url = f"http://127.0.0.1:{port}"
    slog = open(os.path.join(out, "server-stderr.log"), "w")
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir, "--content-dir", content_dir,
           "--operator-stdin", "--exit-on-stdin-eof", "--access-log"]
    results["server_argv"] = cmd
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    op = Operator(srv, out)
    op.pump_start()
    chrome = None
    tabs = {}
    try:
        banner = op.banner()
        check("production banner on this route: surface=production, loopback", banner.get("surface") == "production" and banner.get("host") == "127.0.0.1", banner)

        profile = tempfile.mkdtemp(prefix="majlis-first-pair-smoke-")
        dport_s = socket.socket(); dport_s.bind(("127.0.0.1", 0)); dport = dport_s.getsockname()[1]; dport_s.close()
        chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                                   "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                   "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version", timeout=2).read())
                browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("headless Chrome reachable over CDP", browser is not None)

        def new_tab(name):
            ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
            tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.viewport(base.PHONE)
            tabs[name] = t
            return t

        created = op.call({"op": "create", "body": {}})
        code = created["code"]
        check("bridge create: room code issued", created["ok"])

        names = ["Aisha", "Omar", "Noora"]  # room default min_players is 3 (majlis-core.js)
        players = {}
        for nm in names:
            p = new_tab(nm)
            p.goto(f"{base_url}/play.html?code={code}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what="lobby")
            players[nm] = p
        pid = {}
        for nm, p in players.items():
            rec = json.loads(p.storage()[f"majlisParty.v1.player.{code}"])
            pid[nm] = rec["playerId"]
        check("three distinct player seats issued on this route", len(set(pid.values())) == 3, pid)

        op.act(code, "room.set_mode", {"mode": "who_am_i"})
        r = op.act(code, "room.start")
        check("bridge set_mode(who_am_i) + start accepted on this route", r["ok"] and r["status"] == 200, r.get("status"))
        for nm, p in players.items():
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} who-am-i card")
        st = op.state(code)
        r1 = st["roundId"]
        check("who_am_i round started, rendered to both real browser tabs", bool(r1), r1)

        players["Aisha"].type_into("#guess", "smoke-test-guess")
        players["Aisha"].click("__btn('Send guess')", "guess")
        players["Aisha"].wait("document.body.textContent.includes('smoke-test-guess')", what="guess pending")
        r = op.act(code, "whoami.award", {"playerId": pid["Aisha"]}, round_id=r1)
        check("bridge award accepted on this route", r["ok"] and r["status"] == 200, r.get("status"))
        sc = {q["id"]: q["score"] for q in op.state(code)["players"]}
        check("scoring applied through the real DOM + bridge on this exact native+PartyWeb route", sc.get(pid["Aisha"]) == 1, sc)

        check("every page script ran without a JS exception on this route",
              not any(p.page_errors() for p in players.values()), {k: p.page_errors()[:2] for k, p in players.items() if p.page_errors()})
    finally:
        try:
            srv.stdin.close()
        except Exception:
            pass
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()
        if chrome is not None:
            chrome.kill()

    passed = sum(1 for c in results["checks"] if c["pass"])
    total = len(results["checks"])
    results["summary"] = {"pass": passed, "fail": total - passed, "total": total}
    with open(os.path.join(out, "first-pair-route-smoke-results.json"), "w") as f:
        json.dump(results, f, indent=2, default=str)
    print(json.dumps(results["summary"]))
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
