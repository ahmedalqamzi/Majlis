"""Scoring/timer mutation controls for the Taboo native engine.

Builds an unmodified BASELINE and four isolated MUTANT trees (scratch copies
of party/core + party/native; the checkout is never modified) with the real
build.sh, then runs the same independent harnesses against each:

  * taboo_lifecycle_sse_timing.py --sections scoring pause autopush late
    (real compiled test host, real wall-clock waits, real SSE)
  * taboo_frozen_traces.py --mode core --core-dir <tree>/party/core
  * taboo_frozen_traces.py --mode http --bin <tree>/build/majlis-party-native-test

Mutants (each is a single-occurrence textual edit; anchors are asserted):
  double-scoring        a correct card awards +2 instead of +1
  timer-during-pause    resume restores the ORIGINAL wall-clock deadline, so
                        the turn clock keeps running while paused
  late-scoring          the request-time deadline tick and the reducer's
                        deadline guard are removed, so an answer that arrives
                        after the deadline (before any sweep) is scored
  no-autonomous-push    the stream poll and sweep no longer tick the room, so
                        expiry is only observed when a request arrives

A control passes when the baseline passes every check and the mutant fails
its pinned exact assertion(s) (named below) with a nonzero harness exit.
Every command, exit code and full output is preserved under EVIDENCE/.

    python3 -I -B party/native/harness/taboo_mutation_controls.py SCRATCH EVIDENCE [--only NAME ...]
"""
import argparse
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, HERE)
from taboo_harness_common import build_binary  # noqa: E402

CORE = "core/majlis-core.js"
MUTANTS = {
    "double-scoring": {
        "edits": [(CORE, "if (awardTeam) s.teamScores[awardTeam] += 1;", "if (awardTeam) s.teamScores[awardTeam] += 2;")],
        "mustFail": ["correct (normalized) guess accepted: active team +1 exactly, other team 0"],
    },
    "timer-during-pause": {
        "edits": [
            (CORE, "s.pausedRemainingSeconds = Math.max(0, s.deadlineAt - now);\n      s.deadlineAt = null;",
             "s.pausedRemainingSeconds = Math.max(0, s.deadlineAt - now);\n      s.pausedAt = now;\n      s.deadlineAt = null;"),
            (CORE, "s.deadlineAt = now + s.pausedRemainingSeconds;",
             "s.deadlineAt = (s.pausedAt !== undefined ? s.pausedAt : now) + s.pausedRemainingSeconds;"),
        ],
        "mustFail": ["autonomous SSE expiry after resume arrives at resume + saved remainder: not early (>= -0.05s) and <= 1.0s late"],
    },
    "late-scoring": {
        "edits": [
            (CORE, "    this._checkLive(room, principal, now);\n    this._tickRoom(room, now);\n    var key = principal.key();",
             "    this._checkLive(room, principal, now);\n    var key = principal.key();"),
            (CORE, 'if (phase === CLUE_TURN && state.deadlineAt !== null && now >= state.deadlineAt) return [state, "invalid_phase"];',
             "/* mutant: no late-adjudication guard */"),
        ],
        "mustFail": ["exact correct guess sent 0.6s AFTER the deadline (first request since) -> rejected 409",
                     "no score from late answers: teamScores 0/0, turn expired with no award"],
    },
    "no-autonomous-push": {
        "edits": [
            (CORE, 'if (now >= principal.expiresAt) return ["error", "token_expired"];\n    this._tickRoom(room, now);',
             'if (now >= principal.expiresAt) return ["error", "token_expired"];'),
            (CORE, "this.rooms.forEach(function (room) { self._tickRoom(room, now); });",
             "this.rooms.forEach(function (room) { void room; void self; });"),
        ],
        "mustFail": ["expiry state pushed over SSE with zero incoming requests, <= 1.0s after the 10s deadline (not early)"],
    },
}
SECTIONS = ["scoring", "pause", "autopush", "late"]


def run(cmd, log_path, timeout):
    started = time.time()
    with open(log_path, "wb") as log:
        try:
            proc = subprocess.run(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, timeout=timeout)
            code = proc.returncode
        except subprocess.TimeoutExpired:
            code = "timeout"
    with open(log_path, encoding="utf-8", errors="replace") as handle:
        out = handle.read()
    return {"cmd": cmd, "exit": code, "log": log_path, "seconds": round(time.time() - started, 1), "tail": out[-1500:]}


def variant(name, edits, scratch, evid):
    d = os.path.join(evid, name)
    os.makedirs(d, exist_ok=True)
    info = build_binary(ROOT, scratch, "mut-" + name, edits)
    tree = os.path.join(scratch, "mut-" + name)
    res = {"build": info}
    py = [sys.executable, "-I", "-B", "-u"]
    life_dir = os.path.join(d, "lifecycle")
    res["lifecycle"] = run(py + [os.path.join(HERE, "taboo_lifecycle_sse_timing.py"), "--test-bin", info["test"],
                                 "--evidence", life_dir, "--scratch", d, "--sections"] + SECTIONS,
                           os.path.join(d, "lifecycle.log"), 600)
    try:
        with open(os.path.join(life_dir, "taboo_lifecycle_sse_timing.json")) as handle:
            life = json.load(handle)
        res["lifecycleFailed"] = [c["name"] for c in life["checks"] if not c["pass"]]
        res["lifecycleCounts"] = [life["passed"], life["total"]]
    except (OSError, ValueError) as exc:
        res["lifecycleFailed"] = ["<no report: %s>" % exc]
        res["lifecycleCounts"] = None
    for mode, extra in (("core", ["--core-dir", os.path.join(tree, "party", "core")]), ("http", ["--bin", info["test"]])):
        fdir = os.path.join(d, "frozen-" + mode)
        res["frozen-" + mode] = run(py + [os.path.join(HERE, "taboo_frozen_traces.py"), "--mode", mode, "--evidence", fdir,
                                          "--max-seconds", "900"] + extra, os.path.join(d, "frozen-%s.log" % mode), 1000)
        try:
            with open(os.path.join(fdir, "summary.json")) as handle:
                summ = json.load(handle)
            res["frozen-" + mode + "-counts"] = [summ["passed"], summ["total"]]
        except (OSError, ValueError):
            res["frozen-" + mode + "-counts"] = None
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("scratch")
    ap.add_argument("evidence")
    ap.add_argument("--only", nargs="*")
    args = ap.parse_args()
    scratch, evid = os.path.abspath(args.scratch), os.path.abspath(args.evidence)
    os.makedirs(scratch, exist_ok=True)
    os.makedirs(evid, exist_ok=True)
    report = {}
    ok = True
    base = variant("baseline", [], scratch, evid)
    base_ok = (base["lifecycle"]["exit"] == 0 and not base["lifecycleFailed"] and base["frozen-core"]["exit"] == 0
               and base["frozen-http"]["exit"] == 0)
    report["baseline"] = dict(base, passedAll=base_ok)
    print("%s baseline: lifecycle %s exit %s; frozen core %s exit %s; frozen http %s exit %s" % (
        "PASS" if base_ok else "FAIL", base["lifecycleCounts"], base["lifecycle"]["exit"], base["frozen-core-counts"],
        base["frozen-core"]["exit"], base["frozen-http-counts"], base["frozen-http"]["exit"]), flush=True)
    ok = ok and base_ok
    for name, spec in MUTANTS.items():
        if args.only and name not in args.only:
            continue
        res = variant(name, spec["edits"], scratch, evid)
        missing = [m for m in spec["mustFail"] if m not in res["lifecycleFailed"]]
        passed = base_ok and res["lifecycle"]["exit"] not in (0, "timeout") and not missing
        report[name] = dict(res, mustFail=spec["mustFail"], missingExpectedFailures=missing, control_passed=passed)
        print("%s mutant %s: lifecycle %s exit %s failed=%s; frozen core %s exit %s; frozen http %s exit %s" % (
            "PASS" if passed else "FAIL", name, res["lifecycleCounts"], res["lifecycle"]["exit"], res["lifecycleFailed"],
            res["frozen-core-counts"], res["frozen-core"]["exit"], res["frozen-http-counts"], res["frozen-http"]["exit"]), flush=True)
        ok = ok and passed
    with open(os.path.join(evid, "taboo_mutation_controls.json"), "w") as handle:
        json.dump(report, handle, indent=1, default=str)
    n = sum(1 for k, v in report.items() if k != "baseline" and v["control_passed"])
    print("mutation controls %d/%d passed; baseline passedAll=%s" % (n, len(report) - 1, report["baseline"]["passedAll"]))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
