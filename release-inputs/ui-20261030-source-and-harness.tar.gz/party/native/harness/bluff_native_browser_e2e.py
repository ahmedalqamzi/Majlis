"""Compiled native host + REAL headless-Chrome browser, serving the EXACT bundled
production player assets (majlis-ios/PartyWeb), for Bluff.

Same pattern as the accepted Impostor harness
(party/native/harness/impostor_native_browser_e2e.py), extended to Bluff:
3 isolated headless-Chrome player contexts drive the real play.js UI
against play.html served by the compiled production native binary; the
operator is driven only through its private stdin bridge, never over the
network. Operator-side privacy uses the accepted whole-payload scanner
(tests/bluff_privacy.scan/build_truth); player-side privacy is checked on
the real rendered DOM and the raw bytes each browser actually received.

  python3 bluff_native_browser_e2e.py REPO_ROOT SCRATCH_DIR EVIDENCE_DIR
Needs Google Chrome and python websocket-client. Exit 0 iff every check passes.
"""
import hashlib, json, os, queue, re, secrets, socket, subprocess, sys, tempfile, threading, time
import urllib.error, urllib.request

REPO = os.path.abspath(sys.argv[1]) if len(sys.argv) > 1 else None


def sha(path_or_bytes):
    h = hashlib.sha256()
    if isinstance(path_or_bytes, bytes):
        h.update(path_or_bytes)
    else:
        with open(path_or_bytes, "rb") as f:
            h.update(f.read())
    return h.hexdigest()


results = {
    "label": "Compiled native production binary + real headless-Chrome players against the "
              "exact bundled majlis-ios/PartyWeb player assets, for Bluff. Operator via private "
              "stdin bridge only, never over the network.",
    "checks": [],
}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


class Operator:
    def __init__(self, proc, out):
        self.proc, self.lines, self.lock = proc, queue.Queue(), threading.Lock()
        self.transcript = open(os.path.join(out, "operator-bridge.jsonl"), "w")
        self.raw = []

    def pump_start(self):
        threading.Thread(target=self._pump, daemon=True).start()

    def _pump(self):
        for ln in self.proc.stdout:
            self.lines.put(ln.decode("utf-8"))

    def banner(self, timeout=10):
        return json.loads(self.lines.get(timeout=timeout))

    def call(self, req):
        with self.lock:
            self.proc.stdin.write(json.dumps(req, ensure_ascii=False).encode() + b"\n")
            self.proc.stdin.flush()
            ln = self.lines.get(timeout=10)
        self.raw.append(ln)
        self.transcript.write(json.dumps({"req": req, "reply": json.loads(ln)}, ensure_ascii=False) + "\n")
        self.transcript.flush()
        return json.loads(ln)

    def decoded(self, since=0):
        return "\n".join(json.dumps(json.loads(ln), ensure_ascii=False) for ln in self.raw[since:])

    def act(self, code, type_, payload=None, round_id=None, action_id=None):
        body = {"actionId": action_id or secrets.token_hex(8), "type": type_, "payload": payload or {}}
        if round_id is not None:
            body["roundId"] = round_id
        r = self.call({"op": "action", "code": code, "body": body})
        time.sleep(0.12)
        return r

    def state(self, code):
        return self.call({"op": "state", "code": code})["state"]


def http_get(url, headers=None):
    req = urllib.request.Request(url, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, dict(r.headers), r.read()
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers), e.read()


def main():
    repo, scratch, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "party", "web", "tests"))
    sys.path.insert(0, os.path.join(repo, "tests"))
    import real_e2e as base  # Tab, NET_HOOK, CHROME, PHONE, decoded_text
    import bluff_privacy as bp

    with open(os.path.join(repo, "tests", "fixtures", "content", "bluff.json"), encoding="utf-8") as f:
        pack = json.load(f)

    # ---------------------------------------------------------------- build + identity
    build_out = os.path.join(scratch, "build")
    build_log = open(os.path.join(out, "build.log"), "w")
    r = subprocess.run(["sh", os.path.join(repo, "party", "native", "build.sh"), build_out],
                        cwd=repo, env=dict(os.environ), stdout=build_log, stderr=subprocess.STDOUT)
    check("build.sh exit 0 (production + test binaries built from this checkout)", r.returncode == 0, r.returncode)
    binary = os.path.join(build_out, "majlis-party-native")
    results["binary_path"] = binary
    results["binary_sha256"] = sha(binary)
    file_out = subprocess.run(["file", binary], capture_output=True, text=True).stdout.strip()
    results["binary_file_type"] = file_out
    check("server executable is a real Mach-O binary, not a script/interpreter wrapper",
          "Mach-O" in file_out and "executable" in file_out, file_out)
    strings_out = subprocess.run(["strings", "-a", binary], capture_output=True, text=True).stdout
    check("binary contains no Python/CPython fallback markers", "CPython" not in strings_out and "python3" not in strings_out.lower(), None)
    check("binary carries the MajlisNative Swift module identity (compiled, not interpreted)",
          "MajlisNative" in strings_out, None)

    # ---------------------------------------------------------------- start, serving the exact bundled assets
    web_dir = os.path.join(repo, "majlis-ios", "PartyWeb")
    content_dir = os.path.join(repo, "tests", "fixtures", "content")
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    base_url = f"http://127.0.0.1:{port}"
    slog = open(os.path.join(out, "server-stderr.log"), "w")
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir, "--content-dir", content_dir,
           "--operator-stdin", "--exit-on-stdin-eof", "--access-log"]
    results["server_argv"] = cmd
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    results["server_pid"] = srv.pid
    op = Operator(srv, out)
    op.pump_start()
    chrome = None
    tabs = {}
    try:
        banner = op.banner()
        results["banner"] = banner
        check("production banner: surface=production, loopback, memory-only persistence",
              banner.get("surface") == "production" and banner.get("host") == "127.0.0.1" and banner.get("url") == base_url
              and banner.get("event") == "listening", banner)

        # ---------------------------------------------------- served bytes == bundled checkout bytes
        manifest = open(os.path.join(web_dir, "MANIFEST.txt"), encoding="utf-8").read().splitlines()
        rel_paths = [ln for ln in manifest if ln and not ln.startswith("Generated") and not ln.startswith("Files copied")]
        asset_hash = {}
        for rel in rel_paths:
            st, _, body = http_get(base_url + "/" + rel)
            local = sha(os.path.join(web_dir, rel))
            served = sha(body)
            asset_hash[rel] = {"status": st, "local_sha256": local, "served_sha256": served, "match": st == 200 and local == served}
        results["served_asset_hashes"] = asset_hash
        check("every bundled PartyWeb file served by the native host is byte-identical (sha256) to the checkout's majlis-ios/PartyWeb",
              all(v["match"] for v in asset_hash.values()), {k: v["match"] for k, v in asset_hash.items()})
        st, _, _ = http_get(base_url + "/host.html")
        st2, _, _ = http_get(base_url + "/tv.html")
        check("operator/display pages are not served on this production surface (404) - no browser route exists for them here",
              st == 404 and st2 == 404, [st, st2])

        # ---------------------------------------------------- real headless-Chrome players
        profile = tempfile.mkdtemp(prefix="majlis-bluff-native-browser-")
        dport_s = socket.socket(); dport_s.bind(("127.0.0.1", 0)); dport = dport_s.getsockname()[1]; dport_s.close()
        chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                                   "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                                   "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        browser = None
        for _ in range(100):
            try:
                ver = json.loads(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version", timeout=2).read())
                browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")
                break
            except Exception:
                time.sleep(0.1)
        check("headless Chrome reachable over CDP", browser is not None)

        def new_tab(name, vp):
            ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
            tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.call("Emulation.setFocusEmulationEnabled", enabled=True)
            t.viewport(vp)
            tabs[name] = t
            return t

        created = op.call({"op": "create", "body": {}})
        code = created["code"]
        check("bridge create: room code only, no credential leaked in the reply", created["ok"] and re.fullmatch(r"[A-Z0-9]{6}", code) is not None)

        names = ["Aisha", "Omar", "Noora"]
        players = {}
        for nm in names:
            p = new_tab(nm, base.PHONE)
            p.goto(f"{base_url}/play.html?code={code}")
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what="lobby")
            players[nm] = p
        pid = {}
        tokens = {}
        for nm, p in players.items():
            rec = json.loads(p.storage()[f"majlisParty.v1.player.{code}"])
            pid[nm] = rec["playerId"]
            tokens[nm] = rec["token"]
        check("three distinct player seats issued, each isolated browser context holds only its own seat",
              len(set(pid.values())) == 3)
        name_of = {v: k for k, v in pid.items()}
        players["Aisha"].shot(out, "01-lobby")

        op.act(code, "room.set_mode", {"mode": "bluff"})
        r = op.act(code, "room.start", {"rounds": 2, "language": "en"})
        check("bridge set_mode(bluff) + start(rounds=2, language=en) accepted", r["ok"] and r["status"] == 200, r.get("status"))

        op_offset = {"n": 0}

        def op_privacy(stage, truth):
            st = op.state(code)
            leaks = bp.scan(st, {"role": "operator"}, truth, surface="state")
            check(f"[{stage}] operator bridge state: no pre-reveal leak via whole-payload scanner", not leaks, leaks)
            op_offset["n"] = len(op.raw)

        def player_privacy(stage, truth):
            for nm, p in players.items():
                snap = p.last_snap()
                leaks = bp.scan(snap, {"role": "player", "id": pid[nm], "token": tokens[nm]}, truth, surface="state")
                check(f"[{stage}] {nm} browser SSE snapshot: no pre-reveal leak via whole-payload scanner", not leaks, leaks)
                dom = p.html()
                check(f"[{stage}] {nm}: rendered DOM never shows fake-answer authorship pre-reveal",
                      "authorId" not in dom)

        hs = op.state(code)
        check("round g1r1 started, operator bridge sees 3 players submitted so far totalling 3",
              hs["roundId"] == "g1r1" and hs["game"]["totalPlayers"] == 3, hs.get("roundId"))
        truth1 = bp.build_truth(hs, pack, (), list(tokens.values()))

        for nm, p in players.items():
            p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} submission form")
        op_privacy("round1-submission-0", truth1)
        player_privacy("round1-submission-0", truth1)
        players["Aisha"].shot(out, "02-submission")

        fakes = {"Aisha": "A fake but believable answer", "Omar": "Another convincing fake", "Noora": "Yet another fake"}
        for nm, p in players.items():
            p.type_into("#bluff-answer", fakes[nm])
            p.click("__btn('Submit fake answer')", f"{nm} submits fake answer")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} submitted status")

        truth1 = bp.build_truth(op.state(code), pack, (), list(tokens.values()))
        op_privacy("round1-submission-full", truth1)
        player_privacy("round1-submission-full", truth1)

        rid1 = op.state(code)["roundId"]
        r = op.act(code, "bluff.open_vote", {"force": False}, round_id=rid1)
        check("bridge open_vote accepted once all 3 submitted", r["ok"] and r["status"] == 200, r.get("status"))
        for nm, p in players.items():
            p.wait("!!document.querySelector('.bluff-option-btn')", what=f"{nm} voting options")
        truth1v = bp.build_truth(op.state(code), pack, (), list(tokens.values()))
        op_privacy("round1-voting", truth1v)
        player_privacy("round1-voting", truth1v)
        players["Omar"].shot(out, "03-voting")

        # Each player's own fake-answer option is disabled in the real DOM; verify
        # that structurally, then have each vote for a DIFFERENT (not-own) option.
        for nm, p in players.items():
            disabled_count = p.eval("document.querySelectorAll('.bluff-option-btn[disabled]').length")
            check(f"[round1-voting] {nm}: exactly one voting option (their own fake) is disabled in the real DOM", disabled_count == 1, disabled_count)

        for nm, p in players.items():
            # Vote for the first non-disabled option.
            p.eval("(() => { const b = [...document.querySelectorAll('.bluff-option-btn')].find(x => !x.disabled); b.click(); })()")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} voted status")

        r = op.act(code, "bluff.reveal", {"force": False}, round_id=rid1)
        check("bridge reveal accepted once all 3 voted", r["ok"] and r["status"] == 200, r.get("status"))
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('scored')", what=f"{nm} reveal/scoring view")
        players["Noora"].shot(out, "04-reveal")
        rv = op.state(code)["game"]
        check("round1 reveal: lastResult carries trueOptionId/options/voteTally/scoreDelta (operator truth)",
              bool(rv["lastResult"]) and "trueOptionId" in rv["lastResult"], list((rv.get("lastResult") or {}).keys()))

        r = op.act(code, "round.next", round_id="g1r1")
        check("bridge round.next accepted from reveal", r["ok"] and r["status"] == 200, r.get("status"))
        for nm, p in players.items():
            p.wait("!!document.querySelector('#bluff-answer')", what=f"{nm} round2 submission form")
        check("round2: fresh round id", op.state(code)["roundId"] != "g1r1", op.state(code)["roundId"])

        # ---------------------------------------------------- reload / reconnect mid-round2
        reload_target = "Omar"
        before_pid = pid[reload_target]
        players[reload_target].reload()
        players[reload_target].wait("!!document.querySelector('#bluff-answer')", what=f"{reload_target} reconnected")
        snap_after = players[reload_target].last_snap()
        check(f"{reload_target} reloads mid-round2 and reconnects into the SAME seat/round (server-authoritative, not a new join)",
              snap_after["self"]["id"] == before_pid)
        players[reload_target].shot(out, "05-reload-reconnect")

        for nm, p in players.items():
            p.type_into("#bluff-answer", fakes[nm] + " v2")
            p.click("__btn('Submit fake answer')", f"{nm} submits fake answer round2")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} submitted round2")
        rid2 = op.state(code)["roundId"]
        op.act(code, "bluff.open_vote", {"force": False}, round_id=rid2)
        for nm, p in players.items():
            p.wait("!!document.querySelector('.bluff-option-btn')", what=f"{nm} round2 voting options")
            p.eval("(() => { const b = [...document.querySelectorAll('.bluff-option-btn')].find(x => !x.disabled); b.click(); })()")
            p.wait("document.body.textContent.includes('Waiting for everyone else')", what=f"{nm} voted round2")
        op.act(code, "bluff.reveal", {"force": False}, round_id=rid2)
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('scored')", what=f"{nm} round2 reveal")
        # Engine semantics (party/core/majlis-core.js): REVEAL -> FINISHED only happens on an
        # explicit round.next, even when roundNo already reached the configured total.
        r = op.act(code, "round.next", round_id=rid2)
        check("bridge round.next accepted from final reveal (reveal -> finished)", r["ok"] and r["status"] == 200, r.get("status"))
        check("full 2-round game played end to end through the real rendered UI", op.state(code)["game"]["phase"] == "finished", op.state(code)["game"]["phase"])

        op.act(code, "room.end")
        for nm, p in players.items():
            p.wait("document.body.textContent.includes('Game over') || document.body.textContent.includes('Final')", what=f"{nm} game over")
        check("every page script ran on every player tab without a JS exception",
              not any(p.page_errors() for p in players.values()), {k: p.page_errors()[:2] for k, p in players.items() if p.page_errors()})

        # ---------------------------------------------------- credential hygiene over the wire
        all_rx = "\n".join(base.decoded_text(p.rx_raw()) for p in players.values())
        check("no operator credential (hostToken) anywhere in player-received bytes", "hostToken" not in all_rx)
        leaks = []
        for nm, tok in tokens.items():
            for t in tabs.values():
                if tok in t.eval("document.documentElement.outerHTML + location.href") or tok in t.console_text():
                    leaks.append((nm, t.name))
        check("no player token in any DOM, URL or console of any tab", not leaks, leaks)

    except Exception:
        import traceback
        check("run completed without an exception", False, traceback.format_exc()[-2000:])
    finally:
        for t in list(tabs.values()):
            try: t.ws.close()
            except Exception: pass
        if chrome is not None:
            chrome.terminate()
            try: chrome.wait(10)
            except Exception: chrome.kill()
        try:
            srv.stdin.close()
            srv.wait(10)
        except Exception:
            srv.kill()
        results["server_exit"] = srv.returncode

    p_ = sum(1 for c in results["checks"] if c["pass"])
    f_ = len(results["checks"]) - p_
    results["summary"] = {"pass": p_, "fail": f_, "total": len(results["checks"])}
    json.dump(results, open(os.path.join(out, "bluff-native-browser-results.json"), "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps(results["summary"]))
    sys.exit(0 if f_ == 0 and p_ > 0 else 1)


if __name__ == "__main__":
    main()
