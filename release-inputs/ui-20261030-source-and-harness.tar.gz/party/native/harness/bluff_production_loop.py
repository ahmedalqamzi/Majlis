"""Bluff on the PRODUCTION native binary (correction v3, fix 5).

Runs the compiled production ``majlis-party-native`` (not the -test build:
no network room create, no test surface) with the private operator stdin
bridge as the only host, and >=3 authenticated HTTP players, each with its
own SSE stream. Covers: join name collision + retry, submission collision +
retry, truth submission rejected (knowing the truth scores nothing),
actionId replay, late join while playing and while paused (spectator,
read-only, actions forbidden), voting, exactly-once score reveal (replayed
receipt and fresh reveal both leave scores unchanged), two rounds through
``finished``, a genuine SSE disconnect (socket shutdown) observed in
presence followed by token resume + a new stream, pause/resume, end, a new
game in Arabic with spectators promoted, prior-round / prior-game /
foreign-room option ids rejected, reset and clean exit on stdin EOF.

Every player/spectator HTTP response and every SSE ``state`` event is
scanned with tests/bluff_privacy.scan against the operator ground truth read
over the bridge at that revision. Capability tokens never reach the
evidence: HTTP logs replace them with ``<redacted:token:N>`` and a final
pass checks every evidence file for every token and token hash.

  python3 bluff_production_loop.py REPO_ROOT BINARY EVIDENCE_DIR
Exit 0 iff every check passes.
"""
import hashlib
import importlib.util
import json
import os
import re
import socket
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("impostor_native_browser_e2e", os.path.join(HERE, "impostor_native_browser_e2e.py"))
impostor_mod = importlib.util.module_from_spec(spec)
sys.argv_backup = sys.argv
sys.argv = ["impostor_native_browser_e2e.py"]
spec.loader.exec_module(impostor_mod)
sys.argv = sys.argv_backup
Operator, sha = impostor_mod.Operator, impostor_mod.sha

OPTION_ID_RE = re.compile(r"^o[0-9a-f]{16}$")
results = {"label": "Bluff correction v3: production native binary + private operator bridge + "
                     "authenticated HTTP/SSE players", "checks": []}


def check(name, ok, detail=None):
    results["checks"].append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


def main():
    repo, binary, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2]), os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)
    sys.path.insert(0, os.path.join(repo, "tests"))
    import support
    import bluff_privacy as bp

    content_dir = os.path.join(repo, "party", "content")
    web_dir = os.path.join(repo, "majlis-ios", "PartyWeb")
    pack = json.load(open(os.path.join(content_dir, "bluff.json"), encoding="utf-8"))
    tokens = []

    def redact(text):
        for i, tok in enumerate(tokens):
            text = text.replace(tok, "<redacted:token:%d>" % i)
            text = text.replace(hashlib.sha256(tok.encode()).hexdigest(), "<redacted:token-sha256:%d>" % i)
        return text

    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    cmd = [binary, "--host", "127.0.0.1", "--port", str(port), "--web-dir", web_dir, "--content-dir", content_dir,
           "--operator-stdin", "--exit-on-stdin-eof", "--access-log"]
    home = os.path.expanduser("~")
    results["server_argv_redacted"] = [a.replace(home, "~") for a in cmd]
    results["binary_sha256"] = sha(binary)
    results["content_bluff_sha256"] = sha(os.path.join(content_dir, "bluff.json"))
    results["harness_sha256"] = sha(os.path.abspath(__file__))
    results["privacy_checker_sha256"] = sha(os.path.join(repo, "tests", "bluff_privacy.py"))
    slog_path = os.path.join(out, "server-stderr.log")
    slog = open(slog_path, "w")
    srv = subprocess.Popen(cmd, cwd=repo, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=slog)
    op = Operator(srv, out)
    op.pump_start()
    api = support.Api(port)
    hlog = open(os.path.join(out, "http-protocol.jsonl"), "w")
    seq = [0]
    timeline = {}  # revision -> truth (room A)
    played = []
    findings = []
    streams = []  # (label, client, viewer)

    def http(who, fn, *a, **kw):
        time.sleep(0.06)  # stay far below the per-IP action/request buckets
        r = fn(*a, **kw)
        if isinstance(r.json, dict) and r.json.get("playerToken") and r.json["playerToken"] not in tokens:
            tokens.append(r.json["playerToken"])
        seq[0] += 1
        hlog.write(redact(json.dumps({"seq": seq[0], "who": who, "call": fn.__name__,
                                      "args": [x for x in a if not (isinstance(x, str) and x in tokens)],
                                      "status": r.status, "replayed": r.headers.get("x-action-replayed"),
                                      "body": r.json if r.json is not None else r.text[:200]},
                                     ensure_ascii=False)) + "\n")
        hlog.flush()
        return r

    def bstate(code):
        return op.state(code)

    def record(code):
        snap = bstate(code)
        t = bp.build_truth(snap, pack, played, tokens)
        timeline[snap["revision"]] = t
        return snap, t

    def scan_resp(resp, viewer, surface, where):
        _, t = record(A)
        surf = "error" if (resp.status >= 400 and surface not in ("action",)) else surface
        raw_t = t
        if surface in ("join", "reconnect"):  # a join/resume response legitimately carries the caller's OWN token
            raw_t = dict(t, tokens=[x for x in t["tokens"] if x != viewer.get("token")])
        fs = bp.scan(resp.json, viewer, t, surf) + bp.scan_raw(resp.text, viewer, raw_t)
        for f in fs:
            findings.append(dict(f.as_dict(), where=where, viewer=viewer["role"]))
        return fs

    def view(p):
        return {"role": p.get("role", "player"), "id": p["id"], "token": p["token"]}

    def state_of(p, where):
        r = http(p["name"], api.state, A, p["token"])
        scan_resp(r, view(p), "state", where)
        return r.json

    def act(p, kind, rid=None, payload=None, action_id=None, where=None):
        r = http(p["name"], api.action, A, p["token"], kind, rid, payload, action_id)
        scan_resp(r, view(p), "action", where or kind)
        return r

    def bact(code, kind, payload=None, rid=None, action_id=None):
        r = op.act(code, kind, payload, rid, action_id)
        if code == A:
            record(A)
        return r

    def open_stream(p, label):
        c = support.SSEClient(port, "/api/rooms/%s/events" % A, token=p["token"])
        streams.append((label, c, view(p)))
        return c

    def scores(snap):
        return {p["id"]: p["score"] for p in snap["players"]}

    def wait_presence(code, pid, want, timeout=45.0):
        t0 = time.time()
        while time.time() - t0 < timeout:
            snap = bstate(code)
            for p in snap["players"] + (snap.get("spectators") or []):
                if p["id"] == pid and p.get("connected") == want:
                    return round(time.time() - t0, 2)
            time.sleep(0.5)
        return None

    rc = None
    try:
        banner = op.banner()
        check("production banner: surface=production on loopback", banner.get("surface") == "production" and banner.get("host") == "127.0.0.1", banner)
        check("production surface has no network room create", http("anon", api.create_room).status in (403, 404, 405), None)

        # -------------------------------------------------------------- room A
        cr = op.call({"op": "create", "body": {}})
        A = cr["code"]
        check("bridge create room A", cr.get("ok") is True and set(cr) == {"ok", "op", "code", "revision"}, cr)
        P = {}
        for nm in ("Aisha", "Omar"):
            jr = http(nm, api.join, A, nm)
            check("join %s 201" % nm, jr.status == 201, jr.status)
            P[nm] = {"name": nm, "id": jr.json["playerId"], "token": jr.json["playerToken"]}
        dup = http("Noora", api.join, A, "omar")
        check("join name collision rejected name_taken 409 (case-insensitive)", dup.status == 409 and dup.json["error"]["code"] == "name_taken", dup.json)
        scan_resp(dup, {"role": "player", "id": None, "token": None}, "join", "join-collision")
        jr = http("Noora", api.join, A, "Noora")
        check("join retry with a free name 201", jr.status == 201, jr.status)
        P["Noora"] = {"name": "Noora", "id": jr.json["playerId"], "token": jr.json["playerToken"]}
        players = [P["Aisha"], P["Omar"], P["Noora"]]
        for p in players:
            p["sse"] = open_stream(p, "game1:" + p["name"])
        time.sleep(0.3)
        check("3 authenticated SSE streams 200", all(p["sse"].status == 200 for p in players), [p["sse"].status for p in players])

        # ----------------------------------------------- room B (foreign ids)
        B = op.call({"op": "create", "body": {}})["code"]
        bpl = []
        for nm in ("Badr", "Basma", "Bilal"):
            j = http(nm, api.join, B, nm)
            bpl.append({"name": nm, "id": j.json["playerId"], "token": j.json["playerToken"]})
        bact(B, "room.set_mode", {"mode": "bluff"})
        bact(B, "room.start", {"rounds": 1})
        brid = bstate(B)["roundId"]
        for i, p in enumerate(bpl):
            http(p["name"], api.action, B, p["token"], "bluff.submit_answer", brid, {"text": "foreign room fake %d" % i})
        bact(B, "bluff.open_vote", None, brid)
        foreign_ids = [o["optionId"] for o in bstate(B)["game"]["options"]]

        # ------------------------------------------------- game 1, round 1 (EN)
        r = bact(A, "room.set_mode", {"mode": "bluff"})
        r = bact(A, "room.start", {"rounds": 2, "language": "en"})
        check("bridge room.start bluff rounds=2 en", r.get("status") == 200, r.get("result"))
        snap, t = record(A)
        rid1 = snap["roundId"]
        check("game 1 round 1 is g1r1 submission, players unchanged", (rid1, snap["game"]["phase"], len(snap["players"])) == ("g1r1", "submission", 3), [rid1, snap["game"]["phase"]])
        truth = snap["game"]["trueAnswer"]
        q1 = snap["game"]["question"]["en"]
        for p in players:
            state_of(p, "g1r1-submission-0")
        for lang in ("en", "ar"):
            rr = act(P["Aisha"], "bluff.submit_answer", rid1, {"text": truth[lang]}, where="truth-submit-" + lang)
            check("submitting the true answer (%s) is rejected invalid_answer 400 and scores nothing" % lang,
                  rr.status == 400 and rr.json["error"]["code"] == "invalid_answer" and scores(bstate(A)) == {p["id"]: 0 for p in players}, rr.json)
        fakeA, fakeO, fakeN = "Aisha invented answer", "Omar invented answer", "Noora invented answer"
        r1 = act(P["Aisha"], "bluff.submit_answer", rid1, {"text": fakeA}, action_id="prod-submit-aisha")
        r2 = act(P["Aisha"], "bluff.submit_answer", rid1, {"text": fakeA}, action_id="prod-submit-aisha")
        check("submission accepted, same actionId replayed (x-action-replayed: 1, same revision)",
              r1.status == 200 and r2.status == 200 and r2.headers.get("x-action-replayed") == "1" and r1.json == r2.json, [r1.json, r2.json])
        col = act(P["Omar"], "bluff.submit_answer", rid1, {"text": fakeA.upper()}, where="collision")
        check("submission collision rejected neutrally (invalid_answer, no author id)",
              col.status == 400 and col.json["error"]["code"] == "invalid_answer" and P["Aisha"]["id"] not in col.text, col.json)
        rr = act(P["Omar"], "bluff.submit_answer", rid1, {"text": fakeO})
        check("submission retry after collision accepted", rr.status == 200, rr.json)

        # late join while PLAYING -> spectator
        lj = http("Late", api.join, A, "Late Viewer")
        S1 = {"name": "Late Viewer", "role": "spectator", "id": lj.json["playerId"], "token": lj.json["playerToken"]}
        scan_resp(lj, view(S1), "join", "join-spectator-playing")
        check("late join while playing: 201 + spectator credential", lj.status == 201 and lj.json.get("spectator") is True, sorted(lj.json))
        snap = bstate(A)
        check("participants and scores unchanged by spectator", len(snap["players"]) == 3 and [p["id"] for p in snap.get("spectators", [])] == [S1["id"]] and snap["game"]["totalPlayers"] == 3 and scores(snap) == {p["id"]: 0 for p in players}, None)
        sv = state_of(S1, "g1r1-submission-spectator")
        check("spectator projection is read-only spectator role", sv["role"] == "spectator" and (sv.get("self") or {}).get("spectator") is True and "you" not in (sv.get("game") or {}), [sv["role"], sv.get("self")])
        sa = act(S1, "bluff.submit_answer", rid1, {"text": "spectator fake"}, where="spectator-submit")
        check("spectator action rejected forbidden 403", sa.status == 403 and sa.json["error"]["code"] == "forbidden", sa.json)
        S1["sse"] = open_stream(S1, "game1:spectator-playing")
        rr = act(P["Noora"], "bluff.submit_answer", rid1, {"text": fakeN})
        check("third submission accepted", rr.status == 200, rr.json)
        for p in players:
            state_of(p, "g1r1-submission")

        # voting
        r = bact(A, "bluff.open_vote", None, rid1)
        check("bridge open_vote", r.get("status") == 200, r.get("result"))
        snap, t = record(A)
        opsr1 = t["options"]
        r1_ids = [o["optionId"] for o in opsr1]
        pub = [state_of(p, "g1r1-voting")["game"]["options"] for p in players + [S1]]
        check("every viewer receives the identical option list", all(x == pub[0] for x in pub), None)
        check("public options are exactly {optionId,text}, string text, opaque ids",
              all(set(o) == {"optionId", "text"} and isinstance(o["text"], str) and OPTION_ID_RE.match(o["optionId"]) for o in pub[0]), pub[0])
        check("option ids disjoint from foreign room B and never positional",
              not set(r1_ids) & set(foreign_ids) and not any(re.match(r"^o\d+$", i) for i in r1_ids), None)
        true_id = next(o["optionId"] for o in opsr1 if o["authorId"] is None)
        by_author = {o["authorId"]: o["optionId"] for o in opsr1}
        results["g1r1_true_position"] = r1_ids.index(true_id)

        # pause; late join while PAUSED
        r = bact(A, "room.pause")
        check("bridge room.pause", r.get("status") == 200 and bstate(A)["phase"] == "paused", r.get("result"))
        lj2 = http("Paused", api.join, A, "Paused Viewer")
        S2 = {"name": "Paused Viewer", "role": "spectator", "id": lj2.json["playerId"], "token": lj2.json["playerToken"]}
        scan_resp(lj2, view(S2), "join", "join-spectator-paused")
        check("late join while paused: 201 + spectator", lj2.status == 201 and lj2.json.get("spectator") is True, sorted(lj2.json))
        pv = act(P["Aisha"], "bluff.vote", rid1, {"optionId": true_id}, where="vote-while-paused")
        check("vote while paused rejected (paused 409), nothing recorded", pv.status == 409 and pv.json["error"]["code"] == "paused" and bstate(A)["game"]["votes"] == {}, pv.json)
        state_of(S2, "g1r1-paused-spectator")
        r = bact(A, "room.resume")
        check("bridge room.resume", r.get("status") == 200 and bstate(A)["phase"] == "playing", r.get("result"))

        # genuine stream disconnect + reconnect
        noora = P["Noora"]
        noora["sse"].close()  # socket shutdown(SHUT_RDWR) + close: a real peer disconnect
        dt = wait_presence(A, noora["id"], False)
        check("server observed the dropped SSE stream (Noora connected=false)", dt is not None, {"seconds": dt})
        rj = http("Noora", api.join, A, None, token=noora["token"])
        scan_resp(rj, view(noora), "reconnect", "reconnect-noora")
        check("token resume returns same playerId, resumed", rj.status in (200, 201) and rj.json.get("playerId") == noora["id"] and rj.json.get("resumed") is True, sorted(rj.json))
        noora["sse"] = open_stream(noora, "game1:Noora-reconnected")
        first = noora["sse"].next_state()
        check("reconnected stream delivers current voting state first", first["json"]["game"]["phase"] == "voting" and first["json"]["game"]["options"] == pub[0], first["json"]["revision"])
        dt2 = wait_presence(A, noora["id"], True, 10)
        check("presence back to connected after reconnect", dt2 is not None, {"seconds": dt2})

        # votes + bad ids
        fv = act(P["Aisha"], "bluff.vote", rid1, {"optionId": foreign_ids[0]}, where="vote-foreign-room")
        check("foreign-room option id rejected unknown_option (valid current roundId)", fv.status == 400 and fv.json["error"]["code"] == "unknown_option", fv.json)
        sv2 = act(S1, "bluff.vote", rid1, {"optionId": true_id}, where="spectator-vote")
        check("spectator vote rejected forbidden 403", sv2.status == 403, sv2.json)
        act(P["Aisha"], "bluff.vote", rid1, {"optionId": true_id})
        act(P["Omar"], "bluff.vote", rid1, {"optionId": by_author[P["Aisha"]["id"]]})
        act(P["Noora"], "bluff.vote", rid1, {"optionId": by_author[P["Omar"]["id"]]})
        for p in players:
            state_of(p, "g1r1-voted")
        expected = {P["Aisha"]["id"]: 200, P["Omar"]["id"]: 100, P["Noora"]["id"]: 0}
        rv = bact(A, "bluff.reveal", None, rid1, action_id="prod-reveal-g1r1")
        after = scores(bstate(A))
        check("reveal scores exactly (truth +100 voter, fooled +100 author)", rv.get("status") == 200 and after == expected, after)
        rv2 = bact(A, "bluff.reveal", None, rid1, action_id="prod-reveal-g1r1")
        check("reveal replay (same actionId) is a replayed receipt, scores unchanged",
              rv2.get("replayed") is True and rv2.get("result") == rv.get("result") and scores(bstate(A)) == expected, rv2)
        rv3 = bact(A, "bluff.reveal", {"force": True}, rid1)
        check("fresh reveal rejected invalid_phase 409, scores unchanged", rv3.get("status") == 409 and scores(bstate(A)) == expected, rv3.get("result"))
        for p in players + [S1, S2]:
            g = state_of(p, "g1r1-reveal")
        lr = g["game"]["lastResult"]
        check("revealed result visible to spectator with exact deltas", lr and lr["scoreDelta"] == expected, lr and lr.get("scoreDelta"))

        # ------------------------------------------------------- round 2
        played.append(q1)
        bact(A, "round.next", None, rid1)
        snap, _ = record(A)
        rid2 = snap["roundId"]
        st = act(P["Aisha"], "bluff.submit_answer", rid1, {"text": "late"}, where="stale-round")
        check("round 2 is g1r2; prior roundId rejected stale_round", rid2 == "g1r2" and st.json["error"]["code"] == "stale_round", st.json)
        for i, p in enumerate(players):
            act(p, "bluff.submit_answer", rid2, {"text": "second round fake %d" % i})
        bact(A, "bluff.open_vote", None, rid2)
        snap, t = record(A)
        opsr2 = t["options"]
        r2_ids = [o["optionId"] for o in opsr2]
        check("round-2 ids disjoint from round-1 ids", not set(r2_ids) & set(r1_ids), None)
        results["g1r2_true_position"] = [o["authorId"] for o in opsr2].index(None)
        pr = act(P["Aisha"], "bluff.vote", rid2, {"optionId": r1_ids[0]}, where="vote-prior-round")
        check("prior-round option id rejected unknown_option under the current roundId", pr.status == 400 and pr.json["error"]["code"] == "unknown_option", pr.json)
        byA2 = {o["authorId"]: o["optionId"] for o in opsr2}
        t2 = next(o["optionId"] for o in opsr2 if o["authorId"] is None)
        act(P["Aisha"], "bluff.vote", rid2, {"optionId": byA2[P["Noora"]["id"]]})
        act(P["Omar"], "bluff.vote", rid2, {"optionId": t2})
        act(P["Noora"], "bluff.vote", rid2, {"optionId": t2})
        for p in players:
            state_of(p, "g1r2-voted")
        bact(A, "bluff.reveal", None, rid2)
        expected2 = {P["Aisha"]["id"]: 200, P["Omar"]["id"]: 200, P["Noora"]["id"]: 200}
        check("round 2 reveal scores exactly once", scores(bstate(A)) == expected2, scores(bstate(A)))
        played.append(snap["game"]["question"]["en"])
        bact(A, "round.next", None, rid2)
        snap, _ = record(A)
        check("after the configured 2 rounds the game is finished", snap["game"]["phase"] == "finished", snap["game"]["phase"])
        for p in players + [S1]:
            state_of(p, "g1-finished")
        r = bact(A, "room.end")
        snap, _ = record(A)
        check("room.end -> ended; spectators still listed separately", snap["phase"] == "ended" and len(snap["players"]) == 3 and len(snap.get("spectators") or []) == 2, [snap["phase"], len(snap.get("spectators") or [])])
        for p in players + [S1, S2]:
            state_of(p, "g1-ended")

        # close game-1 streams; keep their bytes for the scan
        time.sleep(0.4)
        for _, c, _ in streams:
            c.close()

        # ---------------------------------------------- game 2 (AR, promoted)
        r = bact(A, "room.start", {"rounds": 1, "language": "ar"})
        snap, _ = record(A)
        rid3 = snap["roundId"]
        check("new game g2r1 in Arabic; both spectators promoted to players",
              r.get("status") == 200 and rid3 == "g2r1" and snap["game"]["language"] == "ar" and len(snap["players"]) == 5 and not snap.get("spectators")
              and {S1["id"], S2["id"]} <= {p["id"] for p in snap["players"]} and snap["game"]["totalPlayers"] == 5, [rid3, len(snap["players"])])
        check("new game starts clean (no fakes/votes/lastResult carried over)",
              snap["game"]["fakes"] == {} and snap["game"]["votes"] == {} and snap["game"]["lastResult"] is None and snap["game"]["round"] == 1, None)
        check("room scores carried, promoted players start at 0",
              scores(snap) == dict(expected2, **{S1["id"]: 0, S2["id"]: 0}), scores(snap))
        S1["role"] = S2["role"] = "player"
        g2 = players + [S1, S2]
        for p in g2:
            p["sse"] = open_stream(p, "game2:" + p["name"])
        time.sleep(0.3)
        for p in g2:
            state_of(p, "g2r1-submission")
        for i, p in enumerate(g2):
            act(p, "bluff.submit_answer", rid3, {"text": "إجابة مختلقة %d" % i})
        bact(A, "bluff.open_vote", None, rid3)
        snap, t = record(A)
        opsg2 = t["options"]
        pubg2 = [state_of(p, "g2r1-voting")["game"]["options"] for p in g2]
        check("Arabic game: identical {optionId,text} options for all five players",
              all(x == pubg2[0] for x in pubg2) and all(set(o) == {"optionId", "text"} and isinstance(o["text"], str) for o in pubg2[0]), None)
        check("Arabic truth option carries only the Arabic answer",
              any(o["text"] == snap["game"]["trueAnswer"]["ar"] for o in pubg2[0]), None)
        pg = act(S1, "bluff.vote", rid3, {"optionId": true_id}, where="vote-prior-game")
        check("prior-game option id rejected unknown_option (promoted player, current roundId)", pg.status == 400 and pg.json["error"]["code"] == "unknown_option", pg.json)
        results["g2r1_true_position"] = [o["authorId"] for o in opsg2].index(None)
        tg2 = next(o["optionId"] for o in opsg2 if o["authorId"] is None)
        for p in g2:
            act(p, "bluff.vote", rid3, {"optionId": tg2})
        before = scores(bstate(A))
        bact(A, "bluff.reveal", None, rid3)
        after = scores(bstate(A))
        check("game 2 reveal: +100 each for the truth, exactly once", all(after[k] == before[k] + 100 for k in before), after)
        for p in g2:
            state_of(p, "g2r1-reveal")
        bact(A, "room.end")
        r = bact(A, "room.reset")
        snap, _ = record(A)
        check("room.reset -> lobby, game cleared", snap["phase"] == "lobby" and snap["game"] is None, snap["phase"])
        time.sleep(0.4)
        for _, c, _ in streams:
            c.close()

        # --------------------------------------------------------- SSE scan
        total = 0
        sselog = open(os.path.join(out, "sse-streams.log"), "w", encoding="utf-8")
        for label, c, v in streams:
            raw = c.raw_text()
            sselog.write("==== stream %s (role %s, %d bytes)\n" % (label, v["role"], len(raw)) + redact(raw) + "\n")
            evs = []
            while True:
                try:
                    it = c.items.get_nowait()
                except Exception:
                    break
                if it and it.get("event") == "state" and it.get("json"):
                    evs.append(it["json"])
            revs = sorted(timeline)
            for ev in evs:
                rvn = ev["revision"]
                t = timeline.get(rvn) or timeline[max([x for x in revs if x <= rvn] or revs[:1])]
                for f in bp.scan(ev, v, t, "sse"):
                    findings.append(dict(f.as_dict(), where="sse:%s@%d" % (label, rvn), viewer=v["role"]))
            for f in bp.scan_raw(raw, v, timeline[max(timeline)]):
                findings.append(dict(f.as_dict(), where="sse-raw:" + label, viewer=v["role"]))
            total += len(evs)
            results.setdefault("sse_streams", []).append({"label": label, "role": v["role"], "events": len(evs), "bytes": len(raw)})
        sselog.close()
        check("SSE events captured and scanned", total > 20, total)
        # bridge (operator) views must pass the operator rules unflagged
        bfs = bp.scan(bstate(A), {"role": "operator", "id": None, "token": None}, record(A)[1], "bridge")
        check("bridge operator view passes operator rules (private inspection unflagged)", not bfs, [f.as_dict() for f in bfs])
        check("privacy: zero findings over every player/spectator response and SSE event", not findings, findings[:20])
        results["privacy_findings"] = findings
        results["timeline_revisions"] = len(timeline)
    finally:
        try:
            srv.stdin.close()
        except Exception:
            pass
        try:
            rc = srv.wait(20)
        except Exception:
            srv.kill()
            rc = srv.wait(5)
        slog.close()
        hlog.close()
        op.transcript.close()
    check("production server exited 0 on stdin EOF", rc == 0, rc)
    results["server_exit_code"] = rc
    results["token_count"] = len(tokens)

    # redact server log in place, then verify no evidence file carries a token
    with open(slog_path, encoding="utf-8", errors="replace") as fh:
        stext = fh.read()
    with open(slog_path, "w", encoding="utf-8") as fh:
        fh.write(redact(stext))
    passed = all(c["pass"] for c in results["checks"])
    results["summary"] = {"pass": sum(c["pass"] for c in results["checks"]), "fail": sum(not c["pass"] for c in results["checks"])}
    path = os.path.join(out, "bluff-production-loop-results.json")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(redact(json.dumps(results, ensure_ascii=False, indent=1, default=str)))
    leaks = []
    hashes = [hashlib.sha256(t.encode()).hexdigest() for t in tokens]
    for name in sorted(os.listdir(out)):
        data = open(os.path.join(out, name), encoding="utf-8", errors="replace").read()
        if any(t in data for t in tokens) or any(h in data.lower() for h in hashes):
            leaks.append(name)
    ok = check("no capability token or token hash in any evidence file", not leaks and bool(tokens), leaks)
    print(json.dumps({"pass": results["summary"]["pass"] + int(ok), "fail": results["summary"]["fail"] + int(not ok)}))
    return 0 if (passed and ok) else 1


if __name__ == "__main__":
    sys.exit(main())
