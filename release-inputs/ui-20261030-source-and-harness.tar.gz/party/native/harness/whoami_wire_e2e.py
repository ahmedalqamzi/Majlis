"""Real compiled native host, over real raw-socket HTTP + SSE, driving one full
Who Am I guess / change-guess / host-clear / ready / reveal loop with >=3 real
player identities plus an operator -- using the exact Api/SSEClient/ServerProcess
classes tests/test_http_*.py already use, swapped onto the native test binary
via the same NativePopen technique as taboo_wire_e2e.py (this file duplicates
that small swap rather than importing it, to stay independent). Content dir is
a private copy of the synthetic tests/fixtures/content/who_am_i.json pack, so
the shared tests/fixtures/content/ directory is never touched.

    python3 -I -B party/native/harness/whoami_wire_e2e.py NATIVE_BIN CONTENT_DIR EVIDENCE_DIR

Exit 0 iff every check passes.
"""
import json
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, ROOT)


def main():
    native_bin = os.path.abspath(sys.argv[1])
    content_dir = os.path.abspath(sys.argv[2])
    out = os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)

    original_popen = subprocess.Popen

    class NativePopen(original_popen):
        def __init__(self, args, *rest, **kwargs):
            if isinstance(args, (list, tuple)) and len(args) >= 3 and list(args[1:3]) == ["-m", "party.server"]:
                args = [native_bin] + list(args[3:])
            elif isinstance(args, (list, tuple)) and "party.server" in args:
                raise AssertionError("reference server launched outside the native swap")
            original_popen.__init__(self, args, *rest, **kwargs)

    subprocess.Popen = NativePopen

    from support import Api, ServerProcess, SSEClient  # noqa: E402

    checks = []

    def check(name, cond, detail=None):
        checks.append({"name": name, "pass": bool(cond), "detail": detail})
        print(("PASS " if cond else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, default=str)[:300]))

    transcript = open(os.path.join(out, "transcript.jsonl"), "w")

    def record(label, resp):
        transcript.write(json.dumps({"label": label, "status": resp.status, "json": resp.json}, default=str) + "\n")
        transcript.flush()
        return resp

    server = ServerProcess((), content_dir, fast=True).start()
    api = Api(server.port)
    clean_shutdown = False
    try:
        created = record("create_room", api.create_room(minPlayers=3, maxPlayers=12))
        check("create_room 201", created.status == 201, created.text)
        code, host_token = created.json["code"], created.json["hostToken"]

        players = []
        for i in range(3):
            j = record("join_%d" % i, api.join(code, "Player%d" % i))
            check("join_%d 201" % i, j.status == 201, j.text)
            players.append({"id": j.json["playerId"], "token": j.json["playerToken"]})
        p0, p1, p2 = players

        sm = record("set_mode_who_am_i", api.action(code, host_token, "room.set_mode", payload={"mode": "who_am_i"}))
        check("set_mode accepted", sm.status == 200 and sm.json.get("accepted") is True, sm.text)

        display_stream = SSEClient(server.port, "/api/rooms/%s/events" % code, token=host_token)
        check("operator SSE connected", display_stream.status == 200, display_stream.status)

        start = record("room_start", api.action(code, host_token, "room.start"))
        check("room.start accepted", start.status == 200, start.text)

        op_state = api.state(code, host_token).json
        round_id = op_state["roundId"]
        check("operator sees full assignments map pre-reveal", all(pl["id"] in op_state["game"]["assignments"] for pl in players),
              op_state["game"]["assignments"])
        check("operator pendingGuesses empty at round start", op_state["game"]["pendingGuesses"] == [])

        # ---- pre-reveal privacy: each player sees every OTHER player's assignment (the point of
        # the game -- the label is "on your forehead"), but never their own.
        p0_state = api.state(code, p0["token"]).json
        check("player never sees own assignment pre-reveal", p0["id"] not in p0_state["game"]["assignments"], p0_state["game"]["assignments"])
        check("player's own you.assignment absent pre-reveal", "assignment" not in p0_state["game"]["you"], p0_state["game"]["you"])
        check("player sees every OTHER player's assignment", all(pl["id"] in p0_state["game"]["assignments"] for pl in players if pl["id"] != p0["id"]),
              p0_state["game"]["assignments"])
        check("player's view of own guess is null before guessing", p0_state["game"]["you"]["guess"] is None)
        check("player's own revealed/ready false at round start", p0_state["game"]["you"]["revealed"] is False and p0_state["game"]["you"]["ready"] is False)

        # ---- whoami.ready
        rdy = api.action(code, p0["token"], "whoami.ready", round_id=round_id, payload={"ready": True})
        check("whoami.ready accepted", rdy.status == 200 and rdy.json.get("accepted") is True, rdy.text)
        after_ready = api.state(code, host_token).json
        check("operator sees p0 in ready list", p0["id"] in after_ready["game"]["ready"], after_ready["game"]["ready"])

        # ---- whoami.guess (initial) then change-guess (re-submit overwrites, not duplicates)
        g1 = api.action(code, p0["token"], "whoami.guess", round_id=round_id, payload={"text": "a lion?"})
        check("first guess accepted", g1.status == 200 and g1.json.get("accepted") is True, g1.text)
        op_after_g1 = api.state(code, host_token).json
        check("operator sees p0's pending guess text", op_after_g1["game"]["guesses"].get(p0["id"]) == "a lion?", op_after_g1["game"]["guesses"])
        other_state_after_g1 = api.state(code, p1["token"]).json
        check("another player never sees guess text (operator-only field)", "guesses" not in other_state_after_g1["game"],
              other_state_after_g1["game"])

        g2 = api.action(code, p0["token"], "whoami.guess", round_id=round_id, payload={"text": "a tiger?"})
        check("changed guess accepted", g2.status == 200 and g2.json.get("accepted") is True, g2.text)
        op_after_g2 = api.state(code, host_token).json
        check("operator now sees the CHANGED guess text, not the old one", op_after_g2["game"]["guesses"].get(p0["id"]) == "a tiger?",
              op_after_g2["game"]["guesses"])
        check("exactly one pending guess for p0 (overwrite, not duplicate)", op_after_g2["game"]["pendingGuesses"] == [p0["id"]],
              op_after_g2["game"]["pendingGuesses"])

        # ---- whoami.dismiss (host-clear): operator clears the pending guess without revealing
        dismiss = api.action(code, host_token, "whoami.dismiss", round_id=round_id, payload={"playerId": p0["id"]})
        check("whoami.dismiss accepted", dismiss.status == 200 and dismiss.json.get("accepted") is True, dismiss.text)
        op_after_dismiss = api.state(code, host_token).json
        check("host-clear removes the pending guess", p0["id"] not in op_after_dismiss["game"]["pendingGuesses"],
              op_after_dismiss["game"]["pendingGuesses"])
        check("host-clear does not reveal the player", p0["id"] not in op_after_dismiss["game"]["revealed"],
              op_after_dismiss["game"]["revealed"])
        p0_after_dismiss = api.state(code, p0["token"]).json
        check("cleared player's own guess view goes back to null", p0_after_dismiss["game"]["you"]["guess"] is None,
              p0_after_dismiss["game"]["you"])

        # dismiss with nothing pending is rejected, zero mutation
        redismiss = api.action(code, host_token, "whoami.dismiss", round_id=round_id, payload={"playerId": p0["id"]})
        check("re-dismiss with no pending guess rejected", redismiss.status == 409 and redismiss.json["error"]["code"] == "no_pending_guess",
              redismiss.text)

        # ---- a non-display SSE listener never receives the operator-only guess text, and the
        # operator's own SSE stream does carry it when p0 guesses again.
        g3 = api.action(code, p0["token"], "whoami.guess", round_id=round_id, payload={"text": "a falcon?"})
        check("third guess accepted", g3.status == 200, g3.text)
        saw_guess_over_sse = False
        for _ in range(20):
            item = display_stream.next(timeout=3.0)
            if item is None:
                break
            if item.get("event") == "state" and item.get("json"):
                st = item["json"].get("state") or item["json"]
                gm = st.get("game") if isinstance(st, dict) else None
                if gm and gm.get("guesses", {}).get(p0["id"]) == "a falcon?":
                    saw_guess_over_sse = True
                    break
        check("operator SSE stream carries the live guess text", saw_guess_over_sse)

        # ---- whoami.reveal (single player): player's own view flips to revealed+assignment;
        # others still cannot see that player's guess field disappearing early.
        reveal1 = api.action(code, host_token, "whoami.reveal", round_id=round_id, payload={"playerId": p0["id"]})
        check("whoami.reveal (single) accepted", reveal1.status == 200 and reveal1.json.get("accepted") is True, reveal1.text)
        p0_after_reveal = api.state(code, p0["token"]).json
        check("revealed player now sees own revealed=true", p0_after_reveal["game"]["you"]["revealed"] is True)
        check("revealed player now sees own assignment", "assignment" in p0_after_reveal["game"]["you"] and
              p0_after_reveal["game"]["you"]["assignment"].get("label"), p0_after_reveal["game"]["you"])
        p1_state_after_reveal = api.state(code, p1["token"]).json
        check("other players see the revealed player's assignment via the shared map too",
              p0["id"] in p1_state_after_reveal["game"]["assignments"], p1_state_after_reveal["game"]["assignments"])

        # guessing after being revealed is rejected
        post_reveal_guess = api.action(code, p0["token"], "whoami.guess", round_id=round_id, payload={"text": "too late"})
        check("guess after reveal rejected", post_reveal_guess.status == 409 and
              post_reveal_guess.json["error"]["code"] == "already_revealed", post_reveal_guess.text)

        # ---- whoami.award for the revealed player; then reveal everyone else via omitted playerId
        award = api.action(code, host_token, "whoami.award", round_id=round_id, payload={"playerId": p0["id"], "points": 1})
        check("whoami.award accepted", award.status == 200 and award.json.get("accepted") is True, award.text)
        op_after_award = api.state(code, host_token).json
        p0_room_entry = next(p for p in op_after_award["players"] if p["id"] == p0["id"])
        check("score incremented by award (room-level players[].score)", p0_room_entry["score"] == 1, p0_room_entry)
        check("award recorded under solved", p0["id"] in op_after_award["game"]["solved"], op_after_award["game"]["solved"])

        reveal_all = api.action(code, host_token, "whoami.reveal", round_id=round_id, payload={})
        check("whoami.reveal (all, omitted playerId) accepted", reveal_all.status == 200 and reveal_all.json.get("accepted") is True,
              reveal_all.text)
        op_final = api.state(code, host_token).json
        check("round phase is revealed once everyone is revealed", op_final["game"]["roundPhase"] == "revealed")
        check("all players present in revealed list", sorted(op_final["game"]["revealed"]) == sorted(pl["id"] for pl in players),
              op_final["game"]["revealed"])

        # revealing again once everyone is already revealed is rejected
        rereveal = api.action(code, host_token, "whoami.reveal", round_id=round_id, payload={})
        check("reveal-all again once fully revealed rejected", rereveal.status == 409 and rereveal.json["error"]["code"] == "already_revealed",
              rereveal.text)

        # ---- round.next starts a fresh round: new roundId, cleared guesses/ready/revealed
        rn = api.action(code, host_token, "round.next", round_id=round_id)
        check("round.next accepted", rn.status == 200 and rn.json.get("accepted") is True, rn.text)
        new_op_state = api.state(code, host_token).json
        check("round.next produced a new roundId", new_op_state["roundId"] != round_id, (new_op_state["roundId"], round_id))
        check("new round starts back in asking phase", new_op_state["game"]["roundPhase"] == "asking")
        check("new round clears ready list", new_op_state["game"]["ready"] == [])
        check("new round clears revealed list", new_op_state["game"]["revealed"] == [])
        check("new round clears pending guesses", new_op_state["game"]["pendingGuesses"] == [])

        # stale roundId (the old, now-finished round) is rejected on the fresh round
        stale = api.action(code, host_token, "whoami.reveal", round_id=round_id, payload={"playerId": p1["id"]})
        check("stale (prior) roundId rejected on new round", stale.status == 409 and stale.json["error"]["code"] == "stale_round", stale.text)

        # reconnect mid-round with the same token re-authenticates to the identical authorized view
        reconnect_state = api.state(code, p1["token"]).json
        check("reconnect mid-game preserves identity (own guess view still null, not an error)",
              reconnect_state["game"]["you"]["guess"] is None)

        clean_shutdown = True
    finally:
        try:
            display_stream.close()
        except Exception:
            pass
        server.stop()
        if server.proc.poll() is None:
            clean_shutdown = False
            raise AssertionError("server still running after stop()")
    check("clean server shutdown", clean_shutdown)

    transcript.close()
    with open(os.path.join(out, "results.json"), "w") as f:
        json.dump(checks, f, indent=2)
    n_fail = sum(1 for c in checks if not c["pass"])
    print("TOTAL %d  PASS %d  FAIL %d" % (len(checks), len(checks) - n_fail, n_fail))
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
