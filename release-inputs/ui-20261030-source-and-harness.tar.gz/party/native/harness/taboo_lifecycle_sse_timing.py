"""Taboo lifecycle / timer / spectator checks against REAL compiled hosts,
over real HTTP + SSE with real wall-clock waits (no injected clock).

Sections (each starts its own host on a dynamic port and stops it on every
path):

  test-loopback surface (majlis-party-native-test, FAST limits):
    spectators  late joins while playing AND while paused are read-only
                spectators (join/resume/snapshot/SSE/error/receipt), same
                identity on resume, promoted only by the next successful
                room.start (a rejected start -- malformed modeConfig, HTTP
                400 -- promotes nobody)
    default60   room.start without modeConfig -> turnSeconds 60
    scoring     one correct guess = exactly +1 team point, individual
                player scores unchanged, replay does not re-score
    pause       10s turn, pause held longer than the remainder, resume, then
                the autonomous SSE expiry arrives at resume + saved remainder
                (not early, <=1s late) with no incoming request
    autopush    10s turn, zero requests while waiting; the expiry state is
                pushed over SSE <=1s after the deadline
    late        host run with a 600s sweep and no SSE stream so nothing but
                the late request itself can observe the deadline: a correct
                guess (exact word) and an operator taboo.correct sent after
                the deadline are rejected and score nothing
    reset       reused room code: 10s game ended+reset+restarted (60s); the
                old deadline passes with SSE open and must not fire; old
                roundId is stale. close isolation: a closed room's pending
                deadline never fires while a sibling room's does

  production surface (majlis-party-native, --operator-stdin):
    production  operator only over the stdin bridge (production issues no
                network host/display token: POST /api/rooms is 404 and the
                bridge create reply carries no token); 4 players + a late
                spectator (playing) + a second (paused) over HTTP/SSE;
                read-only receipts, resume identity, default 60, scoring,
                exact privacy oracle on every envelope, promotion at the
                next bridge room.start

    python3 -I -B party/native/harness/taboo_lifecycle_sse_timing.py \
        --test-bin BUILD/majlis-party-native-test --prod-bin BUILD/majlis-party-native \
        --evidence DIR [--sections a b ...]

Writes DIR/taboo_lifecycle_sse_timing.json; exit 0 iff every check passed.
"""
import argparse
import json
import os
import queue
import secrets
import select
import subprocess
import sys
import threading
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, HERE)

from taboo_harness_common import FAST, start_native, stop_native, taboo_content_dir  # noqa: E402
from support import Api, SSEClient  # noqa: E402
from taboo_privacy import envelope_leaks, NO_RESOLVED_WORD  # noqa: E402

SECTIONS = ["spectators", "default60", "scoring", "pause", "autopush", "late", "reset", "production"]
NAMES = ["Aisha", "Omar", "Noora", "Khalid"]


class Checks(object):
    def __init__(self):
        self.items = []
        self.section = None
        self.surface = None

    def check(self, name, cond, detail=None):
        self.items.append({"section": self.section, "surface": self.surface, "name": name,
                           "pass": bool(cond), "detail": detail})
        print("%s [%s/%s] %s%s" % ("PASS" if cond else "FAIL", self.surface, self.section, name,
                                   "" if detail is None else "  " + json.dumps(detail, default=str)[:300]), flush=True)
        return bool(cond)


def wait_sse(stream, predicate, until):
    """Return (snapshot, wall_time) of the first state frame matching predicate, or (None, None)."""
    while time.time() < until:
        try:
            item = stream.next(timeout=max(0.01, until - time.time()))
        except AssertionError:
            return None, None
        if item is None:
            return None, None
        if item.get("event") == "state" and predicate(item["json"]):
            return item["json"], time.time()
    return None, None


def expired(snap):
    g = snap.get("game") or {}
    return (g.get("lastResolved") or {}).get("outcome") == "expired"


def setup_room(api, n=4, turn=None, mode="taboo", start=True):
    r = api.create_room(minPlayers=3, maxPlayers=12, operatorName="Host")
    assert r.status == 201, r.text
    room = {"code": r.json["code"], "host": r.json["hostToken"], "display": r.json["displayToken"], "players": []}
    for name in NAMES[:n]:
        j = api.join(room["code"], name)
        assert j.status == 201, j.text
        room["players"].append({"name": name, "id": j.json["playerId"], "token": j.json["playerToken"]})
    a = api.action(room["code"], room["host"], "room.set_mode", payload={"mode": mode})
    assert a.status == 200, a.text
    if start:
        payload = {} if turn is None else {"modeConfig": {"turnSeconds": turn}}
        t0 = time.time()
        s = api.action(room["code"], room["host"], "room.start", payload=payload)
        assert s.status == 200 and s.json["accepted"] is True, s.text
        room["startWall"] = (t0, time.time())
    return room


def op_state(api, room):
    r = api.state(room["code"], room["host"])
    assert r.status == 200, r.text
    return r.json


def sec_spectators(c, test_bin, content):
    proc, port = start_native(test_bin, content)
    streams = []
    try:
        api = Api(port)
        room = setup_room(api, turn=120)
        code, host = room["code"], room["host"]
        g = op_state(api, room)["game"]
        rid = op_state(api, room)["roundId"]
        j = api.join(code, "Layla")
        c.check("late join while playing -> 201 read-only spectator (spectator:true, player id, token)",
                j.status == 201 and j.json.get("spectator") is True and j.json["playerId"].startswith("p"), j.json if j.status != 201 else sorted(j.json))
        s1 = {"id": j.json["playerId"], "token": j.json["playerToken"]}
        snap = api.state(code, s1["token"]).json
        c.check("spectator snapshot: role spectator, no card, listed in spectators, not in players",
                snap["game"]["you"] == {"role": "spectator"} and snap["self"].get("spectator") is True
                and any(x["id"] == s1["id"] for x in snap["spectators"]) and all(p["id"] != s1["id"] for p in snap["players"]),
                {"you": snap["game"]["you"], "self": snap["self"]})
        # Nothing has resolved yet in this game: lastResolved must be null.
        leaks = envelope_leaks("snapshot", snap, ITEMS, "spectator", active=g and op_state(api, room)["game"]["you"]["card"],
                               last_word=NO_RESOLVED_WORD, guess_log=[])
        c.check("exact privacy oracle: spectator snapshot clean", not leaks, leaks)
        st = SSEClient(port, "/api/rooms/%s/events" % code, token=s1["token"])
        streams.append(st)
        first, _ = wait_sse(st, lambda s: True, time.time() + 5)
        c.check("spectator SSE stream opens (200) and pushes a spectator-role state frame",
                st.status == 200 and first is not None and first["game"]["you"] == {"role": "spectator"}, first and first["game"]["you"])
        rev_before = op_state(api, room)["revision"]
        a = api.action(code, s1["token"], "taboo.guess", round_id=rid, payload={"cardEpoch": 0, "text": "hello"})
        c.check("spectator guess -> 403 rejected receipt spectator_read_only, room revision unchanged",
                a.status == 403 and a.json["accepted"] is False and a.json["error"]["code"] == "spectator_read_only"
                and op_state(api, room)["revision"] == rev_before, a.text)
        a2 = api.action(code, s1["token"], "room.start", payload={})
        c.check("spectator operator-control attempt rejected (403)", a2.status == 403 and a2.json["accepted"] is False, a2.text)
        dup = api.join(code, "layla")
        c.check("spectator name reserved: case-folded duplicate join -> 409 name_taken (error envelope)",
                dup.status == 409 and dup.json == {"ok": False, "error": {"code": "name_taken", "message": dup.json["error"]["message"]}}, dup.text)
        p = api.action(code, host, "room.pause")
        c.check("room.pause accepted", p.status == 200 and p.json["accepted"] is True, p.text)
        j2 = api.join(code, "Hamad")
        c.check("late join while PAUSED -> 201 read-only spectator", j2.status == 201 and j2.json.get("spectator") is True, j2.text[:200])
        s2 = {"id": j2.json["playerId"], "token": j2.json["playerToken"]}
        rs = api.join(code, None, token=s1["token"])
        c.check("spectator resume with its token -> 200 resumed, same playerId, spectator:true",
                rs.status == 200 and rs.json.get("resumed") is True and rs.json["playerId"] == s1["id"] and rs.json.get("spectator") is True,
                rs.text[:300])
        rs2 = api.join(code, "Someone Else", token=s2["token"])
        c.check("paused-spectator resume keeps identity (same playerId)", rs2.status == 200 and rs2.json["playerId"] == s2["id"], rs2.text[:200])
        bad = api.action(code, host, "room.resume")
        c.check("room.resume accepted", bad.status == 200, bad.text)
        e = api.action(code, host, "room.end")
        c.check("room.end accepted; spectators still spectators in ended room",
                e.status == 200 and api.state(code, s1["token"]).json["self"].get("spectator") is True, e.text)
        reset = api.action(code, host, "room.reset", payload={"clearScores": False})
        c.check("room.reset accepted (lobby); spectators remain pending until the next start",
                reset.status == 200 and len(op_state(api, room)["spectators"]) == 2, op_state(api, room)["spectators"])
        badstart = api.action(code, host, "room.start", payload={"modeConfig": {"turnSeconds": "ten"}})
        st2 = op_state(api, room)
        c.check("malformed modeConfig -> HTTP 400 rejected start, nobody promoted",
                badstart.status == 400 and badstart.json["accepted"] is False and len(st2["players"]) == 4 and len(st2["spectators"]) == 2,
                {"status": badstart.status, "body": badstart.json, "players": len(st2["players"])})
        unk = api.action(code, host, "room.start", payload={"modeConfig": {"turnSeconds": 30, "extra": 1}})
        c.check("unknown modeConfig key -> 400, nobody promoted", unk.status == 400 and len(op_state(api, room)["players"]) == 4, unk.text)
        ok = api.action(code, host, "room.start", payload={"modeConfig": {"turnSeconds": 30}})
        st3 = op_state(api, room)
        ids = [p["id"] for p in st3["players"]]
        roster = st3["game"]["teams"]["A"] + st3["game"]["teams"]["B"]
        c.check("next valid room.start promotes both spectators into players and team rosters (6 players, spectators empty)",
                ok.status == 200 and s1["id"] in ids and s2["id"] in ids and s1["id"] in roster and s2["id"] in roster
                and st3["spectators"] == [] and len(ids) == 6, {"players": len(ids), "spectators": st3["spectators"]})
        me = api.state(code, s1["token"]).json
        c.check("promoted spectator now has a roster role and no spectator flag",
                me["game"]["you"]["role"] in ("guesser", "clue_giver") and not me["self"].get("spectator"), me["game"]["you"])
        promoted, _ = wait_sse(st, lambda s: s["game"] and s["game"]["you"].get("role") in ("guesser", "clue_giver"), time.time() + 5)
        c.check("promotion pushed on the spectator's existing SSE stream", promoted is not None)
        rg = st3["roundId"]
        mine = st3["game"]
        guesser = s1 if (s1["id"] in mine["teams"][mine["activeTeam"]] and s1["id"] != mine["clueGiverId"]) else None
        if guesser:
            gg = api.action(code, s1["token"], "taboo.guess", round_id=rg, payload={"cardEpoch": mine["cardEpoch"], "text": "nope"})
            c.check("promoted player can act (guess accepted)", gg.status == 200 and gg.json["accepted"] is True, gg.text)
        else:
            gg = api.action(code, s1["token"], "taboo.guess", round_id=rg, payload={"cardEpoch": mine["cardEpoch"], "text": "nope"})
            c.check("promoted player is no longer read-only (rejection, if any, is not spectator_read_only)",
                    gg.json.get("accepted") is True or gg.json["error"]["code"] != "spectator_read_only", gg.text)
    finally:
        for st in streams:
            st.close()
        stop_native(proc)


def sec_default60(c, test_bin, content):
    proc, port = start_native(test_bin, content)
    try:
        api = Api(port)
        room = setup_room(api, turn=None)
        g = op_state(api, room)["game"]
        c.check("room.start without modeConfig: turnSeconds == 60 and 59000 < remainingMs <= 60000",
                g["turnSeconds"] == 60 and 59000 < g["remainingMs"] <= 60000, {"turnSeconds": g["turnSeconds"], "remainingMs": g["remainingMs"]})
    finally:
        stop_native(proc)


def sec_scoring(c, test_bin, content):
    proc, port = start_native(test_bin, content)
    try:
        api = Api(port)
        room = setup_room(api, turn=120)
        code, host = room["code"], room["host"]
        st = op_state(api, room)
        g = st["game"]
        team = g["activeTeam"]
        guesser = next(p for p in room["players"] if p["id"] in g["teams"][team] and p["id"] != g["clueGiverId"])
        word = g["you"]["card"]["word"]
        aid = secrets.token_hex(8)
        r = api.action(code, guesser["token"], "taboo.guess", round_id=st["roundId"], action_id=aid,
                       payload={"cardEpoch": g["cardEpoch"], "text": "  " + word.upper() + " "})
        after = op_state(api, room)
        c.check("correct (normalized) guess accepted: active team +1 exactly, other team 0",
                r.status == 200 and after["game"]["teamScores"][team] == 1 and after["game"]["teamScores"]["B" if team == "A" else "A"] == 0,
                after["game"]["teamScores"])
        c.check("individual player scores unchanged (all 0) by a team point",
                all(p["score"] == 0 for p in after["players"]), [p["score"] for p in after["players"]])
        rep = api.action(code, guesser["token"], "taboo.guess", round_id=st["roundId"], action_id=aid,
                         payload={"cardEpoch": g["cardEpoch"], "text": "  " + word.upper() + " "})
        again = op_state(api, room)
        c.check("replayed actionId returns the same receipt and does not re-score",
                rep.json == r.json and again["game"]["teamScores"][team] == 1 and again["revision"] == after["revision"], again["game"]["teamScores"])
        cr = api.action(code, host, "taboo.correct", round_id=st["roundId"], payload={"cardEpoch": after["game"]["cardEpoch"]})
        fin = op_state(api, room)
        c.check("operator taboo.correct: active team exactly +1 more (2 total)",
                cr.status == 200 and fin["game"]["teamScores"][team] == 2, fin["game"]["teamScores"])
        unk = api.action(code, host, "taboo.correct", round_id=st["roundId"], payload={"cardEpoch": fin["game"]["cardEpoch"], "x": 1})
        c.check("unknown key on taboo.correct rejected, no score change",
                unk.status == 400 and unk.json["accepted"] is False and op_state(api, room)["game"]["teamScores"][team] == 2, unk.text)
    finally:
        stop_native(proc)


def sec_pause(c, test_bin, content):
    proc, port = start_native(test_bin, content)
    stream = None
    try:
        api = Api(port)
        room = setup_room(api, turn=10)
        code, host = room["code"], room["host"]
        stream = SSEClient(port, "/api/rooms/%s/events" % code, token=room["display"])
        time.sleep(4.0)
        p = api.action(code, host, "room.pause")
        paused = op_state(api, room)
        saved = paused["game"]["remainingMs"]
        c.check("paused with a saved remainder of ~6s", p.status == 200 and paused["phase"] == "paused" and 4500 < saved < 6600, saved)
        time.sleep(saved / 1000.0 + 2.5)
        held = op_state(api, room)
        c.check("pause held LONGER than the remainder: still paused, clue_turn, remainingMs frozen exactly, no expiry",
                held["phase"] == "paused" and held["game"]["roundPhase"] == "clue_turn" and held["game"]["remainingMs"] == saved
                and not expired(held), {"remainingMs": held["game"]["remainingMs"], "saved": saved, "roundPhase": held["game"]["roundPhase"]})
        # drain frames so far
        while True:
            try:
                item = stream.next(timeout=0.2)
            except AssertionError:
                break
            if item is None:
                break
            if item.get("event") == "state" and expired(item["json"]):
                c.check("no expiry frame pushed during pause", False, item["json"]["revision"])
        t0 = time.time()
        r = api.action(code, host, "room.resume")
        t1 = time.time()
        resumed = op_state(api, room)
        c.check("resume: remainingMs restarts from the saved remainder (within 300ms)",
                r.status == 200 and saved - 300 <= resumed["game"]["remainingMs"] <= saved, {"remainingMs": resumed["game"]["remainingMs"], "saved": saved})
        snap, seen = wait_sse(stream, expired, t1 + saved / 1000.0 + 3.0)
        early = None if seen is None else seen - (t1 + saved / 1000.0)
        late = None if seen is None else seen - (t0 + saved / 1000.0)
        c.check("autonomous SSE expiry after resume arrives at resume + saved remainder: not early (>= -0.05s) and <= 1.0s late",
                seen is not None and early >= -0.05 and late <= 1.0,
                {"notEarlyMargin_s": early, "latencyUpperBound_s": late, "saved_ms": saved})
    finally:
        if stream:
            stream.close()
        stop_native(proc)


def sec_autopush(c, test_bin, content):
    proc, port = start_native(test_bin, content)
    stream = None
    try:
        api = Api(port)
        r = api.create_room(minPlayers=3, maxPlayers=12)
        code, host = r.json["code"], r.json["hostToken"]
        for name in NAMES:
            api.join(code, name)
        stream = SSEClient(port, "/api/rooms/%s/events" % code, token=r.json["displayToken"])
        api.action(code, host, "room.set_mode", payload={"mode": "taboo"})
        t0 = time.time()
        s = api.action(code, host, "room.start", payload={"modeConfig": {"turnSeconds": 10}})
        t1 = time.time()
        c.check("room.start with turnSeconds 10 accepted", s.status == 200, s.text)
        # NO request of any kind from here until the expiry frame arrives.
        snap, seen = wait_sse(stream, expired, t1 + 13.0)
        c.check("expiry state pushed over SSE with zero incoming requests, <= 1.0s after the 10s deadline (not early)",
                seen is not None and seen - (t1 + 10.0) >= -0.05 and seen - (t0 + 10.0) <= 1.0,
                {"latencyUpperBound_s": None if seen is None else seen - (t0 + 10.0),
                 "notEarlyMargin_s": None if seen is None else seen - (t1 + 10.0)})
        if snap:
            g = snap["game"]
            c.check("pushed frame: turn_complete, remainingMs 0, outcome expired, no award",
                    g["roundPhase"] == "turn_complete" and g["remainingMs"] == 0 and g["lastResolved"]["teamAward"] is None,
                    {"roundPhase": g["roundPhase"], "lastResolved": {k: v for k, v in g["lastResolved"].items() if k != "word"}})
    finally:
        if stream:
            stream.close()
        stop_native(proc)


def _no_sweep_args():
    out, skip = [], False
    for i, a in enumerate(FAST):
        if skip:
            skip = False
            continue
        if a == "--sweep-interval":
            skip = True
            continue
        out.append(a)
    return out + ["--sweep-interval", "600"]


def sec_late(c, test_bin, content):
    proc, port = start_native(test_bin, content, extra=_no_sweep_args(), fast=False)
    try:
        api = Api(port)
        room = setup_room(api, turn=10)
        code, host = room["code"], room["host"]
        t0 = room["startWall"][0]
        st = op_state(api, room)
        g = st["game"]
        team = g["activeTeam"]
        guesser = next(p for p in room["players"] if p["id"] in g["teams"][team] and p["id"] != g["clueGiverId"])
        word = g["you"]["card"]["word"]
        # Nothing observes the room until after the deadline (no stream, sweep 600s).
        time.sleep(max(0.0, t0 + 10.0 + 0.6 - time.time()))
        r = api.action(code, guesser["token"], "taboo.guess", round_id=st["roundId"], payload={"cardEpoch": g["cardEpoch"], "text": word})
        c.check("exact correct guess sent 0.6s AFTER the deadline (first request since) -> rejected 409",
                r.status == 409 and r.json["accepted"] is False and r.json["error"]["code"] in ("invalid_phase", "stale_card"), r.text)
        o = api.action(code, host, "taboo.correct", round_id=st["roundId"], payload={"cardEpoch": g["cardEpoch"]})
        c.check("operator taboo.correct after the deadline -> rejected 409", o.status == 409 and o.json["accepted"] is False, o.text)
        after = op_state(api, room)
        c.check("no score from late answers: teamScores 0/0, turn expired with no award",
                after["game"]["teamScores"] == {"A": 0, "B": 0} and expired(after) and after["game"]["lastResolved"]["teamAward"] is None,
                {"teamScores": after["game"]["teamScores"], "lastResolved": after["game"]["lastResolved"] and after["game"]["lastResolved"]["outcome"]})
    finally:
        stop_native(proc)


def sec_reset(c, test_bin, content):
    proc, port = start_native(test_bin, content)
    streams = []
    try:
        api = Api(port)
        room = setup_room(api, turn=10)
        code, host = room["code"], room["host"]
        sib = setup_room(api, turn=10)
        closing = setup_room(api, turn=10)
        old_rid = op_state(api, room)["roundId"]
        t_old = room["startWall"][1] + 10.0
        st = SSEClient(port, "/api/rooms/%s/events" % code, token=room["display"])
        st_sib = SSEClient(port, "/api/rooms/%s/events" % sib["code"], token=sib["display"])
        st_close = SSEClient(port, "/api/rooms/%s/events" % closing["code"], token=closing["display"])
        streams += [st, st_sib, st_close]
        time.sleep(1.5)
        e = api.action(code, host, "room.end")
        rs = api.action(code, host, "room.reset", payload={"clearScores": True})
        s2 = api.action(code, host, "room.start", payload={"modeConfig": {"turnSeconds": 60}})
        new = op_state(api, room)
        c.check("same room code: end + reset + start (60s) accepted, fresh game 2 turn 1",
                e.status == rs.status == s2.status == 200 and new["game"]["gameNo"] == 2 and new["game"]["turnNo"] == 1,
                {"gameNo": new["game"]["gameNo"], "roundId": new["roundId"]})
        cl = api.action(closing["code"], closing["host"], "room.close")
        c.check("sibling room closed while its 10s deadline is pending", cl.status == 200, cl.text)
        # Wait past the old deadline (+1.5s) observing SSE only.
        until = max(t_old, sib["startWall"][1] + 10.0, closing["startWall"][1] + 10.0) + 1.5
        bad, _ = wait_sse(st, expired, until)
        c.check("old game's deadline passed with SSE open: no expiry frame in the reused room code", bad is None,
                bad and bad["revision"])
        sib_snap, sib_seen = wait_sse(st_sib, expired, until + 0.1)
        c.check("control: the untouched sibling room DID expire autonomously in the same window",
                sib_snap is not None, sib_seen)
        cframes = []
        drain_until = time.time() + 0.5
        while time.time() < drain_until:
            try:
                item = st_close.next(timeout=max(0.01, drain_until - time.time()))
            except AssertionError:
                break
            if item is None:
                break
            if item.get("event") == "state":
                cframes.append(item["json"])
        c.check("closed room: no expiry frame after its old deadline (game null in every frame after close)",
                all(f["phase"] == "closed" and f["game"] is None for f in cframes if f["phase"] == "closed")
                and not any(expired(f) for f in cframes), [(f["revision"], f["phase"]) for f in cframes][-4:])
        now = op_state(api, room)
        g = now["game"]
        c.check("reused code's new game still clue_turn, no lastResolved, remainingMs consistent with its own 60s clock",
                g["roundPhase"] == "clue_turn" and g["lastResolved"] is None and 45000 < g["remainingMs"] <= 60000,
                {"roundPhase": g["roundPhase"], "remainingMs": g["remainingMs"]})
        stale = api.action(code, host, "taboo.correct", round_id=old_rid, payload={"cardEpoch": 0})
        c.check("previous game's roundId against the reused code -> 409 stale_round",
                stale.status == 409 and stale.json["error"]["code"] == "stale_round", stale.text)
        after_close = api.action(closing["code"], closing["host"], "room.pause")
        c.check("closed room is terminal: actions rejected (room_closed, or room_not_found once purged)",
                after_close.status in (404, 409) and after_close.json["error"]["code"] in ("room_closed", "room_not_found"),
                after_close.text)
    finally:
        for s in streams:
            s.close()
        stop_native(proc)


class Bridge(object):
    def __init__(self, proc, log_path):
        self.proc = proc
        self.q = queue.Queue()
        self.log = open(log_path, "w")
        self.thread = threading.Thread(target=self._pump, daemon=True)
        self.thread.start()

    def _pump(self):
        try:
            for ln in self.proc.stdout:
                self.q.put(ln.decode("utf-8"))
        except (ValueError, OSError):
            pass
        self.q.put(None)

    def line(self, timeout=10):
        ln = self.q.get(timeout=timeout)
        if ln is None:
            raise RuntimeError("bridge closed")
        return json.loads(ln)

    def call(self, req):
        self.proc.stdin.write(json.dumps(req).encode() + b"\n")
        self.proc.stdin.flush()
        rep = self.line()
        self.log.write(json.dumps({"req": req, "reply": rep}) + "\n")
        self.log.flush()
        return rep

    def act(self, code, kind, payload=None, round_id=None):
        body = {"actionId": secrets.token_hex(8), "type": kind, "payload": payload or {}}
        if round_id is not None:
            body["roundId"] = round_id
        return self.call({"op": "action", "code": code, "body": body})

    def state(self, code):
        return self.call({"op": "state", "code": code})["state"]

    def close(self):
        self.log.close()


def sec_production(c, prod_bin, content, evid):
    c.surface = "production-operator-stdin"
    cmd = [prod_bin, "--host", "127.0.0.1", "--port", "0", "--content-dir", content, "--operator-stdin", "--exit-on-stdin-eof"] + FAST
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    bridge = Bridge(proc, os.path.join(evid, "production-operator-bridge.jsonl"))
    streams = []
    envelopes = []
    ACTIVE = [None]  # active card (operator view) at the time each envelope was captured
    LAST = [None]    # exact resolved word at that time (None = nothing resolved yet -> lastResolved must be null)
    try:
        banner = bridge.line(timeout=15)
        c.check("production banner (surface production)", banner.get("surface") == "production", banner)
        port = banner["port"]
        api = Api(port)
        net = api.request("POST", "/api/rooms", body={})
        c.check("production issues no network host/display token: POST /api/rooms -> 404 not_found",
                net.status == 404 and net.json["error"]["code"] == "not_found", net.text)
        cr = bridge.call({"op": "create", "body": {"minPlayers": 3, "maxPlayers": 12, "operatorName": "Host"}})
        c.check("bridge create reply is {ok,op,code,revision} only (no token of any kind)",
                cr["ok"] is True and sorted(cr) == ["code", "ok", "op", "revision"], sorted(cr))
        code = cr["code"]
        players = []
        for name in NAMES:
            j = api.join(code, name)
            envelopes.append(("join", j.json, "teammate", ACTIVE[0], LAST[0]))
            players.append({"name": name, "id": j.json["playerId"], "token": j.json["playerToken"]})
        c.check("4 players joined over production HTTP (4 distinct credentials)",
                len(set(p["token"] for p in players)) == 4, [p["id"] for p in players])
        r = bridge.act(code, "room.set_mode", {"mode": "taboo"})
        r2 = bridge.act(code, "room.start", {})
        st = bridge.state(code)
        g = st["game"]
        c.check("bridge set_mode taboo + start (no modeConfig) accepted; default turnSeconds 60",
                r["status"] == 200 and r2["status"] == 200 and g["turnSeconds"] == 60 and 58000 < g["remainingMs"] <= 60000,
                {"turnSeconds": g["turnSeconds"], "remainingMs": g["remainingMs"]})
        active = g["you"]["card"]
        ACTIVE[0] = active
        sp = api.join(code, "Layla")
        envelopes.append(("join", sp.json, "spectator", ACTIVE[0], LAST[0]))
        c.check("production late join while playing -> 201 spectator:true", sp.status == 201 and sp.json.get("spectator") is True, sp.text[:200])
        s1 = {"id": sp.json["playerId"], "token": sp.json["playerToken"]}
        sst = SSEClient(port, "/api/rooms/%s/events" % code, token=s1["token"])
        streams.append(sst)
        f, _ = wait_sse(sst, lambda s: True, time.time() + 5)
        c.check("production spectator SSE frame: role spectator", f is not None and f["game"]["you"] == {"role": "spectator"}, f and f["game"]["you"])
        if f:
            envelopes.append(("snapshot", f, "spectator", ACTIVE[0], LAST[0]))
        rej = api.action(code, s1["token"], "taboo.guess", round_id=st["roundId"], payload={"cardEpoch": g["cardEpoch"], "text": active["word"]})
        envelopes.append(("receipt", rej.json, "spectator", ACTIVE[0], LAST[0]))
        c.check("production spectator guess (even the right word) -> 403 spectator_read_only, no score",
                rej.status == 403 and rej.json["error"]["code"] == "spectator_read_only" and bridge.state(code)["game"]["teamScores"] == {"A": 0, "B": 0},
                rej.text)
        forb = api.action(code, players[0]["token"], "room.pause")
        c.check("production player bearer refused for operator control (403)", forb.status == 403, forb.text)
        roles = {}
        for p in players:
            snap = api.state(code, p["token"]).json
            role = "clue_giver" if p["id"] == g["clueGiverId"] else ("teammate" if p["id"] in g["teams"][g["activeTeam"]] else "opponent")
            roles[p["id"]] = role
            envelopes.append(("snapshot", snap, role, ACTIVE[0], LAST[0]))
        envelopes.append(("snapshot", st, "operator", ACTIVE[0], LAST[0]))
        envelopes.append(("snapshot", api.state(code, s1["token"]).json, "spectator", ACTIVE[0], LAST[0]))
        guesser = next(p for p in players if roles[p["id"]] == "teammate")
        gg = api.action(code, guesser["token"], "taboo.guess", round_id=st["roundId"],
                        payload={"cardEpoch": g["cardEpoch"], "text": "  " + active["word"].lower() + "  "})
        envelopes.append(("receipt", gg.json, "teammate", ACTIVE[0], LAST[0]))
        if gg.status == 200 and gg.json.get("accepted") is True:
            LAST[0] = active["word"]
        st2 = bridge.state(code)
        ACTIVE[0] = st2["game"]["you"]["card"]
        c.check("production guesser correct (normalized) -> +1 active team, individual scores 0",
                gg.status == 200 and st2["game"]["teamScores"][g["activeTeam"]] == 1 and all(p["score"] == 0 for p in st2["players"]),
                st2["game"]["teamScores"])
        bc = bridge.act(code, "taboo.correct", {"cardEpoch": st2["game"]["cardEpoch"]}, st2["roundId"])
        if bc.get("status") == 200:
            LAST[0] = st2["game"]["you"]["card"]["word"]
        c.check("production bridge taboo.correct -> +1 (2 total)", bc["status"] == 200 and bridge.state(code)["game"]["teamScores"][g["activeTeam"]] == 2,
                bc.get("status"))
        pz = bridge.act(code, "room.pause")
        sp2 = api.join(code, "Hamad")
        envelopes.append(("join", sp2.json, "spectator", ACTIVE[0], LAST[0]))
        c.check("production late join while PAUSED -> 201 spectator:true", pz["status"] == 200 and sp2.status == 201 and sp2.json.get("spectator") is True,
                sp2.text[:200])
        s2 = {"id": sp2.json["playerId"], "token": sp2.json["playerToken"]}
        res = api.join(code, None, token=s1["token"])
        envelopes.append(("join", res.json, "spectator", ACTIVE[0], LAST[0]))
        c.check("production spectator resume: 200 resumed, same id, spectator:true",
                res.status == 200 and res.json.get("resumed") is True and res.json["playerId"] == s1["id"] and res.json.get("spectator") is True, res.text[:200])
        cur = bridge.state(code)
        ACTIVE[0] = cur["game"]["you"]["card"]
        for p in players:
            envelopes.append(("snapshot", api.state(code, p["token"]).json, roles[p["id"]], ACTIVE[0], LAST[0]))
        envelopes.append(("snapshot", api.state(code, s2["token"]).json, "spectator", ACTIVE[0], LAST[0]))
        leaks = []
        for kind, payload, viewer, act, last in envelopes:
            # Exact historical resolved word; no guess text was stored at any
            # captured revision (only correct guesses, which clear the list).
            extra = {"guess_log": []} if kind == "snapshot" else {}
            for path, reason in envelope_leaks(kind, payload, ITEMS, viewer, active=act, last_word=last, **extra):
                leaks.append([kind, viewer, list(path), reason])
        c.check("exact privacy oracle over %d production envelopes (join/resume/receipt/snapshot/SSE): zero leaks" % len(envelopes),
                not leaks, leaks[:6])
        bridge.act(code, "room.resume")
        bridge.act(code, "room.end")
        ns = bridge.act(code, "room.start", {"modeConfig": {"turnSeconds": 10}})
        fin = bridge.state(code)
        ids = [p["id"] for p in fin["players"]]
        c.check("production next bridge room.start promotes both spectators (6 players, spectators empty)",
                ns["status"] == 200 and s1["id"] in ids and s2["id"] in ids and fin["spectators"] == [] and len(ids) == 6,
                {"players": len(ids), "spectators": fin["spectators"]})
        t_start = time.time()
        promoted, _ = wait_sse(sst, lambda s: s["game"] and s["game"]["you"].get("role") in ("guesser", "clue_giver"), time.time() + 5)
        c.check("production promotion pushed on the spectator's SSE stream", promoted is not None)
        exp, seen = wait_sse(sst, expired, t_start + 13.0)
        c.check("production autonomous 10s expiry pushed over SSE (no request) <= ~1s after deadline",
                exp is not None and seen - t_start <= 11.2, None if seen is None else seen - t_start)
    finally:
        for s in streams:
            s.close()
        rc = stop_native(proc)
        bridge.close()
        c.check("production host exited on stdin EOF (exit code recorded)", rc is not None, rc)
        c.surface = "test-loopback"


ITEMS = None


def main():
    global ITEMS
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-bin", required=True)
    ap.add_argument("--prod-bin")
    ap.add_argument("--evidence", required=True)
    ap.add_argument("--sections", nargs="*", default=SECTIONS)
    ap.add_argument("--scratch")
    args = ap.parse_args()
    evid = os.path.abspath(args.evidence)
    os.makedirs(evid, exist_ok=True)
    with open(os.path.join(ROOT, "party", "content", "taboo.json"), encoding="utf-8") as handle:
        ITEMS = json.load(handle)["items"]
    content = taboo_content_dir(ROOT, os.path.abspath(args.scratch or evid))
    c = Checks()
    c.surface = "test-loopback"
    errors = []
    for name in args.sections:
        c.section = name
        t = time.time()
        try:
            if name == "production":
                if not args.prod_bin:
                    raise RuntimeError("--prod-bin required")
                sec_production(c, os.path.abspath(args.prod_bin), content, evid)
            else:
                globals()["sec_" + name](c, os.path.abspath(args.test_bin), content)
        except Exception:
            tb = traceback.format_exc()
            errors.append({"section": name, "traceback": tb})
            c.check("section completed without exception", False, tb.strip().splitlines()[-1])
        print("section %s done in %.1fs" % (name, time.time() - t), flush=True)
    passed = sum(1 for i in c.items if i["pass"])
    with open(os.path.join(evid, "taboo_lifecycle_sse_timing.json"), "w") as handle:
        json.dump({"testBin": args.test_bin, "prodBin": args.prod_bin, "sections": args.sections,
                   "checks": c.items, "errors": errors, "passed": passed, "total": len(c.items)}, handle, indent=1, default=str)
    print("%d/%d checks passed" % (passed, len(c.items)))
    return 0 if c.items and passed == len(c.items) else 1


if __name__ == "__main__":
    sys.exit(main())
