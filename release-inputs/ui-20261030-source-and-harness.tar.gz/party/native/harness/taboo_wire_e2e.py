"""Real compiled native host, over real raw-socket HTTP + SSE, driving a full
Taboo (Forbidden Words) game with >=4 real player credentials, an operator
and a display client -- using the exact Api/SSEClient/ServerProcess classes
tests/test_http_*.py already use, swapped onto the native test binary via the
same NativePopen technique as reference_wire.py (this file duplicates that
small swap rather than importing it, to stay independent of the first-pair
harness). Content dir is a private copy (who_am_i/feud/impostor/taboo fixtures)
so the shared tests/fixtures/content/ directory is never touched.

    python3 -I -B party/native/harness/taboo_wire_e2e.py NATIVE_BIN CONTENT_DIR EVIDENCE_DIR

Exit 0 iff every check passes.
"""
import json
import os
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
sys.path.insert(0, os.path.join(ROOT, "tests"))
sys.path.insert(0, ROOT)


def main():
    native_bin = os.path.abspath(sys.argv[1])
    content_dir = os.path.abspath(sys.argv[2])
    out = os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)

    original_popen = subprocess.Popen

    class NativePopen(original_popen):
        def __init__(self, args, *rest, **kwargs):
            if isinstance(args, (list, tuple)) and len(args) >= 3 and list(args[1:3]) == ["-m", "party.server"]:
                args = [native_bin] + list(args[3:])
            elif isinstance(args, (list, tuple)) and "party.server" in args:
                raise AssertionError("reference server launched outside the native swap")
            original_popen.__init__(self, args, *rest, **kwargs)

    subprocess.Popen = NativePopen

    from support import Api, ServerProcess, SSEClient  # noqa: E402

    checks = []

    def check(name, cond, detail=None):
        checks.append({"name": name, "pass": bool(cond), "detail": detail})
        print(("PASS " if cond else "FAIL ") + name + ("" if detail is None else "  " + json.dumps(detail, default=str)[:300]))

    transcript = open(os.path.join(out, "transcript.jsonl"), "w")

    def record(label, resp):
        transcript.write(json.dumps({"label": label, "status": resp.status, "json": resp.json}, default=str) + "\n")
        transcript.flush()
        return resp

    # ---------------------------------------------------------------- 60s-default run
    server = ServerProcess((), content_dir, fast=True).start()
    api = Api(server.port)
    try:
        created = record("create_room", api.create_room(minPlayers=4, maxPlayers=12))
        check("create_room 201", created.status == 201, created.text)
        code, host_token, display_token = created.json["code"], created.json["hostToken"], created.json["displayToken"]

        players = []
        for i in range(4):
            j = record("join_%d" % i, api.join(code, "Player%d" % i))
            check("join_%d 201" % i, j.status == 201, j.text)
            players.append({"id": j.json["playerId"], "token": j.json["playerToken"]})

        sm = record("set_mode_taboo", api.action(code, host_token, "room.set_mode", payload={"mode": "taboo"}))
        check("set_mode_taboo accepted", sm.status == 200 and sm.json.get("accepted") is True, sm.text)

        start = record("room_start_default_turn", api.action(code, host_token, "room.start"))
        check("room_start accepted", start.status == 200, start.text)

        op_state = api.state(code, host_token).json
        check("default turnSeconds is 60", op_state["game"]["turnSeconds"] == 60, op_state["game"].get("turnSeconds"))
        check("default remainingMs ~60000ms at turn start (within HTTP round-trip tolerance)",
              59900 <= op_state["game"]["remainingMs"] <= 60000, op_state["game"].get("remainingMs"))

        giver_id = op_state["game"]["clueGiverId"]
        check("operator sees active card (60s game)", "card" in op_state["game"]["you"] and op_state["game"]["you"]["card"] is not None)

        guesser = next(p for p in players if p["id"] != giver_id and
                        (p["id"] in op_state["game"]["teams"]["A"] or p["id"] in op_state["game"]["teams"]["B"]))
        guesser_state = api.state(code, guesser["token"]).json
        check("guesser view has no card field", "card" not in guesser_state["game"]["you"], guesser_state["game"]["you"])

        end1 = record("end_60s_game", api.action(code, host_token, "room.end", round_id=op_state["roundId"]))
        check("room.end accepted (cleanup 60s game)", end1.status == 200, end1.text)
    finally:
        server.stop()
        if server.proc.poll() is None:
            raise AssertionError("60s-default server still running after stop()")

    # ---------------------------------------------------------------- main 10s-configured run
    server = ServerProcess((), content_dir, fast=True).start()
    api = Api(server.port)
    try:
        created = record("create_room_main", api.create_room(minPlayers=4, maxPlayers=12))
        code, host_token, display_token = created.json["code"], created.json["hostToken"], created.json["displayToken"]

        players = []
        for i in range(4):
            j = record("join_main_%d" % i, api.join(code, "P%d" % i))
            players.append({"id": j.json["playerId"], "token": j.json["playerToken"]})

        display_stream = SSEClient(server.port, "/api/rooms/%s/events" % code, token=display_token)
        check("display SSE connected", display_stream.status == 200, display_stream.status)

        api.action(code, host_token, "room.set_mode", payload={"mode": "taboo"})
        start = api.action(code, host_token, "room.start", payload={"modeConfig": {"turnSeconds": 10}})
        check("room.start (10s config) accepted", start.status == 200, start.text)

        op_state = api.state(code, host_token).json
        check("configured turnSeconds is 10", op_state["game"]["turnSeconds"] == 10)
        giver_id = op_state["game"]["clueGiverId"]
        active_team = op_state["game"]["activeTeam"]
        teammates = op_state["game"]["teams"][active_team]
        opponents = op_state["game"]["teams"]["B" if active_team == "A" else "A"]
        guesser = next(p for p in players if p["id"] in teammates and p["id"] != giver_id)
        giver = next(p for p in players if p["id"] == giver_id)
        opponent = next(p for p in players if p["id"] in opponents)
        round_id = op_state["roundId"]

        # role projections over the wire
        giver_state = api.state(code, giver["token"]).json
        check("clue_giver sees word+forbidden over HTTP", giver_state["game"]["you"]["role"] == "clue_giver" and
              giver_state["game"]["you"]["card"]["word"] and giver_state["game"]["you"]["card"]["forbidden"])
        guesser_state = api.state(code, guesser["token"]).json
        check("guesser gets no card over HTTP", "card" not in guesser_state["game"]["you"])
        opp_state = api.state(code, opponent["token"]).json
        check("opponent (other team) gets no card over HTTP", "card" not in opp_state["game"]["you"])
        display_state = api.state(code, display_token).json
        check("display gets no you/card over HTTP", "you" not in display_state["game"] or display_state["game"].get("you") is None)

        # opponent guess forbidden
        bad = api.action(code, opponent["token"], "taboo.guess", round_id=round_id,
                          payload={"text": "nonsense", "cardEpoch": giver_state["game"]["cardEpoch"]})
        check("opponent guess rejected forbidden", bad.status == 403 and bad.json["error"]["code"] == "forbidden", bad.text)

        # correct guess -> operator correct -> score, epoch, privacy of forbidden word throughout
        correct_word = giver_state["game"]["you"]["card"]["word"]
        forbidden_terms = set(giver_state["game"]["you"]["card"]["forbidden"])
        guess = api.action(code, guesser["token"], "taboo.guess", round_id=round_id,
                            payload={"text": correct_word, "cardEpoch": giver_state["game"]["cardEpoch"]})
        check("correct guess accepted over HTTP", guess.status == 200 and guess.json.get("accepted") is True, guess.text)
        after = api.state(code, host_token).json
        check("team scored after correct guess", after["game"]["teamScores"][active_team] == 1, after["game"]["teamScores"])
        check("lastResolved word visible after resolution", after["game"]["lastResolved"]["word"] == correct_word)

        # stale epoch replay rejected, zero mutation
        stale = api.action(code, guesser["token"], "taboo.guess", round_id=round_id,
                            payload={"text": "whatever", "cardEpoch": giver_state["game"]["cardEpoch"]})
        check("stale cardEpoch rejected over HTTP", stale.status == 409 and stale.json["error"]["code"] == "stale_card", stale.text)
        after2 = api.state(code, host_token).json

        def strip_clock(game):
            g = dict(game)
            g.pop("remainingMs", None)  # the only field that legitimately changes with real wall-clock time
            return g

        check("state (excluding the real-time remainingMs clock) byte-identical after rejected stale action",
              json.dumps(strip_clock(after2["game"]), sort_keys=True) == json.dumps(strip_clock(after["game"]), sort_keys=True))
        check("revision not bumped by rejected stale action", after2["revision"] == after["revision"], (after2["revision"], after["revision"]))

        # race: stale operator adjudication on an epoch already resolved by the player guess above
        race = api.action(code, host_token, "taboo.correct", round_id=round_id,
                           payload={"cardEpoch": giver_state["game"]["cardEpoch"]})
        check("stale operator adjudication rejected (no double-score)", race.status == 409 and race.json["error"]["code"] == "stale_card", race.text)

        # actionId replay protection: resubmit the exact same accepted action body
        replay_body = {"actionId": "fixed-replay-1", "type": "taboo.skip", "payload": {"cardEpoch": after["game"]["cardEpoch"]}, "roundId": round_id}
        r1 = api.request("POST", "/api/rooms/%s/actions" % code, body=replay_body, token=host_token)
        r2 = api.request("POST", "/api/rooms/%s/actions" % code, body=replay_body, token=host_token)
        check("first skip (replay body) accepted", r1.status == 200, r1.text)
        check("exact actionId replay does not re-apply", r2.json == r1.json, (r1.json, r2.json))

        after_skip = api.state(code, host_token).json
        check("skip zero award", after_skip["game"]["teamScores"][active_team] == 1 and after_skip["game"]["teamScores"][("B" if active_team == "A" else "A")] == 0)

        # violation awards opposing team
        viol = api.action(code, host_token, "taboo.violation", round_id=round_id, payload={"cardEpoch": after_skip["game"]["cardEpoch"]})
        check("violation accepted", viol.status == 200, viol.text)
        after_viol = api.state(code, host_token).json
        opp_team = "B" if active_team == "A" else "A"
        check("violation awarded opposing team", after_viol["game"]["teamScores"][opp_team] == 1, after_viol["game"]["teamScores"])

        # pass_turn -> turn_complete -> round.next (stale round rejection + reconnect)
        passt = api.action(code, host_token, "taboo.pass_turn", round_id=round_id, payload={"cardEpoch": after_viol["game"]["cardEpoch"]})
        check("pass_turn accepted", passt.status == 200, passt.text)
        tc = api.state(code, host_token).json
        check("phase turn_complete after pass", tc["game"]["roundPhase"] == "turn_complete")

        stale_round_try = api.action(code, host_token, "taboo.skip", round_id="not-the-current-round-id", payload={"cardEpoch": tc["game"]["cardEpoch"]})
        check("wrong/stale roundId rejected", stale_round_try.status == 409 and stale_round_try.json["error"]["code"] == "stale_round", stale_round_try.text)

        rn = api.action(code, host_token, "round.next", round_id=round_id)
        check("round.next accepted", rn.status == 200, rn.text)
        flipped = api.state(code, host_token).json
        check("team flipped after round.next", flipped["game"]["activeTeam"] != active_team)
        new_round_id = flipped["roundId"]
        new_giver = flipped["game"]["clueGiverId"]

        # former clue-giver loses visibility the instant the turn changes
        former_giver_state = api.state(code, giver["token"]).json
        check("former clue_giver no longer sees card after turn change",
              former_giver_state["game"]["you"]["role"] != "clue_giver" or giver["id"] == new_giver)
        if giver["id"] != new_giver:
            check("former clue_giver view has no card field", "card" not in former_giver_state["game"]["you"], former_giver_state["game"]["you"])

        # reconnect: re-authenticate with same token mid-game, must see identical authorized view (no turn reassignment)
        reconnect_state = api.state(code, guesser["token"]).json
        check("reconnect mid-game preserves identity/role (no turn reassigned)",
              reconnect_state["game"]["clueGiverId"] == flipped["game"]["clueGiverId"])

        # pause freezes remaining; resume consumes only remainder
        pause = api.action(code, host_token, "room.pause", round_id=new_round_id)
        check("pause accepted", pause.status == 200, pause.text)
        paused_now = api.state(code, host_token).json
        remaining_at_pause = paused_now["game"]["remainingMs"]
        time.sleep(1.5)
        paused_later = api.state(code, host_token).json
        check("remainingMs frozen across real wall-clock wait while paused",
              paused_later["game"]["remainingMs"] == remaining_at_pause, (remaining_at_pause, paused_later["game"]["remainingMs"]))
        check("no expiry fires while paused", paused_later["game"]["roundPhase"] == "clue_turn")

        resume = api.action(code, host_token, "room.resume", round_id=new_round_id)
        check("resume accepted", resume.status == 200, resume.text)
        resumed = api.state(code, host_token).json
        check("resume consumes only remainder (not elapsed pause wall time)",
              abs(resumed["game"]["remainingMs"] - remaining_at_pause) < 500, (resumed["game"]["remainingMs"], remaining_at_pause))

        # autonomous expiry over real SSE with ZERO player requests during the wait
        pre_expiry_revision = api.state(code, host_token).json
        deadline_wait = pre_expiry_revision["game"]["remainingMs"] / 1000.0 + 1.0
        got_expiry = None
        deadline_t = time.time() + deadline_wait + 2.0
        while time.time() < deadline_t:
            item = display_stream.next(timeout=2.0)
            if item is None:
                break
            if item.get("event") == "state" and item.get("json"):
                st = item["json"].get("state") or item["json"]
                g = st.get("game") if isinstance(st, dict) else None
                if g and g.get("lastResolved") and g["lastResolved"].get("outcome") == "expired":
                    got_expiry = g
                    break
        check("autonomous expiry pushed over real SSE with zero player requests", got_expiry is not None, got_expiry)

        shutdown_ok = True
    finally:
        display_stream.close()
        server.stop()
        if server.proc.poll() is None:
            shutdown_ok = False
            raise AssertionError("main server still running after stop()")
    check("clean server shutdown", shutdown_ok)

    transcript.close()
    with open(os.path.join(out, "results.json"), "w") as f:
        json.dump(checks, f, indent=2)
    n_fail = sum(1 for c in checks if not c["pass"])
    print("TOTAL %d  PASS %d  FAIL %d" % (len(checks), len(checks) - n_fail, n_fail))
    return 0 if n_fail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
