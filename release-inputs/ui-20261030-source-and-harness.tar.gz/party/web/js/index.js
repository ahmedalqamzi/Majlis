// Landing page: keeps the simulation flag on its links so a simulated session never talks to a real server.
import { h, mount, simRibbon, pageUrl } from './ui.js';

const simEl = document.getElementById('sim');
if (simEl) mount(simEl, simRibbon());
for (const [id, path] of [['go-play', 'play.html'], ['go-host', 'host.html']]) {
  const a = document.getElementById(id);
  if (a) a.href = pageUrl(path);
}

import { MODES } from './modes.js';
const catalog = document.getElementById('game-catalog');
if (catalog) {
  const shown = MODES.filter(m => m.playable || m.id === 'escape_room');
  mount(catalog, shown.map(m => h('article', { class: 'mode-tile' + (m.playable ? '' : ' disabled'), 'data-mode': m.id },
    h('h3', { class: 'mode-name', text: m.title, style: { margin: '0' } }),
    h('span', { class: 'mode-ar', lang: 'ar', dir: 'rtl', text: m.ar }),
    h('p', { class: 'mode-blurb', text: m.blurb || 'A new challenge is on its way.' }),
    h('span', { class: m.playable ? 'badge-good' : 'badge-later', text: m.playable ? 'Ready to play' : 'In development' }))));
}
