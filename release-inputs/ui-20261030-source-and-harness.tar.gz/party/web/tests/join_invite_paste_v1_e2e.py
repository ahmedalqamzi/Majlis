"""Real headless-Chrome + real `python -m party.server` (loopback HTTP, same-origin) checks for
the join form's invite-paste/formatted-room-code handling (party/web/js/play.js renderJoin's
resolveRoomCode()/paste listener).

Drives the SAME web dir twice at two different loopback ports: once at the pre-fix BASELINE
commit (a real `git worktree` checkout) and once against this checkout's CANDIDATE working tree,
so the baseline-failure / candidate-pass contrast is a real before/after of the same browser
automation against the same server code, not a hand-written claim.

A real paste is simulated with a real `ClipboardEvent`/`DataTransfer` dispatched at the actual
`#join-code` input in the actual page (no clipboard read permission/API is used or needed: this
is the standard way to drive a paste listener from CDP without OS-level clipboard access) -- the
listener under test is the real shipped code, not a reimplementation.

  python3 join_invite_paste_v1_e2e.py REPO_ROOT BASE_COMMIT OUT_DIR

Needs Google Chrome and python websocket-client. Exit 0 iff every check passes for the candidate
(baseline is expected, and required, to show at least the known pre-fix failures).
"""
import json, os, shutil, socket, subprocess, sys, tempfile, time
import urllib.error, urllib.request
import websocket

CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

results = {"label": "join-invite-paste-v1: real Chrome + real party.server, baseline vs candidate", "runs": {}}


def check(bucket, name, ok, detail=None):
    results["runs"].setdefault(bucket, []).append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + f"[{bucket}] " + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def http_json(method, url, body=None, timeout=10):
    data = json.dumps(body).encode("utf-8") if body is not None else (b"{}" if method == "POST" else None)
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))


class Tab:
    def __init__(self, ws_url):
        self.ws = websocket.create_connection(ws_url, timeout=60, suppress_origin=True)
        self.n = 0

    def call(self, method, **params):
        self.n += 1
        mid = self.n
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError(f"{method}: {msg['error']}")
                return msg.get("result", {})

    def eval(self, expr, timeout=10):
        res = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True, timeout=timeout)
        if "exceptionDetails" in res:
            raise RuntimeError(json.dumps(res["exceptionDetails"])[:800])
        return res["result"].get("value")

    def wait(self, expr, timeout=10.0, what=None):
        end = time.time() + timeout
        while time.time() < end:
            v = self.eval(expr)
            if v:
                return v
            time.sleep(0.05)
        raise TimeoutError(f"timed out waiting for {what or expr}")

    def goto(self, url):
        self.call("Page.navigate", url=url)
        self.wait("document.readyState === 'complete'", what="load")


# Dispatches a real ClipboardEvent('paste') with a real DataTransfer carrying `text` at the real
# #join-code input -- no OS clipboard, no clipboard-read permission/API, exactly what the shipped
# listener (codeIn.addEventListener('paste', ...)) receives from an actual user paste gesture.
JS_PASTE = """
(() => {
  const el = document.getElementById('join-code');
  el.focus();
  const dt = new DataTransfer();
  dt.setData('text/plain', %s);
  const ev = new ClipboardEvent('paste', { bubbles: true, cancelable: true, clipboardData: dt });
  const defaultPrevented0 = false;
  el.dispatchEvent(ev);
  return { value: el.value, codeError: document.getElementById('code-error')?.textContent ?? null,
           codeInvalid: document.getElementById('join-code')?.getAttribute('aria-invalid') ?? null,
           defaultPrevented: ev.defaultPrevented };
})()
"""

JS_FIELD_STATE = """
(() => ({
  codeValue: document.getElementById('join-code')?.value ?? null,
  codeError: document.getElementById('code-error')?.textContent ?? null,
  codeInvalid: document.getElementById('join-code')?.getAttribute('aria-invalid') ?? null,
  nameValue: document.getElementById('join-name')?.value ?? null,
  activeId: document.activeElement && document.activeElement.id,
}))()
"""

JS_SET_CODE_NATIVE = """
(() => {
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  const el = document.getElementById('join-code');
  nativeSetter.call(el, %s);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  return el.value;
})()
"""

JS_INSTALL_REQUEST_COUNTER = """
(() => {
  window.__joinRequestCount = 0;
  const orig = window.fetch;
  window.fetch = function(...args) { window.__joinRequestCount++; return orig.apply(this, args); };
  return true;
})()
"""


def run_matrix(bucket, base_url, repo, out):
    port_log = open(os.path.join(out, f"server-{bucket}.log"), "w")
    server_cmd = [sys.executable, "-m", "party.server", "--port", str(base_url.rsplit(":", 1)[1]),
                  "--web-dir", os.path.join(repo, "party", "web"), "--content-dir", os.path.join(repo, "party", "content"),
                  "--create-per-minute", "1000", "--create-burst", "100",
                  "--exit-on-stdin-eof"]
    srv = subprocess.Popen(server_cmd, cwd=repo, stdin=subprocess.PIPE, stdout=port_log, stderr=port_log)
    dport = free_port()
    profile = tempfile.mkdtemp(prefix="majlis-invite-e2e-")
    chrome = subprocess.Popen([CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                               "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                               "--window-size=430,900", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        st = body = None
        for _ in range(100):
            try:
                st, body = http_json("GET", base_url + "/api/health")
                if st == 200:
                    break
            except Exception:
                pass
            time.sleep(0.1)
        check(bucket, "real server answers /api/health", st == 200, body)

        ver = None
        for _ in range(100):
            try:
                ver = json.load(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version")); break
            except Exception:
                time.sleep(0.2)
        browser = Tab(ver["webSocketDebuggerUrl"])

        open_tids = []

        def new_tab():
            tid = browser.call("Target.createTarget", url="about:blank")["targetId"]
            open_tids.append(tid)
            t = Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}")
            t.call("Page.enable"); t.call("Runtime.enable")
            t._tid = tid
            return t

        def close_tab(t):
            try:
                browser.call("Target.closeTarget", targetId=t._tid)
            except Exception:
                pass
            if t._tid in open_tids:
                open_tids.remove(t._tid)

        def fresh(name=None):
            st2, room = http_json("POST", base_url + "/api/rooms")
            check(bucket, "room created" + (f" ({name})" if name else ""), st2 == 201 and "code" in room, {"status": st2})
            code = room["code"]
            # Headless Chrome occasionally needs a beat to free renderer resources after a prior
            # Target.closeTarget before a freshly created target will render within the normal
            # timeout; retry with fresh targets rather than failing the whole matrix on a transient
            # target-creation stall (this is a test-harness concern, not product behavior).
            last_exc = None
            for attempt in range(3):
                t = new_tab()
                try:
                    t.goto(base_url + "/play.html")
                    t.wait("!!document.getElementById('join-code')", timeout=20.0,
                           what="join form rendered" + (f" ({name})" if name else ""))
                    t.eval(JS_INSTALL_REQUEST_COUNTER)
                    return t, code
                except Exception as e:
                    last_exc = e
                    close_tab(t)
                    time.sleep(0.5 * (attempt + 1))
            raise last_exc

        here = base_url  # same-origin base for building invite-link fixtures

        # ---- fixture 1: baseline truncation is exercised -- native maxlength/pattern must be gone
        t, code1 = fresh("truncation probe")
        inserted_len = t.eval(
            "(() => { const el = document.getElementById('join-code'); el.focus(); "
            "document.execCommand('insertText', false, 'ABCDEFGHIJ'); "
            "el.dispatchEvent(new Event('input', {bubbles:true})); return el.value.length; })()")
        check(bucket, "real-DOM typing of a 10-character string into the code field is not natively truncated to 6",
              inserted_len == 10, {"inserted_len": inserted_len})
        close_tab(t)

        # ---- fixture 2: plain lowercase code with leading/trailing whitespace, via real paste ----
        t, code2 = fresh("plain lowercase + whitespace")
        res = t.eval(JS_PASTE % json.dumps("  " + code2.lower() + "  "))
        check(bucket, "pasting a lowercase code with surrounding whitespace fills the canonical uppercase code",
              res["value"] == code2 and not res["codeError"], res)
        close_tab(t)

        # ---- fixture 3: human-grouped "ABC 123" and "ABC-123" forms ----
        t, code3 = fresh("space-grouped")
        res = t.eval(JS_PASTE % json.dumps(code3[:3] + " " + code3[3:]))
        check(bucket, "pasting the space-grouped form (ABC 123) resolves to the canonical code",
              res["value"] == code3 and not res["codeError"], res)
        close_tab(t)
        t, code3b = fresh("hyphen-grouped")
        res = t.eval(JS_PASTE % json.dumps(code3b[:3] + "-" + code3b[3:]))
        check(bucket, "pasting the hyphen-grouped form (ABC-123) resolves to the canonical code",
              res["value"] == code3b and not res["codeError"], res)
        close_tab(t)

        # ---- fixture 4: full same-origin invite link, single valid code query value ----
        t, code4 = fresh("same-origin invite link")
        res = t.eval(JS_PASTE % json.dumps(here + "/play.html?code=" + code4.lower()))
        check(bucket, "pasting a full same-origin invite URL resolves to its canonical code",
              res["value"] == code4 and not res["codeError"], res)
        close_tab(t)

        # ---- fixture 5: too-short / too-long / stray punctuation are rejected, field kept ----
        for bad, label in [("ABC12", "too-short"), ("ABCDEFG", "too-long"), ("AB*123", "punctuation")]:
            t, codeX = fresh(label)
            t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
            res = t.eval(JS_PASTE % json.dumps(bad))
            check(bucket, f"pasting a {label} value is rejected with a field-linked message and the prior code is kept",
                  bool(res["codeError"]) and res["value"] == "ZZZZZZ", res)
            close_tab(t)

        # ---- fixture 6: duplicate code query is rejected as ambiguous ----
        t, code6 = fresh("duplicate code query")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
        res = t.eval(JS_PASTE % json.dumps(here + "/play.html?code=" + code6 + "&code=AAAAAA"))
        check(bucket, "pasting an invite URL with a duplicate code query is rejected, prior code kept",
              bool(res["codeError"]) and res["value"] == "ZZZZZZ", res)
        close_tab(t)

        # ---- fixture 7: encoded malformed query value is rejected ----
        t, code7 = fresh("encoded malformed value")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
        res = t.eval(JS_PASTE % json.dumps(here + "/play.html?code=AB%20123"))
        check(bucket, "pasting an invite URL whose code query decodes to something other than 6 plain characters is rejected",
              bool(res["codeError"]) and res["value"] == "ZZZZZZ", res)
        close_tab(t)

        # ---- fixture 8: foreign origin is rejected without ever fetching/navigating ----
        t, code8 = fresh("foreign origin")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
        res = t.eval(JS_PASTE % json.dumps("https://example.com/play.html?code=ABC123"))
        reqs = t.eval("window.__joinRequestCount")
        check(bucket, "pasting a foreign-origin link is rejected with a field-linked message, prior code kept, no request made",
              bool(res["codeError"]) and res["value"] == "ZZZZZZ" and reqs == 0, {**res, "requests": reqs})
        close_tab(t)

        # ---- fixture 9: unexpected path on this same origin is rejected ----
        t, code9 = fresh("unexpected path")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
        res = t.eval(JS_PASTE % json.dumps(here + "/index.html?code=ABC123"))
        check(bucket, "pasting a same-origin link to a different page/path is rejected, prior code kept",
              bool(res["codeError"]) and res["value"] == "ZZZZZZ", res)
        close_tab(t)

        # ---- fixture 10: userinfo in the URL is rejected ----
        t, code10 = fresh("userinfo")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
        res = t.eval(JS_PASTE % json.dumps(here.replace("http://", "http://user:pass@") + "/play.html?code=ABC123"))
        check(bucket, "pasting a URL with userinfo is rejected, prior code kept",
              bool(res["codeError"]) and res["value"] == "ZZZZZZ", res)
        close_tab(t)

        # ---- fixture 11: javascript: scheme is rejected, never evaluated ----
        t, code11 = fresh("javascript scheme")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
        res = t.eval(JS_PASTE % json.dumps("javascript:alert(1)"))
        check(bucket, "pasting a javascript: URL is rejected with a field-linked message, never executed",
              bool(res["codeError"]) and res["value"] == "ZZZZZZ", res)
        close_tab(t)

        # ---- fixture 12: a rejected paste never touches the typed name draft ----
        t, code12 = fresh("name preserved on reject")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
        t.eval("(() => { document.getElementById('join-name').value = 'Noora'; "
               "document.getElementById('join-name').dispatchEvent(new Event('input', {bubbles:true})); return true; })()")
        res = t.eval(JS_PASTE % json.dumps("https://example.com/play.html?code=ABC123"))
        state = t.eval(JS_FIELD_STATE)
        check(bucket, "a rejected code paste leaves the typed name draft untouched",
              state["nameValue"] == "Noora", state)
        close_tab(t)

        # ---- fixture 13: editing after a rejected paste clears the stale error normally ----
        t, code13 = fresh("clears on edit")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("ZZZZZZ"))
        t.eval(JS_PASTE % json.dumps("javascript:alert(1)"))
        t.eval("(() => { document.getElementById('join-code').focus(); "
               "document.execCommand('insertText', false, 'X'); "
               "document.getElementById('join-code').dispatchEvent(new Event('input', {bubbles:true})); return true; })()")
        state = t.eval(JS_FIELD_STATE)
        check(bucket, "typing after a rejected paste clears the stale code-field error",
              not state["codeError"], state)
        close_tab(t)

        # ---- fixture 14: a real explicit submit after a successful paste sends exactly one join ----
        t, code14 = fresh("submit after paste")
        t.eval(JS_PASTE % json.dumps(code14.lower()))
        t.eval("(() => { const n = document.getElementById('join-name'); n.value = 'Ahmed'; "
               "n.dispatchEvent(new Event('input', {bubbles:true})); return true; })()")
        t.eval("document.querySelector('form').requestSubmit()")
        joined = bool(t.wait("!!document.querySelector('.topbar .me-chip')", timeout=10, what="joined room header (fixture 14)"))
        check(bucket, "after a successful paste, the explicit Join action sends exactly one normalized code and joins", joined)
        close_tab(t)

        # ---- fixture 15: autofill/script-set value bypasses the paste event but not the submit guard ----
        t, code15 = fresh("script-set bypass")
        t.eval(JS_SET_CODE_NATIVE % json.dumps("https://example.com/play.html?code=ABC123"))
        t.eval("(() => { const n = document.getElementById('join-name'); n.value = 'Ahmed'; "
               "n.dispatchEvent(new Event('input', {bubbles:true})); return true; })()")
        t.eval("document.querySelector('form').requestSubmit()")
        time.sleep(0.3)
        state = t.eval(JS_FIELD_STATE)
        reqs = t.eval("window.__joinRequestCount")
        check(bucket, "a script-set foreign-link value (no paste event fired) is still rejected on submit, no request made",
              bool(state["codeError"]) and state["activeId"] == "join-code" and reqs == 0, {**state, "requests": reqs})
        close_tab(t)

        # ---- fixture 16: existing URL-query entry (?code=) still works unaffected ----
        st2, room16 = http_json("POST", base_url + "/api/rooms")
        code16 = room16["code"]
        last_exc = None
        t16 = None
        for attempt in range(3):
            t16 = new_tab()
            try:
                t16.goto(base_url + "/play.html?code=" + code16)
                t16.wait("!!document.getElementById('join-code')", timeout=20.0, what="join form rendered (fixture 16)")
                last_exc = None
                break
            except Exception as e:
                last_exc = e
                close_tab(t16)
                time.sleep(0.5 * (attempt + 1))
        if last_exc:
            raise last_exc
        state16 = t16.eval(JS_FIELD_STATE)
        check(bucket, "existing ?code= URL-query entry still prefills the canonical code",
              state16["codeValue"] == code16, state16)
        close_tab(t16)
    finally:
        try:
            chrome.terminate(); chrome.wait(timeout=5)
        except Exception:
            try:
                chrome.kill()
            except Exception:
                pass
        try:
            srv.stdin.close()
        except Exception:
            pass
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()
        shutil.rmtree(profile, ignore_errors=True)


def main():
    repo = os.path.abspath(sys.argv[1])
    base_commit = sys.argv[2]
    out = os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)

    baseline_dir = tempfile.mkdtemp(prefix="majlis-invite-e2e-baseline-")
    try:
        subprocess.run(["git", "worktree", "add", "--detach", baseline_dir, base_commit],
                       cwd=repo, check=True, capture_output=True, text=True)

        port_b = free_port()
        try:
            run_matrix("baseline", f"http://127.0.0.1:{port_b}", baseline_dir, out)
        except Exception as e:
            check("baseline", "baseline run completed without crashing (informational; crash is expected pre-fix evidence, not a candidate defect)",
                  False, repr(e)[:500])

        port_c = free_port()
        run_matrix("candidate", f"http://127.0.0.1:{port_c}", repo, out)
    finally:
        subprocess.run(["git", "worktree", "remove", "--force", baseline_dir], cwd=repo, capture_output=True, text=True)
        shutil.rmtree(baseline_dir, ignore_errors=True)

    json.dump(results, open(os.path.join(out, "results.json"), "w"), indent=2, ensure_ascii=False)
    baseline_pass = sum(1 for c in results["runs"].get("baseline", []) if c["pass"])
    baseline_total = len(results["runs"].get("baseline", []))
    candidate_fail = [c for c in results["runs"].get("candidate", []) if not c["pass"]]
    print(f"\nbaseline: {baseline_pass}/{baseline_total} passed (pre-fix failures are EXPECTED here)")
    print(f"candidate: {baseline_total - len(candidate_fail)}/{baseline_total} passed")
    if candidate_fail:
        print("CANDIDATE FAILURES:", json.dumps(candidate_fail, indent=2, ensure_ascii=False)[:4000])
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
