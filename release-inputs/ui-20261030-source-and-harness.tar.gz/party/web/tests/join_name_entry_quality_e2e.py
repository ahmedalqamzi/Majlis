"""Real headless-Chrome + real `python -m party.server` (loopback HTTP, same-origin) checks for
the join form's Unicode-aware name length, IME-safe submission and field-linked validation
feedback (party/web/js/play.js renderJoin).

Drives the SAME web dir twice at two different loopback ports: once at the pre-fix BASELINE
commit (`git show <base>:party/web -> tmp dir`) and once against this checkout's CANDIDATE
working tree, so the baseline-failure / candidate-pass contrast is a real before/after of the
same browser automation against the same server code, not a hand-written claim.

IME composition is simulated with real `CompositionEvent`/`KeyboardEvent` objects dispatched at
the real `#join-name` input in the real page (OS-level IME input cannot be driven by CDP; this is
the standard way to exercise composition-aware listeners in automated browser tests) -- the
listeners under test (play.js's compositionstart/compositionend/keydown handlers) are the real
shipped code, not a reimplementation.

  python3 join_name_entry_quality_e2e.py REPO_ROOT BASE_COMMIT OUT_DIR

Needs Google Chrome and python websocket-client. Exit 0 iff every check passes for the candidate
(baseline is expected, and required, to show at least the known pre-fix failures).
"""
import json, os, secrets, shutil, socket, subprocess, sys, tempfile, time
import urllib.error, urllib.request
import websocket

CHROME = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"

results = {"label": "join-name-entry-quality-v1: real Chrome + real party.server, baseline vs candidate", "runs": {}}


def check(bucket, name, ok, detail=None):
    results["runs"].setdefault(bucket, []).append({"name": name, "pass": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + f"[{bucket}] " + name + ("" if detail is None else "  " + json.dumps(detail, ensure_ascii=False, default=str)[:300]), flush=True)
    return ok


def free_port():
    s = socket.socket(); s.bind(("127.0.0.1", 0)); p = s.getsockname()[1]; s.close(); return p


def sw(x, prefix):
    """startswith that tolerates a missing (pre-fix baseline has no name-help element) field."""
    return isinstance(x, str) and x.startswith(prefix)


def http_json(method, url, body=None, token=None, timeout=10):
    data = json.dumps(body).encode("utf-8") if body is not None else (b"{}" if method == "POST" else None)
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read().decode("utf-8"))


class Tab:
    def __init__(self, ws_url):
        self.ws = websocket.create_connection(ws_url, timeout=60, suppress_origin=True)
        self.n = 0

    def call(self, method, **params):
        self.n += 1
        mid = self.n
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise RuntimeError(f"{method}: {msg['error']}")
                return msg.get("result", {})

    def eval(self, expr):
        res = self.call("Runtime.evaluate", expression=expr, returnByValue=True, awaitPromise=True)
        if "exceptionDetails" in res:
            raise RuntimeError(json.dumps(res["exceptionDetails"])[:800])
        return res["result"].get("value")

    def wait(self, expr, timeout=10.0, what=None):
        end = time.time() + timeout
        while time.time() < end:
            v = self.eval(expr)
            if v:
                return v
            time.sleep(0.05)
        raise TimeoutError(f"timed out waiting for {what or expr}")

    def goto(self, url):
        self.call("Page.navigate", url=url)
        self.wait("document.readyState === 'complete'", what="load")


# ---- JS driven against the real #join-name input in the real page --------------------------

JS_SET_VALUE = """
(() => {
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  const el = document.getElementById('join-name');
  nativeSetter.call(el, %s);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  return el.value;
})()
"""

JS_COMPOSE_THEN_ENTER = """
(() => {
  const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
  const el = document.getElementById('join-name');
  el.focus();
  el.dispatchEvent(new CompositionEvent('compositionstart', { bubbles: true, data: '' }));
  nativeSetter.call(el, %s);
  el.dispatchEvent(new CompositionEvent('compositionupdate', { bubbles: true, data: %s }));
  el.dispatchEvent(new Event('input', { bubbles: true }));
  // The IME's own Enter keystroke while still composing, as a real IME delivers it: keyCode 229,
  // isComposing true, no 'key' the browser would otherwise treat as a plain Enter.
  const ke = new KeyboardEvent('keydown', { bubbles: true, cancelable: true, key: 'Enter', keyCode: 229, isComposing: true });
  const submittedDuringComposition = window.__joinSubmitCount || 0;
  el.dispatchEvent(ke);
  el.dispatchEvent(new CompositionEvent('compositionend', { bubbles: true, data: %s }));
  nativeSetter.call(el, %s);
  el.dispatchEvent(new Event('input', { bubbles: true }));
  return { prevented: ke.defaultPrevented, submittedDuringComposition, afterSubmitCount: window.__joinSubmitCount || 0, value: el.value };
})()
"""

JS_INSTALL_SUBMIT_COUNTER = """
(() => {
  window.__joinSubmitCount = 0;
  const f = document.querySelector('form');
  f.addEventListener('submit', () => { window.__joinSubmitCount++; }, true);
  return true;
})()
"""

JS_FIELD_STATE = """
(() => ({
  nameHelp: document.getElementById('name-help')?.textContent ?? null,
  nameError: document.getElementById('name-error')?.textContent ?? null,
  codeError: document.getElementById('code-error')?.textContent ?? null,
  nameInvalid: document.getElementById('join-name')?.getAttribute('aria-invalid') ?? null,
  codeInvalid: document.getElementById('join-code')?.getAttribute('aria-invalid') ?? null,
  activeId: document.activeElement && document.activeElement.id,
  nameValue: document.getElementById('join-name')?.value ?? null,
}))()
"""


def run_matrix(bucket, base_url, repo, out, server_cmd_extra=None):
    port_log = open(os.path.join(out, f"server-{bucket}.log"), "w")
    server_cmd = [sys.executable, "-m", "party.server", "--port", str(base_url.rsplit(":", 1)[1]),
                  "--web-dir", os.path.join(repo, "party", "web"), "--content-dir", os.path.join(repo, "party", "content"),
                  "--exit-on-stdin-eof"]
    srv = subprocess.Popen(server_cmd, cwd=repo, stdin=subprocess.PIPE, stdout=port_log, stderr=port_log)
    dport = free_port()
    profile = tempfile.mkdtemp(prefix="majlis-join-e2e-")
    chrome = subprocess.Popen([CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                               "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                               "--window-size=430,900", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(100):
            try:
                st, body = http_json("GET", base_url + "/api/health")
                if st == 200:
                    break
            except Exception:
                pass
            time.sleep(0.1)
        check(bucket, "real server answers /api/health", st == 200, body)

        for _ in range(100):
            try:
                ver = json.load(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version")); break
            except Exception:
                time.sleep(0.2)
        browser = Tab(ver["webSocketDebuggerUrl"])
        tid = browser.call("Target.createTarget", url="about:blank")["targetId"]
        tab = Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}")
        tab.call("Page.enable"); tab.call("Runtime.enable")

        # ---- fixture 1: host-valid 24-codepoint supplementary-plane name, never truncated ----
        st, room = http_json("POST", base_url + "/api/rooms")
        check(bucket, "room created", st == 201 and "code" in room, {"status": st})
        code = room["code"]
        tab.goto(base_url + "/play.html?code=" + code)
        tab.wait("!!document.getElementById('join-name')", what="join form rendered")
        tab.eval(JS_INSTALL_SUBMIT_COUNTER)

        emoji_name = "\U0001F600" * 24  # 24 code points, 48 UTF-16 units -- the exact bug fixture
        got = tab.eval(JS_SET_VALUE % json.dumps(emoji_name))
        check(bucket, "24-codepoint supplementary-plane name is not truncated while typing",
              got == emoji_name, {"expected_len": len(emoji_name), "got_len": len(got), "got": got[:10] + "..."})
        state = tab.eval(JS_FIELD_STATE)
        check(bucket, "name-help reports 24/24 for the 24-codepoint supplementary name (not 48, the UTF-16 count)",
              sw(state["nameHelp"], "24/24"), state["nameHelp"])

        # ---- fixture 2: NFC combining-sequence name counts as composed length ----
        # Each pair is the DECOMPOSED form (U+0041 LATIN CAPITAL LETTER A, U+0301
        # COMBINING ACUTE ACCENT) -- two code points that normalize to one NFC code
        # point, the exact composition cleanName's nfc(value) performs before counting.
        # Built with chr() rather than a literal precomposed character so this source
        # file's own normalization can't silently collapse the fixture itself.
        combining_name = (chr(0x0041) + chr(0x0301)) * 12  # -> 12 NFC code points after composition
        tab.eval(JS_SET_VALUE % json.dumps(combining_name))
        state = tab.eval(JS_FIELD_STATE)
        check(bucket, "NFC combining-sequence name (24 raw code points, 12 after composition) counts as 12 composed characters",
              sw(state["nameHelp"], "12/24"), state["nameHelp"])

        # ---- fixture 3: 25-codepoint name is rejected on submit, draft kept, field-linked ----
        over_name = "x" * 25
        tab.eval(JS_SET_VALUE % json.dumps(over_name))
        tab.eval("document.querySelector('form').requestSubmit()")
        time.sleep(0.2)
        state = tab.eval(JS_FIELD_STATE)
        check(bucket, "25-character name is rejected on submit with the name field marked invalid",
              bool(state["nameError"]) and state["nameInvalid"] == "true" and state["activeId"] == "join-name", state)
        check(bucket, "the typed 25-character draft is kept for correction, not cleared",
              state["nameValue"] == over_name, state["nameValue"])

        # ---- fixture 4: whitespace collapse (incl. Python-specific NBSP) + mixed Arabic name ----
        tab.eval(JS_SET_VALUE % json.dumps("    Ahmed    Al Qemzi   "))
        state = tab.eval(JS_FIELD_STATE)
        check(bucket, "leading/trailing/NBSP whitespace is collapsed for the live count",
              sw(state["nameHelp"], "14/24"), state["nameHelp"])
        # ---- fixture 4b: U+001C FILE SEPARATOR and U+0085 NEL are Python str.split() whitespace
        # (and so the real host's clean_name collapses them), but are NOT in JS's native \s class.
        # collapseJoinName now mirrors the host's whitespace set directly, so this asserts REAL
        # client-side parity -- the live count and the submitted payload, not just the host's own
        # independent collapse -- plus genuine (non-setter-bypass) real-DOM text insertion so a
        # native maxlength clamp could not hide a regression here.
        st, room_fs = http_json("POST", base_url + "/api/rooms")
        code_fs = room_fs["code"]
        tab_fs_id = browser.call("Target.createTarget", url="about:blank")["targetId"]
        tab_fs = Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tab_fs_id}")
        tab_fs.call("Page.enable"); tab_fs.call("Runtime.enable")
        tab_fs.goto(base_url + "/play.html?code=" + code_fs)
        tab_fs.wait("!!document.getElementById(\'join-name\')", what="join form rendered (tab_fs)")
        # A long run (30) of U+001C between A and B, past genuine real-DOM text insertion
        # (execCommand('insertText'), the actual browser input pipeline that an old native
        # maxlength would have clamped -- unlike a direct .value setter, which bypasses it).
        long_fs_raw = "A" + (chr(0x1C) * 30) + "B"
        tab_fs.eval("document.getElementById(\'join-name\').focus()")
        inserted_len = tab_fs.eval(
            "(() => { document.execCommand(\'insertText\', false, " + json.dumps(long_fs_raw) + "); "
            "document.getElementById(\'join-name\').dispatchEvent(new Event(\'input\', {bubbles:true})); "
            "return document.getElementById(\'join-name\').value.length; })()")
        check(bucket, "no native maxlength clamps the real-DOM-inserted 32-UTF-16-unit whitespace-padded name "
                      "(no silent loss of the closing character before collapseJoinName ever sees it)",
              inserted_len == len(long_fs_raw), {"inserted_len": inserted_len, "expected": len(long_fs_raw)})
        state_fs = tab_fs.eval(JS_FIELD_STATE)
        check(bucket, "the live count mirrors the host's whitespace collapse for U+001C: 'A' + 30xFS + 'B' counts as 3 ('A B')",
              sw(state_fs["nameHelp"], "3/24"), state_fs["nameHelp"])
        tab_fs.eval("document.querySelector(\'form\').requestSubmit()")
        time.sleep(0.4)
        chip = tab_fs.wait(
            "(() => { const c = document.querySelector(\'.topbar .me-chip\'); return c && c.textContent; })()",
            timeout=10, what="joined room header (tab_fs)")
        check(bucket, "the real host accepts the client's own canonical payload for the U+001C name and renders it as 'A B'",
              sw(chip, "A B"), chip)

        # ---- fixture 4c: U+0085 NEL run, same client/host parity check as 4b -----------------
        st, room_nel = http_json("POST", base_url + "/api/rooms")
        code_nel = room_nel["code"]
        tab_nel_id = browser.call("Target.createTarget", url="about:blank")["targetId"]
        tab_nel = Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tab_nel_id}")
        tab_nel.call("Page.enable"); tab_nel.call("Runtime.enable")
        tab_nel.goto(base_url + "/play.html?code=" + code_nel)
        tab_nel.wait("!!document.getElementById(\'join-name\')", what="join form rendered (tab_nel)")
        nel_name = "A" + (chr(0x85) * 30) + "B"
        tab_nel.eval(JS_SET_VALUE % json.dumps(nel_name))
        state_nel = tab_nel.eval(JS_FIELD_STATE)
        check(bucket, "the live count mirrors the host's whitespace collapse for U+0085 NEL: 'A' + 30xNEL + 'B' counts as 3 ('A B')",
              sw(state_nel["nameHelp"], "3/24"), state_nel["nameHelp"])
        tab_nel.eval("document.querySelector(\'form\').requestSubmit()")
        time.sleep(0.4)
        chip_nel = tab_nel.wait(
            "(() => { const c = document.querySelector(\'.topbar .me-chip\'); return c && c.textContent; })()",
            timeout=10, what="joined room header (tab_nel)")
        check(bucket, "the real host accepts the client's own canonical payload for the U+0085 name and renders it as 'A B'",
              sw(chip_nel, "A B"), chip_nel)

        # ---- fixture 4d: U+FEFF retains its host-canonical identity, not collapsed to a space ----
        st, room_feff = http_json("POST", base_url + "/api/rooms")
        code_feff = room_feff["code"]
        tab_feff_id = browser.call("Target.createTarget", url="about:blank")["targetId"]
        tab_feff = Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tab_feff_id}")
        tab_feff.call("Page.enable"); tab_feff.call("Runtime.enable")
        tab_feff.goto(base_url + "/play.html?code=" + code_feff)
        tab_feff.wait("!!document.getElementById(\'join-name\')", what="join form rendered (tab_feff)")
        feff_name = "A" + chr(0xFEFF) + "B"
        tab_feff.eval(JS_SET_VALUE % json.dumps(feff_name))
        state_feff = tab_feff.eval(JS_FIELD_STATE)
        check(bucket, "U+FEFF is not collapsed into a space by the live count: 'A' + FEFF + 'B' counts as 3, value unchanged",
              sw(state_feff["nameHelp"], "3/24") and state_feff["nameValue"] == feff_name, state_feff)
        tab_feff.eval("document.querySelector(\'form\').requestSubmit()")
        time.sleep(0.4)
        chip_feff = tab_feff.wait(
            "(() => { const c = document.querySelector(\'.topbar .me-chip\'); return c && c.textContent; })()",
            timeout=10, what="joined room header (tab_feff)")
        check(bucket, "the real host accepts the FEFF-preserving payload and renders the FEFF-identity name verbatim (not 'A B')",
              sw(chip_feff, feff_name), {"chip": chip_feff, "expected": feff_name})


        arabic_name = "أحمد القمزي"  # "Ahmed Al Qemzi" in Arabic
        tab.eval(JS_SET_VALUE % json.dumps(arabic_name))
        state = tab.eval(JS_FIELD_STATE)
        check(bucket, "mixed Arabic/RTL name preserved verbatim and counted by code point",
              state["nameValue"] == arabic_name and sw(state["nameHelp"], str(len(arabic_name)) + "/24"), state)

        # ---- fixture 5: IME composition Enter never submits; final composed text is retained ----
        tab.eval(JS_SET_VALUE % json.dumps(""))
        res = tab.eval(JS_COMPOSE_THEN_ENTER % (json.dumps("あ"), json.dumps("あい"), json.dumps("あいう"), json.dumps("あいう")))
        check(bucket, "Enter during IME composition is prevented and does not submit the join form",
              res["prevented"] is True and res["afterSubmitCount"] == res["submittedDuringComposition"], res)
        check(bucket, "compositionend's final committed text is retained in the field",
              res["value"] == "あいう", res["value"])

        # ---- fixture 6: a deliberate subsequent valid submission joins exactly once ----
        valid_name = res["value"] + "san"
        tab.eval(JS_SET_VALUE % json.dumps(valid_name))
        before = tab.eval("window.__joinSubmitCount")
        tab.eval("document.querySelector('form').requestSubmit()")
        time.sleep(0.4)
        after = tab.eval("window.__joinSubmitCount")
        check(bucket, "a deliberate submit after composition fires the form's submit handler exactly once",
              after - before == 1, {"before": before, "after": after})
        # !!: a bare querySelector result is a DOM Element, which CDP's returnByValue serializes
        # as {} (an empty object -- falsy in Python) rather than failing, so wait() would otherwise
        # spin for the full timeout on every call no matter how fast the real join completes.
        joined_ok = bool(tab.wait("!!document.querySelector('.topbar .me-chip')", timeout=10, what="joined room header"))
        check(bucket, "real server accepted the post-IME name and this phone entered the room", joined_ok)

        # ---- fixture 7: forbidden control character is rejected by the real server, field-linked ----
        st, room2 = http_json("POST", base_url + "/api/rooms")
        code2 = room2["code"]
        tab2_id = browser.call("Target.createTarget", url="about:blank")["targetId"]
        tab2 = Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tab2_id}")
        tab2.call("Page.enable"); tab2.call("Runtime.enable")
        tab2.goto(base_url + "/play.html?code=" + code2)
        tab2.wait("!!document.getElementById('join-name')", what="join form rendered (tab2)")
        bidi_name = "A‮b"  # RIGHT-TO-LEFT OVERRIDE, a rejected bidi control, not whitespace
        tab2.eval(JS_SET_VALUE % json.dumps(bidi_name))
        tab2.eval("document.querySelector('form').requestSubmit()")
        time.sleep(0.4)
        state2 = tab2.eval(JS_FIELD_STATE)
        check(bucket, "a forbidden bidi-control name is rejected by the real server and reported on the name field",
              bool(state2["nameError"]) and state2["nameInvalid"] == "true", state2)

        # ---- fixture 8: server name_taken is reported on the name field with draft kept ----
        st, room3 = http_json("POST", base_url + "/api/rooms")
        code3 = room3["code"]
        st, j1 = http_json("POST", base_url + "/api/rooms/" + code3 + "/join", body={"name": "Noora"})
        check(bucket, "first player joins room3 as Noora", st == 201, {"status": st})
        tab3_id = browser.call("Target.createTarget", url="about:blank")["targetId"]
        tab3 = Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tab3_id}")
        tab3.call("Page.enable"); tab3.call("Runtime.enable")
        tab3.goto(base_url + "/play.html?code=" + code3)
        tab3.wait("!!document.getElementById('join-name')", what="join form rendered (tab3)")
        tab3.eval(JS_SET_VALUE % json.dumps("Noora"))
        tab3.eval("document.querySelector('form').requestSubmit()")
        time.sleep(0.4)
        state3 = tab3.eval(JS_FIELD_STATE)
        check(bucket, "name_taken is reported on the name field and the typed draft ('Noora') is kept",
              bool(state3["nameError"]) and state3["nameInvalid"] == "true" and state3["nameValue"] == "Noora", state3)

        # ---- fixture 9: invalid room code is reported on the code field, not the name field ----
        tab4_id = browser.call("Target.createTarget", url="about:blank")["targetId"]
        tab4 = Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tab4_id}")
        tab4.call("Page.enable"); tab4.call("Runtime.enable")
        tab4.goto(base_url + "/play.html")
        tab4.wait("!!document.getElementById('join-name')", what="join form rendered (tab4)")
        tab4.eval("(() => { document.getElementById('join-code').value = 'short'; return true; })()")
        tab4.eval(JS_SET_VALUE % json.dumps("Ahmed"))
        tab4.eval("document.querySelector('form').requestSubmit()")
        time.sleep(0.2)
        state4 = tab4.eval(JS_FIELD_STATE)
        check(bucket, "a malformed room code is reported on the code field, the name field stays clean",
              bool(state4["codeError"]) and state4["codeInvalid"] == "true" and not state4["nameError"] and state4["activeId"] == "join-code", state4)
    finally:
        try:
            chrome.terminate(); chrome.wait(timeout=5)
        except Exception:
            try:
                chrome.kill()
            except Exception:
                pass
        try:
            srv.stdin.close()
        except Exception:
            pass
        try:
            srv.wait(timeout=5)
        except Exception:
            srv.kill()
        shutil.rmtree(profile, ignore_errors=True)


def main():
    repo = os.path.abspath(sys.argv[1])
    base_commit = sys.argv[2]
    out = os.path.abspath(sys.argv[3])
    os.makedirs(out, exist_ok=True)

    baseline_dir = tempfile.mkdtemp(prefix="majlis-join-e2e-baseline-")
    try:
        subprocess.run(["git", "worktree", "add", "--detach", baseline_dir, base_commit],
                       cwd=repo, check=True, capture_output=True, text=True)

        port_b = free_port()
        try:
            run_matrix("baseline", f"http://127.0.0.1:{port_b}", baseline_dir, out)
        except Exception as e:
            # The pre-fix baseline is EXPECTED to fail / lack the new markup; a hard crash here
            # (e.g. a missing element the new fixtures assume) is itself baseline-failure evidence,
            # not a reason to abort the candidate run.
            check("baseline", "baseline run completed without crashing (informational; crash is expected pre-fix evidence, not a candidate defect)",
                  False, repr(e)[:500])

        port_c = free_port()
        run_matrix("candidate", f"http://127.0.0.1:{port_c}", repo, out)
    finally:
        subprocess.run(["git", "worktree", "remove", "--force", baseline_dir], cwd=repo, capture_output=True, text=True)
        shutil.rmtree(baseline_dir, ignore_errors=True)

    json.dump(results, open(os.path.join(out, "results.json"), "w"), indent=2, ensure_ascii=False)
    baseline_pass = sum(1 for c in results["runs"].get("baseline", []) if c["pass"])
    baseline_total = len(results["runs"].get("baseline", []))
    candidate_fail = [c for c in results["runs"].get("candidate", []) if not c["pass"]]
    print(f"\nbaseline: {baseline_pass}/{baseline_total} passed (pre-fix failures are EXPECTED here)")
    print(f"candidate: {baseline_total - len(candidate_fail)}/{baseline_total} passed")
    if candidate_fail:
        print("CANDIDATE FAILURES:", json.dumps(candidate_fail, indent=2, ensure_ascii=False)[:4000])
        sys.exit(1)
    sys.exit(0)


if __name__ == "__main__":
    main()
