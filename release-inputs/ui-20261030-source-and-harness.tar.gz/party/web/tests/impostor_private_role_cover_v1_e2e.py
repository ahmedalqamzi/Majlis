"""Impostor private role-card reveal/hide + lifecycle concealment checks, against the REAL
party.server over loopback HTTP + fetch-SSE, headless Chrome. Same approach as real_e2e.py /
real_e2e_impostor.py (reused directly: Tab driver, fetch tee, trusted CDP clicks, the established
visibilitychange-override and Network.emulateNetworkConditions patterns already used there),
scoped to majlis:impostor-private-role-cover-v1: the player's own role/word card defaults
covered, reveals/hides only on this device's own explicit tap, and conceals again on every
lifecycle transition the brief lists.

  python impostor_private_role_cover_v1_e2e.py <repo root> <out dir>

Env MAJLIS_SERVER_PY selects the interpreter for the server (default: this interpreter).
Needs Google Chrome and python websocket-client.
"""
import json, os, re, sys, tempfile, subprocess, time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import real_e2e as base  # noqa: E402  (reuses Tab, NET_HOOK, HELPERS, check, free_port, http_get)

check = base.check
results = base.results
results["label"] = "REAL NETWORK Impostor private role-card cover (loopback HTTP + fetch-SSE to the in-repo party.server) - headless Chrome on one Mac"


def wait_for(get, pred, timeout=12.0, what=None):
    end = time.time() + timeout
    last = None
    while time.time() < end:
        last = get()
        if pred(last):
            return last
        time.sleep(0.15)
    raise TimeoutError(f"timed out waiting for {what or pred}; last value: {json.dumps(last, default=str)[:400]}")


def card_html(tab):
    """The player's own role-card element only, never the whole page: scoping here is what keeps
    this scan honest, since the mode heading legitimately shows the game title 'Impostor'
    elsewhere on the same page regardless of this card's own cover state."""
    return tab.eval("(document.querySelector('.my-card') || {}).outerHTML || ''")


def is_revealed(tab):
    return bool(tab.eval("!!document.querySelector('.my-card.revealed')"))


def toggle_state(tab):
    return tab.eval("(() => { const b = document.getElementById('impostor-card-toggle'); "
                    "return b ? { text: (b.textContent||'').trim(), pressed: b.getAttribute('aria-pressed') } : null; })()")


def assert_covered(tab, label, word, role_text="Impostor"):
    """Covered-state DOM-safety: no secret in text, attributes or the card's own subtree at all
    (not merely CSS-hidden), and the toggle reads as not-pressed / 'Reveal role'."""
    check(f"[{label}] {tab.name}: card not revealed", not is_revealed(tab), label)
    html = card_html(tab)
    check(f"[{label}] {tab.name}: no '.char-big' node while covered", "char-big" not in html, label)
    check(f"[{label}] {tab.name}: crew word absent from covered card DOM", bool(word) and word not in html, {"label": label, "word": word})
    check(f"[{label}] {tab.name}: role text absent from covered card DOM", role_text not in html, label)
    ts = toggle_state(tab)
    check(f"[{label}] {tab.name}: toggle reads 'Reveal role' / aria-pressed=false", ts == {"text": "Reveal role", "pressed": "false"}, {"label": label, "toggle": ts})


def assert_revealed_crew(tab, label, word):
    check(f"[{label}] {tab.name}: card revealed", is_revealed(tab), label)
    html = card_html(tab)
    check(f"[{label}] {tab.name}: own crew word now present", word in html, label)
    ts = toggle_state(tab)
    check(f"[{label}] {tab.name}: toggle reads 'Hide role' / aria-pressed=true", ts == {"text": "Hide role", "pressed": "true"}, {"label": label, "toggle": ts})


def assert_revealed_impostor(tab, label):
    check(f"[{label}] {tab.name}: card revealed", is_revealed(tab), label)
    html = card_html(tab)
    check(f"[{label}] {tab.name}: own 'Impostor' role now present", "Impostor" in html, label)
    ts = toggle_state(tab)
    check(f"[{label}] {tab.name}: toggle reads 'Hide role' / aria-pressed=true", ts == {"text": "Hide role", "pressed": "true"}, {"label": label, "toggle": ts})


def reveal(tab):
    tab.click("document.getElementById('impostor-card-toggle')", "Reveal role")


def hide(tab):
    tab.click("document.getElementById('impostor-card-toggle')", "Hide role")


def set_hidden(tab, hidden):
    tab.eval(
        "Object.defineProperty(document, 'visibilityState', { configurable: true, get: () => " + ("'hidden'" if hidden else "'visible'") +
        " }); Object.defineProperty(document, 'hidden', { configurable: true, get: () => " + ("true" if hidden else "false") +
        " }); document.dispatchEvent(new Event('visibilitychange')); true")


def main():
    repo, out = os.path.abspath(sys.argv[1]), os.path.abspath(sys.argv[2])
    os.makedirs(out, exist_ok=True)
    server_py = os.environ.get("MAJLIS_SERVER_PY") or sys.executable
    port = base.free_port()
    base_url = f"http://127.0.0.1:{port}"
    server_log = open(os.path.join(out, "server-stderr.log"), "w")
    server_cmd = [server_py, "-m", "party.server", "--port", str(port), "--web-dir", "party/web", "--content-dir", "party/content", "--access-log", "--exit-on-stdin-eof"]
    results["server_command"] = " ".join(server_cmd[1:])
    srv = subprocess.Popen(server_cmd, cwd=repo, stdin=subprocess.PIPE, stdout=server_log, stderr=server_log)
    results["server_pid"] = srv.pid
    results["base"] = base_url
    profile = tempfile.mkdtemp(prefix="majlis-party-imp-cover-")
    dport = base.free_port()
    chrome = subprocess.Popen([base.CHROME, "--headless=new", f"--remote-debugging-port={dport}", f"--user-data-dir={profile}",
                               "--no-first-run", "--no-default-browser-check", "--hide-scrollbars", "--mute-audio",
                               "--window-size=1280,800", "about:blank"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    tabs = {}
    try:
        for _ in range(100):
            try:
                st, _, body = base.http_get(base_url + "/api/health")
                if st == 200:
                    break
            except Exception:
                pass
            time.sleep(0.1)
        check("real server answers /api/health on loopback", st == 200, body)
        import urllib.request
        for _ in range(100):
            try:
                ver = json.load(urllib.request.urlopen(f"http://127.0.0.1:{dport}/json/version")); break
            except Exception:
                time.sleep(0.2)
        browser = base.Tab(ver["webSocketDebuggerUrl"], "browser")

        def new_tab(name, vp, isolated):
            if isolated:
                ctx = browser.call("Target.createBrowserContext", disposeOnDetach=False)["browserContextId"]
                tid = browser.call("Target.createTarget", url="about:blank", browserContextId=ctx, newWindow=True)["targetId"]
            else:
                tid = browser.call("Target.createTarget", url="about:blank")["targetId"]
            t = base.Tab(f"ws://127.0.0.1:{dport}/devtools/page/{tid}", name)
            t.call("Page.enable"); t.call("Runtime.enable"); t.call("Network.enable")
            t.call("Page.addScriptToEvaluateOnNewDocument", source=base.NET_HOOK)
            t.call("Emulation.setFocusEmulationEnabled", enabled=True)
            t.viewport(vp)
            tabs[name] = t
            return t

        host = new_tab("host", base.LAPTOP, isolated=False)
        host.goto(base_url + "/host.html")
        host.click("__btn('Create room')", "Create room")
        code = host.wait("(document.querySelector('.room-code')||{}).textContent", what="room code")
        join_url = host.eval("document.querySelector('[data-join-url]').getAttribute('data-join-url')")

        names = ["Aisha", "Omar", "Noora"]
        players = {}
        for nm in names:
            p = new_tab(nm, base.PHONE, isolated=True)
            p.goto(join_url)
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what="lobby")
            players[nm] = p
        pid = {}
        for nm, p in players.items():
            rec = json.loads(p.storage()[f"majlisParty.v1.player.{code}"])
            pid[nm] = rec["playerId"]
        host.wait("document.querySelectorAll('.chip').length === 3", what="host sees players")

        def current_impostor():
            found = None
            for nm, p in players.items():
                you = (p.last_snap() or {}).get("game", {}).get("you", {})
                if you.get("role") == "impostor":
                    found = nm
            return found

        def crew_word():
            for nm, p in players.items():
                you = (p.last_snap() or {}).get("game", {}).get("you", {})
                if you.get("role") == "crew" and you.get("word"):
                    return you["word"]
            return None

        host.click("document.querySelector('[data-mode=impostor]')", "impostor tile")
        host.wait("document.querySelector('[data-mode=impostor]').getAttribute('aria-pressed') === 'true'", what="mode chosen")
        host.click("__btn('Start Impostor')", "Start")
        for nm, p in players.items():
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} role card")

        wait_for(host.last_snap, lambda s: s and s["roundId"] == "g1r1", what="round g1r1")
        impostor1 = wait_for(current_impostor, lambda v: v, what="impostor1 revealed to itself")
        word1 = wait_for(crew_word, lambda v: v, what="crew word1")
        crew1 = [n for n in names if n != impostor1][0]

        # ---------- 1. initial cover: every player's own card starts covered (no DOM leak) ----------
        for nm, p in players.items():
            assert_covered(p, "initial-cover", word1)
        host.shot(out, "imp-cover-01-initial-covered")

        # ---------- planted-secret control: proves the scan above can actually detect a leak,
        # rather than passing vacuously because it never looked in the right place. ----------
        planted = players[crew1].eval(
            "(() => { const c = document.querySelector('.my-card'); const s = document.createElement('span'); "
            "s.id = '__planted-secret'; s.textContent = " + json.dumps(word1) + "; c.appendChild(s); "
            "return document.querySelector('.my-card').outerHTML.includes(" + json.dumps(word1) + "); })()")
        check("[scan-self-test] a word planted into the covered card IS detected by the same outerHTML scan the checks above rely on", planted)
        players[crew1].eval("document.getElementById('__planted-secret').remove(); true")
        assert_covered(players[crew1], "planted-secret-removed-clean", word1)

        # ---------- 2. explicit reveal/hide, own authorized role only ----------
        reveal(players[crew1])
        assert_revealed_crew(players[crew1], "reveal-crew", word1)
        reveal(players[impostor1])
        assert_revealed_impostor(players[impostor1], "reveal-impostor")
        host.shot(out, "imp-cover-02-revealed")
        hide(players[impostor1])
        assert_covered(players[impostor1], "hide-impostor", word1)
        # crew1 stays revealed — hiding one player's card must not affect another's local state.
        assert_revealed_crew(players[crew1], "other-player-unaffected", word1)

        # ---------- 3. ordinary same-authority snapshot (roundPhase change) preserves an active reveal ----------
        host.click("__btn('Open voting')", "Open voting")
        players[crew1].wait("!!document.querySelector('.who-cards') || document.body.textContent.includes('voted for')", what="crew1 vote ui")
        assert_revealed_crew(players[crew1], "preserved-across-roundphase-change", word1)

        # ---------- 4. document hidden/visible conceals; returning visible does not auto-reveal ----------
        set_hidden(players[crew1], True)
        wait_for(lambda: is_revealed(players[crew1]), lambda v: not v, timeout=5, what="crew1 concealed on hidden")
        assert_covered(players[crew1], "hidden-conceals", word1)
        # While still non-live, an explicit reveal attempt must itself be rejected (not merely
        # "nothing auto-reveals") — the toggle's own key-gate, not a race with the cover sweep.
        players[crew1].eval("(document.getElementById('impostor-card-toggle')||{}).click && document.getElementById('impostor-card-toggle').click(); true")
        check("[reveal-rejected-while-non-live] crew1: explicit reveal tap while hidden stays covered", not is_revealed(players[crew1]))
        set_hidden(players[crew1], False)
        time.sleep(0.3)
        check("[visible-no-auto-reveal] crew1: staying covered after becoming visible again", not is_revealed(players[crew1]))
        reveal(players[crew1])
        assert_revealed_crew(players[crew1], "fresh-reveal-after-visibility-transition", word1)

        # ---------- 5. disconnect/reconnect conceals; reconnecting does not auto-reveal ----------
        players[crew1].call("Network.emulateNetworkConditions", offline=True, latency=0, downloadThroughput=-1, uploadThroughput=-1)
        wait_for(lambda: players[crew1].eval("document.body.dataset.conn"), lambda v: v in ("reconnecting", "fatal"), timeout=15, what="crew1 goes offline")
        wait_for(lambda: is_revealed(players[crew1]), lambda v: not v, timeout=5, what="crew1 concealed on disconnect")
        assert_covered(players[crew1], "disconnect-conceals", word1)
        players[crew1].call("Network.emulateNetworkConditions", offline=False, latency=0, downloadThroughput=-1, uploadThroughput=-1)
        wait_for(lambda: players[crew1].eval("document.body.dataset.conn"), lambda v: v == "live", timeout=10, what="crew1 back online")
        check("[reconnect-no-auto-reveal] crew1: staying covered after reconnecting", not is_revealed(players[crew1]))
        reveal(players[crew1])
        assert_revealed_crew(players[crew1], "fresh-reveal-after-reconnect", word1)

        # ---------- 6. pause/resume conceals; resuming does not auto-reveal ----------
        host.click("__btn('Pause')", "Pause")
        players[crew1].wait("!!document.querySelector('.overlay')", what="crew1 paused overlay")
        wait_for(lambda: is_revealed(players[crew1]), lambda v: not v, timeout=5, what="crew1 concealed on pause")
        host.click("__btn('Resume game')", "Resume")
        players[crew1].wait("!document.querySelector('.overlay')", what="crew1 resumed")
        check("[resume-no-auto-reveal] crew1: staying covered after resume", not is_revealed(players[crew1]))
        reveal(players[crew1])
        assert_revealed_crew(players[crew1], "fresh-reveal-after-resume", word1)

        # ---------- 7. explicit-hide retirement (the reported defect): a callback captured while
        # revealed, or one captured while covered just before a later reveal/hide cycle, must
        # never be able to re-reveal once an explicit Hide has moved past it — this is the exact
        # defect the binding review flagged ("capture the revealed button callback, press Hide,
        # then invoke the captured callback: the private crew word reappears") and the exact
        # scenario this correction's onclick fix targets, not merely a lifecycle-transition reset. ----------
        stale_revealed = players[crew1].eval("window.__staleRevealed = document.getElementById('impostor-card-toggle'); !!window.__staleRevealed")
        check("[explicit-hide-retire] captured the live REVEALED toggle node", bool(stale_revealed))
        hide(players[crew1])  # real UI click: looks up the toggle fresh and hides it
        assert_covered(players[crew1], "explicit-hide", word1)
        check("[explicit-hide-retire] re-invoking the captured revealed-state callback after Hide does not re-reveal",
              players[crew1].eval("window.__staleRevealed.click(); !document.querySelector('.my-card.revealed')"))
        assert_covered(players[crew1], "explicit-hide-retire-no-reveal", word1)
        # Now capture a callback from the COVERED state, then run a full reveal/hide cycle through
        # live UI clicks (fresh nodes each time) before invoking the old covered-state callback —
        # proving a handler captured before an earlier cycle stays retired, not just the one from
        # immediately before the most recent Hide.
        stale_covered = players[crew1].eval("window.__staleCovered = document.getElementById('impostor-card-toggle'); !!window.__staleCovered")
        check("[explicit-hide-retire] captured the live COVERED toggle node before a later cycle", bool(stale_covered))
        reveal(players[crew1])
        assert_revealed_crew(players[crew1], "explicit-hide-retire-cycle-reveal", word1)
        hide(players[crew1])
        assert_covered(players[crew1], "explicit-hide-retire-cycle-hide", word1)
        check("[explicit-hide-retire] invoking the pre-cycle covered-state callback after a later reveal/hide cycle does not re-reveal",
              players[crew1].eval("window.__staleCovered.click(); !document.querySelector('.my-card.revealed')"))
        assert_covered(players[crew1], "explicit-hide-retire-covered-callback-no-op", word1)
        # A genuinely fresh, live explicit reveal still works after all of the above.
        reveal(players[crew1])
        assert_revealed_crew(players[crew1], "fresh-reveal-after-explicit-hide-retirement", word1)

        # ---------- 8. round change (room/round authority replacement) retires an in-round captured
        # callback too, distinct from #7's same-round explicit-hide path; same device keeps its
        # covered default next round ----------
        stale_round = players[crew1].eval("window.__staleRound = document.getElementById('impostor-card-toggle'); !!window.__staleRound")
        check("[round-change-retire] captured the live revealed toggle node before the round-resolving transition", bool(stale_round))
        # The two crew members unanimously vote out the impostor, who in turn votes a crew member
        # (same deterministic pattern as real_e2e_impostor.py's rounds 2-4).
        crew_voters = [n for n in names if n != impostor1]
        for nm in crew_voters:
            players[nm].click(f"__btn({json.dumps(impostor1)})", f"{nm} votes {impostor1}")
        players[impostor1].click(f"__btn({json.dumps(crew1)})", "impostor votes a crew member")
        wait_for(lambda: (host.last_snap() or {}).get("game", {}).get("roundPhase"), lambda ph: ph == "guess_word", timeout=10, what="round1 nominee caught")
        host.click("__btn('Forfeit (no guess)')", "Forfeit")
        host.confirm(accept=True)
        wait_for(lambda: (host.last_snap() or {}).get("game", {}).get("roundPhase"), lambda ph: ph == "reveal", timeout=10, what="round1 reveal")
        host.click("__btn('Next round')", "Next round")
        wait_for(lambda: host.last_snap()["roundId"], lambda rid: rid == "g1r2", what="round g1r2")
        for nm, p in players.items():
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} round2 card")
        word2 = wait_for(crew_word, lambda v: v, what="crew word2")
        assert_covered(players[crew1], "round-change-conceals", word1 if word1 != word2 else word2)
        check("[round-change-retire] invoking the pre-round-change captured callback after the new round starts does not reveal either word",
              players[crew1].eval("window.__staleRound.click(); !document.querySelector('.my-card.revealed')"))
        check("[round-change-retire] round1 word absent from DOM after the retired-callback click", word1 not in card_html(players[crew1]))
        check("[round-change-retire] round2 word absent from DOM after the retired-callback click", word2 not in card_html(players[crew1]))
        reveal(players[crew1])
        assert_revealed_crew(players[crew1], "fresh-reveal-after-round-change", word2)
        hide(players[crew1])
        assert_covered(players[crew1], "round2-rehidden", word2)
        host.shot(out, "imp-cover-03-next-round-covered")

        # ---------- 9. spectator / missing game.you gets neutral truthful text, never a fabricated role ----------
        # Impostor itself has no LATE_SPECTATORS flag (confirmed by reading majlis-core.js's
        # Impostor module directly: no flags object, no reference anywhere in the module) — a
        # mid-game join attempt against an already-running Impostor room is unconditionally
        # rejected ("A game is in progress"), so a genuine excluded spectator must be produced
        # the real way the engine actually allows it: join while a LATE_SPECTATORS mode
        # (EscapeRoom) is running and the player roster is already at its capacity, so
        # _promote_spectators() (room_logic.py) leaves the spectator seated-but-unpromoted when
        # the room later switches to and starts Impostor. A fresh room is used here, pinned to
        # maxPlayers=3 — exactly the 3 real players already joined — via a raw same-origin
        # fetch() to /api/rooms (the server accepts a custom maxPlayers in the POST body per
        # manager.py's _validate_limit, but neither host.js's "Create room" button nor
        # transport.createRoom() expose it), with the returned hostToken written into
        # localStorage in the exact shape session.js's saveCredential('operator', ...) uses so
        # host.html's own normal resume-by-hash logic (loadCredential + hashCode) picks it up.
        host2 = new_tab("host2", base.LAPTOP, isolated=True)
        host2.goto(base_url + "/host.html")
        created = host2.eval(
            "(async () => {"
            "const res = await fetch('/api/rooms', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ maxPlayers: 3 }) });"
            "const j = await res.json();"
            "const norm = String(j.code).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 6);"
            "localStorage.setItem('majlisParty.v1.operator.' + norm, JSON.stringify({ token: j.hostToken, savedAt: Date.now() }));"
            "localStorage.setItem('majlisParty.v1.last.operator', norm);"
            "return { code: j.code, hostToken: j.hostToken, displayToken: j.displayToken };"
            "})()")
        code2 = created.get("code")
        check("[spectator-setup] raw /api/rooms bypass accepted maxPlayers:3 and returned an operator token",
              bool(code2) and bool(created.get("hostToken")), created)
        # A fragment-only navigation from the blank `host.html` load above is a same-document
        # navigation in Chrome (no new module evaluation), so host.js's hash-credential-resume
        # check at the top of its module would never re-run on a plain goto(); setting the hash
        # in-page then forcing a real reload is what actually re-executes that check.
        host2.eval("location.hash = 'code=' + " + json.dumps(code2) + "; true")
        host2.reload()
        host2.wait("(document.querySelector('.room-code')||{}).textContent === " + json.dumps(code2), what="host2 auto-resumed as operator via injected credential")
        join_url2 = host2.eval("document.querySelector('[data-join-url]').getAttribute('data-join-url')")

        names2 = ["Mina", "Rafi", "Suha"]
        players2 = {}
        for nm in names2:
            p = new_tab(nm, base.PHONE, isolated=True)
            p.goto(join_url2)
            p.type_into("#join-name", nm)
            p.click("__btn('Join game')", "Join game")
            p.wait("document.body.textContent.includes('You’re in')", what=f"{nm} lobby (room2)")
            players2[nm] = p
        host2.wait("document.querySelectorAll('.chip').length === 3", what="host2 sees 3 players (roster already at maxPlayers cap)")

        # EscapeRoom is implemented server-side (party/server/modes/escape_room.py,
        # LATE_SPECTATORS = True — confirmed by reading it directly) and room.set_mode/room.start
        # validate only `target_spec.implemented`, but modes.js's host-UI allowlist marks it
        # `playable: false` (not one of the 5 modes the UI exposes a selectable tile/Start button
        # for), confirmed by reading the actual disabled tile's rendered DOM above. Reaching it
        # therefore means dispatching the same two real, authenticated room actions the UI's own
        # click handlers would send, via the harness's established raw-action-bypass helper
        # (`__rawAct`, already injected into every tab) instead of a UI click that does not exist
        # for this mode — this is a real server-side mode switch/start, not a simulated one.
        host2.raw_act("operator", code2, "room.set_mode", {"mode": "escape_room"})
        wait_for(lambda: (host2.last_snap() or {}).get("mode"), lambda m: m == "escape_room", timeout=10, what="room2 mode switched to escape_room")
        host2.raw_act("operator", code2, "room.start", {})
        for nm, p in players2.items():
            wait_for(lambda p=p: (p.last_snap() or {}).get("mode"), lambda m: m == "escape_room", timeout=10, what=f"{nm} sees escape_room start")

        # Zayd joins mid-game: EscapeRoom's LATE_SPECTATORS lets this succeed, but the player
        # roster is already full (3/3), so apply_join() parks him in state["spectators"], never
        # state["players"] — a genuine, server-real excluded spectator, not a synthetic one.
        late = new_tab("Zayd", base.PHONE, isolated=True)
        late.goto(join_url2)
        late.type_into("#join-name", "Zayd")
        late.click("__btn('Join game')", "Join game")
        # A spectator admitted mid-game goes straight to the live game view (never the normal
        # pre-game "You're in" lobby screen a promoted player would see) — confirmed directly: the
        # real rendered page here reads "Spectating this game. Watch the team solve it."
        late.wait("document.body.textContent.includes('Spectating this game')", what="Zayd spectator game view")
        wait_for(lambda: (late.last_snap() or {}).get("mode"), lambda m: m == "escape_room", timeout=10, what="Zayd sees escape_room as spectator")
        spec_snap = late.last_snap()
        check("[spectator-setup] Zayd's mid-game join was accepted as a genuine spectator (room-level role), not rejected",
              spec_snap.get("role") == "spectator", spec_snap)

        # End EscapeRoom (room.set_mode/room.start both require phase in LOBBY/ENDED) and switch
        # to Impostor: _promote_spectators() only seats a waiting spectator while
        # len(players) < limits.max, which is false here (3 == 3), so Zayd stays excluded and
        # Impostor's own state.order is built from state.players alone — he can never appear in it.
        host2.click("__btn('End game')", "End game")
        host2.confirm(accept=True)
        wait_for(lambda: (host2.last_snap() or {}).get("phase"), lambda ph: ph == "ended", timeout=10, what="room2 escape_room ended")
        # host.js/play.js both deliberately close their SSE stream the instant phase hits
        # 'ended' (confirmed by reading host.js line ~107 and play.js line ~408) — every tab's
        # last_snap() is now frozen and will never reflect further state on its own. Once a
        # room reaches `ended`, host.js's own ended() view also only offers "Start a new room"
        # (room.close) — there is no UI path back to the mode picker for an ended room, by
        # deliberate product design. But room_logic.py's room.set_mode reducer still accepts
        # phase ENDED (confirmed by reading it) and resets phase back to LOBBY, so dispatching
        # that one real, authenticated action via the same raw_act bypass already used for
        # escape_room above, then forcing a real reload (re-running each page's own boot/resume
        # logic, which reads the saved credential and opens a fresh stream) is what lets every
        # tab observe the new state — this is still genuine server + client behavior, not a
        # simulated shortcut.
        host2.raw_act("operator", code2, "room.set_mode", {"mode": "impostor"})
        host2.reload()
        host2.wait("document.querySelector('[data-mode=impostor]').getAttribute('aria-pressed') === 'true'", what="room2 impostor mode selected after reload")
        host2.click("__btn('Start Impostor')", "Start Impostor (room2)")
        for nm, p in players2.items():
            p.reload()
            p.wait("!!document.querySelector('.my-card')", what=f"{nm} role card (room2)")

        def crew_word2():
            for nm, p in players2.items():
                you = (p.last_snap() or {}).get("game", {}).get("you", {})
                if you.get("role") == "crew" and you.get("word"):
                    return you["word"]
            return None

        word_room2 = wait_for(crew_word2, lambda v: v, what="crew word (room2)")
        late.reload()  # Zayd's own stream also closed at 'ended'; reload re-resumes and reconnects.
        wait_for(lambda: (late.last_snap() or {}).get("mode"), lambda m: m == "impostor", timeout=10, what="Zayd sees Impostor start")
        late.wait("!!document.querySelector('.my-card')", what="Zayd role card renders")
        zayd_snap = late.last_snap()
        check("[spectator-you] Zayd stayed a spectator once Impostor started (roster already at cap, never promoted)",
              zayd_snap.get("role") == "spectator", zayd_snap)
        g = zayd_snap.get("game") or {}
        check("[spectator-you] Zayd (excluded spectator): engine never sent a `you` field at all", "you" not in g, g)
        check("[spectator-you] Zayd: own card not revealed", not is_revealed(late))
        html = card_html(late)
        check("[spectator-you] Zayd: neutral spectator text shown, no fabricated role word", "watching this game" in html, html[:300])
        for secret in (word1, word2, word_room2, "Impostor"):
            check(f"[spectator-you] Zayd: {secret!r} absent from own card DOM", secret not in html, {"secret": secret})
        check("[spectator-you] Zayd: no reveal toggle offered (nothing legitimate to reveal)",
              "impostor-card-toggle" not in html)

        check("every page script ran without an exception", not any(t.page_errors() for t in list(tabs.values())),
              {k: t.page_errors()[:2] for k, t in tabs.items() if t.page_errors()})

    except Exception:
        import traceback
        check("run completed without an exception", False, traceback.format_exc()[-2000:])
    finally:
        results["finished_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        results["summary"] = {"pass": sum(1 for c in results["checks"] if c["pass"]), "fail": sum(1 for c in results["checks"] if not c["pass"]), "total": len(results["checks"])}
        json.dump(results, open(os.path.join(out, "real-results-impostor-cover.json"), "w"), ensure_ascii=False, indent=1)
        print(json.dumps(results["summary"]))
        chrome.terminate()
        try:
            srv.stdin.close()
            srv.wait(timeout=10)
        except Exception:
            srv.kill()
    sys.exit(0 if results["summary"]["fail"] == 0 else 1)


if __name__ == "__main__":
    main()
