"""Pure room-level reducer and role projection.

Room state is a plain dict containing no credentials. Tokens, presence,
replay logs and locking live in ``manager.Room``. Every function here is pure:
inputs are never mutated, and accepted transitions return a new dict.

``room.pause``/``room.resume`` additionally forward a synthetic
``game.pause``/``game.resume`` action into the active mode's own ``reduce``
when that mode sets ``HAS_TIMER = True`` (currently only ``escape_room``), so
a mode that owns a server-authoritative wall-clock timer can freeze and
unfreeze its own elapsed-time accounting. Modes without a timer never receive
these two action kinds, so this is purely additive for them.

Three further opt-in mode flags (currently only ``escape_room`` sets them;
every other mode keeps its exact previous behaviour and state shape):

* ``PRIVATE_GAME_KEYS`` -- game-state keys that no shared projection exposes
  (``escape_room``: the per-player ``cooldownUntil``). ``public_change``
  ignores them, so an accepted action that only touches them (a wrong guess
  that cannot lower a zero team score) is committed without a public
  revision bump or stream event (manager.py).
* ``STRICT_PAYLOADS`` -- every room action and every action of that mode is
  checked against an exact payload schema (``ROOM_PAYLOAD_SCHEMAS`` plus the
  mode's ``PAYLOAD_SCHEMAS``) and an envelope without unknown top-level
  fields *before* any reducer runs: unknown keys or wrong types are
  ``invalid_payload`` (``invalid_action`` for envelope fields).
* ``LATE_SPECTATORS`` -- a join while a game is playing/paused is admitted
  as a spectator (``state["spectators"]``) instead of ``game_in_progress``.
  A spectator holds an ordinary player credential, receives the
  display-level game projection with ``role: "spectator"``, may not act
  (``forbidden``), and is promoted to the roster (capacity permitting) by
  the next ``room.reset``/``room.set_mode``/``room.start``.
"""

import copy

from . import PROTOCOL
from .modes import REGISTRY, catalog, get_mode, mode_for_action
from .textutil import match_key

HARD_MIN_PLAYERS = 3
HARD_MAX_PLAYERS = 12

LOBBY = "lobby"
PLAYING = "playing"
PAUSED = "paused"
ENDED = "ended"
CLOSED = "closed"

ROOM_ACTIONS = frozenset([
    "room.set_mode", "room.start", "room.pause", "room.resume", "room.end",
    "room.reset", "room.close", "round.next",
])

# Exact payload schemas (allowed key -> required type) for room actions, used
# only when the room is in STRICT_PAYLOADS scope (see ``_strict_scope``).
# Keys are optional; presence of any other key or a wrong type is rejected.
ROOM_PAYLOAD_SCHEMAS = {
    "room.set_mode": {"mode": str},
    "room.start": {},
    "room.pause": {},
    "room.resume": {},
    "room.end": {},
    "room.reset": {"clearScores": bool},
    "room.close": {},
    "round.next": {},
}

MAX_SPECTATORS = HARD_MAX_PLAYERS


def new_room_state(code, operator_name, min_players, max_players):
    return {
        "code": code,
        "operatorName": operator_name,
        "limits": {"min": min_players, "max": max_players},
        "phase": LOBBY,
        "mode": None,
        "gameNo": 0,
        "players": [],
        "game": None,
    }


def _mode_flag(mode_id, flag):
    spec = get_mode(mode_id)
    return bool(spec is not None and spec.implemented and getattr(spec.module, flag, False))


def _name_used(state, key):
    return any(match_key(p["name"]) == key for p in state["players"]) or \
        any(match_key(p["name"]) == key for p in state.get("spectators", ()))


def is_spectator(state, player_id):
    return player_id is not None and any(p["id"] == player_id for p in state.get("spectators", ()))


def apply_join(state, player_id, name):
    """Add a new player (or, mid-game in a LATE_SPECTATORS mode, a spectator).

    Returns ``(state, None)`` or ``(state, error_code)``.
    """
    phase = state["phase"]
    if phase == CLOSED:
        return state, "room_closed"
    key = match_key(name)
    if phase in (PLAYING, PAUSED):
        if not _mode_flag(state["mode"], "LATE_SPECTATORS"):
            return state, "game_in_progress"
        if len(state.get("spectators", ())) >= MAX_SPECTATORS:
            return state, "room_full"
        if _name_used(state, key):
            return state, "name_taken"
        s = copy.deepcopy(state)
        s.setdefault("spectators", []).append({"id": player_id, "name": name})
        return s, None
    if len(state["players"]) >= state["limits"]["max"]:
        return state, "room_full"
    if _name_used(state, key):
        return state, "name_taken"
    s = copy.deepcopy(state)
    s["players"].append({"id": player_id, "name": name, "score": 0})
    return s, None


def _promote_spectators(s):
    """Seat waiting spectators in join order while the roster has room.

    Mutates ``s`` (a private copy). Spectators that do not fit keep watching;
    the key is dropped once empty so a room without spectators keeps the
    exact legacy state shape.
    """
    waiting = s.get("spectators")
    if waiting is None:
        return
    remaining = []
    for spectator in waiting:
        if len(s["players"]) < s["limits"]["max"]:
            s["players"].append({"id": spectator["id"], "name": spectator["name"], "score": 0})
        else:
            remaining.append(spectator)
    if remaining:
        s["spectators"] = remaining
    else:
        del s["spectators"]


def public_change(old_state, new_state):
    """True when an accepted transition changed anything a shared projection shows.

    Only keys listed in the active mode's ``PRIVATE_GAME_KEYS`` are ignored;
    a mode without that flag always reports a change (legacy behaviour).
    """
    spec = get_mode(new_state.get("mode"))
    private = getattr(spec.module, "PRIVATE_GAME_KEYS", ()) if (spec is not None and spec.implemented) else ()
    if not private:
        return True

    def strip(state):
        out = dict(state)
        if isinstance(out.get("game"), dict):
            out["game"] = dict((k, v) for k, v in out["game"].items() if k not in private)
        return out

    return strip(old_state) != strip(new_state)


def _strict_scope(state, kind, payload):
    if _mode_flag(state["mode"], "STRICT_PAYLOADS"):
        return True
    return kind == "room.set_mode" and _mode_flag(payload.get("mode"), "STRICT_PAYLOADS")


def _schema_error(state, kind, action, payload):
    """Exact-schema check for STRICT_PAYLOADS scope; runs before any reducer."""
    if not _strict_scope(state, kind, payload):
        return None
    if action.get("payloadWasNull"):
        return "invalid_payload"
    if kind in ROOM_PAYLOAD_SCHEMAS:
        schema = ROOM_PAYLOAD_SCHEMAS[kind]
    else:
        spec = get_mode(state["mode"])
        if spec is None or not kind.startswith(spec.action_prefix):
            return None  # wrong_mode / unknown_action are decided later
        schema = getattr(spec.module, "PAYLOAD_SCHEMAS", {}).get(kind)
        if schema is None:
            return None
    if action.get("unknownFields"):
        return "invalid_action"
    for key, value in payload.items():
        expected = schema.get(key)
        if expected is None:
            return "invalid_payload"
        if expected is bool:
            if not isinstance(value, bool):
                return "invalid_payload"
        elif not isinstance(value, expected) or isinstance(value, bool):
            return "invalid_payload"
    return None


def _sync_scores(s):
    scores = s["game"].get("scores", {}) if s["game"] else {}
    for player in s["players"]:
        if player["id"] in scores:
            player["score"] = scores[player["id"]]


def _content_error(contents, mode):
    status = contents.get(mode)
    if status is None or status.status == "content_missing":
        return "content_missing"
    if not status.ok:
        return "content_invalid"
    return None


def reduce_room(state, actor, action, server_sequence, contents, seed):
    """Apply one action. Returns ``(new_state, None)`` or ``(state, error_code)``.

    ``actor`` is token-derived ``{role, playerId}``; ``action`` is a validated
    ``{type, roundId, payload}``; ``seed`` is only consumed by ``room.start``.
    """
    role = actor.get("role")
    kind = action["type"]
    payload = action.get("payload") or {}
    round_id = action.get("roundId")
    phase = state["phase"]

    if role == "display":
        return state, "forbidden"
    if role == "player" and is_spectator(state, actor.get("playerId")):
        return state, "forbidden"
    is_room_action = kind in ROOM_ACTIONS
    spec = None if is_room_action else mode_for_action(kind)
    if not is_room_action and spec is None:
        return state, "unknown_action"
    if is_room_action and role != "operator":
        return state, "forbidden"
    schema_err = _schema_error(state, kind, action, payload)
    if schema_err:
        return state, schema_err
    if phase == CLOSED:
        return state, "room_closed"
    game = state["game"]
    if phase in (PLAYING, PAUSED) and game is not None and round_id is not None \
            and round_id != game["roundId"]:
        return state, "stale_round"

    if kind == "room.set_mode":
        target = payload.get("mode")
        target_spec = get_mode(target)
        if target_spec is None:
            return state, "unknown_mode"
        if not target_spec.implemented:
            return state, "mode_unimplemented"
        if phase not in (LOBBY, ENDED):
            return state, "invalid_phase"
        s = copy.deepcopy(state)
        s["mode"] = target
        s["phase"] = LOBBY
        s["game"] = None
        _promote_spectators(s)
        return s, None

    if kind == "room.start":
        if phase not in (LOBBY, ENDED):
            return state, "invalid_phase"
        mode_spec = get_mode(state["mode"])
        if mode_spec is None:
            return state, "mode_not_selected"
        if not mode_spec.implemented:
            return state, "mode_unimplemented"
        err = _content_error(contents, mode_spec.id)
        if err:
            return state, err
        s = copy.deepcopy(state)
        _promote_spectators(s)
        count = len(s["players"])
        if count < max(state["limits"]["min"], mode_spec.module.MIN_PLAYERS):
            return state, "not_enough_players"
        if count > state["limits"]["max"]:
            return state, "too_many_players"
        s["gameNo"] += 1
        config = {"seed": seed, "gameNo": s["gameNo"]}
        game_state, err = mode_spec.module.initialize(
            config, copy.deepcopy(s["players"]), contents[mode_spec.id].pack)
        if err:
            return state, err
        s["game"] = game_state
        s["phase"] = PLAYING
        return s, None

    if kind == "room.pause":
        if phase != PLAYING:
            return state, "invalid_phase"
        s = copy.deepcopy(state)
        s["phase"] = PAUSED
        if game is not None and getattr(REGISTRY[state["mode"]].module, "HAS_TIMER", False):
            new_game, err = REGISTRY[state["mode"]].module.reduce(
                game, actor, {"type": "game.pause", "payload": {}}, server_sequence)
            if err:
                return state, err
            s["game"] = new_game
        return s, None

    if kind == "room.resume":
        if phase != PAUSED:
            return state, "invalid_phase"
        s = copy.deepcopy(state)
        s["phase"] = PLAYING
        if game is not None and getattr(REGISTRY[state["mode"]].module, "HAS_TIMER", False):
            new_game, err = REGISTRY[state["mode"]].module.reduce(
                game, actor, {"type": "game.resume", "payload": {}}, server_sequence)
            if err:
                return state, err
            s["game"] = new_game
        return s, None

    if kind == "room.end":
        if phase not in (PLAYING, PAUSED) or game is None:
            return state, "invalid_phase"
        module = REGISTRY[state["mode"]].module
        new_game, err = module.reduce(game, actor, {"type": "game.end", "payload": {}}, server_sequence)
        if err:
            return state, err
        s = copy.deepcopy(state)
        s["game"] = new_game
        s["phase"] = ENDED
        _sync_scores(s)
        return s, None

    if kind == "room.reset":
        clear = payload.get("clearScores", False)
        if not isinstance(clear, bool):
            return state, "invalid_payload"
        s = copy.deepcopy(state)
        s["phase"] = LOBBY
        s["game"] = None
        if clear:
            for player in s["players"]:
                player["score"] = 0
        _promote_spectators(s)
        return s, None

    if kind == "room.close":
        s = copy.deepcopy(state)
        s["phase"] = CLOSED
        s["game"] = None
        return s, None

    # round.next and mode-scoped actions are delegated to the active mode.
    if phase == PAUSED:
        return state, "paused"
    if phase != PLAYING or game is None:
        return state, "invalid_phase"
    if spec is not None and spec.id != state["mode"]:
        return state, "wrong_mode"
    if round_id is None:
        return state, "round_required"
    module = REGISTRY[state["mode"]].module
    new_game, err = module.reduce(game, actor, action, server_sequence)
    if err:
        return state, err
    s = copy.deepcopy(state)
    s["game"] = new_game
    _sync_scores(s)
    return s, None


def project_room(state, viewer, revision, presence, contents):
    """Role-projected snapshot. ``viewer`` is ``{role, playerId?}``.

    Common keys follow CONTRACT.md; ``operatorName``, ``playerLimits`` and
    the operator-only ``modes`` list are documented additive fields.
    """
    role = viewer["role"]
    pid = viewer.get("playerId") if role == "player" else None
    self_view = None
    game_role = role
    if pid is not None:
        for player in state["players"]:
            if player["id"] == pid:
                self_view = {"id": player["id"], "name": player["name"]}
        for spectator in state.get("spectators", ()):
            if spectator["id"] == pid:
                self_view = {"id": spectator["id"], "name": spectator["name"]}
                role, game_role, pid = "spectator", "display", None
    players = [
        {"id": p["id"], "name": p["name"], "connected": presence.get(p["id"], 0) > 0, "score": p["score"]}
        for p in state["players"]
    ]
    game_view = None
    round_id = None
    game = state["game"]
    spec = get_mode(state["mode"])
    if game is not None and spec is not None and spec.implemented:
        game_view = spec.module.project(game, {"role": game_role, "playerId": pid})
        round_id = game["roundId"]
    snapshot = {
        "protocol": PROTOCOL,
        "code": state["code"],
        "revision": revision,
        "role": role,
        "self": self_view,
        "mode": state["mode"],
        "phase": state["phase"],
        "roundId": round_id,
        "players": players,
        "game": game_view,
        "operatorName": state["operatorName"],
        "playerLimits": dict(state["limits"]),
    }
    if "spectators" in state:
        snapshot["spectators"] = [
            {"id": p["id"], "name": p["name"], "connected": presence.get(p["id"], 0) > 0}
            for p in state["spectators"]
        ]
    if role == "operator":
        snapshot["modes"] = catalog(contents)
    return snapshot
