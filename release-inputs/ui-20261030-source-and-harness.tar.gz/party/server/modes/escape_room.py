"""Escape Room: pure initialize / reduce / project.

Cooperative mode. One frozen roster (3-8 players) shares a single team score
and a single authoritative 10-minute timer across three sequential puzzles.
At freeze time (``initialize``) every player is deterministically assigned
exactly one private clue fragment per puzzle, keyed by that player's position
in join order (``fragmentOf[pid] = order.index(pid)``). A disconnecting
player keeps its id, roster slot and fragment; nothing is ever reassigned.
A player who joins after the game has started cannot become a participant:
with ``LATE_SPECTATORS`` the room layer (room_logic.apply_join) admits them
as a *spectator* holding an ordinary player credential (no operator or
display capability is ever issued to them), projects this mode to them as
the fragment-free ``display`` view, rejects every action from them
(``forbidden``), and seats them at the next ``room.reset``/``room.set_mode``/
``room.start`` if the roster has room. A reconnecting roster player resumes
with its bearer token and keeps its id and therefore its fragments.

Round phases per puzzle: ``active`` (players may submit) -> ``solved`` (the
team solved it; the operator must call ``round.next`` to continue, so the
host can never skip an unsolved puzzle) -> next puzzle's ``active``, or,
for the third puzzle, the solve ends the game directly with
``outcome: "success"``. See ``ESCAPE_ROOM.md`` for the full contract,
including the two resolved contract adjustments this mode required
(the timer freeze hook and the lazily-committed timeout) and the fixed
test-only timer override.

Fragments and aliases are never projected to anyone before the game ends
(``project``'s ``reveal`` key); a player's own projection carries only that
player's own fragment and never another player's. No public, operator or
display projection ever carries a solution, an alias, another player's
fragment, or any content-pack metadata before reveal.
"""

import copy
import os
import time
import unicodedata

from ..content import MAX_ID, is_text
from ..textutil import clean_text, match_key

MODE_ID = "escape_room"
TITLE = "Escape Room"
ACTION_PREFIX = "escape_room."
MIN_PLAYERS = 3
MAX_PLAYERS = 8
PUZZLE_COUNT = 3
FRAGMENTS_PER_PUZZLE = MAX_PLAYERS

# Test-only acceleration hook (see ESCAPE_ROOM.md, "Resolved contract
# adjustments"). Production never sets this env var, so TIMER_SECONDS is
# always 600 (10 minutes) outside of automated tests.
TIMER_SECONDS = float(os.environ.get("ESCAPE_ROOM_TIMER_SECONDS", "600"))

MAX_PROMPT_LEN = 500
MAX_FRAGMENT_LEN = 240
MAX_HINT_LEN = 240
MAX_ANSWER_LEN = 80
MIN_ALIASES = 1
MAX_ALIASES = 20

SOLVE_POINTS = 100
WRONG_PENALTY = 5
HINT_PENALTY = 20
COOLDOWN_SECONDS = 2.0

ACTIVE = "active"
SOLVED = "solved"

OUTCOME_SUCCESS = "success"
OUTCOME_TIMEOUT = "timeout"
OUTCOME_ABORTED = "aborted"

# This mode owns a server-authoritative wall-clock timer, so room-level
# pause/resume must freeze it. See room_logic.py's ``HAS_TIMER`` forwarding
# and ESCAPE_ROOM.md.
HAS_TIMER = True

# Room-layer opt-ins (room_logic.py): ``cooldownUntil`` is per-player private
# state that no shared projection shows, so a change confined to it (a wrong
# guess that cannot lower a zero team score) commits without a public
# revision bump or stream event; every room action and every action of this
# mode is validated against an exact schema before any reducer runs; late
# joiners spectate instead of being refused.
PRIVATE_GAME_KEYS = ("cooldownUntil",)
STRICT_PAYLOADS = True
LATE_SPECTATORS = True
PAYLOAD_SCHEMAS = {
    "escape_room.answer": {"text": str},
    "escape_room.hint": {},
}


def _bilingual(d, path, en_key, ar_key, issues, max_len):
    ok = True
    if not is_text(d.get(en_key), max_len):
        issues.append("%s.%s: required non-empty string (max %d)" % (path, en_key, max_len))
        ok = False
    if not is_text(d.get(ar_key), max_len):
        issues.append("%s.%s: required non-empty string (max %d)" % (path, ar_key, max_len))
        ok = False
    return ok


def validate_item(item, path, issues):
    """Puzzle ``{id, promptEn, promptAr, fragments[8]{en,ar}, hintEn, hintAr, aliases[]}``."""
    if not isinstance(item, dict):
        issues.append(path + ": must be an object")
        return None
    before = len(issues)
    if not is_text(item.get("id"), MAX_ID):
        issues.append(path + ".id: required non-empty string (max 64)")
    _bilingual(item, path, "promptEn", "promptAr", issues, MAX_PROMPT_LEN)
    _bilingual(item, path, "hintEn", "hintAr", issues, MAX_HINT_LEN)

    fragments = item.get("fragments")
    out_fragments = None
    if not isinstance(fragments, list) or len(fragments) != FRAGMENTS_PER_PUZZLE:
        issues.append("%s.fragments: required array of exactly %d entries" % (path, FRAGMENTS_PER_PUZZLE))
    else:
        out_fragments = []
        ok = True
        for index, frag in enumerate(fragments):
            fpath = "%s.fragments[%d]" % (path, index)
            if not isinstance(frag, dict):
                issues.append(fpath + ": must be an object")
                ok = False
                continue
            if not _bilingual(frag, fpath, "en", "ar", issues, MAX_FRAGMENT_LEN):
                ok = False
                continue
            out_fragments.append({"en": frag["en"], "ar": frag["ar"]})
        if not ok:
            out_fragments = None

    aliases = item.get("aliases")
    out_aliases = None
    if not isinstance(aliases, list) or not (MIN_ALIASES <= len(aliases) <= MAX_ALIASES):
        issues.append("%s.aliases: required array of %d-%d strings" % (path, MIN_ALIASES, MAX_ALIASES))
    else:
        out_aliases = []
        ok = True
        seen = set()
        for index, alias in enumerate(aliases):
            apath = "%s.aliases[%d]" % (path, index)
            cleaned = clean_text(alias, MAX_ANSWER_LEN) if is_text(alias, MAX_ANSWER_LEN) else None
            if cleaned is None:
                issues.append(apath + ": required non-empty printable string (max %d)" % MAX_ANSWER_LEN)
                ok = False
                continue
            key = match_key(cleaned)
            if key in seen:
                issues.append(apath + ": duplicates another alias of this puzzle (case/width-insensitive)")
                ok = False
                continue
            seen.add(key)
            out_aliases.append(cleaned)
        if not ok:
            out_aliases = None

    if len(issues) != before:
        return None
    return {
        "id": item["id"],
        "promptEn": item["promptEn"],
        "promptAr": item["promptAr"],
        "hintEn": item["hintEn"],
        "hintAr": item["hintAr"],
        "fragments": out_fragments,
        "aliases": out_aliases,
    }


def validate_items(items, issues):
    """Cross-puzzle check: no alias of one puzzle may match an alias of another.

    A shared alias would let a correct answer to puzzle A also solve puzzle B,
    collapsing the "sequential, distinct puzzles" contract. Issues name paths
    only, never the colliding text.
    """
    owner = {}
    for index, item in enumerate(items):
        for alias in item["aliases"]:
            key = match_key(alias)
            first = owner.get(key)
            if first is not None and first != index:
                issues.append("items[%d].aliases: collides with an alias of items[%d] "
                              "(case/width-insensitive)" % (index, first))
            else:
                owner[key] = index


def _round_id(game_no, puzzle_index):
    return "g%dp%d" % (game_no, puzzle_index + 1)


def _elapsed(state, now):
    if state["runningSince"] is not None:
        return state["accumulatedActive"] + (now - state["runningSince"])
    return state["accumulatedActive"]


def _remaining(state, now):
    return max(0.0, TIMER_SECONDS - _elapsed(state, now))


def _freeze(s, now):
    """Stop the clock permanently (called on every path that ends the game)."""
    if s["runningSince"] is not None:
        s["accumulatedActive"] += now - s["runningSince"]
        s["runningSince"] = None


def _maybe_commit_timeout(state, now):
    """Returns an ended-by-timeout copy, or None if the timer has not expired.

    Expiry is detected lazily (consistent with the room/token expiry idiom in
    manager.py): it is always visible in ``project`` once wall-clock time
    passes the limit, and is committed into persisted state the next time any
    action reaches ``reduce``, which then absorbs that action into the
    timeout transition instead of applying it.
    """
    if state["ended"] or state["runningSince"] is None:
        return None
    if _remaining(state, now) > 0:
        return None
    s = copy.deepcopy(state)
    _freeze(s, now)
    s["ended"] = True
    s["outcome"] = OUTCOME_TIMEOUT
    return s


def initialize(config, players, content):
    """Returns ``(state, None)`` or ``(None, error_code)``."""
    order = [p["id"] for p in players]
    if len(order) < MIN_PLAYERS:
        return None, "not_enough_players"
    if len(order) > MAX_PLAYERS:
        return None, "too_many_players"
    items = content["items"]
    if len(items) < PUZZLE_COUNT:
        return None, "content_insufficient"
    puzzles = copy.deepcopy(items[:PUZZLE_COUNT])
    now = time.time()
    state = {
        "mode": MODE_ID,
        "title": content["title"],
        "gameNo": config["gameNo"],
        "seed": config["seed"],
        "order": order,
        "fragmentOf": dict((pid, index) for index, pid in enumerate(order)),
        "puzzles": puzzles,
        "puzzleIndex": 0,
        "phase": ACTIVE,
        "roundId": _round_id(config["gameNo"], 0),
        "hintUsed": [False] * PUZZLE_COUNT,
        "teamScore": 0,
        "scores": dict((p["id"], p["score"]) for p in players),
        "cooldownUntil": {},
        "accumulatedActive": 0.0,
        "runningSince": now,
        "ended": False,
        "outcome": None,
    }
    return state, None


def _sync_team_score(s):
    for pid in s["order"]:
        s["scores"][pid] = s["teamScore"]


def reduce(state, actor, action, server_sequence):
    """Pure transition. Returns ``(new_state, None)`` or ``(state, error_code)``.

    The input state is never mutated; accepted transitions return a copy.
    Every call first checks wall-clock timer expiry (see
    ``_maybe_commit_timeout``) before dispatching the actual action.
    """
    now = time.time()
    timed_out = _maybe_commit_timeout(state, now)
    if timed_out is not None:
        return timed_out, None

    kind = action.get("type")
    payload = action.get("payload")
    if payload is None:
        payload = {}
    if not isinstance(payload, dict):
        return state, "invalid_payload"
    role = actor.get("role")
    pid = actor.get("playerId")
    round_id = action.get("roundId")
    if round_id is not None and round_id != state["roundId"]:
        return state, "stale_round"

    if kind == "game.end":
        if role != "operator":
            return state, "forbidden"
        if state["ended"]:
            return state, "invalid_phase"
        s = copy.deepcopy(state)
        _freeze(s, now)
        s["ended"] = True
        s["outcome"] = OUTCOME_ABORTED
        return s, None

    if state["ended"]:
        return state, "invalid_phase"

    if kind == "game.pause":
        # Forwarded only for HAS_TIMER modes when the room transitions to
        # paused (room_logic.py); role is already gated operator there.
        if role != "operator":
            return state, "forbidden"
        if state["runningSince"] is None:
            return state, None
        s = copy.deepcopy(state)
        s["accumulatedActive"] += now - s["runningSince"]
        s["runningSince"] = None
        return s, None

    if kind == "game.resume":
        if role != "operator":
            return state, "forbidden"
        if state["runningSince"] is not None:
            return state, None
        s = copy.deepcopy(state)
        s["runningSince"] = now
        return s, None

    if state["runningSince"] is None:
        # Room-level pause already rejects with "paused" before reaching
        # here for ordinary mode actions; this guards the mode-owned
        # game.pause/game.resume/game.end bypass above from leaving a
        # paused game answerable to round.next/answer/hint.
        return state, "paused"

    phase = state["phase"]
    index = state["puzzleIndex"]

    if kind == "escape_room.answer":
        if role != "player" or pid not in state["order"]:
            return state, "forbidden"
        if set(payload.keys()) - {"text"} or not isinstance(payload.get("text"), str):
            return state, "invalid_payload"
        if phase != ACTIVE:
            return state, "invalid_phase"
        if state["cooldownUntil"].get(pid, 0.0) > now:
            return state, "cooldown"
        text = clean_text(payload.get("text"), MAX_ANSWER_LEN)
        if text is None:
            return state, "invalid_payload"
        s = copy.deepcopy(state)
        puzzle = s["puzzles"][index]
        key = match_key(text)
        if any(match_key(alias) == key for alias in puzzle["aliases"]):
            s["teamScore"] += SOLVE_POINTS
            s["phase"] = SOLVED
            if index == PUZZLE_COUNT - 1:
                _freeze(s, now)
                s["ended"] = True
                s["outcome"] = OUTCOME_SUCCESS
        else:
            s["teamScore"] = max(0, s["teamScore"] - WRONG_PENALTY)
            s["cooldownUntil"][pid] = now + COOLDOWN_SECONDS
        _sync_team_score(s)
        return s, None

    if kind == "escape_room.hint":
        if role != "operator":
            return state, "forbidden"
        if payload:
            return state, "invalid_payload"
        if phase != ACTIVE:
            return state, "invalid_phase"
        if state["hintUsed"][index]:
            return state, "already_hinted"
        s = copy.deepcopy(state)
        s["hintUsed"][index] = True
        s["teamScore"] = max(0, s["teamScore"] - HINT_PENALTY)
        _sync_team_score(s)
        return s, None

    if kind == "round.next":
        if role != "operator":
            return state, "forbidden"
        if payload:
            return state, "invalid_payload"
        if phase != SOLVED:
            return state, "invalid_phase"
        if index + 1 >= PUZZLE_COUNT:
            return state, "invalid_phase"
        s = copy.deepcopy(state)
        s["puzzleIndex"] = index + 1
        s["phase"] = ACTIVE
        s["roundId"] = _round_id(s["gameNo"], s["puzzleIndex"])
        return s, None

    return state, "unknown_action"


def _public_puzzle(puzzle, hint_used):
    out = {"id": puzzle["id"], "promptEn": puzzle["promptEn"], "promptAr": puzzle["promptAr"]}
    if hint_used:
        out["hintEn"] = puzzle["hintEn"]
        out["hintAr"] = puzzle["hintAr"]
    return out


def project(state, viewer):
    """Role projection. ``viewer`` is ``{role, playerId?}``. Pure.

    Nobody sees any fragment, alias or solution before the game ends. A
    player sees only their own fragment for the current puzzle; operator and
    display see no fragment at all pre-reveal. At end (success, timeout or
    operator abort) every viewer receives the full reveal: every puzzle's
    answer and every player's fragment for every puzzle.
    """
    role = viewer.get("role")
    me = viewer.get("playerId") if role == "player" else None
    if me is not None and me not in state["order"]:
        role, me = "display", None
    order = state["order"]
    now = time.time()
    remaining = _remaining(state, now)
    live_timeout = (not state["ended"]) and state["runningSince"] is not None and remaining <= 0
    ended = state["ended"] or live_timeout
    outcome = state["outcome"] if state["ended"] else (OUTCOME_TIMEOUT if live_timeout else None)
    index = state["puzzleIndex"]
    solved_count = index + (1 if (state["phase"] == SOLVED or (ended and outcome == OUTCOME_SUCCESS)) else 0)

    view = {
        "title": state["title"],
        "phase": "ended" if ended else state["phase"],
        "outcome": outcome,
        "puzzleIndex": index,
        "puzzleCount": PUZZLE_COUNT,
        "solvedCount": solved_count,
        "remainingSeconds": round(remaining, 1),
        "order": list(order),
        "currentPuzzle": None if ended else _public_puzzle(state["puzzles"][index], state["hintUsed"][index]),
    }

    if ended:
        view["reveal"] = {
            "puzzles": [
                {
                    "id": puzzle["id"],
                    "promptEn": puzzle["promptEn"],
                    "promptAr": puzzle["promptAr"],
                    "answer": puzzle["aliases"][0],
                    "aliases": list(puzzle["aliases"]),
                    "fragments": dict(
                        (pid, dict(puzzle["fragments"][state["fragmentOf"][pid]])) for pid in order
                    ),
                }
                for puzzle in state["puzzles"]
            ],
        }
    elif role == "player":
        fragment = state["puzzles"][index]["fragments"][state["fragmentOf"][me]]
        view["you"] = {
            "fragment": dict(fragment),
            "cooldownSeconds": round(max(0.0, state["cooldownUntil"].get(me, 0.0) - now), 1),
        }

    return view
