"""Mode registry.

All ten contract mode ids are declared. Only ``who_am_i``, ``feud``,
``impostor`` and ``escape_room`` are implemented; the other six are
``implemented: False`` and the room rejects selecting or starting them
(``mode_unimplemented``). Even an implemented mode is not presented as
playable until a reviewed player/operator/display UI loop exists for it
(``escape_room`` is engine/native-only at this point; see ESCAPE_ROOM.md).

An implemented mode module provides ``MODE_ID``, ``TITLE``, ``ACTION_PREFIX``,
``MIN_PLAYERS``, ``validate_item(item, path, issues)``,
``initialize(config, players, content)``,
``reduce(state, actor, action, serverSequence)`` and ``project(state, viewer)``.
A mode that owns its own server-authoritative timer additionally sets
``HAS_TIMER = True`` and handles the synthetic ``game.pause``/``game.resume``
action kinds in ``reduce`` (room_logic.py forwards ``room.pause``/
``room.resume`` to such a mode so it can freeze/unfreeze elapsed time).
"""

import collections

from . import escape_room, feud, impostor, who_am_i


class ModeSpec(object):
    __slots__ = ("id", "title", "implemented", "module", "action_prefix")

    def __init__(self, mode_id, title, module=None, action_prefix=None):
        self.id = mode_id
        self.title = title
        self.module = module
        self.implemented = module is not None
        self.action_prefix = action_prefix


def _build():
    specs = [
        ModeSpec(who_am_i.MODE_ID, who_am_i.TITLE, who_am_i, who_am_i.ACTION_PREFIX),
        ModeSpec(feud.MODE_ID, feud.TITLE, feud, feud.ACTION_PREFIX),
        ModeSpec(impostor.MODE_ID, impostor.TITLE, impostor, impostor.ACTION_PREFIX),
        ModeSpec("draw_guess", "Draw & Guess", action_prefix="draw_guess."),
        ModeSpec("drawing_chain", "Drawing Chain", action_prefix="drawing_chain."),
        ModeSpec("bluff", "Bluff", action_prefix="bluff."),
        ModeSpec("werewolf", "Werewolf", action_prefix="werewolf."),
        ModeSpec("taboo", "Forbidden Words", action_prefix="taboo."),
        ModeSpec("wavelength", "Spectrum", action_prefix="wavelength."),
        ModeSpec(escape_room.MODE_ID, escape_room.TITLE, escape_room, escape_room.ACTION_PREFIX),
    ]
    return collections.OrderedDict((s.id, s) for s in specs)


REGISTRY = _build()


def get_mode(mode_id):
    return REGISTRY.get(mode_id) if isinstance(mode_id, str) else None


def mode_for_action(action_type):
    """Mode spec owning a mode-scoped action type, or None."""
    for spec in REGISTRY.values():
        if action_type.startswith(spec.action_prefix):
            return spec
    return None


def catalog(contents):
    """Public, secret-free list of modes with implementation/content status."""
    out = []
    for spec in REGISTRY.values():
        status = contents.get(spec.id)
        out.append({
            "id": spec.id,
            "title": spec.title,
            "implemented": spec.implemented,
            "content": status.status if (spec.implemented and status is not None) else None,
        })
    return out
