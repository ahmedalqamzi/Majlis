# Escape Room mode: wire reference (backend candidate N03-02 / escape-room-delivery-v2)

Module: `party/server/modes/escape_room.py` (reference) / the `EscapeRoom` module inside
`party/core/majlis-core.js` (native/browser engine — the production code path). Mode id
`escape_room`, action prefix `escape_room.`. Engine + HTTP/SSE candidate only: no browser UI
renders it yet, and it has not been accepted as a playable game on any phone, TV or network.

Everything below sits inside the generic room protocol in `../README.md`: same envelope
`{actionId, type, roundId?, payload?}`, the same per-principal replay log, the room lock and
receipt sequence, `paused`/`stale_round`/`round_required`/`wrong_mode` checks in
`room_logic.reduce_room`/`reduceRoom`, and the same `project_room`/`projectRoom` snapshot.
Only `game` is mode-specific.

## Content

Pack `escape_room.json`, standard envelope `{schemaVersion:1, mode:"escape_room", title,
licenseNote, items}`. Each item is a puzzle:

| Field | Rule |
| --- | --- |
| `id` | non-empty string, max 64; unique within the pack |
| `promptEn`/`promptAr` | non-empty, max 500 |
| `fragments` | exactly 8 objects `{en, ar}`, each non-empty, max 240 — one clue per seated player slot (max room size), round-robin assigned by seat order |
| `hintEn`/`hintAr` | non-empty, max 240 |
| `aliases` | 1-20 non-empty strings, max 80; the first alias is the canonical `answer` echoed in the reveal; aliases are matched with the same NFKC `matchKey` as the rest of the engine, and are checked for cross-puzzle collisions at validation time (two puzzles sharing a matchable alias make the pack `content_invalid`) |

The pack needs exactly `PUZZLE_COUNT` (3) items; a game is always the same 3 puzzles played
in pack order (no shuffling, no content exhaustion across games — each game restarts the
sequence from puzzle 1).

## Game shape

3-8 players. One shared 10-minute room timer (`HAS_TIMER = true`, see below) covering all 3
puzzles. Each puzzle gives every seated player a distinct fragment (round-robin over
`fragments[0..7]` by seat order, clipped to however many players are seated — redundant
fragments beyond the seated count exist purely so the same content pack still works at any
room size from 3 to 8 without re-authoring). Any player may submit `escape_room.answer`;
a correct submission (matched via `matchKey` against any alias) solves the puzzle for
everyone; the host then explicitly advances with `round.next` (matching the Feud/Impostor
round-break convention), which is rejected `invalid_phase` before a solve. A wrong submission
costs `WRONG_PENALTY` (5) points and starts a `COOLDOWN_SECONDS` (2.0) per-player cooldown
(`cooldown`, 429) before that player may submit again. Any operator may request
`escape_room.hint` once per puzzle (`HINT_PENALTY` 20 points, team-wide, applied once); a
second hint on the same puzzle is rejected `already_hinted` (409). Scores are a single shared
team score mirrored onto every seated player's `score` field (there is no individual
leaderboard — escape rooms are cooperative, not competitive).

Outcomes: `success` (all 3 puzzles solved before the timer), `timeout` (10 minutes elapse
with puzzles remaining), `aborted` (operator ends the game early via `room.end`). All three
produce the same full `reveal` shape.

## `now`-threading and `HAS_TIMER`

Escape Room is the **first mode in the whole engine that needs wall-clock time inside
`reduce`/`project`/`initialize`** (every earlier mode — WhoAmI, Feud, Impostor — is a pure
turn-based reducer with no timer). `majlis-core.js`'s own header forbids internal `Date`,
timer, or `Math.random` access: time must arrive as an explicit `now` (seconds, double)
argument supplied by the caller at every layer. Adding the first `HAS_TIMER`-owning mode
required threading `now` all the way down through `RoomManager` → `reduceRoom`/`projectRoom`
→ `module.reduce`/`project`/`initialize`, which previously stopped one layer short because
nothing needed it yet. The Python reference (`room_logic.py`) already had this threading from
an earlier mode-agnostic pass; this delivery brought the JS engine up to the same contract.

Modes opt in with `HAS_TIMER = true` (checked via `getMode(mode).module.HAS_TIMER`) to receive
synthetic `game.pause`/`game.resume` reduce calls when the room itself is paused/resumed
(`room.pause`/`room.resume`), so a HAS_TIMER mode's own state can freeze/unfreeze elapsed time
(`escape_room`'s `_freeze(state, now)` folds elapsed wall-clock time into the stored
`accumulatedActive` total and nulls `runningSince` while paused, so time spent paused is never
counted and resuming never charges it twice) without every other mode
needing to know pause/resume exists at all.

**Lazy-expiry / absorbed-action idiom**: the engine never runs a background timer. Expiry is
detected lazily, the first time *any* `reduce()` or `project()` call happens after the
wall-clock deadline has passed (`maybeCommitTimeout`). The action that happens to trigger that
detection is *absorbed* into the timeout commit — it is accepted (200, revision bumped) but
has no further effect of its own (e.g. a `round.next` submitted a moment after the timer
expired does not advance the puzzle; it just causes the `timeout` ending to be committed).
Room-level `phase` stays `"playing"` until that commit happens, decoupled from the mode's own
internal `ended` flag, which can already be true in-memory before any caller observes it.

A game that ends on its own (`success` or `timeout`) leaves the room `phase` at `"playing"`
with `game.phase == "ended"` (same convention as Feud/WhoAmI): the operator starts the next
game with `room.reset` then `room.start`. `room.end` only aborts a live game; on an
already-ended game it is rejected `invalid_phase` with no state change.

**Known asymmetry — no test-acceleration hook in JS/native (timeout path verified in real time).** The Python reference exposes
`ESCAPE_ROOM_TIMER_SECONDS` (env var) so `tests/http_verify_timeout.py`-style scripts can
run the full 10-minute timeout path in a few seconds. The JS/native engine architecturally
cannot read environment variables (same `now`/`EntropyPool`-only contract above), and no
mode-specific config-override mechanism exists in `ServerConfig`/`CONFIG_DEFAULTS` to add one
without widening scope beyond this brief. `TIMER_SECONDS()` in the JS port is therefore a
fixed `600.0`, matching Python's production default exactly. There is still no acceleration
hook, so correction-v3 verified the native timeout path in real time instead
(`evidence/escape-room-correction-v3/native/prod-v3-timer.log`). The run used a fresh
production binary through the operator bridge, with 3 authenticated players on SSE.
- After a 20 s pause, the game was still active at wall 603 s.
- After expiry, a read projected ended/timeout plus the reveal lazily, with no revision bump.
- The first action after expiry was absorbed (200) and committed the timeout (+1 revision, SSE
  frame with outcome timeout and no solve credited).
- Later answers returned 409 invalid_phase.

The env override remains Python-only.

## Private revision (correction-v3)

`escape_room` declares `PRIVATE_GAME_KEYS = ("cooldownUntil",)`. `RoomManager.submit_action`
/ `submitAction` compares the old and new room state with those keys removed from `game`
(`room_logic.public_change` / `publicChange`); if nothing else changed, the action is still
committed (state, cooldown and per-principal replay log are updated, the response is
`200 {accepted:true, revision}`), but the room `revision` is **not** bumped and no SSE frame is
emitted to anyone. In practice that is a wrong guess while the team score is already 0 (the
penalty clamps at 0, so only the guesser's cooldown changes). Any visible change still bumps:
a solve, a wrong guess that lowers the score, hint, pause/resume, `round.next`, timeout commit
(including an absorbed action), `room.end`, reset/start. No counter of private actions exists
anywhere in the public state. Modes without `PRIVATE_GAME_KEYS` keep the unconditional bump.

## Strict payload schemas (correction-v3)

With `STRICT_PAYLOADS = True`, every action submitted while the room's mode is `escape_room`
(and `room.set_mode` targeting it) is validated before any reducer runs or any state is copied:

| Action | Allowed payload |
| --- | --- |
| `room.set_mode` | `{mode: str}` |
| `room.reset` | `{clearScores?: bool}` |
| `room.start`, `room.pause`, `room.resume`, `room.end`, `room.close`, `round.next` | `{}` (or omitted) |
| `escape_room.answer` | `{text: str}` |
| `escape_room.hint` | `{}` (or omitted) |

An unknown payload key or a wrong type (`bool` must be a real boolean, `str` a real string,
`null` is not a string) is rejected `invalid_payload` (400); an unknown envelope key (anything
outside `actionId`, `type`, `roundId`, `payload`) is rejected `invalid_action` (400). Both
leave the room state byte-for-byte unchanged, bump nothing, and cannot trigger the lazy timeout
commit. Sibling modes are unaffected (lenient, as before).

## Late joiners: spectators (correction-v3)

With `LATE_SPECTATORS = True`, `POST /api/rooms/{code}/join` with a new name while the room is
`playing`/`paused` no longer fails `game_in_progress`: the joiner gets an ordinary player
token (same adapter auth, same `/state` and `/events` routes, no new credential type, no host
or display secret) and is recorded in the room's `spectators` list. Their snapshot has
`role: "spectator"`, `self: {id, name}`, and `game` projected exactly as the public display
sees it (no fragment, no answer, no hint before it is used). Any action they submit is
rejected `forbidden` (403). Names are unique across players and spectators (`name_taken`), and
spectators count against their own cap (`room_full` beyond 12).

At the next `room.reset`, `room.set_mode` or `room.start`, spectators are seated as players
in join order while the roster limit allows (score 0); any left over stay spectators. A
roster player who reconnects (bearer re-join, or a new SSE stream) keeps the same id, seat
and fragments; their own projection is unchanged. Snapshots include a public
`spectators: [{id, name, connected}]` list only while at least one spectator exists.

## Errors specific to this mode

`cooldown` (429) and `already_hinted` (409) are new error codes added to both the Python
`ERRORS` table and the JS `ERRORS` table in this delivery (previously registered in neither,
since no earlier mode produced them — an unregistered code falls back to `internal_error`
(500) via each table's `PartyError`/`get_error_response`-style default, which is exactly the
bug the native HTTP verification run caught and this delivery fixed).
