import XCTest

final class NativeUIReviewTests: XCTestCase {
    func capture(_ name: String, app: XCUIApplication) {
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = name
        attachment.lifetime = .keepAlways
        add(attachment)
        let tree = XCTAttachment(string: app.debugDescription)
        tree.name = name + "-accessibility"
        tree.lifetime = .keepAlways
        add(tree)
    }
    @MainActor func testNativeHomeLobbyAndPicker() throws {
        continueAfterFailure = false
        let app = XCUIApplication()
        app.launch()
        let host = app.buttons["Host a game"]
        XCTAssertTrue(host.waitForExistence(timeout: 20), "Native home host button missing")
        capture("01-native-home", app: app)
        host.tap()
        let lobby = app.staticTexts["Scan in. Settle in."]
        if !lobby.waitForExistence(timeout: 25) {
            capture("02-native-host-failure", app: app)
            XCTFail("Native host did not reach room lobby")
            return
        }
        capture("02-native-lobby", app: app)
        let picker = app.staticTexts["What are we playing?"]
        for _ in 0..<5 {
            if picker.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(picker.exists, "Full-name game picker missing")
        capture("03-native-game-picker", app: app)
        let choose = app.buttons["Choose Who Am I?"]
        for _ in 0..<6 {
            if choose.isHittable { break }
            app.swipeUp()
        }
        XCTAssertTrue(choose.isHittable, "Choose game action unreachable")
        capture("04-native-picker-action", app: app)
        choose.tap()
        XCTAssertTrue(app.buttons["Start game"].waitForExistence(timeout: 10))
        capture("05-native-selected-mode", app: app)
    }
}
