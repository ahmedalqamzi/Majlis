import SwiftUI
import CoreImage.CIFilterBuiltins
import UIKit

// Pure, SwiftUI-free helpers for the lobby Start gate and the taboo room.start payload bridge —
// pulled out of roomControls(phase:) verbatim (same expression, no behavior change) so they can be
// extracted by signature and run under plain `swiftc` in a sandbox with no Xcode project, the same
// technique tests/taboo-correction-v1/extract.py already uses for party/web/js/play.js.
func rosterGateDisabled(mode: String?, count: Int, min: Int, max: Int) -> Bool {
    mode == nil || count < min || count > max
}

func roomStartPayload(mode: String?, turnSeconds: Int) -> [String: Any]? {
    mode == "taboo" ? ["modeConfig": ["turnSeconds": turnSeconds]] : nil
}

// Native first-pair operator screen (L02A item 6): mode pick, host, QR +
// full address, round/lifecycle controls, player list with scores, explicit
// pause/resume, and now the full private operator controls for Who Am I and
// Majlis Feud — all through PartyLifecycleCoordinator's in-process bridge,
// never a second network hop. This mirrors the *operator's* slice of
// party/web/js/host.js (lines ~279-400 for the per-mode panels), not the
// player surface: per party/core/majlis-core.js's reduceRoom, only
// ROOM_ACTIONS (room.set_mode/start/pause/resume/end/reset/close,
// round.next) and the per-mode operator-only actions below are ever
// operator-submitted — player guesses/buzzes are player-submitted over the
// player HTTP surface this view never touches.
//
// Mode selection (L02A blocker 1): RoomManager.createRoom ignores any mode
// in the create body, so hosting always starts in the lobby with no mode
// selected; the operator must explicitly room.set_mode before room.start is
// accepted (reduceRoom rejects room.start with mode_not_selected otherwise).
//
// Not checkable with standalone swiftc in this sandbox (SwiftUI/UIKit; see
// PartyLifecycleCoordinator.swift's own note) — written and reasoned from
// the real wire shapes (party/core/majlis-core.js's projectRoom and the
// WhoAmI/Feud modules' own project() functions, already read this session)
// but not build-verified here. A genuine engine-exposed round/scoring
// "replay" or history feed was not found in party/core (projectRoom exposes
// only live phase/round/players/scores, no separate history log) — this
// view intentionally does not fabricate one; "replay" means a new
// round/game via round.next/room.reset/room.start.
@MainActor
struct OperatorView: View {
    @StateObject private var coordinator: PartyLifecycleCoordinator
    @State private var selectedMode = "who_am_i"
    @State private var state: [String: Any]?
    @State private var lastError: String?
    @State private var pollTimer: Timer?
    // Taboo's own bounded turn length, forwarded as room.start's
    // payload.modeConfig.turnSeconds. Bounds mirror party/core/majlis-core.js's
    // own DEFAULT/MIN/MAX_TURN_SECONDS (60/10/180): the engine re-validates and
    // rejects out-of-range values itself, so this Stepper's range only keeps the
    // operator from building a request the engine would refuse.
    @State private var tabooTurnSeconds: Double = 60
    // Bluff round count (1-10, engine default 3 — party/core/majlis-core.js
    // Bluff MAX_ROUNDS/DEFAULT_ROUNDS) and voting language (en/ar), chosen
    // once in the lobby before room.start, mirroring party/web/js/host.js's
    // bluffStartConfig(). The engine's own Bluff.initialize validation is
    // what actually enforces the bounds; this UI just offers the same range.
    @State private var bluffRounds = 3
    @State private var bluffLanguage = "en"

    private static let modes = [("who_am_i", "Who Am I?"), ("feud", "Majlis Feud"), ("impostor", "Impostor"), ("taboo", "Taboo"), ("bluff", "Bluff"), ("escape_room", "Escape Room")]

    private static let impostorOutcomes: [String: String] = [
        "impostor_survived": "Nobody caught the impostor.",
        "impostor_guessed_word": "The impostor guessed the word!",
        "crew_wrong_guess": "The impostor guessed wrong.",
        "crew_forfeit": "The host ended the guess.",
        "aborted": "The round ended early.",
    ]

    /// All mode-specific gameplay state (pendingGuesses, revealed,
    /// assignments, buzzer, control, answers, strikes, ...) sits nested
    /// under `game` in party/core/majlis-core.js's projectRoom; only
    /// mode/phase/roundId/players/playerLimits are top-level (L02A blocker 2
    /// — the panels below were reading these off `state` directly).
    private var game: [String: Any]? { state?["game"] as? [String: Any] }

    /// Pure grouping helper kept outside any ViewBuilder context: SwiftUI's
    /// result builder rejects an imperative `for` loop inside a view closure
    /// ("closure containing control flow statement cannot be used with
    /// result builder 'ViewBuilder'"), which is what bluffPanel's reveal case
    /// used to do inline to turn last["voters"] (pid -> optionId) into
    /// optionId -> [display name]. reduce(into:) is a single expression, so
    /// the call site stays a plain `let` inside the builder.
    private static func votersByOption(_ voters: [String: String], names: [String: String]) -> [String: [String]] {
        voters.reduce(into: [String: [String]]()) { acc, entry in
            let (pid, optionId) = entry
            acc[optionId, default: []].append(names[pid] ?? pid)
        }
    }

    private func playerNames() -> [String: String] {
        var out: [String: String] = [:]
        for p in (state?["players"] as? [[String: Any]]) ?? [] {
            if let id = p["id"] as? String { out[id] = (p["name"] as? String) ?? id }
        }
        return out
    }

    init(makeHost: @escaping () throws -> PartyHost) {
        // No longer `try!`: PartyLifecycleCoordinator.init does not throw —
        // a failed makeHost() is reported as `.failed(...)` instead of
        // crashing the app on launch (L02A blocker 7).
        _coordinator = StateObject(wrappedValue: PartyLifecycleCoordinator(makeHost: makeHost))
    }

    var body: some View {
        VStack(spacing: 16) {
            switch coordinator.status {
            case .stopped, .failed:
                startScreen
            case .starting:
                ProgressView().tint(.white)
            case .reconnecting:
                // Unlike hostingScreen, this has no onAppear by default — a
                // tab return while already in .reconnecting (as opposed to a
                // real OS foreground/background transition, which the
                // top-level .onReceive below already handles) had no wired
                // route to coordinator.onForeground(), so the view was stuck
                // showing a spinner instead of reaching .pausedResumable/
                // .ended once the pause window closed (L02A blocker 7).
                ProgressView().tint(.white)
                    .onAppear { coordinator.onViewVisible() }
            case .hosting(let host, let port, let code):
                hostingScreen(host: host, port: port, code: code)
            case .pausedResumable(let code):
                pausedScreen(code: code)
            case .resumeFailed(let code, let message):
                resumeFailedScreen(code: code, message: message)
            case .ended(let reason):
                endedScreen(reason: reason)
            }
            if let lastError {
                Text(lastError).foregroundColor(.red).font(.footnote)
            }
        }
        .padding()
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.didEnterBackgroundNotification)) { _ in
            coordinator.onBackground()
        }
        .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
            coordinator.onForeground()
        }
    }

    private var startScreen: some View {
        VStack(spacing: 12) {
            if case .failed(let msg) = coordinator.status {
                Text("Could not start: \(msg)").foregroundColor(.red)
            }
            // Mode is picked in the lobby once the room exists (see
            // roomControls' "lobby" case below), not here: createRoom
            // ignores any mode passed in the create body (blocker 1).
            Button("Host a Room") {
                lastError = nil
                coordinator.startHosting(body: [:])
            }
            .buttonStyle(.borderedProminent)
        }
    }

    private func hostingScreen(host: String, port: UInt16, code: String) -> some View {
        let address = "http://\(host):\(port)/play.html?code=\(code)"
        // Scrollable: the per-mode panels below (whoAmIPanel/feudPanel) can
        // grow past the screen height once a room has several players and
        // pending guesses/answers (L02A blocker 2 — "missing
        // scroll/reachability verification for the large VStack").
        return ScrollView { VStack(spacing: 12) {
            Text(code).font(.system(size: 44, weight: .bold, design: .monospaced))
            if let qr = Self.qrImage(from: address) {
                Image(uiImage: qr).interpolation(.none).resizable()
                    .frame(width: 180, height: 180)
            }
            Text(address).font(.footnote).textSelection(.enabled)

            if let phase = state?["phase"] as? String {
                Text("Phase: \(phase)")
                // Round identity is party/core's own String id (e.g.
                // "g1r1"/"g1b1"), never numeric — a stale Int cast here
                // silently dropped every round label (L02A blocker 3).
                if let roundId = state?["roundId"] as? String { Text("Round: \(roundId)") }
            }

            if let players = state?["players"] as? [[String: Any]], !players.isEmpty {
                List(players.indices, id: \.self) { i in
                    let p = players[i]
                    HStack {
                        Text((p["name"] as? String) ?? "?")
                        if (p["connected"] as? Bool) != true { Text("(offline)").foregroundColor(.secondary) }
                        Spacer()
                        Text("\(p["score"] as? Int ?? 0)")
                    }
                }
                .frame(maxHeight: 160)
            }

            // room.set_mode is accepted by the reducer from "lobby" OR
            // "ended" (reduceRoom has no phase guard on it besides those
            // two) — restricting this to "lobby" left no way to pick a mode
            // again after room.end (L02A blocker 2).
            let currentPhase = state?["phase"] as? String
            if currentPhase == nil || currentPhase == "lobby" || currentPhase == "ended" {
                modePicker()
                // Bluff-only settings, offered once mode is actually set to
                // "bluff" (room.set_mode already accepted) and before
                // room.start — same place/same two fields as host.js's
                // bluffStartConfig(), read by roomControls' Start button below.
                if (state?["mode"] as? String) == "bluff" {
                    bluffStartConfig()
                }
            }
            modePanel(phase: currentPhase)
            roomControls(phase: currentPhase)
        } }
        .onAppear {
            startPolling()
            coordinator.onViewVisible()
        }
        .onDisappear {
            stopPolling()
            coordinator.onViewHidden()
        }
    }

    /// The private operator affordances that ROOM_ACTIONS alone can't reach
    /// (L02A blocker 2): per-mode panels ported from party/web/js/host.js's
    /// whoAmIPanel/feudPanel. Rendered only while actually playing a round;
    /// lobby/paused/ended show nothing here (roomControls covers those).
    private func modePanel(phase: String?) -> some View {
        Group {
            // party/core never produces a room-level phase called
            // "round_end" (that string only ever appears as a per-mode
            // roundPhase nested under `game`) — the old check was dead code
            // that hid these panels for the entire "paused" phase too, which
            // is exactly when an operator most needs to see pending
            // guesses/the buzzer before resuming (L02A blocker 2).
            if phase == "playing" || phase == "paused" {
                switch state?["mode"] as? String {
                case "who_am_i": whoAmIPanel
                case "feud": feudPanel
                case "impostor": impostorPanel
                case "taboo": tabooPanel
                case "bluff": bluffPanel
                case "escape_room": escapeRoomPanel
                default: EmptyView()
                }
            }
        }
    }

    private var whoAmIPanel: some View {
        // All of the following were read straight off the top-level `state`
        // dict before, but party/core/majlis-core.js's WhoAmI project()
        // nests every one of them under `game`, and types pendingGuesses /
        // revealed as arrays of player-id strings, not a dict list / Bool
        // (L02A blocker 2).
        let roundId = state?["roundId"] as? String
        let roundPhase = game?["roundPhase"] as? String
        let pendingIds = (game?["pendingGuesses"] as? [String]) ?? []
        let guesses = (game?["guesses"] as? [String: String]) ?? [:]
        let assignments = (game?["assignments"] as? [String: [String: Any]]) ?? [:]
        let names = playerNames()
        return VStack(alignment: .leading, spacing: 8) {
            Text("Who Am I — round \(roundId ?? "?")").font(.headline)
            if !pendingIds.isEmpty {
                Text("Pending guesses").font(.subheadline)
                ForEach(pendingIds, id: \.self) { playerId in
                    HStack {
                        Text(names[playerId] ?? playerId)
                        if let g = guesses[playerId] { Text("\u{201c}\(g)\u{201d}").foregroundColor(.secondary) }
                        Spacer()
                        Button("Award") { send("whoami.award", payload: ["playerId": playerId], roundId: roundId) }
                            .buttonStyle(.borderedProminent)
                        Button("Dismiss") { send("whoami.dismiss", payload: ["playerId": playerId], roundId: roundId) }
                            .buttonStyle(.bordered)
                    }
                }
            }
            if roundPhase != "revealed" {
                Button("Reveal All") { send("whoami.reveal", roundId: roundId) }
                    .buttonStyle(.bordered)
            }
            if !assignments.isEmpty {
                Text("Assignments").font(.subheadline)
                ForEach(assignments.keys.sorted(), id: \.self) { playerId in
                    if let a = assignments[playerId] {
                        HStack {
                            Text(names[playerId] ?? playerId)
                            Spacer()
                            Text((a["label"] as? String) ?? (a["ar"] as? String) ?? "?")
                        }.font(.footnote)
                    }
                }
            }
            Button("Next Round") { send("round.next", roundId: roundId) }
                .buttonStyle(.bordered)
        }
    }

    private var feudPanel: some View {
        // Same top-level-vs-`game` bug as whoAmIPanel above: answers,
        // buzzer, strikes, maxStrikes, control and question all live under
        // `game` in Feud's project(), not at the top level (L02A blocker 2).
        let roundId = state?["roundId"] as? String
        let roundPhase = game?["roundPhase"] as? String
        let answers = (game?["answers"] as? [[String: Any]]) ?? []
        let buzzer = (game?["buzzer"] as? [String: Any]) ?? [:]
        let buzzerWinner = buzzer["winner"] as? String
        let strikes = (game?["strikes"] as? Int) ?? 0
        let maxStrikes = (game?["maxStrikes"] as? Int) ?? 3
        let control = game?["control"] as? String
        // party/core/majlis-core.js's Feud project() exposes this as
        // `roundPoints` (awarded total once a target is chosen, else the
        // live sum of revealed answers) — the operator panel never showed
        // it (L02A blocker 2).
        let roundPoints = (game?["roundPoints"] as? Int) ?? 0
        let names = playerNames()
        return VStack(alignment: .leading, spacing: 8) {
            Text("Feud — round \(roundId ?? "?")").font(.headline)
            if let question = game?["question"] as? String { Text(question) }
            Text("Strikes: \(strikes)/\(maxStrikes)").font(.subheadline)
            Text("Round points: \(roundPoints)").font(.subheadline)

            ForEach(answers.indices, id: \.self) { i in
                let a = answers[i]
                let answerId = a["id"] as? String
                let isRevealed = (a["revealed"] as? Bool) ?? false
                HStack {
                    Text((a["text"] as? String) ?? "?")
                    Spacer()
                    Text("\(a["points"] as? Int ?? 0)")
                    if !isRevealed, let answerId {
                        Button("Reveal") { send("feud.reveal", payload: ["answerId": answerId], roundId: roundId) }
                            .buttonStyle(.bordered)
                    }
                }
            }

            HStack {
                if roundPhase == "buzzer_open" {
                    Text("Buzzer open").foregroundColor(.green)
                } else if let buzzerWinner {
                    Text("Buzzed: \(names[buzzerWinner] ?? buzzerWinner)")
                }
                Spacer()
                // feud.open_buzzer is only accepted from roundPhase
                // "closed"; feud.reset_buzzer is rejected ("round_awarded")
                // only once roundPhase is "awarded" — deriving the button
                // from buzzer.open alone (old code) left it stuck on "Open
                // Buzzer" after a winner/control was already set, and let
                // "Reset Buzzer" be sent (and rejected) once a board was
                // already awarded (L02A blocker 2).
                if roundPhase == "closed" {
                    Button("Open Buzzer") { send("feud.open_buzzer", roundId: roundId) }
                        .buttonStyle(.bordered)
                } else if roundPhase != "awarded" {
                    Button("Reset Buzzer") { send("feud.reset_buzzer", roundId: roundId) }
                        .buttonStyle(.bordered)
                }
            }

            HStack {
                Button("Strike") { send("feud.strike", roundId: roundId) }
                    .buttonStyle(.bordered)
                    .disabled(strikes >= maxStrikes || !(roundPhase == "answering" || roundPhase == "steal"))
                // feud.steal requires a target different from the current
                // control-holder (reducer: target !== state.control, else
                // "invalid_payload") — the old code re-sent `control` itself
                // as the steal target, which the reducer could only ever
                // reject (L02A blocker 2).
                if strikes >= maxStrikes, roundPhase == "answering" {
                    ForEach((state?["players"] as? [[String: Any]])?.compactMap { $0["id"] as? String } ?? [], id: \.self) { playerId in
                        if playerId != control {
                            Button("Steal: \(names[playerId] ?? playerId)") {
                                send("feud.steal", payload: ["playerId": playerId], roundId: roundId)
                            }
                            .buttonStyle(.bordered)
                        }
                    }
                }
            }

            if roundPhase != "awarded", let players = state?["players"] as? [[String: Any]], !players.isEmpty {
                Text("Award points").font(.subheadline)
                ForEach(players.indices, id: \.self) { i in
                    if let playerId = players[i]["id"] as? String {
                        Button((players[i]["name"] as? String) ?? playerId) {
                            send("feud.award", payload: ["playerId": playerId], roundId: roundId)
                        }
                        .buttonStyle(.bordered)
                    }
                }
            }

            Button("Next Round") { send("round.next", roundId: roundId) }
                .buttonStyle(.bordered)
        }
    }

    private var impostorPanel: some View {
        // Mirrors party/web/js/host.js's impostorPanel(): discussion (open
        // voting) / vote (tally + close early) / guess_word (forfeit) /
        // reveal (impostor + word + per-player points + next round), all
        // read off `game` per majlis-core.js's Impostor project().
        let roundId = state?["roundId"] as? String
        let roundPhase = game?["roundPhase"] as? String
        let order = (game?["order"] as? [String]) ?? []
        let votes = (game?["votes"] as? [String: String]) ?? [:]
        let tally = (game?["tally"] as? [String: Int]) ?? [:]
        let votesNeeded = (game?["votesNeeded"] as? Int) ?? order.count
        let names = playerNames()
        return VStack(alignment: .leading, spacing: 8) {
            Text("Impostor — round \(roundId ?? "?")").font(.headline)
            switch roundPhase {
            case "discussion":
                Text("Players are discussing out loud. Open voting once they are ready to accuse someone.")
                    .font(.footnote).foregroundColor(.secondary)
                Button("Open voting") { send("impostor.advance", roundId: roundId) }
                    .buttonStyle(.borderedProminent)
            case "vote":
                Text("\(votes.count) of \(votesNeeded) players have voted.").font(.subheadline)
                ForEach(order, id: \.self) { playerId in
                    HStack {
                        Text(names[playerId] ?? playerId)
                        if votes[playerId] != nil { Text("Voted").foregroundColor(.green) }
                        Spacer()
                        let n = tally[playerId] ?? 0
                        Text("\(n) vote\(n == 1 ? "" : "s")").foregroundColor(.secondary)
                    }
                }
                Button("Close voting now") { send("impostor.advance", roundId: roundId) }
                    .buttonStyle(.bordered)
            case "guess_word":
                let nominee = game?["nominee"] as? String
                Text("\(names[nominee ?? ""] ?? nominee ?? "?") was caught! Waiting for their word guess.")
                    .font(.subheadline)
                Button("Forfeit (no guess)") { send("impostor.advance", roundId: roundId) }
                    .buttonStyle(.bordered)
            default:
                // reveal
                let reveal = (game?["reveal"] as? [String: Any]) ?? [:]
                let points = (game?["roundPoints"] as? [String: Int]) ?? [:]
                let remaining = game?["roundsRemaining"] as? Int
                let outcome = game?["outcome"] as? String
                Text(Self.impostorOutcomes[outcome ?? ""] ?? "Round over.").font(.subheadline)
                if let impostorId = reveal["impostor"] as? String {
                    Text("\(names[impostorId] ?? impostorId) was the impostor.")
                }
                if let word = reveal["word"] as? String {
                    Text("The word was \u{201c}\(word)\u{201d}.")
                }
                ForEach(order, id: \.self) { playerId in
                    HStack {
                        Text(names[playerId] ?? playerId)
                        Spacer()
                        Text("+\(points[playerId] ?? 0)")
                    }.font(.footnote)
                }
                if remaining == 0 {
                    Text("No words left for another round. End the game to show the final scores.")
                        .font(.footnote).foregroundColor(.secondary)
                } else {
                    Button("Next round") { send("round.next", roundId: roundId) }
                        .buttonStyle(.borderedProminent)
                }
            }
        }
    }

    /// party/core/majlis-core.js's Taboo project() for role "operator" nests
    /// the active card under game.you.card (word+forbidden) — never at a
    /// top-level field — and every operator action (taboo.correct/
    /// violation/skip/pass_turn) requires the *current* cardEpoch in its
    /// payload (reduce()'s checkCardEpoch), rejecting "stale_card"
    /// otherwise; this mirrors the same field read by party/web/js's
    /// equivalent panel pattern (no web Taboo operator panel exists — this
    /// native view is the only operator surface for Taboo per the brief).
    private var tabooPanel: some View {
        let roundId = state?["roundId"] as? String
        let roundPhase = game?["roundPhase"] as? String
        let activeTeam = game?["activeTeam"] as? String
        let clueGiverId = game?["clueGiverId"] as? String
        let teams = (game?["teams"] as? [String: [String]]) ?? [:]
        let teamScores = (game?["teamScores"] as? [String: Int]) ?? [:]
        let cardEpoch = (game?["cardEpoch"] as? Int) ?? 0
        let cardsRemaining = (game?["cardsRemaining"] as? Int) ?? 0
        let remainingMs = (game?["remainingMs"] as? Int) ?? 0
        let you = (game?["you"] as? [String: Any]) ?? [:]
        let card = (you["card"] as? [String: Any])
        let word = card?["word"] as? String
        let forbidden = (card?["forbidden"] as? [String]) ?? []
        let lastResolved = (game?["lastResolved"] as? [String: Any])
        let ended = (game?["ended"] as? Bool) ?? false
        let result = (game?["result"] as? [String: Any])
        let names = playerNames()
        return VStack(alignment: .leading, spacing: 8) {
            Text("Taboo — round \(roundId ?? "?")").font(.headline)
            HStack {
                Text("Team A: \(teamScores["A"] ?? 0)")
                Spacer()
                Text("Team B: \(teamScores["B"] ?? 0)")
            }.font(.subheadline)
            if let activeTeam {
                Text("Active team: \(activeTeam) — clue giver: \(names[clueGiverId ?? ""] ?? clueGiverId ?? "?")")
                    .font(.subheadline)
            }
            if roundPhase == "clue_turn" {
                Text("\(remainingMs / 1000)s left · \(cardsRemaining) cards left").font(.footnote).foregroundColor(.secondary)
                if let word {
                    // Operator-only: this card is never sent to any player role
                    // (project()'s guesser/spectator branches omit `card`).
                    Text(word).font(.title2).bold()
                    Text(forbidden.joined(separator: ", ")).font(.footnote).foregroundColor(.red)
                }
                HStack {
                    Button("Correct") { send("taboo.correct", payload: ["cardEpoch": cardEpoch], roundId: roundId) }
                        .buttonStyle(.borderedProminent)
                    Button("Violation") { send("taboo.violation", payload: ["cardEpoch": cardEpoch], roundId: roundId) }
                        .buttonStyle(.bordered)
                    Button("Skip") { send("taboo.skip", payload: ["cardEpoch": cardEpoch], roundId: roundId) }
                        .buttonStyle(.bordered)
                }
                Button("Pass turn", role: .destructive) { send("taboo.pass_turn", payload: ["cardEpoch": cardEpoch], roundId: roundId) }
            } else if roundPhase == "turn_complete" {
                if let lastResolved, let w = lastResolved["word"] as? String {
                    Text("Last card: \u{201c}\(w)\u{201d} — \((lastResolved["outcome"] as? String) ?? "")").font(.footnote)
                }
                Button("Next turn") { send("round.next", roundId: roundId) }
                    .buttonStyle(.borderedProminent)
            } else if roundPhase == "exhausted" || ended {
                if let result {
                    if let winner = result["winner"] as? String {
                        Text("Team \(winner) wins!").font(.headline)
                    } else {
                        Text("Draw.").font(.headline)
                    }
                }
            }
            Text("Team A: \((teams["A"] ?? []).map { names[$0] ?? $0 }.joined(separator: ", "))").font(.footnote)
            Text("Team B: \((teams["B"] ?? []).map { names[$0] ?? $0 }.joined(separator: ", "))").font(.footnote)
        }
    }

    /// Lobby-only Bluff settings (mirrors host.js's bluffStartConfig()):
    /// round count 1-10 (engine default 3, MAX_ROUNDS 10) and the voting
    /// language, forwarded as room.start's payload by roomControls' Start
    /// button above. The question itself always stays bilingual; only the
    /// options/true-answer text are rendered in the chosen language, so
    /// neither language choice gives the truth away on its own.
    private func bluffStartConfig() -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Bluff settings").font(.headline)
            Stepper("Rounds: \(bluffRounds)", value: $bluffRounds, in: 1...10)
            Picker("Voting language", selection: $bluffLanguage) {
                Text("English").tag("en")
                Text("العربية (Arabic)").tag("ar")
            }
            .pickerStyle(.segmented)
        }
    }

    private var bluffPanel: some View {
        // Mirrors party/web/js/host.js's bluffPanel(): submission (who has
        // submitted, never the fake text itself) / voting (who has voted,
        // never the tally or who-voted-what until reveal) / reveal+finished
        // (true answer + each fake's author + vote tally + round points +
        // next round), all read off `game` per majlis-core.js Bluff's
        // project(). Per-player rows use the room's own `players` list
        // (state?["players"]), same as host.js's `snap.players` — Bluff's
        // own project() never exposes a separate `order` array.
        let roundId = state?["roundId"] as? String
        let phase = game?["phase"] as? String
        let players = (state?["players"] as? [[String: Any]]) ?? []
        let names = playerNames()
        let questionEn = (game?["question"] as? [String: Any])?["en"] as? String
        let questionAr = (game?["question"] as? [String: Any])?["ar"] as? String
        return VStack(alignment: .leading, spacing: 8) {
            Text("Bluff — round \(roundId ?? "?")").font(.headline)
            if let questionEn { Text(questionEn) }
            if let questionAr { Text(questionAr) }

            switch phase {
            case "submission":
                let fakes = (game?["fakes"] as? [String: String]) ?? [:]
                let excluded = Set((game?["excluded"] as? [String]) ?? [])
                let submittedCount = (game?["submittedCount"] as? Int) ?? fakes.count + excluded.count
                let totalPlayers = (game?["totalPlayers"] as? Int) ?? players.count
                Text("\(submittedCount) / \(totalPlayers) answers in").font(.subheadline)
                Text("Only you see who has submitted, never the fake answer text itself — that stays private until voting.")
                    .font(.footnote).foregroundColor(.secondary)
                ForEach(players.indices, id: \.self) { i in
                    if let pid = players[i]["id"] as? String {
                        HStack {
                            Text(names[pid] ?? pid)
                            Spacer()
                            if fakes[pid] != nil { Text("Submitted").foregroundColor(.green) }
                            else if excluded.contains(pid) { Text("Skipped").foregroundColor(.secondary) }
                            else { Text("Waiting").foregroundColor(.secondary) }
                        }
                    }
                }
                let accounted = fakes.count + excluded.count
                Button("Open voting") { send("bluff.open_vote", payload: ["force": false], roundId: roundId) }
                    .buttonStyle(.borderedProminent)
                    .disabled(accounted < totalPlayers)
                if accounted < totalPlayers {
                    Button("Open voting now (skip stragglers)") {
                        send("bluff.open_vote", payload: ["force": true], roundId: roundId)
                    }
                    .buttonStyle(.bordered)
                }
            case "voting":
                let votes = (game?["votes"] as? [String: String]) ?? [:]
                let totalPlayers = (game?["totalPlayers"] as? Int) ?? players.count
                Text("\(votes.count) / \(totalPlayers) votes in").font(.subheadline)
                Text("Voting is anonymous — only vote counts are shown here, never who voted for what, until you reveal.")
                    .font(.footnote).foregroundColor(.secondary)
                ForEach(players.indices, id: \.self) { i in
                    if let pid = players[i]["id"] as? String {
                        HStack {
                            Text(names[pid] ?? pid)
                            Spacer()
                            if votes[pid] != nil { Text("Voted").foregroundColor(.green) }
                            else { Text("Waiting").foregroundColor(.secondary) }
                        }
                    }
                }
                Button("Reveal") { send("bluff.reveal", payload: ["force": false], roundId: roundId) }
                    .buttonStyle(.borderedProminent)
                    .disabled(votes.count < totalPlayers)
                if votes.count < totalPlayers {
                    Button("Reveal now (skip stragglers)") {
                        send("bluff.reveal", payload: ["force": true], roundId: roundId)
                    }
                    .buttonStyle(.bordered)
                }
            default:
                // reveal / finished — majlis-core.js's awardRound() puts the
                // true answer, every option's authorId, the vote tally and
                // voters (pid -> optionId, same reveal-only tier as
                // authorId/trueOptionId/scoreDelta) into lastResult; options
                // carry authorId to every role (operator included) only from
                // REVEAL/FINISHED onward, never pre-reveal.
                let last = (game?["lastResult"] as? [String: Any]) ?? [:]
                let options = (last["options"] as? [[String: Any]]) ?? []
                let trueOptionId = last["trueOptionId"] as? String
                let tally = (last["voteTally"] as? [String: Int]) ?? [:]
                let voters = (last["voters"] as? [String: String]) ?? [:]
                let votersByOption = Self.votersByOption(voters, names: names)
                let delta = (last["scoreDelta"] as? [String: Int]) ?? [:]
                let abstained = (last["abstained"] as? [String]) ?? []
                let roundsRemaining = game?["roundsRemaining"] as? Int
                Text("Reveal — round \(last["roundNo"].map { "\($0)" } ?? "?")").font(.subheadline)
                if !abstained.isEmpty {
                    Text("\(abstained.count) player(s) didn\u{2019}t vote and scored nothing this round.")
                        .font(.footnote).foregroundColor(.secondary)
                }
                ForEach(options.indices, id: \.self) { i in
                    let o = options[i]
                    let optionId = o["optionId"] as? String
                    let isTrue = optionId != nil && optionId == trueOptionId
                    let authorId = o["authorId"] as? String
                    let votes = optionId.flatMap { tally[$0] } ?? 0
                    let voterNames = optionId.flatMap { votersByOption[$0] } ?? []
                    VStack(alignment: .leading) {
                        HStack {
                            Text(isTrue ? "True answer" : (authorId.map { names[$0] ?? $0 } ?? "Fake"))
                                .foregroundColor(isTrue ? .green : .primary)
                            Spacer()
                            Text("\(votes) vote\(votes == 1 ? "" : "s")").foregroundColor(.secondary)
                        }
                        Text((o["text"] as? String) ?? "").font(.footnote)
                        if !voterNames.isEmpty {
                            Text("Voted by: \(voterNames.joined(separator: ", "))")
                                .font(.footnote).foregroundColor(.secondary)
                        }
                    }
                }
                if !delta.isEmpty {
                    Text("Points this round").font(.subheadline)
                    ForEach(players.indices, id: \.self) { i in
                        if let pid = players[i]["id"] as? String, let pts = delta[pid], pts != 0 {
                            HStack { Text(names[pid] ?? pid); Spacer(); Text("+\(pts)") }.font(.footnote)
                        }
                    }
                }
                if phase == "finished" || roundsRemaining == 0 {
                    Text("No rounds left. End the game to show the final scores.")
                        .font(.footnote).foregroundColor(.secondary)
                } else {
                    Button("Next round") { send("round.next", roundId: roundId) }
                        .buttonStyle(.borderedProminent)
                }
            }
        }
    }

    /// Escape Room (party/server/modes/escape_room.py's project()): no
    /// fragment or `reveal` ever reaches the operator role before the game
    /// ends, so this panel only ever has the public puzzle/progress/timer/
    /// team-score fields to show — the same fields party/web/js/tv.js
    /// renders. "Next Puzzle" (round.next) is enabled only once
    /// `game.phase` is "solved" (the reducer itself rejects it from
    /// "active" with invalid_phase, so the team can never be advanced past
    /// an unsolved puzzle from here either).
    @ViewBuilder
    private var escapeRoomPanel: some View {
        let roundId = state?["roundId"] as? String
        let phase = game?["phase"] as? String
        let puzzleIndex = (game?["puzzleIndex"] as? Int) ?? 0
        let puzzleCount = (game?["puzzleCount"] as? Int) ?? 3
        let remaining = (game?["remainingSeconds"] as? Double) ?? Double((game?["remainingSeconds"] as? Int) ?? 0)
        let puzzle = (game?["currentPuzzle"] as? [String: Any]) ?? [:]
        let hintEn = puzzle["hintEn"] as? String
        let hintUsed = hintEn != nil
        let teamScore = ((state?["players"] as? [[String: Any]])?.first?["score"] as? Int) ?? 0
        let mins = Int(remaining) / 60, secs = Int(remaining) % 60
        // The mode's own game can finish (success/timeout) before this room's phase moves to
        // "ended" (that only happens once the operator sends room.end), so `phase` here can read
        // "ended" while roomControls(phase:) below is still showing the "playing" controls
        // (End/Pause/Reset). currentPuzzle is nil once ended (escape_room.py project()).
        if phase == "ended" {
            let outcome = game?["outcome"] as? String
            let outcomeText = outcome == "success" ? "The team escaped! All three puzzles solved."
                : outcome == "timeout" ? "Time ran out before the team escaped." : "The game ended."
            VStack(alignment: .leading, spacing: 8) {
                Text("Escape Room — finished").font(.headline)
                Text(outcomeText)
                Text("Team score: \(teamScore)").font(.subheadline)
                Text("Press End to close out the room.").font(.footnote).foregroundColor(.secondary)
            }
        } else {
            VStack(alignment: .leading, spacing: 8) {
                Text("Escape Room — puzzle \(puzzleIndex + 1) of \(puzzleCount)").font(.headline)
                Text(String(format: "%d:%02d left \u{2022} Team score: %d", mins, secs, teamScore)).font(.subheadline)
                if let promptEn = puzzle["promptEn"] as? String { Text(promptEn) }
                if let hintEn { Text("Hint: \(hintEn)").font(.footnote).foregroundColor(.secondary) }
                HStack {
                    Button("Hint") { send("escape_room.hint", roundId: roundId) }
                        .buttonStyle(.bordered)
                        .disabled(hintUsed || phase != "active")
                    Button("Next Puzzle") { send("round.next", roundId: roundId) }
                        .buttonStyle(.borderedProminent)
                        .disabled(phase != "solved")
                }
            }
        }
    }

    private func roomControls(phase: String?) -> some View {
        HStack(spacing: 10) {
            switch phase {
            case "lobby", nil:
                // Start is gated on an explicit mode and the mode's own
                // minimum player count (lobby()'s own gate in
                // party/web/js/host.js) — never enabled on an unselected
                // mode (blocker 1).
                let limits = state?["playerLimits"] as? [String: Any]
                let min = limits?["min"] as? Int ?? 3
                // The max side of the same projected limits was never checked here
                // (the gate only disabled Start for too few players, never too many),
                // letting the operator submit a room.start the engine's own
                // `count > state.limits.max` check would reject.
                let max = limits?["max"] as? Int ?? Int.max
                let count = (state?["players"] as? [[String: Any]])?.count ?? 0
                let mode = state?["mode"] as? String
                if mode == "taboo" {
                    Stepper(value: $tabooTurnSeconds, in: 10...180, step: 5) {
                        Text("Turn length: \(Int(tabooTurnSeconds))s")
                    }
                }
                // Bluff is the other mode whose room.start carries a payload
                // (rounds/language) — Bluff.initialize validates both itself;
                // this just forwards the lobby's chosen values, exactly like
                // host.js's Start button (`act('room.start', chosen ===
                // 'bluff' ? { rounds, language } : {}, ...)`).
                Button("Start") {
                    if let payload = roomStartPayload(mode: mode, turnSeconds: Int(tabooTurnSeconds)) {
                        send("room.start", payload: payload)
                    } else if mode == "bluff" {
                        send("room.start", payload: ["rounds": bluffRounds, "language": bluffLanguage])
                    } else {
                        send("room.start")
                    }
                }
                    .disabled(rosterGateDisabled(mode: mode, count: count, min: min, max: max))
            case "playing":
                Button("Pause") { send("room.pause") }
            case "paused":
                Button("Resume") { send("room.resume") }
            case "ended":
                // reduceRoom's ROOM_ACTIONS gating accepts room.reset and
                // room.close unconditionally from any phase, including
                // "ended" — but the old switch had no "ended" case at all,
                // so after room.end the operator was stuck with no way to
                // reset or close the room (L02A blocker 2).
                Button("Play Again") { send("room.reset") }
                    .buttonStyle(.borderedProminent)
                Button("Close Room", role: .destructive) { send("room.close") }
            case "closed":
                // room.close leaves the engine's own room/token state
                // terminal (same as "ended" for ROOM_ACTIONS purposes), but
                // the coordinator's own status stays `.hosting` until
                // endSession is actually called — the old switch had no
                // "closed" case, so the operator was left looking at a dead
                // room with zero controls after closing it (L02A blocker 2:
                // "closed phase must offer new-room/exit, not leave the
                // coordinator stuck hosting").
                Button("Host a New Room") { coordinator.endSession(reason: "The room was closed.") }
                    .buttonStyle(.borderedProminent)
            default:
                EmptyView()
            }
            if phase != "ended" && phase != "closed" {
                Button("End", role: .destructive) { send("room.end") }
            }
        }
    }

    /// Lobby-only mode picker (blocker 1): room.set_mode must be submitted
    /// and its accepted revision observed before Start can ever be enabled
    /// — createRoom never selects a mode itself.
    private func modePicker() -> some View {
        VStack(spacing: 8) {
            // JSONSerialization decodes a JSON null as NSNull, not Swift
            // nil, so `state?["mode"] == nil` was always false once the
            // server had answered even one state request (mode starts out
            // JSON null, not an absent key) — the mode picker/Set Mode
            // button could never appear (L02A blocker 1).
            if (state?["mode"] as? String) == nil {
                Picker("Mode", selection: $selectedMode) {
                    ForEach(Self.modes, id: \.0) { mode in Text(mode.1).tag(mode.0) }
                }
                .pickerStyle(.segmented)
                Button("Set Mode") { send("room.set_mode", payload: ["mode": selectedMode]) }
                    .buttonStyle(.borderedProminent)
            } else if let mode = state?["mode"] as? String {
                Text("Mode: \(Self.modes.first(where: { $0.0 == mode })?.1 ?? mode)")
            }
        }
    }

    private func pausedScreen(code: String) -> some View {
        VStack(spacing: 12) {
            Text("Paused — room \(code)").font(.headline)
            Text("Resume to rebind and tell the room to continue.")
            Button("Resume Hosting") { coordinator.resumeHosting() }
                .buttonStyle(.borderedProminent)
        }
    }

    /// Resume failed (L02A blocker 5): the checkpoint for `code` is still
    /// intact, so this is a retry point, not a dead end — distinct from the
    /// `.failed`/startScreen path, which can only start a brand-new room.
    private func resumeFailedScreen(code: String, message: String) -> some View {
        VStack(spacing: 12) {
            Text("Could not resume room \(code)").font(.headline).foregroundColor(.red)
            Text(message).font(.footnote).foregroundColor(.secondary)
            Button("Retry") { coordinator.resumeHosting() }
                .buttonStyle(.borderedProminent)
            Button("End", role: .destructive) {
                coordinator.endSession(reason: "Room \(code) ended.")
            }
            .buttonStyle(.bordered)
        }
    }

    private func endedScreen(reason: String) -> some View {
        VStack(spacing: 12) {
            Text(reason).multilineTextAlignment(.center)
            // startHosting(body:) already builds a fresh PartyHost when
            // status is .ended (Server.shutdown is terminal — see
            // PartyLifecycleCoordinator.init's doc comment) — this is the
            // same action as the start screen's button, not a separate path.
            Button("Host a New Room") {
                lastError = nil
                coordinator.startHosting(body: [:])
            }
            .buttonStyle(.bordered)
        }
    }

    /// `roundId` binds the action to the round the operator was actually
    /// looking at; party/core's own stale-action protection then rejects it
    /// if the room has moved on since (mirrors party/web/js/host.js's own
    /// `act(type, payload, btn, { round })`).
    private func send(_ type: String, payload: [String: Any] = [:], roundId: String? = nil) {
        coordinator.submitAction(type: type, payload: payload, roundId: roundId) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let r) where r.accepted:
                    lastError = nil
                case .success(let r):
                    lastError = r.error ?? "rejected"
                case .failure(let e):
                    lastError = String(describing: e)
                }
            }
        }
    }

    private func startPolling() {
        pollTimer?.invalidate()
        pollTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            Task { @MainActor in
                coordinator.fetchState { result in
                    DispatchQueue.main.async {
                        if case .success(let s) = result { state = s }
                    }
                }
            }
        }
    }

    private func stopPolling() {
        pollTimer?.invalidate()
        pollTimer = nil
    }

    private static func qrImage(from string: String) -> UIImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(string.utf8)
        guard let output = filter.outputImage else { return nil }
        let scaled = output.transformed(by: CGAffineTransform(scaleX: 8, y: 8))
        guard let cgImage = CIContext().createCGImage(scaled, from: scaled.extent) else { return nil }
        return UIImage(cgImage: cgImage)
    }
}
