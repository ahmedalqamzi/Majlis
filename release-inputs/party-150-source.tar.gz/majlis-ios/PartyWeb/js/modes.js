// Majlis Party: the ten required modes. `playable` is true only once a complete, server-backed
// loop exists in this build. Everything else is shown as "Not playable yet" and cannot be chosen.
export const MODES = [
  { id: 'who_am_i', title: 'Who Am I?', ar: 'من أنا؟', blurb: 'Everyone sees your character except you. Ask yes/no questions.', playable: true },
  { id: 'feud', title: 'Majlis Feud', ar: 'تحدي المجلس', blurb: 'Buzz in and find the house answers on the board.', playable: true },
  { id: 'impostor', title: 'Impostor', ar: 'الدخيل', blurb: 'Everyone gets the same word except the impostor. Discuss, vote, catch them.', playable: true },
  { id: 'draw_guess', title: 'Draw & Guess', ar: 'ارسم وخمّن', playable: false },
  { id: 'drawing_chain', title: 'Drawing Chain', ar: 'سلسلة الرسم', playable: false },
  { id: 'bluff', title: 'Bluff', ar: 'الخداع', blurb: 'Write a fake answer, vote for the real one, and try to fool everyone else.', playable: true },
  { id: 'werewolf', title: 'Werewolf', ar: 'المستذئب', playable: false },
  { id: 'taboo', title: 'Taboo', ar: 'الممنوع', blurb: 'Give clues for your word without saying the forbidden terms.', playable: true },
  { id: 'wavelength', title: 'Wavelength-style', ar: 'نفس الموجة', playable: false },
  { id: 'escape_room', title: 'Escape Room', ar: 'غرفة الهروب', blurb: 'Share your clue, solve three puzzles together before time runs out.', playable: true },
];

export function modeInfo(id) {
  return MODES.find(m => m.id === id) || { id, title: id || 'No game chosen', playable: false };
}

// Public, static "how to play" steps for the phone's own disclosure (see rulesPanel() in
// views.js). Derived from the engines' actual reduce()/project() behavior in
// party/core/majlis-core.js (WhoAmI, Feud, Impostor, Taboo) and the existing player-facing copy
// in play.js's guess-help text -- never invented score values, automatic-judging claims, or
// private data.
export const RULES = {
  who_am_i: {
    title: 'How to play Who Am I',
    steps: [
      'Everyone else can see your character — only you can’t.',
      'Ask the group yes/no questions out loud to work out who you are.',
      'Type your guess and send it — only the host sees the text; it is not graded automatically.',
      'Tap “I’m ready” to show the host (and the group) you want to answer; it sends no guess.',
      'The host reveals your character when you solve it or when the round ends.',
    ],
  },
  feud: {
    title: 'How to play Majlis Feud',
    steps: [
      'Each board has 6 to 8 house answers. Points are game scores, not real survey results.',
      'When the buzzer opens, tap BUZZ as fast as you can.',
      'Buzz first, then type your answer or say it to the host. The answer clock starts after a buzz, unless Timer off is selected.',
      'Three wrong answers or timeouts automatically give the next side one chance to steal.',
      'The host can reveal matching answers or mark a miss. Turns, team points and the countdown are handled automatically.',
    ],
  },
  impostor: {
    title: 'How to play Impostor',
    steps: [
      'Everyone except the impostor gets the same secret word on their phone; the impostor does not.',
      'Discuss out loud and try to work out who is missing the word — or, if you’re the impostor, blend in.',
      'When the host opens voting, tap a player’s name on your phone to vote for who you think the impostor is.',
      'If the group votes out the actual impostor, they get one phone guess at the word before the round ends.',
      'The host reveals the impostor, the word, and how the round ended.',
    ],
  },
  taboo: {
    title: 'How to play Taboo',
    steps: [
      'Teams take turns: one player is the clue giver, the rest of their team guesses out loud.',
      'The clue giver sees a secret word and its forbidden terms on their phone, and gives spoken clues without saying any of them.',
      'Guessing teammates can also type a guess on their phone; a correct word moves play on to the next card.',
      'The host listens in and adjudicates each card — awarding it, calling a forbidden-word violation, or skipping it.',
      'Each turn runs on a shared timer; the host starts the next team’s turn once it ends.',
    ],
  },
  bluff: {
    title: 'How to play Bluff',
    steps: [
      'Everyone sees the same question and writes their own convincing fake answer on their phone.',
      'No other player can see what you wrote while answers are coming in — the host’s own screen may show submissions differently.',
      'When voting opens, tap the answer you think is the real one; you can’t vote for your own fake.',
      'Pick the real answer and you score; vote for someone else’s fake instead and its author scores from your vote.',
      'The reveal then shows the real answer plus who wrote and voted for every option — nothing stays hidden after that point.',
    ],
  },
};

// The default TV rules: each person keeps a player seat, with no separate referee.
export const PARTY_RULES = {
  who_am_i: { title: 'How to play Who Am I', steps: [
    'Everyone sees your character except you. Ask yes/no questions out loud.',
    'Type your character’s name to score, or ask another player to tap “They got it!” for a correct spoken guess.',
    'You can reveal your character without scoring if you get stuck.',
    'New characters arrive each round. Choose the number of rounds in Game settings before starting.',
  ] },
  feud: { title: 'How to play Majlis Feud', steps: [
    'Pick Red or Blue on your phone before starting. Unassigned players are balanced automatically.',
    'Choose a topic or Mixed Bag on the TV. Each game draws 10 questions. Mixed Bag uses a shuffled pool of 200; other topics show their pool size. Play again in the same lobby without repeats until the pool is used, then it reshuffles.',
    'Buzz first to take control, then type an answer before the timer runs out (or take your time with Timer off). Answers come from our house list, not a survey.',
    'Correct answers reveal points and pass the turn to a teammate. A wrong answer or timeout adds a strike.',
    'Three strikes gives the other team one chance to steal the revealed points. The TV scores and moves to the next question.',
    'Choose Two teams or Free-for-all and an answer timer, including Off, in Game settings. Save before starting.',
  ] },
  impostor: { title: 'How to play Impostor', steps: [
    'Open your private card. Most players get the same secret word; the impostor gets only a hint when hints are on.',
    'Give clues out loud without saying the word. The impostor tries to blend in.',
    'Start voting on your phone when ready, or wait for the discussion timer. Vote for the player you suspect.',
    'A caught impostor gets one chance to guess the word. The TV reveals the result and starts the next round.',
  ] },
  taboo: { title: 'How to play Taboo', steps: [
    'Teams take turns. The clue giver explains the secret word without saying the forbidden words.',
    'Teammates guess out loud or type their guess on their phones.',
    'The other team sees the card and can confirm a correct spoken guess or flag a forbidden word. The clue giver can skip.',
    'When the timer ends, the next team’s turn starts automatically. Everyone still plays for their own team.',
  ] },
  bluff: { title: 'How to play Bluff', steps: [
    'Write a convincing fake answer to the question on your phone. Keep it secret.',
    'When everyone has submitted, or the timer ends, vote for the answer you think is real. You cannot vote for your own fake.',
    'Find the real answer to score, or fool other players into choosing yours.',
    'The TV reveals the answers and scores, then moves to the next round.',
  ] },
  escape_room: { title: 'How to play Escape Room', steps: [
    'Each phone holds a clue. Share what you know and solve the puzzle together.',
    'Anyone can submit an answer or request a hint. Hints cost points.',
    'Solved puzzles move on automatically. Finish all three before the shared timer runs out.',
  ] },
};
