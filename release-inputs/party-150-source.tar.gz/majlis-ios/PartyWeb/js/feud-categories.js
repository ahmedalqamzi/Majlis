// Public labels only; questions and unrevealed answers stay on the server.
export const FEUD_CATEGORIES = [
  {
    "id": "mixed",
    "label": "Mixed bag",
    "ar": "كل الفئات",
    "count": 835,
    "poolSize": 200
  },
  {
    "id": "naruto",
    "label": "Naruto",
    "ar": "ناروتو",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "one_piece",
    "label": "One Piece",
    "ar": "ون بيس",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "minecraft",
    "label": "Minecraft",
    "ar": "ماينكرافت",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "uae_places",
    "label": "UAE places",
    "ar": "أماكن في الإمارات",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "pokemon",
    "label": "Pokémon",
    "ar": "بوكيمون",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "dragon_ball",
    "label": "Dragon Ball",
    "ar": "دراغون بول",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "marvel",
    "label": "Marvel",
    "ar": "مارفل",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "star_wars",
    "label": "Star Wars",
    "ar": "حرب النجوم",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "anime",
    "label": "Anime",
    "ar": "أنمي",
    "count": 230,
    "poolSize": 200
  },
  {
    "id": "games",
    "label": "Games",
    "ar": "ألعاب الفيديو",
    "count": 130,
    "poolSize": 130
  },
  {
    "id": "places",
    "label": "Places",
    "ar": "أماكن",
    "count": 80,
    "poolSize": 80
  },
  {
    "id": "entertainment",
    "label": "Media",
    "ar": "أفلام وتلفزيون وإعلام",
    "count": 150,
    "poolSize": 150
  },
  {
    "id": "food",
    "label": "Food & drink",
    "ar": "أكل ومشروبات",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "home",
    "label": "Home & family",
    "ar": "البيت والعائلة",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "everyday",
    "label": "Everyday life",
    "ar": "الحياة اليومية",
    "count": 51,
    "poolSize": 50
  },
  {
    "id": "travel",
    "label": "Travel & holidays",
    "ar": "سفر وعطلات",
    "count": 61,
    "poolSize": 60
  },
  {
    "id": "nature",
    "label": "Animals & nature",
    "ar": "حيوانات وطبيعة",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "work_school",
    "label": "School & work",
    "ar": "المدرسة والعمل",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "sports_games",
    "label": "Sports & games",
    "ar": "رياضة وألعاب",
    "count": 60,
    "poolSize": 60
  },
  {
    "id": "technology",
    "label": "Technology",
    "ar": "تكنولوجيا",
    "count": 50,
    "poolSize": 50
  },
  {
    "id": "uae",
    "label": "UAE & majlis",
    "ar": "الإمارات والمجلس",
    "count": 61,
    "poolSize": 60
  }
];
export const feudCategoryName = id => (FEUD_CATEGORIES.find(c => c.id === id) || FEUD_CATEGORIES[0]).label;
