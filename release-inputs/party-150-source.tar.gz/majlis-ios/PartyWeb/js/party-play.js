// Everyone plays: controls use role-projected state; answers remain server-authoritative.
import {h} from './ui.js';
import {modeHeading,scoreboard,feudBoard,IMPOSTOR_OUTCOMES,rulesPanel} from './views.js';
import {WHO_AM_I_CATEGORIES} from './who-am-i-categories.js';
const drafts=new Map();let revealKey=null,shown=false;
const name=(s,id)=>(s.players||[]).find(p=>p.id===id)?.name||'A player';
const btn=(text,fn,kind='btn-sec',disabled=false)=>h('button',{type:'button',class:'btn '+kind,'data-focus':'party-'+text.replace(/[^a-z0-9]/gi,'-'),text,disabled,onclick:e=>fn(e.currentTarget)});
const para=text=>h('p',{class:'status-line',text});
const card=(title,...body)=>h('section',{class:'card stack'},h('h2',{class:'card-title',text:title}),...body);
export function partyClock(g){
  if(g.pausedRemainingSeconds!=null)return h('strong',{class:'party-clock',text:Math.ceil(g.pausedRemainingSeconds)+'s · paused'});
  const due=g.deadlineAt||g.nextAt;if(!due)return g.turnSeconds!=null?h('strong',{class:'party-clock clock-waiting',text:g.turnSeconds===0?'Timer off':g.turnSeconds+'s · starts after buzz'}):null;
  return h('strong',{class:'party-clock','data-party-deadline':String(due),'data-party-offset':String(Date.now()/1000-(g.serverNow||Date.now()/1000)),text:Math.max(0,Math.ceil(due-(g.serverNow||Date.now()/1000)))+'s'});
}
setInterval(()=>{for(const el of document.querySelectorAll('[data-party-deadline]')){const now=Date.now()/1000-Number(el.dataset.partyOffset||0);el.textContent=Math.max(0,Math.ceil(Number(el.dataset.partyDeadline)-now))+'s';}},1000);
export function partySetupSummary(snap){
  const s=snap.settings||{},bits=[s.everyonePlays===false?'With a host':'Everyone plays'];
  if(snap.mode==='feud')bits.push(s.feudTeams===false?'Free-for-all':'Two teams',(s.feudSeconds??20)===0?'Timer off':(s.feudSeconds??20)+' seconds per answer');
  if(snap.mode==='who_am_i')bits.push((s.whoRounds||3)+' rounds');
  return bits.join(' · ');
}
export function partySettings(snap,change){
  const settings=snap.settings||{},hostless=settings.everyonePlays!==false,rows=[];
  function choices(key,title,help,values,selected){
    return h('section',{class:'setup-section','data-setting':key},h('h3',{text:title}),h('p',{class:'setup-help',text:help}),
      h('div',{class:'setup-options',role:'group','aria-label':title},values.map(([value,label,detail])=>{
        const picked=selected===value;
        return h('button',{type:'button',class:'setup-option'+(picked?' selected':''),'data-focus':'setting-'+key+'-'+value,'aria-pressed':String(picked),onclick:b=>change({[key]:value},b.currentTarget)},
          h('strong',{text:label}),detail?h('span',{text:detail}):null,picked?h('span',{class:'setup-check','aria-hidden':'true',text:'✓'}):null);
      })));
  }
  rows.push(choices('everyonePlays','Who runs the game?','Choose how your group wants to play.',[[true,'Everyone plays','The game handles judging, turns and scores.'],[false,'With a host','A host can judge spoken answers and run the board.']],hostless));
  if(snap.mode==='who_am_i'){
    const count=WHO_AM_I_CATEGORIES.find(c=>c.id===(snap.whoAmICategory||'mixed'))?.count||360;
    const max=Math.max(1,Math.min(10,Math.floor(count/Math.max(1,(snap.players||[]).length||3)))),n=Math.min(settings.whoRounds||3,max);
    rows.push(choices('whoRounds','How many rounds?','A fresh character for everyone each round.',Array.from({length:max},(_,i)=>[i+1,String(i+1)]),n));
  }
  if(snap.mode==='feud'){
    rows.push(choices('feudTeams','Who scores together?','This works with or without a host.',[[true,'Two teams','Red vs Blue. Share points and steal the bank.'],[false,'Free-for-all','Everyone competes for their own score.']],settings.feudTeams!==false));
    rows.push(choices('feudSeconds','Time per answer','The countdown starts after a buzz. Each next answer gets a fresh clock.',[0,10,20,30,45,60].map(n=>[n,n===0?'Off':n+' seconds']),settings.feudSeconds??20));
    if(settings.feudTeams!==false){
      const assignments=snap.teamAssignments||{},roster=h('section',{class:'setup-section setup-roster'},h('h3',{text:'Set your teams'}),h('p',{class:'setup-help',text:'Players can also choose on their phones. Auto fills the smaller team when you start.'}));
      for(const player of snap.players||[]){
        const team=assignments[player.id]||'auto';
        roster.append(h('div',{class:'setup-player'},h('strong',{text:player.name}),h('div',{class:'team-choices',role:'group','aria-label':player.name+' team'},[['auto','Auto'],['A','Red'],['B','Blue']].map(([value,label])=>h('button',{type:'button',class:'team-choice team-'+value+(team===value?' selected':''),'data-focus':'team-'+player.id+'-'+value,'aria-pressed':String(team===value),text:label,onclick:e=>{const next={...assignments};if(value==='auto')delete next[player.id];else next[player.id]=value;change({teamAssignments:next},e.currentTarget);}})))));
      }
      if(!(snap.players||[]).length)roster.append(h('p',{text:'Teams appear here as players join.'}));rows.push(roster);
    }
    rows.push(h('p',{class:'setup-help',text:'10 questions per game. Three strikes opens one chance to steal. Points shown are our house scoring, not survey results.'}));
  }
  if(snap.mode==='impostor')rows.push(choices('impostorHints','Clue for the impostor','The clue is private to the impostor.',[[true,'Hint on'],[false,'Hint off']],settings.impostorHints!==false));
  return h('div',{class:'party-settings setup-form'},...rows);
}
export function partyTeamPicker(snap,send){
  if(snap.mode!=='feud'||snap.settings?.feudTeams===false)return null;
  const id=snap.self?.id,team=snap.teamAssignments?.[id];
  return card('Pick your team',h('div',{class:'party-choices'},['A','B'].map(t=>btn((t==='A'?'Red team':'Blue team')+(team===t?' ✓':''),b=>send('party.team',{team:t},b),team===t?'btn-pri':'btn-sec'))),para('Or leave it to us: teams are balanced when the game starts.'));
}
function answerForm(snap,send,type,label,payload={}){
  const key=snap.code+':'+snap.roundId+':'+type+':'+(payload.turn||0),draft=drafts.get(key)||'';
  if(drafts.size>30)drafts.clear();
  const input=h('input',{id:'party-answer',name:'answer',autocomplete:'off',maxlength:type==='whoami.guess'?80:type==='feud.answer'?120:160,required:true,value:draft,placeholder:label,oninput:e=>drafts.set(key,e.target.value)});
  const submit=btn('Send answer',()=>{},'btn-pri');submit.type='submit';
  return h('form',{class:'stack',onsubmit:async e=>{e.preventDefault();const r=await send(type,{...payload,text:input.value.trim()},submit);if(r?.accepted){drafts.delete(key);input.value='';}}},h('label',{for:'party-answer',text:label}),input,submit);
}
export function partyTeams(snap){
  const g=snap.game||{};if(!g.teams)return null;
  return h('section',{class:'party-teams','aria-label':'Team scores'},Object.keys(g.teams).map(t=>h('div',{class:'card party-team team-'+t+(g.activeTeam===t?' active':'')},h('h2',{class:'card-title',text:g.teamMode?(t==='A'?'Red team':'Blue team'):name(snap,t)}),h('strong',{class:'party-team-score',text:String(g.teamScores[t]||0)}),h('p',{text:g.teams[t].map(id=>name(snap,id)).join(', ')}))));
}
export function partyPlayer(snap,send){
  const g=snap.game||{},me=snap.self?.id,member=(g.order||[]).includes(me);
  if(!member)return h('div',{class:'stack'},modeHeading(snap),para('You’re watching this game. You can join the next one.'));
  const next=g.everyonePlays&&g.canAdvance?btn(snap.mode==='who_am_i'&&g.round>=g.totalRounds?'Show final scores':snap.mode==='impostor'&&g.roundPhase==='discussion'?'Start voting':'Continue',b=>send('party.advance',{},b),'btn-pri'):null;
  let body;
  if(snap.mode==='who_am_i'){
    const you=g.you||{},done=you.revealed;
    body=h('div',{class:'stack'},
      card(done?'Your character':'Who are you?',done?para(you.assignment?.label||'Revealed'):para('Ask yes/no questions aloud. Everyone else can see your character.')),
      !done?card('Make your guess',answerForm(snap,send,'whoami.guess','Your character’s name'),g.you?.guess?para('Your last guess: '+g.you.guess+'. Try again, or ask someone to confirm it.'):null,btn('Reveal mine — no point',b=>send('whoami.give_up',{},b),'btn-ghost')):null,
      card('Everyone else',...Object.entries(g.assignments||{}).filter(([id])=>id!==me).map(([id,a])=>h('div',{class:'party-character'},h('div',{},h('strong',{text:name(snap,id)}),h('p',{text:a.label}),a.ar?h('p',{lang:'ar',dir:'rtl',text:a.ar}):null),!(g.revealed||[]).includes(id)?btn('They got it!',b=>send('party.confirm',{playerId:id},b),'btn-good'):h('span',{class:'pill',text:(g.solved||[]).includes(id)?'Solved':'Revealed'})))),
      next,partyClock(g),scoreboard(snap,{selfId:me}));
  }else if(snap.mode==='feud'){
    const myTurn=g.control===me && ['answering','steal'].includes(g.roundPhase);
    body=h('div',{class:'stack'},partyTeams(snap),feudBoard(g),
      card(g.roundPhase==='steal'?'One chance to steal':g.roundPhase==='awarded'?'Points awarded':myTurn?'Your turn':g.buzzer?.open?'Buzz to take control':name(snap,g.control)+' is answering',
        partyClock(g),g.buzzer?.open?btn('Buzz!',b=>send('feud.buzz',{},b),'btn-pri btn-lg'):null,
        myTurn?answerForm(snap,send,'feud.answer','Type your answer',{turn:g.turn}):null,
        g.lastAnswer?para(name(snap,g.lastAnswer.playerId)+': '+g.lastAnswer.text+(g.lastAnswer.correct?' ✓':' ✕')):null,
        g.roundPhase==='awarded'?para((g.teamMode?(g.awardedTo==='A'?'Red team':'Blue team'):name(snap,g.awardedTo))+' gets '+g.awardedPoints+' points.'):null,next));
  }else if(snap.mode==='impostor'){
    const key=snap.code+':'+snap.roundId;if(key!==revealKey){revealKey=key;shown=false;}
    const you=g.you||{},phase=g.roundPhase;
    const secret=()=>you.role==='impostor'?h('div',{class:'stack'},para('You are the impostor.'),you.hint?para('Your hint: '+you.hint):para('Listen carefully and blend in.')):h('div',{class:'stack'},para('You know the word:'),h('strong',{class:'party-secret',text:you.word}));
    body=h('div',{class:'stack'},phase==='discussion'?card('Your private card',shown?secret():para('Keep this screen to yourself.'),btn(shown?'Hide my card':'Show my card',()=>{shown=!shown;document.dispatchEvent(new Event('party-render'));})):null,
      partyClock(g),phase==='discussion'?card('Give clues without saying the word',para('Discuss together, then start the vote when everyone is ready.'),next):null,
      phase==='vote'?card('Who is the impostor?',g.votes?.[me]?para('Vote received. Waiting for the others…'):h('div',{class:'stack'},...(g.order||[]).filter(id=>id!==me).map(id=>btn(name(snap,id),b=>send('impostor.vote',{playerId:id},b)))),para(Object.keys(g.votes||{}).length+' / '+g.votesNeeded+' votes')):null,
      phase==='guess_word'?card('Last chance',g.you?.role==='impostor'?answerForm(snap,send,'impostor.guess_word','Guess the secret word'):para('The impostor gets one chance to guess the word.')):null,
      phase==='reveal'?card('The reveal',para(g.reveal?.word||''),para('Impostor: '+name(snap,g.reveal?.impostor)),para(IMPOSTOR_OUTCOMES[g.outcome]||g.outcome||''),next):null,scoreboard(snap,{selfId:me}));
  }
  return h('div',{class:'stack'},modeHeading(snap),rulesPanel(snap.mode,{everyonePlays:!!g.everyonePlays}),body);
}
export function partyExtras(snap,send){
  const g=snap.game||{},me=snap.self?.id;if(!g.everyonePlays || !(g.order||[]).includes(me))return null;
  const controls=[];
  if(snap.mode==='taboo' && g.roundPhase==='clue_turn'){
    if(g.clueGiverId===me)controls.push(btn('Skip this word',b=>send('party.taboo',{result:'skip',cardEpoch:g.cardEpoch},b)));
    else if(g.you?.role==='referee')controls.push(card('Other team: help judge this turn',para(g.you.card?.word||''),para('Do not say: '+(g.you.card?.forbidden||[]).join(', ')),btn('They got it',b=>send('party.taboo',{result:'correct',cardEpoch:g.cardEpoch},b),'btn-good'),btn('Forbidden word used',b=>send('party.taboo',{result:'violation',cardEpoch:g.cardEpoch},b),'btn-ghost')));
  }
  if(snap.mode==='escape_room' && g.phase==='active')controls.push(btn('Use a hint',b=>send('party.hint',{},b)));
  if(g.canAdvance)controls.push(btn('Continue',b=>send('party.advance',{},b),'btn-pri'));
  return h('section',{class:'card stack'},para('Everyone plays. No separate host needed.'),partyClock(g),...controls);
}
