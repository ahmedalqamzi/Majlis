// Majlis Party TV display: optional, read-only, public. It only renders the display projection,
// which never contains unrevealed Who Am I characters or hidden Feud answers.
// Credential: the display token the server gave the operator at room creation. In this build it
// is handed over only within the same browser (host page -> "Open TV display"); a separate TV
// device needs a pairing step that protocol v1 does not yet define (see party/web/README.md).
import {partyClock,partyTeams} from './party-play.js';
import { h, mount, makeTransport, simRibbon, connBanner, describeError, pageUrl, hashCode, playerName, isSim, setRetryHandler, announce, TERMINAL_ROOM, TERMINAL_SEAT } from './ui.js';
import { loadCredential, clearCredential, normalizeCode, isCodeShape } from './session.js';
import { modeInfo } from './modes.js';
import { qrBlock, codeBlock, playerChips, scoreboard, modeHeading, feudBoard, pausedOverlay, FeudChanges, announceFeudChanges, IMPOSTOR_OUTCOMES, teamScoreboard, tabooResultText, tabooStatusPanel } from './views.js';
import { mountPresentationToolbar } from './tv-presentation.js';

const app = document.getElementById('app');
const simEl = document.getElementById('sim');
if (simEl) mount(simEl, simRibbon());
// Outside #app so it is never replaced by render()'s mount(app, ...) and never needs reapplying
// after an SSE snapshot.
const toolbarEl = document.getElementById('tv-toolbar');
if (toolbarEl) mountPresentationToolbar(toolbarEl);

let transport, snap = null;
const feudChanges = new FeudChanges();

// This screen needs a display credential the host issues when it opens its own TV window; that is
// a same-browser hand-off (party/web/README.md), not a cross-device pairing step, and this build has
// no remote way to pair a separate screen or to turn a player/host credential into a display one. If
// that credential is missing here, say so plainly and point at the one thing this device *can* do:
// join the game as a player. Never guess at a host page this route may not even serve (majlis:native-display-route-v1).
function noAccess(message) {
  mount(app, h('main', { class: 'tv-page center' },
    h('section', { class: 'card narrow stack center-text' },
      h('h1', { class: 'card-title', text: 'TV display' }),
      h('p', { text: message }),
      h('p', { class: 'muted', text: 'This screen needs a display credential from the room’s host; it did not get one. ' +
        'There is no way to pair a separate TV or device here - the host’s own browser hands this credential to its own TV window when it opens one.' }),
      h('a', { class: 'btn btn-ghost', href: pageUrl('play.html'), text: 'Join as a player instead' }))));
}

function render() {
  if (!snap) return;
  let body;
  if (snap.phase === 'lobby') body = lobby();
  else if (snap.phase === 'ended') body = ended();
  else if (snap.mode === 'feud') body = feud();
  else if (snap.mode === 'who_am_i') body = whoAmI();
  else if (snap.mode === 'impostor') body = impostor();
  else if (snap.mode === 'taboo') body = taboo();
  else if (snap.mode === 'bluff') body = bluff();
  else if (snap.mode === 'escape_room') body = escapeRoom();
  else body = h('p', { text: modeInfo(snap.mode).title });
  mount(app, h('main', { class: 'tv-page' }, body), snap.phase === 'paused' ? pausedOverlay() : null);
}

function lobby() {
  return h('div', { class: 'tv-lobby' },
    h('div', { class: 'tv-join' },
      h('div', { class: 'tv-brand', text: 'Majlis Party' }),
      codeBlock(snap.code, { label: 'Join with code' }),
      qrBlock(snap.code, { size: 'lg' }),
      h('p', { class: 'tv-hint', text: 'Scan with your phone camera, same Wi‑Fi.' })),
    h('div', { class: 'tv-side' },
      h('h2', { class: 'tv-h2', text: snap.mode ? 'Next: ' + modeInfo(snap.mode).title : 'Waiting for the host' }),
      h('h3', { class: 'tv-h3', text: 'Players (' + (snap.players || []).length + ')' }),
      playerChips(snap)));
}

// Server contract (party/server/modes/who_am_i.py project()): the display projection's
// game.order/ready/revealed/solved/pendingGuesses are the only authoritative player-id lists,
// and game.assignments is keyed ONLY by ids already in game.revealed -- the server never sends
// an unrevealed player's character to this role. A helper that only trusts an id present in
// `order` (deduped, non-string entries dropped) protects every count/card below from a
// malformed snapshot or a planted extra key in assignments without inventing new transport
// shape: this never reads anything beyond the fields already listed above.
function whoAmIOrderSet(g) {
  return new Set(Array.isArray(g.order) ? g.order.filter(id => typeof id === 'string') : []);
}
function whoAmIEligibleSet(list, orderSet) {
  const out = new Set();
  if (Array.isArray(list)) for (const id of list) if (typeof id === 'string' && orderSet.has(id)) out.add(id);
  return out;
}

// Paused room state always wins over round-phase guidance -- including mid-"asking" -- so the
// screen never invites a guess while the host has the game on hold (majlis:whoami-display-round-clarity-v1).
// Resume relies entirely on the next authoritative snapshot; there is no local timer/retry here.
function whoAmIPhaseText(snap) {
  if (snap.phase === 'paused') return 'Paused by the host.';
  const g = snap.game || {};
  if(g.everyonePlays)return g.roundPhase==='asking'?'Ask yes/no questions. Guess on your phone, or confirm another player’s correct guess.':g.roundPhase==='revealed'?'Round complete. The next round starts shortly.':'The game is over.';
  switch (g.roundPhase) {
    case 'asking':
      return 'Players ask yes/no questions aloud and submit guesses on their phones for the host to judge. Unrevealed characters stay hidden on this screen.';
    case 'revealed':
      return 'This round is over — every character is revealed.';
    case 'ended':
      return 'The game is over.';
    default:
      return 'Waiting for the host.';
  }
}

// Labelled, honest public progress counts. Missing/malformed game.order, or a missing/malformed
// individual list, makes that count "unavailable" rather than a fabricated zero or total; an
// explicit empty array for a list present alongside a valid order is a real, valid zero.
function whoAmIProgress(g) {
  const hasOrder = Array.isArray(g.order);
  const orderSet = whoAmIOrderSet(g);
  const total = hasOrder ? orderSet.size : null;
  const count = list => (hasOrder && Array.isArray(list)) ? String(whoAmIEligibleSet(list, orderSet).size) + ' of ' + total : 'unavailable';
  return [
    { label: 'Ready', value: count(g.ready) },
    { label: g.everyonePlays?'Guesses':'Guesses awaiting the host', value: (hasOrder && Array.isArray(g.pendingGuesses)) ? String(whoAmIEligibleSet(g.pendingGuesses, orderSet).size) : 'unavailable' },
    { label: 'Solved', value: count(g.solved) },
    { label: 'Revealed', value: count(g.revealed) },
  ];
}

// Tracks the previous Who Am I snapshot so only a genuine phase change or a brand-new
// reveal/solve is announced once -- never re-announced on every snapshot of the same state
// (mirrors the dedup discipline FeudChanges already uses for Feud, kept local here since
// views.js is out of scope for this change).
class WhoAmIChanges {
  constructor() { this.round = null; this.phase = null; this.revealed = new Set(); this.solved = new Set(); }
  diff(snap) {
    const g = snap.game || {};
    const orderSet = whoAmIOrderSet(g);
    const revealed = whoAmIEligibleSet(g.revealed, orderSet);
    const solved = whoAmIEligibleSet(g.solved, orderSet);
    const phase = snap.phase === 'paused' ? 'paused' : (g.roundPhase || 'unknown');
    const roundKey = g.round != null ? g.round : null;
    if (this.round !== roundKey) {
      this.round = roundKey; this.phase = phase; this.revealed = revealed; this.solved = solved;
      return { phaseChanged: false, freshRevealed: new Set(), freshSolved: new Set() };
    }
    const phaseChanged = phase !== this.phase;
    const freshRevealed = new Set([...revealed].filter(id => !this.revealed.has(id)));
    const freshSolved = new Set([...solved].filter(id => !this.solved.has(id)));
    this.phase = phase; this.revealed = revealed; this.solved = solved;
    return { phaseChanged, freshRevealed, freshSolved };
  }
}
const whoAmIChanges = new WhoAmIChanges();
function announceWhoAmIChanges(diff, snap) {
  if (diff.phaseChanged) announce(whoAmIPhaseText(snap));
  diff.freshSolved.forEach(id => announce(playerName(snap, id) + ' solved their character.'));
  diff.freshRevealed.forEach(id => { if (!diff.freshSolved.has(id)) announce(playerName(snap, id) + '’s character was revealed.'); });
}

function whoAmI() {
  const g = snap.game || {};
  const orderSet = whoAmIOrderSet(g);
  const revealedSet = whoAmIEligibleSet(g.revealed, orderSet);
  const solvedSet = whoAmIEligibleSet(g.solved, orderSet);
  const readySet = whoAmIEligibleSet(g.ready, orderSet);
  const pendingSet = whoAmIEligibleSet(g.pendingGuesses, orderSet);
  // The display projection holds only revealed players' characters; this still only trusts an
  // assignment when the id is independently confirmed revealed above, so a planted extra
  // assignments entry for an unrevealed id can never surface here.
  const assignments = g.assignments || {};
  announceWhoAmIChanges(whoAmIChanges.diff(snap), snap);
  return h('div', { class: 'tv-who' },
    modeHeading(snap),
    h('p', { class: 'tv-sub', text: whoAmIPhaseText(snap) }),g.everyonePlays?partyClock(g):null,
    h('section', { class: 'tv-who-progress', 'aria-label': 'Round progress' },
      whoAmIProgress(g).map(it => h('div', { class: 'tv-who-progress-item' },
        h('span', { class: 'eyebrow', text: it.label }),
        h('span', { class: 'status-line', text: it.value })))),
    h('ul', { class: 'tv-who-grid' }, (snap.players || []).map(p => {
      const id = p.id;
      const isRevealed = revealedSet.has(id);
      const isSolved = solvedSet.has(id);
      const isReady = readySet.has(id);
      const isPending = pendingSet.has(id);
      const a = isRevealed ? assignments[id] : null;
      const hasLabel = !!(a && typeof a.label === 'string' && a.label);
      const score = Number.isFinite(p.score) ? p.score : null;
      const badge = isSolved ? h('span', { class: 'badge-good', text: 'Solved' })
        : isPending ? h('span', { class: 'badge-warn', text: g.everyonePlays?'Guessing':'Guessing — awaiting host' })
        : isReady ? h('span', { class: 'badge-later', text: 'Ready' })
        : null;
      const hasName = p.name != null && String(p.name) !== '';
      return h('li', { class: 'tv-who-card' + (isSolved ? ' solved' : '') },
        h('span', { class: 'who-name', dir: 'auto', text: hasName ? String(p.name) : 'Unknown player' }),
        hasLabel
          ? h('span', { class: 'char-label', dir: 'auto', text: a.label })
          : h('span', { class: 'mystery-sm', 'aria-label': 'Character hidden' }, h('span', { 'aria-hidden': 'true', text: '?' })),
        badge,
        h('span', { class: 'tv-pts', text: score === null ? 'Points unavailable' : String(score) + ' points' }));
    })));
}

// Truthful, paused-aware Feud phase guidance for the shared display (majlis:feud-display-phase-
// clarity-v1). Distinguishes "buzz on your phone" from "answer aloud" from "waiting for the
// host" without exposing any write control, and never fabricates a roster identity: playerName()
// already returns the neutral 'A player' for a missing/unknown id, same as every other mode on
// this page. Paused always wins over every other phase text, even mid-round.
function feudPhaseGuidance(snap) {
  if(snap.game?.everyonePlays || snap.game?.automatedRules){
    const g=snap.game,name=id=>g.teamMode&&id==='A'?'Red team':g.teamMode&&id==='B'?'Blue team':playerName(snap,id);
    if(snap.phase==='paused')return 'Game paused.';
    if(g.roundPhase==='closed')return 'Get ready. The host will reopen the buzzer.';
    if(g.roundPhase==='buzzer_open')return 'Buzz on your phone to take control.';
    if(g.roundPhase==='awarded')return name(g.awardedTo)+' won '+g.awardedPoints+' points. '+(g.everyonePlays?'Next question coming up.':'Choose Continue for the next question.');
    if(g.roundPhase==='steal')return name(g.control)+' — one answer to steal the points!';
    return name(g.control)+(g.everyonePlays?' — type your answer on your phone.':' — type your answer or say it to the host.');
  }

  const g = snap.game || {};
  const name = id => playerName(snap, id);
  if (snap.phase === 'paused') return 'Paused by the host.';
  switch (g.roundPhase) {
    case 'closed': return 'Get ready — the host will open the buzzer.';
    case 'buzzer_open':
      return feudBuzzerOpenConsistent(g) ? 'Buzzer is open — buzz on your phone!' : 'Waiting for the host.';
    case 'answering':
      if (Number.isInteger(g.strikes) && g.strikes >= 0 && Number.isInteger(g.maxStrikes) && g.maxStrikes > 0 && g.strikes >= g.maxStrikes)
        return 'Strike limit reached — the host may offer a steal.';
      return g.control ? name(g.control) + ', answer aloud.' : 'Waiting for the host.';
    case 'steal':
      return g.control ? name(g.control) + ' is trying to steal' + (g.stealFrom ? ' from ' + name(g.stealFrom) : '') + '.' : 'Steal attempt — waiting for the host.';
    case 'awarded': {
      if (!g.awardedTo) return 'Round over.';
      const pts = Number.isFinite(g.awardedPoints) && g.awardedPoints >= 0 ? g.awardedPoints : null;
      return pts === null ? name(g.awardedTo) + ' won this round — points unavailable.'
        : name(g.awardedTo) + ' won ' + pts + ' point' + (pts === 1 ? '' : 's') + ' this round.';
    }
    case 'ended': return 'Game over.';
    default: return 'Waiting for the host…';
  }
}

// Labelled, honest strike count for the shared display: the actual configured limit, never a
// hard-coded "Three strikes" assumption, and neutral "unavailable" wording (never a fabricated
// 0/3) when the authoritative strikes/maxStrikes the server actually sent are missing, negative,
// fractional or otherwise not valid counting numbers.
function feudStrikeLabel(g) {
  const strikes = Number.isInteger(g.strikes) && g.strikes >= 0 ? g.strikes : null;
  const max = Number.isInteger(g.maxStrikes) && g.maxStrikes > 0 ? g.maxStrikes : null;
  if (strikes === null || max === null) return 'Strikes unavailable';
  if (strikes >= max) return 'Strike limit reached';
  return strikes + ' of ' + max + ' strikes';
}

// A buzzer is only truthfully "open" when every authoritative signal agrees: the round phase
// itself is buzzer_open, the server's own buzzer.open flag is the strict boolean true (never a
// truthy string like 'false', and never merely "present"), and there is no public winner yet --
// a winner already means the window closed even if a stale/contradictory open flag lingers.
function feudBuzzerOpenConsistent(g) {
  return g.roundPhase === 'buzzer_open' && !!g.buzzer && g.buzzer.open === true && !g.buzzer.winner;
}

// Buzzer panel state the display is actually entitled to claim: paused always overrides, even
// when the last projected buzzer.open is still true (majlis:feud-display-phase-clarity-v1 point
// 2) -- a round paused mid-buzzer-window must never keep inviting a buzz. Any state that is not
// a strictly consistent open (see feudBuzzerOpenConsistent) and has no public winner to show is
// neutral waiting wording rather than an invitation to buzz, matching the heading above it.
function feudBuzzerPanel(snap) {
  const g = snap.game || {};
  const winner = g.buzzer && g.buzzer.winner;
  if (snap.phase === 'paused') return { cls: '', label: 'Paused by the host' };
  if (feudBuzzerOpenConsistent(g)) return { cls: ' open', label: 'OPEN' };
  if (winner && (g.roundPhase === 'answering' || g.roundPhase === 'steal' || g.roundPhase === 'awarded')) return { cls: ' won', label: playerName(snap, winner) };
  if (g.roundPhase === 'closed') return { cls: '', label: 'Closed' };
  return { cls: '', label: 'Waiting for the host' };
}

// Honest round-points bank for the Feud TV boundary: feudBoard() (shared with the player view,
// never edited here) renders `String(game.roundPoints || 0)`, which fabricates 0 for a
// missing/non-finite value and prints a malformed string like 'bad' verbatim. Compute the one
// truthful value here and overwrite just that rendered text node after mount, leaving the rest
// of the board (icons, slots, house label, strike dots) exactly as feudBoard produced it.
function feudBankValue(g) {
  return Number.isFinite(g.roundPoints) && g.roundPoints >= 0 ? g.roundPoints : null;
}

function feud() {
  const g = snap.game || {};
  const changes = feudChanges.diff(snap);
  announceFeudChanges(changes, g, announce);
  const buzz = feudBuzzerPanel(snap);
  const board = feudBoard(g, { tv: true, changes });
  const bankNum = board.querySelector('.bank-num');
  if (bankNum) {
    const bank = feudBankValue(g);
    bankNum.textContent = bank === null ? 'Unavailable' : String(bank);
  }
  return h('div', { class: 'tv-feud' },
    h('div', { class: 'tv-feud-main' },
      modeHeading(snap),
      board,
      h('p', { class: 'tv-status', dir: 'auto', text: feudPhaseGuidance(snap) }),
      h('p', { class: 'tv-sub', text: feudStrikeLabel(g) })),
    h('aside', { class: 'tv-feud-side' },
      h('div', { class: 'tv-buzz' + buzz.cls },
        h('span', { class: 'eyebrow', text: 'Buzzer' }),
        h('strong', { dir: 'auto', text: buzz.label })),
      (g.everyonePlays||g.automatedRules)?partyClock(g):null,(g.everyonePlays||g.automatedRules)?partyTeams(snap):scoreboard(snap)));
}

// Dedupe-and-validate game.order into the single authoritative roster id set, same discipline as
// whoAmIOrderSet above: non-string entries dropped, duplicates collapsed. Every count/card below
// is built from this set (or explicitly reports "unavailable"), never from snap.players, so a
// spectator entry in snap.players can never inflate a denominator (majlis:impostor-display-round-
// clarity-v1).
function impostorOrderSet(g) {
  return new Set(Array.isArray(g.order) ? g.order.filter(id => typeof id === 'string') : []);
}

// playerName() already falls back to 'A player' for an id with no matching roster row, but an
// existing row whose own name field is missing/null/blank/non-string passes straight through
// (the pre-existing "undefined was caught!" bug this corrects). This local wrapper re-validates
// the returned name so every Impostor display surface -- nominee guidance, grid cards, reveal --
// gets the same honest fallback without touching the shared playerName() helper or any other
// mode's behaviour (majlis:impostor-display-round-clarity-v1:correction-r1).
function impostorSafeName(snap, id) {
  const name = playerName(snap, id);
  return typeof name === 'string' && name.trim() !== '' ? name : 'A player';
}

// Authoritative, labelled public vote-progress text. votesNeeded is only trusted when it is a
// valid non-negative integer AND agrees with the deduped order size (server contract: votesNeeded
// === len(order)); any mismatch is contradictory authority, not a guess. The numerator counts only
// unique vote keys that are members of the roster -- a foreign key (not in order) is ignored, and
// a vote object missing/malformed when the order itself is valid is "unavailable", never a
// fabricated zero or a silent fallback to every room occupant (which previously included
// spectators). Every roster voter's target value is also checked against the public server
// contract (string, a different roster member): a malformed or contradictory target -- null, a
// number, or a value naming nobody in the roster -- is authority the display cannot trust, so the
// whole line reports "unavailable" rather than fabricating completion from it or silently excluding
// the bad voter (majlis:impostor-display-round-clarity-v1:correction-r1).
function impostorVoteProgressText(g, orderSet) {
  const hasOrder = Array.isArray(g.order);
  if (!hasOrder) return 'Votes unavailable.';
  const total = orderSet.size;
  const needed = g.votesNeeded;
  const neededValid = Number.isInteger(needed) && needed >= 0 && needed === total;
  if (!neededValid) return 'Votes unavailable.';
  const votes = g.votes;
  if (votes === null || typeof votes !== 'object' || Array.isArray(votes)) return 'Votes unavailable.';
  const cast = new Set();
  for (const voter of Object.keys(votes)) {
    if (!orderSet.has(voter)) continue;
    const target = votes[voter];
    if (typeof target !== 'string' || !orderSet.has(target) || target === voter) return 'Votes unavailable.';
    cast.add(voter);
  }
  return cast.size + ' of ' + total + ' votes are in.';
}

// Truthful phase guidance. Paused always wins, even mid-vote/guess (same discipline as
// whoAmIPhaseText): the screen never invites discussion/voting/guessing while the host has the
// round on hold. An unknown/missing roundPhase gets a neutral fallback instead of silently
// reading as "Round over." (the pre-existing bug this corrects).
function impostorPhaseText(snap, orderSet) {
  if (snap.phase === 'paused') return 'Paused by the host.';
  const g = snap.game || {};
  switch (g.roundPhase) {
    case 'discussion':
      return 'Discuss! Who doesn’t have the word?';
    case 'vote':
      return impostorVoteProgressText(g, orderSet);
    case 'guess_word':
      return impostorSafeName(snap, g.nominee) + ' was caught! Guessing the word…';
    case 'reveal':
      return 'The round is over — see the reveal below.';
    case 'ended':
      return 'The game is over.';
    default:
      return 'Waiting for the host.';
  }
}

// Per-player vote tally for the shared grid, shown only while votes are meaningful to display
// (vote/guess_word/reveal). tally is only trusted as a map of non-negative integers, each bounded
// by the authoritative deduped roster size (no player can be named on more votes than there are
// roster voters -- a self-vote is never recorded by the server, so the real ceiling is total - 1,
// but total is used as the honest, still-bounding limit without hard-coding that extra server
// rule here); a missing, non-object, or out-of-range entry for a real roster id reports
// "unavailable" rather than a fabricated "0 votes" or an impossible count (a real authoritative
// zero is rendered honestly as "0 votes").
function impostorTallyText(g, pid) {
  const tally = g.tally;
  if (tally === null || typeof tally !== 'object' || Array.isArray(tally)) return 'Votes unavailable';
  const v = tally[pid];
  const total = impostorOrderSet(g).size;
  if (!Number.isInteger(v) || v < 0 || v > total) return 'Votes unavailable';
  return v + ' vote' + (v === 1 ? '' : 's');
}

function impostor() {
  const g = snap.game || {};
  const phase = g.roundPhase;
  const orderSet = impostorOrderSet(g);
  const showTally = phase === 'vote' || phase === 'guess_word' || phase === 'reveal';
  // Deduped, order-preserving unique roster ids -- never the raw (possibly duplicated/foreign-
  // entry-bearing) game.order array, and never snap.players (which can hold spectators).
  const uniqueOrder = [];
  const seen = new Set();
  if (Array.isArray(g.order)) for (const id of g.order) if (orderSet.has(id) && !seen.has(id)) { seen.add(id); uniqueOrder.push(id); }
  return h('div', { class: 'tv-who' },
    modeHeading(snap),
    h('p', { class: 'tv-sub', dir: 'auto', text: impostorPhaseText(snap, orderSet) }),g.everyonePlays?partyClock(g):null,
    h('ul', { class: 'tv-who-grid' }, uniqueOrder.map(pid => {
      const p = (snap.players || []).find(x => x.id === pid);
      const score = p && Number.isFinite(p.score) ? p.score : null;
      return h('li', { class: 'tv-who-card' },
        h('span', { class: 'who-name', dir: 'auto', text: impostorSafeName(snap, pid) }),
        showTally ? h('span', { class: 'char-label', text: impostorTallyText(g, pid) }) : null,
        h('span', { class: 'tv-pts', text: score === null ? 'Points unavailable' : String(score) + ' points' }));
    })),
    impostorReveal(snap, g));
}

// Publicly revealed word/identity/outcome, in separate labelled blocks, shown only in the
// permitted reveal phase (g.reveal is null everywhere else per the server projection contract --
// this never reads game.you, credentials or a role map, and never renders anything before the
// server itself marks the round revealed).
function impostorReveal(snap, g) {
  const phase = g.roundPhase;
  if (phase !== 'reveal' && phase !== 'ended') return null;
  const reveal = g.reveal;
  if (!reveal || typeof reveal !== 'object') return null;
  const hasWord = typeof reveal.word === 'string' && reveal.word !== '';
  if (!hasWord) return null;
  const impostorName = typeof reveal.impostor === 'string' ? impostorSafeName(snap, reveal.impostor) : null;
  return h('section', { class: 'tv-impostor-reveal', 'aria-label': 'Reveal' },
    h('div', { class: 'tv-impostor-reveal-item' },
      h('span', { class: 'eyebrow', text: 'Word' }),
      h('span', { class: 'status-line', dir: 'auto', text: reveal.word })),
    impostorName ? h('div', { class: 'tv-impostor-reveal-item' },
      h('span', { class: 'eyebrow', text: 'Impostor' }),
      h('span', { class: 'status-line', dir: 'auto', text: impostorName })) : null,
    h('div', { class: 'tv-impostor-reveal-item' },
      h('span', { class: 'eyebrow', text: 'Outcome' }),
      h('span', { class: 'status-line', text: IMPOSTOR_OUTCOMES[g.outcome] || 'Unavailable' })));
}

// Public/safe only: team names+scores, active team, clue-giver name, server-derived countdown,
// cards remaining, and the generic outcome word (correct/violation/skip/pass/expired) of the last
// resolved card. Never the active word, forbidden words, a future card, or any credential — the
// display projection carries none of those fields for a role that is never 'operator'/'clue_giver'
// on this page (the TV token is always role 'display').
// Reuses the accepted tabooStatusPanel (majlis:taboo-player-turn-status-v1) for the same honest,
// authoritative-only Time/Team/Cards-left labelling and paused/turn_complete/exhausted text the
// player panel already shows — this view must not re-derive or drift from that logic. The
// clue-giver guidance below is new and kept in its own separate paragraph: it only ever restates
// the giver's roster identity for the active (still-assigned) turn, never a timing or action
// claim, so it stays equally true whether the round is paused or not.
function taboo() {
  const g = snap.game || {};
  const phase = g.roundPhase;
  const giverGuidance = phase === 'clue_turn'
    ? h('p', { class: 'tv-sub', dir: 'auto', text: playerName(snap, g.clueGiverId) + ' is giving clues for Team ' + (g.activeTeam === 'A' || g.activeTeam === 'B' ? g.activeTeam : '—') + '.' })
    : null;
  return h('div', { class: 'tv-who' },
    modeHeading(snap),
    tabooStatusPanel(snap),
    giverGuidance,
    teamScoreboard(snap));
}

// Plain, truthful per-phase guidance for a display nobody can act from: what the phones in
// people's hands are doing right now, never a control or a claim this screen can perform.
const BLUFF_PHASE_GUIDANCE = {
  submission: { label: 'Writing fake answers', text: 'Each player is writing a convincing fake answer on their own phone.' },
  voting: { label: 'Voting', text: 'Each player is choosing which answer they think is the real one on their own phone.' },
  reveal: { label: 'Reveal', text: 'The real answer and who voted for what are shown below.' },
  finished: { label: 'Reveal', text: 'The real answer and who voted for what are shown below.' },
};

// Honest submission/vote progress from the projection's own counters only — never a fabricated
// total or a player count inferred from anything else. Zero is a valid, truthful count; a
// missing/non-finite counter says so plainly instead of rendering undefined/NaN.
function bluffProgress(noun, count, total) {
  const totalOk = Number.isFinite(total) && total >= 0;
  const countOk = Number.isFinite(count) && count >= 0;
  if (!totalOk || !countOk) return noun + ' progress unavailable.';
  return count + ' of ' + total + ' ' + noun + ' in…';
}

// English and Arabic are separate text nodes with their own lang/dir, never concatenated with a
// "/" — a question missing one language is omitted outright instead of leaving a dangling
// separator or the literal word "undefined".
function bluffQuestionBlocks(question) {
  if (!question || typeof question !== 'object') return null;
  const en = typeof question.en === 'string' && question.en ? question.en : null;
  const ar = typeof question.ar === 'string' && question.ar ? question.ar : null;
  if (!en && !ar) return null;
  return [
    en ? h('p', { class: 'tv-q tv-bluff-q', lang: 'en', dir: 'ltr', text: en }) : null,
    ar ? h('p', { class: 'tv-q tv-bluff-q', lang: 'ar', dir: 'rtl', text: ar }) : null,
  ];
}

function bluff() {
  const g = snap.game || {};
  const phase = g.phase;
  const paused = snap.phase === 'paused';
  // Paused overrides only the heading/guidance line: it must never read as an invitation to act
  // on a phone right now. The phase-specific data below (progress, options, reveal) stays the
  // same truthful read of state.game whether or not the room is paused.
  const guidance = paused
    ? { label: 'Paused', text: 'The game is paused. There is nothing to do on your phone right now.' }
    : (BLUFF_PHASE_GUIDANCE[phase] || { label: 'Waiting', text: 'Waiting for the host to continue.' });
  let progress = null, extra = null;
  if (phase === 'submission') {
    progress = bluffProgress('fake answers', g.submittedCount, g.totalPlayers);
  } else if (phase === 'voting') {
    progress = bluffProgress('votes', g.votedCount, g.totalPlayers);
    // Pre-reveal options never carry authorId: nobody on the TV can tell who wrote what.
    extra = h('ul', { class: 'tv-who-grid' }, (g.options || []).map(o =>
      h('li', { class: 'tv-who-card' }, h('span', { class: 'who-name', dir: 'auto', text: o.text }))));
  } else if (phase === 'reveal' || phase === 'finished') {
    const last = g.lastResult || {};
    // Bug fixed: last.question is the {en, ar} bilingual question object
    // (awardRound deep-copies state.item.question verbatim into lastResult),
    // not the true-answer text — concatenating it produced literally
    // "The real answer was: “[object Object]”". The actual true-answer text
    // (already in the selected voting language, same as every other option)
    // is the option whose optionId matches last.trueOptionId.
    const trueOpt = (last.options || []).find(o => o.optionId === last.trueOptionId);
    progress = trueOpt ? 'The real answer was: “' + trueOpt.text + '”' : 'The real answer is not available.';
    const votersByOption = {};
    Object.keys(last.voters || {}).forEach(pid => {
      const oid = last.voters[pid];
      (votersByOption[oid] = votersByOption[oid] || []).push(playerName(snap, pid));
    });
    extra = h('ul', { class: 'tv-who-grid' }, (last.options || []).map(o => {
      const isTrue = o.optionId === last.trueOptionId;
      const votes = (last.voteTally || {})[o.optionId] || 0;
      const voterNames = (votersByOption[o.optionId] || []).join(', ');
      return h('li', { class: 'tv-who-card' + (isTrue ? ' solved' : '') },
        h('span', { class: 'who-name', dir: 'auto', text: o.text }),
        h('span', { class: 'char-label', dir: 'auto',
          text: isTrue ? 'True answer' : (o.authorId ? playerName(snap, o.authorId) + '’s fake' : 'Fake') }),
        h('span', { class: 'tv-pts', text: String(votes) + ' vote' + (votes === 1 ? '' : 's') }),
        voterNames ? h('span', { class: 'tv-sub', dir: 'auto', text: 'Voted by: ' + voterNames }) : null);
    }));
  }
  return h('div', { class: 'tv-who' },
    modeHeading(snap),
    h('p', { class: 'pill', text: guidance.label }),
    h('p', { class: 'tv-sub', text: guidance.text }),
    bluffQuestionBlocks(g.question),
    progress !== null ? h('p', { class: 'tv-sub', text: progress }) : null,
    extra,
    scoreboard(snap));
}

function escapeRoom() {
  const g = snap.game || {};
  const mins = Math.floor((g.remainingSeconds || 0) / 60), secs = Math.floor((g.remainingSeconds || 0) % 60);
  const teamScore = (snap.players || [])[0] ? (snap.players || [])[0].score : 0;
  // The mode's own game can finish (success or timeout) before the operator sends room.end, so
  // snap.phase (room-level) may still read "playing" here while g.currentPuzzle is already null
  // (escape_room.py project()). Show the public reveal immediately rather than a blank puzzle.
  if (g.phase === 'ended') {
    const reveal = g.reveal || {};
    return h('div', { class: 'tv-who' },
      modeHeading(snap),
      h('p', { class: 'tv-sub', text: 'Team score: ' + teamScore }),
      (reveal.puzzles || []).map((p, i) => h('p', { class: 'tv-sub', dir: 'auto', text: 'Puzzle ' + (i + 1) + ': ' + p.answer })));
  }
  const puzzle = g.currentPuzzle || {};
  return h('div', { class: 'tv-who' },
    modeHeading(snap),
    h('p', { class: 'tv-sub', text: mins + ':' + String(secs).padStart(2, '0') + ' left · Team score: ' + teamScore
      + (g.phase === 'solved' ? ' · Solved! Advancing…' : '') }),
    h('p', { class: 'tv-sub', dir: 'auto', text: puzzle.promptEn || '' }),
    puzzle.promptAr ? h('p', { class: 'tv-sub', lang: 'ar', dir: 'rtl', text: puzzle.promptAr }) : null,
    puzzle.hintEn ? h('p', { class: 'tv-sub', dir: 'auto', text: 'Hint: ' + puzzle.hintEn }) : null,
    puzzle.hintAr ? h('p', { class: 'tv-sub', lang: 'ar', dir: 'rtl', text: puzzle.hintAr }) : null);
}

function ended() {
  const reveal = snap.mode === 'escape_room' && snap.game ? (snap.game.reveal || {}) : null;
  const tabooText = snap.mode === 'taboo' && snap.game ? tabooResultText(snap) : null;
  return h('div', { class: 'tv-ended' },
    h('h1', { class: 'tv-title', text: 'Final scores' }),
    tabooText ? h('p', { class: 'tv-status', role: 'status', text: tabooText }) : null,
    reveal ? h('div', { class: 'tv-who' },
      (reveal.puzzles || []).map((p, i) => h('p', { class: 'tv-sub', dir: 'auto', text: 'Puzzle ' + (i + 1) + ': ' + p.answer }))) : null,
    snap.mode === 'taboo' && snap.game ? teamScoreboard(snap, { title: 'Final scores' }) : scoreboard(snap, { title: 'Final scores' }));
}

(async () => {
  try {
    transport = await makeTransport();
  } catch (e) {
    noAccess(describeError(e.code));
    return;
  }
  const code = normalizeCode(hashCode());
  // Opening the TV for another room from the host reuses this window with a new fragment.
  window.addEventListener('hashchange', () => { if (normalizeCode(hashCode()) !== code) location.reload(); });
  if (!isCodeShape(code)) { noAccess('No room selected.'); return; }
  const cred = loadCredential('display', code, isSim);
  if (!cred) { noAccess('This screen is not paired with room ' + code + '.'); return; }
  mount(app, h('main', { class: 'tv-page center' }, h('p', { class: 'muted', text: 'Connecting…' })));
  let stream = null;
  setRetryHandler(() => stream && stream.kick());
  stream = transport.subscribe(code, cred.token, {
    onSnapshot: (s) => {
      if (s.phase === 'closed') {
        if (stream) { stream.close(); stream = null; }
        clearCredential('display', code, isSim);
        connBanner('live');
        noAccess('The host closed room ' + code + '.');
        return;
      }
      snap = s; render();
      if (s.phase === 'ended' && stream) { stream.close(); stream = null; connBanner('live'); }
    },
    onStatus: (st, err) => {
      const c = err && err.code;
      connBanner(st, c);
      if (st === 'fatal' && !(snap && snap.phase === 'ended')) {
        if (TERMINAL_ROOM.has(c) || TERMINAL_SEAT.has(c)) clearCredential('display', code, isSim);
        stream = null;
        connBanner('live');
        noAccess(describeError(c));
      }
    },
  });
  // After the game ends the stream is closed and dropped (final scores stay on screen), so a
  // later hide/show must not try to reconnect it.
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && document.body.dataset.conn !== 'live' && stream) stream.kick(); });
})();
