// Category labels shared by TV, host and player views. Cards stay on the server.
export const WHO_AM_I_CATEGORIES = [
  {
    "id": "mixed",
    "label": "Mixed bag",
    "ar": "كل الفئات",
    "count": 360
  },
  {
    "id": "anime",
    "label": "Anime characters",
    "ar": "شخصيات أنمي",
    "count": 48
  },
  {
    "id": "history",
    "label": "Historical figures",
    "ar": "شخصيات تاريخية",
    "count": 48
  },
  {
    "id": "gaming",
    "label": "Video game characters",
    "ar": "شخصيات ألعاب الفيديو",
    "count": 48
  },
  {
    "id": "characters",
    "label": "Films & cartoons",
    "ar": "أفلام وكرتون",
    "count": 24
  },
  {
    "id": "celebrities",
    "label": "Famous people",
    "ar": "شخصيات مشهورة",
    "count": 24
  },
  {
    "id": "football",
    "label": "Footballers",
    "ar": "لاعبو كرة القدم",
    "count": 24
  },
  {
    "id": "animals",
    "label": "Animals",
    "ar": "حيوانات",
    "count": 24
  },
  {
    "id": "food",
    "label": "Food & drinks",
    "ar": "أكل ومشروبات",
    "count": 24
  },
  {
    "id": "jobs",
    "label": "Jobs",
    "ar": "مهن",
    "count": 24
  },
  {
    "id": "objects",
    "label": "Everyday objects",
    "ar": "أشياء يومية",
    "count": 24
  },
  {
    "id": "places",
    "label": "Places",
    "ar": "أماكن",
    "count": 24
  },
  {
    "id": "nature",
    "label": "Nature",
    "ar": "طبيعة",
    "count": 24
  }
];
export const whoAmICategoryName = id => (WHO_AM_I_CATEGORIES.find(c => c.id === id) || WHO_AM_I_CATEGORIES[0]).label;
