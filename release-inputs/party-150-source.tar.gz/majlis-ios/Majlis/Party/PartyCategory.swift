import Foundation
struct PartyCategory: Identifiable {
    let id: String
    let label: String
    let pool: Int
    static let feud: [PartyCategory] = [
        PartyCategory(id:"mixed",label:"Mixed bag",pool:200),
        PartyCategory(id:"naruto",label:"Naruto",pool:50),
        PartyCategory(id:"one_piece",label:"One Piece",pool:50),
        PartyCategory(id:"minecraft",label:"Minecraft",pool:50),
        PartyCategory(id:"uae_places",label:"UAE places",pool:50),
        PartyCategory(id:"pokemon",label:"Pokémon",pool:50),
        PartyCategory(id:"dragon_ball",label:"Dragon Ball",pool:50),
        PartyCategory(id:"marvel",label:"Marvel",pool:50),
        PartyCategory(id:"star_wars",label:"Star Wars",pool:50),
        PartyCategory(id:"anime",label:"Anime",pool:200),
        PartyCategory(id:"games",label:"Games",pool:130),
        PartyCategory(id:"places",label:"Places",pool:80),
        PartyCategory(id:"entertainment",label:"Media",pool:150),
        PartyCategory(id:"food",label:"Food & drink",pool:50),
        PartyCategory(id:"home",label:"Home & family",pool:50),
        PartyCategory(id:"everyday",label:"Everyday life",pool:50),
        PartyCategory(id:"travel",label:"Travel & holidays",pool:60),
        PartyCategory(id:"nature",label:"Animals & nature",pool:50),
        PartyCategory(id:"work_school",label:"School & work",pool:50),
        PartyCategory(id:"sports_games",label:"Sports & games",pool:60),
        PartyCategory(id:"technology",label:"Technology",pool:50),
        PartyCategory(id:"uae",label:"UAE & majlis",pool:60),
    ]
    static let who: [PartyCategory] = [
        PartyCategory(id:"mixed",label:"Mixed bag",pool:360),
        PartyCategory(id:"anime",label:"Anime characters",pool:48),
        PartyCategory(id:"history",label:"Historical figures",pool:48),
        PartyCategory(id:"gaming",label:"Video game characters",pool:48),
        PartyCategory(id:"characters",label:"Films & cartoons",pool:24),
        PartyCategory(id:"celebrities",label:"Famous people",pool:24),
        PartyCategory(id:"football",label:"Footballers",pool:24),
        PartyCategory(id:"animals",label:"Animals",pool:24),
        PartyCategory(id:"food",label:"Food & drinks",pool:24),
        PartyCategory(id:"jobs",label:"Jobs",pool:24),
        PartyCategory(id:"objects",label:"Everyday objects",pool:24),
        PartyCategory(id:"places",label:"Places",pool:24),
        PartyCategory(id:"nature",label:"Nature",pool:24),
    ]
}
