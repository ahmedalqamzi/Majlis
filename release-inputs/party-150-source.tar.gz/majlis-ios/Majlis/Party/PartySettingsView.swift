import SwiftUI

struct PartySettingsView: View {
    let snapshot: [String: Any]
    let saving: Bool
    let save: ([String: Any], String?) -> Void
    @Environment(\.dismiss) private var dismiss
    @State private var everyone: Bool
    @State private var teams: Bool
    @State private var seconds: Int
    @State private var rounds: Int
    @State private var hints: Bool
    @State private var category: String
    @State private var assignments: [String: String]
    private var mode: String { snapshot["mode"] as? String ?? "" }
    private var categories: [PartyCategory] { mode == "feud" ? PartyCategory.feud : PartyCategory.who }
    init(snapshot: [String: Any], saving: Bool, save: @escaping ([String: Any], String?) -> Void) {
        self.snapshot=snapshot;self.saving=saving;self.save=save
        let s=snapshot["settings"] as? [String: Any] ?? [:]
        _everyone=State(initialValue:s["everyonePlays"] as? Bool ?? true)
        _teams=State(initialValue:s["feudTeams"] as? Bool ?? true)
        _seconds=State(initialValue:s["feudSeconds"] as? Int ?? 20)
        _rounds=State(initialValue:s["whoRounds"] as? Int ?? 3)
        _hints=State(initialValue:s["impostorHints"] as? Bool ?? true)
        _category=State(initialValue:snapshot[Self.modeKey(snapshot)] as? String ?? "mixed")
        _assignments=State(initialValue:snapshot["teamAssignments"] as? [String:String] ?? [:])
    }
    private static func modeKey(_ snapshot:[String:Any]) -> String { snapshot["mode"] as? String == "feud" ? "feudCategory" : "whoAmICategory" }
    var body: some View {
        NavigationStack {
            Form {
                Section("Who runs the game?") {
                    Picker("Play style",selection:$everyone) { Text("Everyone plays").tag(true);Text("With a host").tag(false) }.pickerStyle(.segmented)
                    Text(everyone ? "Turns, judging and scoring are automatic. Players use their phones." : "A host can judge spoken answers and run the board.").font(.footnote)
                }
                if mode == "feud" || mode == "who_am_i" {
                    Section("Category") {
                        Picker("Topic",selection:$category) { ForEach(categories) { c in Text(c.label).tag(c.id) } }
                        if mode == "feud" { Text("\(categories.first(where:{$0.id == category})?.pool ?? 200)-question pool. 10 questions per game. Boards have 6–8 house answers.").font(.footnote) }
                    }
                }
                if mode == "feud" {
                    Section("Who scores together?") {
                        Picker("Scoring",selection:$teams) { Text("Two teams").tag(true);Text("Free-for-all").tag(false) }.pickerStyle(.segmented)
                        Text(teams ? "Red vs Blue. Teammates share points and take turns." : "Each player competes for their own score.").font(.footnote)
                    }
                    Section("Time per answer") {
                        Picker("Answer timer",selection:$seconds) { ForEach([0,10,20,30,45,60],id:\.self) { n in Text(n == 0 ? "Off" : "\(n) seconds").tag(n) } }
                        Text("The countdown starts after a buzz. Each answer gets a fresh clock.").font(.footnote)
                    }
                    if teams {
                        let players=snapshot["players"] as? [[String:Any]] ?? []
                        Section("Set your teams") {
                            ForEach(players.indices,id:\.self) { i in
                                if let id=players[i]["id"] as? String {
                                    Picker(players[i]["name"] as? String ?? "Player",selection:Binding(get:{assignments[id] ?? "auto"},set:{v in if v == "auto" { assignments.removeValue(forKey:id) } else { assignments[id]=v }})) {
                                        Text("Auto").tag("auto");Text("Red").tag("A");Text("Blue").tag("B")
                                    }
                                }
                            }
                            Text("Auto balances unassigned players when you start. Players can also choose on their phones.").font(.footnote)
                        }
                    }
                }
                if mode == "who_am_i" {
                    Section("Rounds") { Stepper("\(rounds) rounds",value:$rounds,in:1...10) }
                }
                if mode == "impostor" { Section("Clues") { Toggle("Give the impostor a hint",isOn:$hints) } }
                Section {
                    Button(saving ? "Saving…" : "Save settings") {
                        let p:[String:Any] = ["everyonePlays":everyone,"feudTeams":teams,"feudSeconds":seconds,"whoRounds":rounds,"impostorHints":hints,"teamAssignments":assignments]
                        save(p,(mode == "feud" || mode == "who_am_i") ? category : nil)
                    }.disabled(saving).font(.headline)
                }
            }
            .navigationTitle("Game settings")
            .toolbar { ToolbarItem(placement:.cancellationAction) { Button("Cancel") { dismiss() }.disabled(saving) } }
            .interactiveDismissDisabled(saving)
        }
    }
}
